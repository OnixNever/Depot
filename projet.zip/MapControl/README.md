# Map Control 1.1.0

Ancien Switcher (0.6.0), rebaptisé : la carte et les zones sont maintenant la fonctionnalité principale.
Switcher devient un module (tuiles DNS, Auto Blocker, tuiles apprises par le scanner) et les zones s'ajoutent à côté.

## Nouveautés 1.1.0

- Nouvelle icône : une épingle posée sur une zone verte, sur un fond de carte (avec version monochrome pour les icônes thématiques d'Android 13+).
- Réglages d'une zone **repliables** : replié, un réglage n'affiche que son titre et « Entrée : … · Sortie : … ». Boutons « Tout replier / Tout déplier ». Un nouveau réglage s'ouvre tout seul ; avec plus de 2 réglages, l'éditeur s'ouvre replié.
- Tracé plus fluide : tous les points intermédiaires du doigt sont pris en compte, trait lissé en direct, aperçu de la zone qui se remplit pendant que tu dessines, contour final fidèle au tracé (jusqu'à 60 points), déplacement des points blancs sans à-coups.

## Carte et zones

- **Carte OpenStreetMap** (osmdroid, aucune clé). Bouton de fond : Plan / Satellite (Esri) / Relief.
- **Nouvelle zone** : tu entoures l'endroit avec un doigt (deux doigts = zoom et déplacement, même en mode dessin).
  Le tracé est simplifié en points blancs que tu peux **glisser pour corriger**. « Redessiner » efface tout. Tu choisis une couleur puis « Valider ».
- **Réglages de la zone** : pour chaque réglage, valeur à l'entrée, et à la sortie « revenir à l'état d'avant » (valeur sauvegardée à l'entrée),
  « appliquer une valeur » ou « ne rien changer ». Bouton **Tester** entrée / sortie.
- **Interrupteur principal** (appli + tuile « Zones ») : les zones ne tournent que si cet interrupteur ET le GPS du téléphone sont allumés.
  Les autres tuiles marchent toujours.
- **Journal** des entrées/sorties et de chaque réglage (✓ réussi, ✗ refusé avec la raison) sur l'accueil.

### Catalogue de réglages
- Son : mode de sonnerie, Ne pas déranger, volumes (sonnerie, notifications, système, média, alarmes, appels), vibrations, sons du toucher…
- Affichage : luminosité (+ auto), mise en veille, rotation, taille du texte, animations.
- Réseau : DNS privé (désactivé / automatique / serveur perso).
- Système : économiseur de batterie, écran allumé en charge, débogage USB, pressions à l'écran.
- Applis et messages : envoyer une notification, ouvrir une appli.
- Tes actions : n'importe quelle tuile « réglage on/off » créée avec le scanner, et un **réglage Android libre** (table, nom, valeur).
- **Via Shizuku (doit tourner à ce moment-là)** : Wi-Fi, Bluetooth, données mobiles, NFC, mode avion, mode sombre. Android interdit ces réglages à une appli normale.

### Autorisations (écran ⚙ de la carte)
- Position + « tout le temps », notifications, Ne pas déranger (pour sonnerie/volumes), « Modifier les réglages » (Shizuku, **une seule fois**, comme Switcher).
- Nouvel identifiant d'appli (`com.mapcontrol.app`) : l'ancien Switcher reste installé à côté ; refais l'autorisation Shizuku une fois pour Map Control, puis tu peux désinstaller Switcher.

### Fonctionnement et limites
- Service au premier plan (notification « Map Control » avec bouton Arrêter), relancé au démarrage du téléphone si l'interrupteur est allumé.
- Les relevés s'espacent quand tu es loin des zones (économie de batterie) et se rapprochent à moins de 300 m.
- Une entrée ou sortie est validée après **2 relevés consécutifs** ; la sortie demande d'être dehors d'au moins 10 m (anti-allers-retours au bord). Relevés à plus de 100 m d'erreur ignorés.
- Zones qui se chevauchent : les sorties sont traitées avant les entrées ; la restauration remet la valeur vue juste avant l'entrée.
- Auto Blocker demande ton schéma à chaque bascule : il reste une tuile, il ne peut pas être automatisé par zone.
- Éteindre l'interrupteur ne remet pas les réglages en place (il arrête simplement la surveillance).
- « Ouvrir une appli » depuis l'arrière-plan : Android le bloque sauf avec « Afficher par-dessus d'autres applis », sinon une notification à toucher est envoyée.

---

# Ancienne documentation Switcher

# Map Control 0.6.0

## Horaires d'activation (facultatif)

Chaque zone peut avoir un horaire : jours de la semaine cochés + plage horaire (ou « toute la journée »).
- Par défaut : pas d'horaire, la zone est active tout le temps.
- Hors créneau, la zone est ignorée (grisée sur la carte, « hors créneau » dans son résumé).
- Fin de créneau pendant que tu es dedans : la sortie est appliquée normalement (retour à l'état d'avant ou réglage de sortie).
- Début de créneau pendant que tu es dedans : l'entrée est appliquée (vérification chaque minute, même sans bouger).
- Plage qui passe minuit (ex. 22:00 → 06:00) : elle compte pour le jour où elle commence.

## Autorisation (une seule fois)
Depuis l'appli, section « Personnaliser » de la carte DNS : suivre les 4 étapes (Shizuku).
Shizuku ne sert qu'à accorder WRITE_SECURE_SETTINGS ; ensuite l'autorisation reste, même après
redémarrage, et Shizuku peut être arrêté. À refaire seulement si l'appli est désinstallée puis réinstallée.
Alternative avec PC : adb shell pm grant com.mapcontrol.app android.permission.WRITE_SECURE_SETTINGS

## Changer l'icône de l'appli
- Fond : app/src/main/res/values/colors.xml (ic_launcher_background)
- Motif : remplacer app/src/main/res/drawable/ic_launcher_foreground.xml (vecteur 108x108, motif dans la zone centrale 66x66)
- Ou PNG : ic_launcher.png dans les mipmap-*dpi, et supprimer mipmap-anydpi/ic_launcher.xml

## Ajouter une nouvelle tuile
1. modules/MonModule.kt : implémenter SwitchModule
2. core/Modules.kt : l'ajouter à la liste `all`
3. tiles/MonTileService.kt : 3 lignes (voir DnsTileService.kt)
4. AndroidManifest.xml : copier le bloc <service> de DnsTileService

## Créer une action depuis l'appli (nouveau en 0.3.0)
1. Accueil → « Scanner une nouvelle action » → « Scanner les actions » (photo de tous les réglages).
2. « Ouvrir les Paramètres », change UNE chose, reviens, « J'ai changé le réglage ».
3. Coche les réglages détectés (les interrupteurs 0/1 sont en haut), nomme, choisis l'icône, « Tester », « Créer la tuile ».
4. Android 13+ : la demande « Ajouter la tuile ? » s'affiche toute seule. Sinon : panneau → ✎ → glisser « Map Control N ».

Limites importantes :
- Le scanner ne détecte que les changements visibles dans les tables Android Global / Secure / System. Il ne peut pas apprendre automatiquement toutes les commandes Android.
- Wi-Fi, Bluetooth, données mobiles, mode avion complet, hotspot et plusieurs fonctions constructeur sont gérés par des services système : une tuile générique ne peut pas forcément les commander. Il faut un module dédié, une API officielle ou un accès système explicitement autorisé.
- Le Bloqueur automatique Samsung n'est pas confirmé comme un réglage de `Settings.Global`, `Settings.Secure` ou `Settings.System`. Cette version filtre les faux positifs, mais ne prétend pas activer/désactiver Auto Blocker. Il faut une interface Samsung officiellement accessible ou une méthode propre au modèle/à la version One UI.
- Une écriture de réglage n'implique pas que la fonction correspondante ait changé. Depuis cette version, Map Control relit la valeur après l'écriture et signale un échec si la valeur demandée n'a pas été enregistrée. Cela confirme la valeur stockée, pas nécessairement l'effet réel dans l'interface Android.
- Certains réglages sont protégés ou réservés au système. Map Control ne tente pas de contourner ces restrictions.
- 12 actions maximum (12 emplacements de tuiles déclarés dans le manifeste : Slot1Tile…Slot12Tile).
- Les actions apprises sont stockées dans SharedPreferences « switcher_actions » (JSON).

## Tuile « ouvrir un écran » (nouveau en 0.4.0)
Pour les réglages qu'Android ne laisse pas modifier à une appli (ex. Auto Blocker de Samsung), une tuile peut
ouvrir directement la page concernée : Accueil → « Tuile qui ouvre un écran ».
- « Raccourcis sûrs » : pages standard Android (Sécurité et confidentialité, Sources inconnues…), toujours disponibles.
- « Chercher l'écran exact » : liste les écrans des applis de Réglages Samsung dont le nom contient un mot (ex. « blocker »),
  avec « Tester » avant de créer la tuile. Les écrans marqués « non exporté » ne peuvent normalement pas être ouverts de l'extérieur.
- La tuile ne change aucun réglage : Samsung demande lui-même une authentification pour désactiver Auto Blocker.
- Nécessite la permission QUERY_ALL_PACKAGES (uniquement pour lister les écrans).

## Sonde Shizuku (0.4.1, page ouverte corrigée en 0.4.2)
Outil de LECTURE uniquement, pour savoir où un réglage « protégé » (ex. Auto Blocker) est réellement stocké ou affiché :
1. Rapport : cherche « blocker / knox / guard » dans les réglages, propriétés système et paquets.
2. Photos A/B : enregistre l'état avec Auto Blocker activé, puis désactivé, et affiche seulement les différences.
3. Page ouverte : après 10 s, relève l'écran et le fragment affichés (ouvre la page Auto Blocker pendant le compte à rebours).
Rien n'est modifié sur le téléphone.

4. Enregistrement automatique (0.4.3) : une photo toutes les 2 s pendant 60 s ; compare les photos successives et n'affiche que les changements (utile quand Shizuku se coupe en basculant Auto Blocker).

## 0.4.4 : Auto Blocker trouvé
La sonde a révélé qu'Auto Blocker est l'appli Samsung « com.samsung.android.rampart », écran
com.samsung.android.rampart.ui.MainSettingActivity. Un raccourci « Auto Blocker » est maintenant dans « Raccourcis sûrs »
(Accueil → Tuile qui ouvre un écran), et la recherche d'écran trouve aussi les paquets dont le nom contient le mot cherché
(ex. « rampart »). La tuile ouvre seulement la page : c'est toi qui touches le bouton et valides ton schéma.

## 0.4.5 : sonde étendue à rampart
Le rapport et l'enregistrement automatique de la sonde incluent maintenant l'appli Auto Blocker (com.samsung.android.rampart) :
écrans, services, récepteurs, fournisseurs, permissions, et (si Shizuku peut les lire) ses préférences. Objectif : trouver
une action interne que la tuile pourrait envoyer pour déclencher la bascule (Samsung demande alors lui-même l'authentification).
Tout reste en LECTURE seule.

## 0.5.0 : clic automatique sur Auto Blocker (service d'accessibilité)
Shizuku se coupe dès qu'Auto Blocker bascule, donc la tuile ne peut pas compter dessus. Nouveau : un service d'accessibilité
(AutoClickService), limité à l'appli com.samsung.android.rampart (voir res/xml/accessibility_service_config.xml).
1. Active-le une fois : Paramètres → Accessibilité → Applications installées → « Map Control : interrupteur Auto Blocker ».
   Si Android grise l'option : Paramètres → Applis → Map Control → ⋮ → « Autoriser les paramètres restreints », puis recommence.
2. Dans Map Control : « Tuile qui ouvre un écran » → coche « La tuile appuie aussi sur l'interrupteur » → crée la tuile Auto Blocker
   (ou, sur une action existante : Personnaliser → « Appuyer aussi sur l'interrupteur »).
3. Au clic sur la tuile : la page s'ouvre, le service trouve l'interrupteur et appuie dessus UNE fois (fenêtre de 12 s).
   Samsung demande encore ton schéma / empreinte pour désactiver : tu valides toi-même.
Test et diagnostic : la carte « Clic automatique sur Auto Blocker » (écran de la tuile qui ouvre un écran) a un bouton « Tester le clic »,
affiche le résultat, et « Copier l'arbre de l'écran » si l'interrupteur n'est pas trouvé.
Tout le reste est inchangé ; Shizuku n'est pas nécessaire pour cette fonction.

## 0.6.0 : version complète, tout réorganisé
**Accueil** : carte « À configurer » (autorisation Shizuku + service d'accessibilité, repliée quand tout est prêt), puis « Mes tuiles »
(modules intégrés + tuiles créées, mêmes cartes), bouton « ＋ Ajouter une tuile », « Modules supprimés » (rétablissables) et « Outils ».
**Ajouter une tuile** : un seul point d'entrée, deux choix : « Un réglage on/off » (scanner) ou « Une page des Paramètres ».

**Auto Blocker est maintenant un module intégré**, comme le DNS : carte « Auto Blocker » sur l'accueil, tuile « Auto Blocker » dans l'éditeur
du panneau. Un tap : la page s'ouvre une seconde, le service appuie sur l'interrupteur, tu valides ton schéma / empreinte, et la page se
referme toute seule (réglable dans Personnaliser). La tuile affiche « Activé / Désactivé » : le service relit l'interrupteur à chaque fois que
tu ouvres la page. Si tu annules la validation, la page reste ouverte (délai de 25 s).

**Supprimer un module intégré** : Personnaliser → « Supprimer ce module ». Sa tuile disparaît du panneau ; « Modules supprimés » → « Rétablir ».

### Ajouter un nouveau module intégré
1. modules/MonModule.kt : implémenter SwitchModule (id, defaultTitle, defaultIcon, description, tileService, isReady, current, toggle).
   Pour ouvrir une page à la place d'un toggle : redéfinir tileClick (voir AutoBlockerModule).
2. core/Modules.kt : l'ajouter à la liste `all`.
3. tiles/MonTileService.kt : 3 lignes (voir DnsTileService.kt).
4. AndroidManifest.xml : copier le bloc <service> de DnsTileService (il sera activé / désactivé automatiquement avec le module).

### Cliquer sur l'interrupteur d'une autre page
core/ClickTargets.kt : une ligne dans `all` (id, paquet de l'appli, mots-clés du libellé). Le service apprend le paquet tout seul et ne voit
aucune autre appli que celles de cette liste. Pour l'utiliser : un module (comme AutoBlockerModule) ou l'option « Appuyer aussi sur
l'interrupteur » d'une tuile « page des Paramètres » dont l'écran appartient à une cible connue.
