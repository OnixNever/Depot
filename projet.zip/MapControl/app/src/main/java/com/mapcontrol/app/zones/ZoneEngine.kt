package com.mapcontrol.app.zones

import android.content.Context

/** Applique les réglages d'une zone à l'entrée et à la sortie. À appeler hors du thread principal. */
object ZoneEngine {

    /**
     * [track] = false pour un simple test depuis l'éditeur : l'état « dedans » n'est pas modifié
     * et les valeurs d'avant sont mémorisées à part.
     * Renvoie une ligne par réglage (✓ ou ✗).
     */
    fun enter(ctx: Context, zone: Zone, track: Boolean = true): List<String> {
        val key = if (track) zone.id else "test_" + zone.id
        if (track) ZoneStore.setInside(ctx, zone.id, true)
        val lines = ArrayList<String>()
        for (a in zone.actions) {
            val value = a.enter ?: continue
            val t = ZoneCatalog.byId(a.type)
            if (t == null) { lines += "✗ Réglage inconnu : ${a.type}"; continue }
            ZoneStore.savePrev(ctx, key, a.id, runCatching { t.read(ctx, a.param) }.getOrNull())
            val r = t.doApply(ctx, value, a.param)
            lines += line(ctx, t, value, a.param, r)
        }
        if (lines.isEmpty()) lines += "Aucun réglage à appliquer à l'entrée."
        ZoneStore.log(ctx, (if (track) "Entrée" else "Test d'entrée") + " : ${zone.name}\n" + lines.joinToString("\n"))
        return lines
    }

    fun exit(ctx: Context, zone: Zone, track: Boolean = true): List<String> {
        val key = if (track) zone.id else "test_" + zone.id
        if (track) ZoneStore.setInside(ctx, zone.id, false)
        val lines = ArrayList<String>()
        for (a in zone.actions) {
            val t = ZoneCatalog.byId(a.type)
            if (t == null) { ZoneStore.takePrev(ctx, key, a.id); continue }
            when (a.exitMode) {
                ExitMode.NOTHING -> ZoneStore.takePrev(ctx, key, a.id)
                ExitMode.SET -> {
                    ZoneStore.takePrev(ctx, key, a.id)
                    val v = a.exit ?: continue
                    lines += line(ctx, t, v, a.param, t.doApply(ctx, v, a.param))
                }
                ExitMode.RESTORE -> {
                    val prev = ZoneStore.takePrev(ctx, key, a.id) ?: continue
                    val v = prev.first
                    if (v == null && !t.nullRestorable) continue
                    lines += "↩ " + line(ctx, t, v, a.param, t.doApply(ctx, v, a.param))
                }
            }
        }
        if (lines.isEmpty()) lines += "Aucun réglage à appliquer à la sortie."
        ZoneStore.log(ctx, (if (track) "Sortie" else "Test de sortie") + " : ${zone.name}\n" + lines.joinToString("\n"))
        return lines
    }

    /** Une zone supprimée ou désactivée pendant qu'on était dedans : on oublie l'état sans rien toucher. */
    fun forget(ctx: Context, zoneId: String) {
        ZoneStore.setInside(ctx, zoneId, false)
        ZoneStore.clearPrev(ctx, zoneId)
    }

    private fun line(ctx: Context, t: ZoneActionType, value: String?, param: String?, r: Result<Unit>): String {
        val what = "${t.title} → ${t.describe(ctx, value, param)}"
        return r.fold(
            onSuccess = { "✓ $what" },
            onFailure = { "✗ $what (${it.message ?: it.javaClass.simpleName})" },
        )
    }
}
