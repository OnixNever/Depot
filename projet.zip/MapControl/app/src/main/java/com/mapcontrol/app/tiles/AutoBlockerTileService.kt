package com.mapcontrol.app.tiles

import com.mapcontrol.app.core.SwitchModule
import com.mapcontrol.app.modules.AutoBlockerModule

class AutoBlockerTileService : BaseTileService() {
    override val module: SwitchModule = AutoBlockerModule
}
