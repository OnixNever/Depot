package com.mapcontrol.app.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.PointF
import android.view.MotionEvent
import com.mapcontrol.app.zones.Geo
import com.mapcontrol.app.zones.GeoPt
import com.mapcontrol.app.zones.Zone
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.Projection
import org.osmdroid.views.overlay.Overlay
import kotlin.math.hypot

/**
 * Couche unique posée sur la carte : dessine les zones, le tracé au doigt et les poignées de correction,
 * et gère les gestes quand on dessine ou corrige. En mode VIEW elle laisse la carte réagir normalement.
 * Avec deux doigts, la carte zoome / se déplace même en mode dessin.
 *
 * Fluidité du tracé : tous les points intermédiaires fournis par Android entre deux images sont utilisés,
 * le trait est lissé en direct (filtre + courbes), l'aperçu de la zone se remplit pendant qu'on dessine,
 * et le redessin est limité à une fois par image.
 */
class ZonesOverlay(private val density: Float) : Overlay() {
    enum class Mode { VIEW, DRAW, EDIT }

    var mode = Mode.VIEW
    var zones: List<Zone> = emptyList()
    var selectedId: String? = null
    /** Zone dont on corrige le tracé : son ancien contour n'est plus dessiné (c'est [polygon] qui le remplace). */
    var editingId: String? = null
    var drawColor: Int = 0xFF1F6FEB.toInt()
    val polygon = ArrayList<GeoPt>()
    var me: GeoPt? = null

    var onTap: (String?) -> Unit = {}
    var onDrawn: () -> Unit = {}
    var onShapeChanged: () -> Unit = {}

    private val stroke = ArrayList<PointF>()
    private var dragIndex = -1
    private var dragDx = 0f
    private var dragDy = 0f
    private val scratch = Point()
    private val path = Path()
    private val closedPath = Path()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFFFFFFF.toInt() }
    private val handleLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF222222.toInt(); strokeWidth = 2f * density }
    private val textFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = 14f * density; textAlign = Paint.Align.CENTER }
    private val textHalo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC000000.toInt(); textSize = 14f * density; textAlign = Paint.Align.CENTER
        style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFF1A73E8.toInt() }

    // ---------------- dessin ----------------
    override fun draw(canvas: Canvas, projection: Projection) {
        for (z in zones) {
            if (z.id == editingId || z.points.size < 3) continue
            drawPolygon(canvas, projection, z.points, z.color, z.id == selectedId, !z.activeNow(), z.name)
        }
        if (mode != Mode.VIEW) {
            if (polygon.size >= 3) drawPolygon(canvas, projection, polygon, drawColor, true, false, null)
            if (mode == Mode.EDIT) {
                val r = (if (polygon.size > 30) 6f else 9f) * density
                for (p in polygon) {
                    projection.toPixels(GeoPoint(p.lat, p.lon), scratch)
                    canvas.drawCircle(scratch.x.toFloat(), scratch.y.toFloat(), r, handleFill)
                    canvas.drawCircle(scratch.x.toFloat(), scratch.y.toFloat(), r, handleLine)
                }
            }
            if (stroke.size > 1) drawStroke(canvas)
        }
        me?.let { m ->
            projection.toPixels(GeoPoint(m.lat, m.lon), scratch)
            canvas.drawCircle(scratch.x.toFloat(), scratch.y.toFloat(), 10f * density, handleFill)
            canvas.drawCircle(scratch.x.toFloat(), scratch.y.toFloat(), 7f * density, dot)
        }
    }

    /** Trait en cours : courbe lisse + aperçu de la zone qui se remplit au fur et à mesure. */
    private fun drawStroke(c: Canvas) {
        path.reset()
        path.moveTo(stroke[0].x, stroke[0].y)
        for (i in 1 until stroke.size - 1) {
            val mx = (stroke[i].x + stroke[i + 1].x) / 2f
            val my = (stroke[i].y + stroke[i + 1].y) / 2f
            path.quadTo(stroke[i].x, stroke[i].y, mx, my)
        }
        val last = stroke[stroke.size - 1]
        path.lineTo(last.x, last.y)

        closedPath.set(path)
        closedPath.close()
        fill.color = (drawColor and 0x00FFFFFF) or (0x33 shl 24)
        c.drawPath(closedPath, fill)

        line.color = drawColor
        line.strokeWidth = 4f * density
        c.drawPath(path, line)
    }

    private fun drawPolygon(c: Canvas, proj: Projection, pts: List<GeoPt>, color: Int, selected: Boolean, dim: Boolean, label: String?) {
        path.reset()
        var sx = 0f
        var sy = 0f
        pts.forEachIndexed { i, p ->
            proj.toPixels(GeoPoint(p.lat, p.lon), scratch)
            val x = scratch.x.toFloat(); val y = scratch.y.toFloat()
            sx += x; sy += y
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        val alpha = if (dim) 0x18 else if (selected) 0x66 else 0x44
        fill.color = (color and 0x00FFFFFF) or (alpha shl 24)
        c.drawPath(path, fill)
        line.color = color
        line.strokeWidth = (if (selected) 4f else 2.5f) * density
        c.drawPath(path, line)
        if (label != null) {
            val cx = sx / pts.size; val cy = sy / pts.size
            c.drawText(label, cx, cy, textHalo)
            c.drawText(label, cx, cy, textFill)
        }
    }

    // ---------------- gestes ----------------
    override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
        if (mode != Mode.VIEW) return false
        val g = mapView.projection.fromPixels(e.x.toInt(), e.y.toInt())
        val pt = GeoPt(g.latitude, g.longitude)
        val hit = zones.lastOrNull { it.points.size >= 3 && Geo.contains(it.points, pt) }
        onTap(hit?.id)
        return hit != null
    }

    override fun onTouchEvent(e: MotionEvent, mapView: MapView): Boolean {
        if (mode == Mode.VIEW) return false
        // Deux doigts : on abandonne le geste en cours et on laisse la carte zoomer / se déplacer.
        if (e.pointerCount > 1) {
            stroke.clear(); dragIndex = -1; mapView.postInvalidateOnAnimation()
            return false
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (mode == Mode.DRAW) {
                    stroke.clear()
                    stroke.add(PointF(e.x, e.y))
                    return true
                }
                dragIndex = nearestVertex(e.x, e.y, mapView.projection)
                return dragIndex >= 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == Mode.DRAW && stroke.isNotEmpty()) {
                    // Android regroupe plusieurs positions entre deux images : on les utilise toutes.
                    for (h in 0 until e.historySize) addStrokePoint(e.getHistoricalX(h), e.getHistoricalY(h))
                    addStrokePoint(e.x, e.y)
                    mapView.postInvalidateOnAnimation()
                    return true
                }
                if (mode == Mode.EDIT && dragIndex >= 0) {
                    val g = mapView.projection.fromPixels((e.x + dragDx).toInt(), (e.y + dragDy).toInt())
                    polygon[dragIndex] = GeoPt(g.latitude, g.longitude)
                    mapView.postInvalidateOnAnimation()
                    onShapeChanged()
                    return true
                }
                return false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val consumed = (mode == Mode.DRAW && stroke.isNotEmpty()) || dragIndex >= 0
                if (mode == Mode.DRAW && stroke.size > 5 && e.actionMasked == MotionEvent.ACTION_UP) finishStroke(mapView)
                stroke.clear()
                dragIndex = -1
                mapView.postInvalidateOnAnimation()
                return consumed
            }
        }
        return false
    }

    /** Ajoute un point en le lissant légèrement (filtre) et en ignorant les micro-mouvements. */
    private fun addStrokePoint(x: Float, y: Float) {
        val last = stroke[stroke.size - 1]
        if (hypot(x - last.x, y - last.y) < 1.5f * density) return
        stroke.add(PointF(last.x + (x - last.x) * 0.6f, last.y + (y - last.y) * 0.6f))
    }

    /** Poignée la plus proche du doigt ; retient l'écart pour que le point ne « saute » pas sous le doigt. */
    private fun nearestVertex(x: Float, y: Float, proj: Projection): Int {
        val limit = (28f * density) * (28f * density)
        var best = -1
        var bestD = Float.MAX_VALUE
        var bx = 0f
        var by = 0f
        polygon.forEachIndexed { i, p ->
            proj.toPixels(GeoPoint(p.lat, p.lon), scratch)
            val dx = scratch.x - x; val dy = scratch.y - y
            val d = dx * dx + dy * dy
            if (d < limit && d < bestD) { bestD = d; best = i; bx = dx; by = dy }
        }
        dragDx = bx
        dragDy = by
        return best
    }

    /** Moyenne glissante sur 5 points : enlève les tremblements de la main (extrémités conservées). */
    private fun smooth(src: List<PointF>): List<PointF> {
        if (src.size < 5) return src
        val out = ArrayList<PointF>(src.size)
        for (i in src.indices) {
            if (i == 0 || i == src.size - 1) { out.add(src[i]); continue }
            val lo = maxOf(0, i - 2)
            val hi = minOf(src.size - 1, i + 2)
            var sx = 0f
            var sy = 0f
            for (j in lo..hi) { sx += src[j].x; sy += src[j].y }
            val n = (hi - lo + 1).toFloat()
            out.add(PointF(sx / n, sy / n))
        }
        return out
    }

    private fun finishStroke(map: MapView) {
        val proj = map.projection
        val geo = ArrayList<GeoPt>()
        for (p in smooth(smooth(stroke))) {
            val g = proj.fromPixels(p.x.toInt(), p.y.toInt())
            geo.add(GeoPt(g.latitude, g.longitude))
        }
        if (geo.size < 3) return
        // Tolérance d'environ 1,8 pixel : le contour reste fidèle au tracé quel que soit le niveau de zoom.
        val a = proj.fromPixels(0, 0)
        val b = proj.fromPixels(100, 0)
        val metersPerPixel = Geo.distance(GeoPt(a.latitude, a.longitude), GeoPt(b.latitude, b.longitude)) / 100.0
        val simple = Geo.simplifyTo(geo, 60, (1.8 * metersPerPixel).coerceAtLeast(0.3))
        if (simple.size < 3) return
        polygon.clear()
        polygon.addAll(simple)
        onDrawn()
    }
}
