package com.mapcontrol.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mapcontrol.app.core.Perm
import com.mapcontrol.app.core.ShizukuHelper
import rikka.shizuku.Shizuku

/** Assistant d'autorisation (Shizuku -> WRITE_SECURE_SETTINGS), une seule fois. */
@Composable
fun PermissionSetup(onChanged: () -> Unit = {}) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    DisposableEffect(Unit) {
        val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> tick++ }
        val onBinder = Shizuku.OnBinderReceivedListener { tick++ }
        try {
            Shizuku.addRequestPermissionResultListener(onPerm)
            Shizuku.addBinderReceivedListener(onBinder)
        } catch (_: Throwable) {}
        onDispose {
            try {
                Shizuku.removeRequestPermissionResultListener(onPerm)
                Shizuku.removeBinderReceivedListener(onBinder)
            } catch (_: Throwable) {}
        }
    }

    val granted = remember(tick) { Perm.granted(ctx) }
    val installed = remember(tick) { ShizukuHelper.isInstalled(ctx) }
    val running = remember(tick) { ShizukuHelper.isRunning() }
    val allowed = remember(tick) { ShizukuHelper.hasPermission() }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (granted) {
            Text(
                "✓ Autorisation accordée. Shizuku n'est plus nécessaire, tu peux l'arrêter.",
                style = MaterialTheme.typography.bodyMedium,
            )
        } else {
            val step = when { !installed -> 1; !running -> 2; !allowed -> 3; else -> 4 }
            Text(
                "Autorisation à accorder une seule fois (étape $step/4), sans PC",
                style = MaterialTheme.typography.titleSmall,
            )
            when (step) {
                1 -> {
                    Text("Installe Shizuku : il permet à Map Control de s'autoriser lui-même.")
                    Button(onClick = {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${ShizukuHelper.PKG}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text("Télécharger Shizuku") }
                }
                2 -> {
                    Text(
                        "Dans Shizuku, choisis « Démarrer via le débogage sans fil » (Wi-Fi requis). " +
                            "Active le débogage sans fil dans les options pour développeurs, puis " +
                            "« Associer avec un code » et saisis le code dans la notification de Shizuku. " +
                            "Reviens ensuite ici."
                    )
                    Button(onClick = {
                        ctx.packageManager.getLaunchIntentForPackage(ShizukuHelper.PKG)?.let { ctx.startActivity(it) }
                    }) { Text("Ouvrir Shizuku") }
                }
                3 -> {
                    Text("Shizuku est lancé. Autorise Map Control à l'utiliser.")
                    Button(onClick = { ShizukuHelper.requestPermission() }) { Text("Autoriser Map Control") }
                }
                else -> {
                    Text("Dernière étape : accorder l'autorisation de modifier les réglages.")
                    Button(
                        enabled = !busy,
                        onClick = {
                            busy = true; msg = null
                            ShizukuHelper.grantWriteSecureSettings(ctx) { r ->
                                busy = false
                                msg = r.exceptionOrNull()?.let { e -> e.cause?.message ?: e.message ?: "Échec" }
                                tick++
                                onChanged()
                            }
                        },
                    ) { Text(if (busy) "En cours…" else "Accorder l'autorisation") }
                }
            }
            msg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
