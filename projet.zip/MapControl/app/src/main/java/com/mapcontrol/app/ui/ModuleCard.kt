package com.mapcontrol.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.mapcontrol.app.core.IconChoices
import com.mapcontrol.app.core.Modules
import com.mapcontrol.app.core.Prefs
import com.mapcontrol.app.core.SwitchModule

/** Carte d'un module intégré (DNS, Auto Blocker…) : état, bascule, ajout au panneau, nom/icône, suppression. */
@Composable
fun ModuleCard(module: SwitchModule, tick: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf(Prefs.rawTitle(ctx, module)) }

    val title = remember(tick, rev) { Prefs.title(ctx, module) }
    val iconKey = remember(tick, rev) { Prefs.iconKey(ctx, module) }
    val ready = remember(tick, rev) { module.isReady(ctx) }
    val state = remember(tick, rev) { if (ready) module.current(ctx) else null }
    val active = state?.active == true
    val refresh = { Modules.refreshTile(ctx, module); rev++ }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            TileHeader(
                iconRes = IconChoices.res(iconKey),
                title = title,
                status = state?.label ?: "Configuration requise",
                detail = module.description,
                active = active,
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    module.toggle(ctx).onSuccess { message = null }.onFailure { message = it.message }
                    refresh()
                },
                enabled = ready,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Changer") }
            message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

            Row {
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded || !ready) "Masquer" else "Personnaliser") }
                TextButton(onClick = { Modules.requestAdd(ctx, module) { message = it } }) { Text("Ajouter au panneau") }
            }
            AnimatedVisibility(expanded || !ready) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it; Prefs.setTitle(ctx, module, it); refresh() },
                        label = { Text("Nom de la tuile") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(IconChoices.all) { (key, res) ->
                            FilledIconToggleButton(
                                checked = key == iconKey,
                                onCheckedChange = { Prefs.setIcon(ctx, module, key); refresh() },
                            ) { Icon(painterResource(res), contentDescription = key) }
                        }
                    }
                    module.Extra { rev++ }
                    OutlinedButton(onClick = { confirmDelete = true }) { Text("Supprimer ce module") }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer « $title » ?") },
            text = { Text("Sa tuile disparaît du panneau. Tu pourras le rétablir à tout moment depuis l'accueil (« Modules supprimés »).") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    Modules.setRemoved(ctx, module, true)
                    onChanged()
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}
