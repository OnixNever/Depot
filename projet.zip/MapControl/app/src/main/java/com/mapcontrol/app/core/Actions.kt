package com.mapcontrol.app.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Un réglage piloté : valeur à écrire pour « actif » et pour « inactif ». */
data class Entry(val table: String, val name: String, val on: String?, val off: String?)

/** Une action apprise = une tuile. [slot] (1..MAX_SLOTS) désigne la classe TileService qui l'affiche. */
data class SwitchAction(
    val id: String,
    val slot: Int,
    val title: String,
    val icon: String,
    val entries: List<Entry>,
    /** Si non nul : action « ouvrir un écran » (voir ScreenLauncher) au lieu d'une bascule de réglages. */
    val launch: String? = null,
    /** Avec [launch] : le service d'accessibilité appuie aussi sur l'interrupteur de la page ouverte (Auto Blocker). */
    val clickSwitch: Boolean = false,
)

object Actions {
    const val MAX_SLOTS = 12

    private fun sp(c: Context) = c.getSharedPreferences("switcher_actions", Context.MODE_PRIVATE)

    private fun same(a: String?, b: String?) = (a ?: "") == (b ?: "")

    fun all(c: Context): List<SwitchAction> {
        val raw = sp(c).getString("actions", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val es = o.getJSONArray("entries")
                SwitchAction(
                    id = o.getString("id"),
                    slot = o.getInt("slot"),
                    title = o.getString("title"),
                    icon = o.getString("icon"),
                    launch = if (o.has("launch") && !o.isNull("launch")) o.getString("launch") else null,
                    clickSwitch = o.optBoolean("click", false),
                    entries = (0 until es.length()).map { j ->
                        val e = es.getJSONObject(j)
                        Entry(
                            e.getString("table"), e.getString("name"),
                            if (e.isNull("on")) null else e.getString("on"),
                            if (e.isNull("off")) null else e.getString("off"),
                        )
                    },
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun save(c: Context, list: List<SwitchAction>) {
        val arr = JSONArray()
        for (a in list) {
            val es = JSONArray()
            for (e in a.entries) es.put(
                JSONObject()
                    .put("table", e.table).put("name", e.name)
                    .put("on", e.on ?: JSONObject.NULL).put("off", e.off ?: JSONObject.NULL)
            )
            arr.put(
                JSONObject().put("id", a.id).put("slot", a.slot)
                    .put("title", a.title).put("icon", a.icon).put("entries", es)
                    .put("launch", a.launch ?: JSONObject.NULL).put("click", a.clickSwitch)
            )
        }
        sp(c).edit().putString("actions", arr.toString()).apply()
    }

    fun bySlot(c: Context, slot: Int) = all(c).firstOrNull { it.slot == slot }

    fun add(c: Context, title: String, icon: String, entries: List<Entry>, launch: String? = null, clickSwitch: Boolean = false): SwitchAction? {
        val list = all(c)
        val slot = (1..MAX_SLOTS).firstOrNull { s -> list.none { it.slot == s } } ?: return null
        val a = SwitchAction(System.currentTimeMillis().toString(), slot, title, icon, entries, launch, clickSwitch)
        save(c, list + a)
        return a
    }

    fun update(c: Context, a: SwitchAction) = save(c, all(c).map { if (it.id == a.id) a else it })

    fun remove(c: Context, a: SwitchAction) = save(c, all(c).filter { it.id != a.id })

    /** Actif quand tous les réglages ont leur valeur « actif ». */
    fun isActive(c: Context, a: SwitchAction): Boolean =
        a.entries.isNotEmpty() && a.entries.all { same(SettingsScanner.read(c, it.table, it.name), it.on) }

    fun apply(c: Context, a: SwitchAction, on: Boolean): Result<Unit> {
        var failure: Throwable? = null
        for (e in a.entries) {
            SettingsScanner.write(c, e.table, e.name, if (on) e.on else e.off)
                .onFailure { if (failure == null) failure = it }
        }
        return failure?.let { Result.failure(it) } ?: Result.success(Unit)
    }

    /** Bascule : actif -> inactif, sinon -> actif. Renvoie le nouvel état. */
    fun toggle(c: Context, a: SwitchAction): Result<Boolean> {
        if (!Perm.granted(c)) return Result.failure(IllegalStateException("Autorisation manquante"))
        val target = !isActive(c, a)
        return apply(c, a, target).map { target }
    }
}
