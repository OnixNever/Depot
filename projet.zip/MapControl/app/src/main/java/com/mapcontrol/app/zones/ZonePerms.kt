package com.mapcontrol.app.zones

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/** Autorisations propres aux zones (la permission « modifier les réglages » est gérée par core/Perm). */
object ZonePerms {
    private fun has(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun fine(c: Context) = has(c, Manifest.permission.ACCESS_FINE_LOCATION)
    fun background(c: Context) = has(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    fun notifications(c: Context) = Build.VERSION.SDK_INT < 33 || has(c, Manifest.permission.POST_NOTIFICATIONS)
    fun dnd(c: Context) = runCatching { c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }.getOrDefault(false)
    fun overlay(c: Context) = Settings.canDrawOverlays(c)
}
