package com.mapcontrol.app.core

/** Une page d'une autre appli où le service d'accessibilité peut appuyer sur l'interrupteur principal. */
data class ClickTarget(val id: String, val pkg: String, val keywords: List<String>)

/**
 * Registre des pages « cliquables ». Pour en ajouter une : une ligne dans [all].
 * Le service apprend le paquet tout seul (il ne voit AUCUNE autre appli que celles de cette liste).
 */
object ClickTargets {
    val autoBlocker = ClickTarget(
        id = "autoblocker",
        pkg = "com.samsung.android.rampart",
        keywords = listOf("blocker", "bloqueur", "blocage automatique"),
    )

    val all: List<ClickTarget> = listOf(autoBlocker)

    fun byPackage(pkg: String?): ClickTarget? = all.firstOrNull { it.pkg == pkg }

    /** Cible associée à un raccourci d'écran « component:pkg/classe », s'il y en a une. */
    fun forSpec(spec: String): ClickTarget? {
        if (!spec.startsWith("component:")) return null
        return byPackage(spec.removePrefix("component:").substringBefore('/'))
    }
}
