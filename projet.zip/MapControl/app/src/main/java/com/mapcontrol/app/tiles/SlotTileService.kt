package com.mapcontrol.app.tiles

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import com.mapcontrol.app.core.Actions
import com.mapcontrol.app.core.ClickArm
import com.mapcontrol.app.core.ClickTargets
import com.mapcontrol.app.core.IconChoices
import com.mapcontrol.app.core.Perm
import com.mapcontrol.app.core.TileLaunch

/** Tuile pilotée par une action créée dans l'appli (voir Actions). Les sous-classes ne donnent que leur numéro d'emplacement. */
abstract class SlotTileService : TileService() {
    abstract val slot: Int

    override fun onStartListening() = refresh()

    override fun onClick() {
        val action = Actions.bySlot(this, slot)
        val launch = action?.launch
        if (action != null && launch != null) {
            if (action.clickSwitch) {
                val target = ClickTargets.forSpec(launch)
                if (target == null || !ClickArm.armIfReady(this, target)) {
                    Toast.makeText(this, "Active le service d'accessibilité de Map Control pour le clic automatique", Toast.LENGTH_LONG).show()
                }
            }
            if (!TileLaunch.open(this, launch)) {
                Toast.makeText(this, "Écran introuvable sur ce téléphone", Toast.LENGTH_SHORT).show()
                TileLaunch.openApp(this)
            }
            return
        }
        if (action == null || !Perm.granted(this)) { TileLaunch.openApp(this); return }
        Actions.toggle(this, action).onFailure {
            Toast.makeText(this, it.message ?: "Échec", Toast.LENGTH_SHORT).show()
        }
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val action = Actions.bySlot(this, slot)
        if (action == null) {
            tile.label = "Libre"
            tile.subtitle = null
            tile.state = Tile.STATE_UNAVAILABLE
        } else if (action.launch != null) {
            tile.label = action.title
            tile.icon = Icon.createWithResource(this, IconChoices.res(action.icon))
            tile.state = Tile.STATE_INACTIVE
            tile.subtitle = if (action.clickSwitch) "Basculer" else "Ouvrir"
        } else {
            val ready = Perm.granted(this)
            val active = ready && Actions.isActive(this, action)
            tile.label = action.title
            tile.icon = Icon.createWithResource(this, IconChoices.res(action.icon))
            tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            tile.subtitle = when {
                !ready -> "Configuration requise"
                active -> "Activé"
                else -> "Désactivé"
            }
        }
        tile.updateTile()
    }
}
