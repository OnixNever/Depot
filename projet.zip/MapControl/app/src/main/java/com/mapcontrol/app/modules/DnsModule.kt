package com.mapcontrol.app.modules

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mapcontrol.app.core.ModuleState
import com.mapcontrol.app.core.Prefs
import com.mapcontrol.app.core.SwitchModule
import com.mapcontrol.app.tiles.DnsTileService
import com.mapcontrol.app.ui.PermissionSetup

/** Bascule du DNS privé : Désactivé → Automatique → Serveur préconfiguré → Désactivé. */
object DnsModule : SwitchModule {
    override val id = "dns"
    override val defaultTitle = "DNS"
    override val defaultIcon = "globe"
    override val tileService = DnsTileService::class.java
    override val description = "Bascule le DNS privé : désactivé, automatique ou serveur préconfiguré."

    private const val MODE = "private_dns_mode"
    private const val SPEC = "private_dns_specifier"

    private fun hasPermission(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    private fun mode(ctx: Context) = Settings.Global.getString(ctx.contentResolver, MODE) ?: "opportunistic"

    override fun isReady(ctx: Context) = hasPermission(ctx)

    override fun current(ctx: Context): ModuleState = when (mode(ctx)) {
        "off" -> ModuleState("Désactivé", false)
        "hostname" -> ModuleState(
            Settings.Global.getString(ctx.contentResolver, SPEC)?.takeIf { it.isNotBlank() } ?: "Serveur perso", true
        )
        else -> ModuleState("Automatique", true)
    }

    override fun toggle(ctx: Context): Result<ModuleState> = runCatching {
        check(hasPermission(ctx)) { "Autorisation manquante : voir « Personnaliser »." }
        val host = Prefs.dnsHost(ctx)
        val next = when (mode(ctx)) {
            "off" -> "opportunistic"
            "opportunistic" -> if (host.isNotBlank()) "hostname" else "off"
            else -> "off"
        }
        val cr = ctx.contentResolver
        if (next == "hostname") Settings.Global.putString(cr, SPEC, host)
        Settings.Global.putString(cr, MODE, next)
        current(ctx)
    }

    @Composable
    override fun Extra(onChanged: () -> Unit) {
        val ctx = LocalContext.current
        var host by remember { mutableStateOf(Prefs.dnsHost(ctx)) }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = host,
                onValueChange = { host = it.trim(); Prefs.setDnsHost(ctx, host) },
                label = { Text("Serveur DNS préconfiguré") },
                placeholder = { Text("dns.exemple.com") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            PermissionSetup(onChanged)
        }
    }
}
