package com.mapcontrol.app.tiles

import com.mapcontrol.app.core.SwitchModule
import com.mapcontrol.app.modules.DnsModule

class DnsTileService : BaseTileService() {
    override val module: SwitchModule = DnsModule
}
