package com.mapcontrol.app.zones

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import com.mapcontrol.app.MainActivity
import com.mapcontrol.app.R
import com.mapcontrol.app.core.Modules
import com.mapcontrol.app.modules.ZonesModule
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Surveille la position en arrière-plan (service au premier plan, type « position ») et applique les réglages
 * des zones à l'entrée et à la sortie. Le rythme des relevés s'adapte à la distance de la zone la plus proche.
 */
class ZoneService : Service() {

    companion object {
        const val ACTION_STOP = "com.mapcontrol.app.ZONES_STOP"
        private const val NOTIF_ID = 4201
        /** Un relevé plus imprécis que ça (m) est ignoré pour décider d'une entrée/sortie. */
        private const val ACC_MAX = 100.0
        /** Nombre de relevés consécutifs qui doivent confirmer un changement. */
        private const val CONFIRM = 2

        /**
         * Localisation précise (GPS, gourmande) seulement près d'une zone ; sinon localisation approximative
         * (wifi / antennes, quelques dizaines à ~300 m, très économe). Deux seuils différents pour éviter
         * de basculer sans arrêt quand on est pile à la limite.
         * Hors zone : GPS dès qu'on est à moins de APPROCHE_ON du bord, retour à l'approximatif au-delà de APPROCHE_OFF.
         * Dans une zone : GPS seulement près du bord (DEDANS_ON), car il faut détecter la sortie.
         */
        private const val APPROCHE_ON = 800.0
        private const val APPROCHE_OFF = 1300.0
        private const val DEDANS_ON = 250.0
        private const val DEDANS_OFF = 400.0
        /** Au-delà (m) : relevés très espacés. */
        private const val LOIN = 5000.0

        fun start(ctx: Context) { ctx.startForegroundService(Intent(ctx, ZoneService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, ZoneService::class.java)) }
        fun sync(ctx: Context) { if (ZoneStore.masterOn(ctx)) start(ctx) else stop(ctx) }

        fun gpsOn(ctx: Context): Boolean =
            runCatching { ctx.getSystemService(LocationManager::class.java).isLocationEnabled }.getOrDefault(false)
    }

    private lateinit var lm: LocationManager
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val pending = HashMap<String, Int>()
    private var level = -1
    private var lastLoc: Location? = null
    private val ticker = android.os.Handler(Looper.getMainLooper())
    /** Réévalue les horaires chaque minute, même sans bouger (début / fin de créneau). */
    private val tick = object : Runnable {
        override fun run() {
            lastLoc?.let { l -> worker.execute { handle(l) } }
            ticker.postDelayed(this, 60_000L)
        }
    }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) { worker.execute { handle(location) } }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private val providersReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            level = -1
            register(1)
            updateNotification()
            Modules.refreshTile(this@ZoneService, ZonesModule)
        }
    }

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LocationManager::class.java)
        ZoneNotifier.ensureChannels(this)
        val f = IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(providersReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(providersReceiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ZoneStore.setMasterOn(this, false)
            Modules.refreshTile(this, ZonesModule)
            stopSelf()
            return START_NOT_STICKY
        }
        val started = runCatching {
            startForeground(NOTIF_ID, buildNotification(statusText()), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        }.isSuccess
        if (!started || !ZonePerms.fine(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        level = -1
        register(1)
        ticker.removeCallbacks(tick)
        ticker.postDelayed(tick, 60_000L)
        Modules.refreshTile(this, ZonesModule)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        ticker.removeCallbacks(tick)
        runCatching { lm.removeUpdates(listener) }
        runCatching { unregisterReceiver(providersReceiver) }
        worker.shutdown()
        Modules.refreshTile(this, ZonesModule)
        super.onDestroy()
    }

    /**
     * Niveau 0 = près du bord d'une zone : GPS + réseau, relevés fréquents.
     * Niveau 1 = moyen : localisation approximative seule (réseau), 30 s.
     * Niveau 2 = loin : localisation approximative seule, très espacée (économie maximale).
     */
    @SuppressLint("MissingPermission")
    private fun register(newLevel: Int) {
        if (newLevel == level) return
        level = newLevel
        runCatching { lm.removeUpdates(listener) }
        if (!ZonePerms.fine(this)) return
        val (time, dist) = when (newLevel) {
            0 -> 10_000L to 5f
            1 -> 30_000L to 50f
            else -> 120_000L to 300f
        }
        fun dispo(p: String) = lm.allProviders.contains(p) && runCatching { lm.isProviderEnabled(p) }.getOrDefault(false)
        var providers = if (newLevel == 0) listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                        else listOf(LocationManager.NETWORK_PROVIDER)
        providers = providers.filter { dispo(it) }
        // Pas de localisation réseau sur ce téléphone : on retombe sur le GPS, au rythme du niveau.
        if (providers.isEmpty() && dispo(LocationManager.GPS_PROVIDER)) providers = listOf(LocationManager.GPS_PROVIDER)
        for (p in providers) runCatching { lm.requestLocationUpdates(p, time, dist, listener, Looper.getMainLooper()) }
    }

    /** Choisit le niveau d'après la distance au bord de la zone la plus proche, avec un seuil d'entrée et un seuil de sortie. */
    private fun chooseLevel(edge: Double, dedans: Boolean): Int {
        val on = if (dedans) DEDANS_ON else APPROCHE_ON
        val off = if (dedans) DEDANS_OFF else APPROCHE_OFF
        return when {
            level == 0 && edge < off -> 0
            edge < on -> 0
            edge < LOIN -> 1
            else -> 2
        }
    }

    private fun handle(loc: Location) {
        lastLoc = loc
        val now = java.util.Calendar.getInstance()
        val valid = ZoneStore.all(this).filter { it.enabled && it.points.size >= 3 }
        // Zones dont le créneau horaire est en cours (sans horaire = toujours).
        val zones = valid.filter { it.activeNow(now) }
        var inside = ZoneStore.insideIds(this)

        // Zones désactivées ou supprimées pendant qu'on était dedans : on oublie l'état.
        val known = valid.map { it.id }.toSet()
        for (id in inside) if (id !in known) ZoneEngine.forget(this, id)

        // Créneau terminé pendant qu'on est dedans : sortie normale (restauration / réglage de sortie).
        for (z in valid) if (z.id in inside && z !in zones) ZoneEngine.exit(this, z)
        if (valid.size != zones.size) { inside = ZoneStore.insideIds(this); updateNotification() }

        if (zones.isEmpty()) { register(2); updateNotification(); return }

        val p = GeoPt(loc.latitude, loc.longitude)
        val acc = if (loc.hasAccuracy()) loc.accuracy.toDouble() else 50.0
        val toExit = ArrayList<Zone>()
        val toEnter = ArrayList<Zone>()
        var nearest = Double.MAX_VALUE
        var edge = Double.MAX_VALUE

        for (z in zones) {
            val d = Geo.distanceOutside(z.points, p)
            nearest = min(nearest, d)
            edge = min(edge, Geo.distanceToEdge(z.points, p))
            if (acc > ACC_MAX) continue
            val was = z.id in inside
            val wantEnter = !was && d == 0.0
            // Sortie : il faut être nettement dehors (au moins 10 m, ou la marge d'erreur du relevé) pour éviter les allers-retours au bord.
            val wantExit = was && d >= max(10.0, min(acc, 40.0))
            if (wantEnter || wantExit) {
                val n = (pending[z.id] ?: 0) + 1
                if (n >= CONFIRM) {
                    pending.remove(z.id)
                    if (wantEnter) toEnter += z else toExit += z
                } else pending[z.id] = n
            } else pending.remove(z.id)
        }

        // Les sorties d'abord : passer d'une zone à la voisine restaure puis applique, dans cet ordre.
        for (z in toExit) ZoneEngine.exit(this, z)
        for (z in toEnter) ZoneEngine.enter(this, z)

        val dedansIds = (inside - toExit.map { it.id }.toSet()) + toEnter.map { it.id }
        register(chooseLevel(edge, zones.any { it.id in dedansIds }))
        if (toExit.isNotEmpty() || toEnter.isNotEmpty()) {
            updateNotification()
            Modules.refreshTile(this, ZonesModule)
        }
    }

    private fun statusText(): String {
        if (!gpsOn(this)) return "GPS coupé : zones en pause"
        val zones = ZoneStore.all(this)
        val inside = ZoneStore.insideIds(this)
        val names = zones.filter { it.id in inside }.map { it.name }
        return if (names.isNotEmpty()) "Dans : " + names.joinToString(", ")
        else "Zones actives (${zones.count { it.activeNow() }})"
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(statusText()))
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ZoneService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(this, ZoneNotifier.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_map)
            .setContentTitle("Map Control")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Arrêter", stop).build())
            .build()
    }
}
