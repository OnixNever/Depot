package com.mapcontrol.app.core

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService
import com.mapcontrol.app.MainActivity

/** Ouvertures d'écrans depuis une tuile (referme le panneau du haut). */
object TileLaunch {
    @Suppress("DEPRECATION")
    private fun go(service: TileService, intent: Intent, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= 34) {
            service.startActivityAndCollapse(
                PendingIntent.getActivity(service, requestCode, intent, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            service.startActivityAndCollapse(intent)
        }
    }

    /** Ouvre l'écran décrit par [spec] (voir ScreenLauncher). Renvoie false s'il est introuvable. */
    fun open(service: TileService, spec: String): Boolean {
        val intent = ScreenLauncher.intentFor(spec) ?: return false
        return try { go(service, intent, 1); true } catch (t: Throwable) { false }
    }

    fun openApp(service: TileService) {
        go(service, Intent(service, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), 0)
    }
}
