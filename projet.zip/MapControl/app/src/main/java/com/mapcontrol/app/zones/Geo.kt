package com.mapcontrol.app.zones

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Un point de la carte (degrés). */
data class GeoPt(val lat: Double, val lon: Double)

/** Géométrie des zones : tout est calculé en mètres autour du point étudié (précis sur quelques kilomètres). */
object Geo {
    private const val M_PER_DEG = 111_195.0

    private fun x(p: GeoPt, ref: GeoPt) = (p.lon - ref.lon) * M_PER_DEG * cos(Math.toRadians(ref.lat))
    private fun y(p: GeoPt, ref: GeoPt) = (p.lat - ref.lat) * M_PER_DEG

    /** Le point est-il à l'intérieur du polygone ? (lancer de rayon) */
    fun contains(poly: List<GeoPt>, p: GeoPt): Boolean {
        if (poly.size < 3) return false
        var inside = false
        var j = poly.size - 1
        for (i in poly.indices) {
            val a = poly[i]
            val b = poly[j]
            if ((a.lat > p.lat) != (b.lat > p.lat) &&
                p.lon < (b.lon - a.lon) * (p.lat - a.lat) / (b.lat - a.lat) + a.lon
            ) inside = !inside
            j = i
        }
        return inside
    }

    /** Distance (m) du point au segment [a, b]. */
    fun segmentDistance(p: GeoPt, a: GeoPt, b: GeoPt): Double {
        val ax = x(a, p); val ay = y(a, p)
        val bx = x(b, p); val by = y(b, p)
        val dx = bx - ax; val dy = by - ay
        val len2 = dx * dx + dy * dy
        val t = if (len2 == 0.0) 0.0 else ((-ax) * dx + (-ay) * dy) / len2
        val tc = t.coerceIn(0.0, 1.0)
        return hypot(ax + tc * dx, ay + tc * dy)
    }

    /** Distance (m) du point au contour du polygone. */
    fun distanceToEdge(poly: List<GeoPt>, p: GeoPt): Double {
        if (poly.isEmpty()) return Double.MAX_VALUE
        var best = Double.MAX_VALUE
        for (i in poly.indices) best = min(best, segmentDistance(p, poly[i], poly[(i + 1) % poly.size]))
        return best
    }

    /** 0 si le point est dans le polygone, sinon la distance (m) au contour. */
    fun distanceOutside(poly: List<GeoPt>, p: GeoPt): Double =
        if (contains(poly, p)) 0.0 else distanceToEdge(poly, p)

    fun distance(a: GeoPt, b: GeoPt): Double {
        val r = 6_371_000.0
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * atan2(sqrt(h), sqrt(1 - h))
    }

    /** Surface approximative en m². */
    fun areaM2(poly: List<GeoPt>): Double {
        if (poly.size < 3) return 0.0
        val ref = poly[0]
        var s = 0.0
        for (i in poly.indices) {
            val a = poly[i]; val b = poly[(i + 1) % poly.size]
            s += x(a, ref) * y(b, ref) - x(b, ref) * y(a, ref)
        }
        return abs(s) / 2.0
    }

    fun centroid(poly: List<GeoPt>): GeoPt =
        GeoPt(poly.sumOf { it.lat } / poly.size, poly.sumOf { it.lon } / poly.size)

    /** Douglas-Peucker : enlève les points qui s'écartent de moins de [tolM] mètres de la ligne. */
    fun simplify(pts: List<GeoPt>, tolM: Double): List<GeoPt> {
        if (pts.size < 3) return pts
        val keep = BooleanArray(pts.size)
        keep[0] = true
        keep[pts.size - 1] = true
        val stack = ArrayDeque<IntArray>()
        stack.addLast(intArrayOf(0, pts.size - 1))
        while (stack.isNotEmpty()) {
            val seg = stack.removeLast()
            val s = seg[0]; val e = seg[1]
            var maxD = 0.0
            var idx = -1
            for (i in s + 1 until e) {
                val d = segmentDistance(pts[i], pts[s], pts[e])
                if (d > maxD) { maxD = d; idx = i }
            }
            if (idx >= 0 && maxD > tolM) {
                keep[idx] = true
                stack.addLast(intArrayOf(s, idx))
                stack.addLast(intArrayOf(idx, e))
            }
        }
        return pts.filterIndexed { i, _ -> keep[i] }
    }

    /** Simplifie jusqu'à obtenir au plus [maxPoints] points (pour pouvoir les corriger à la main). */
    fun simplifyTo(pts: List<GeoPt>, maxPoints: Int, startTolM: Double = 1.0): List<GeoPt> {
        var tol = startTolM
        var out = simplify(pts, tol)
        var n = 0
        while (out.size > maxPoints && n < 30) { tol *= 1.5; out = simplify(pts, tol); n++ }
        return out
    }
}
