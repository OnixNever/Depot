package com.mapcontrol.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mapcontrol.app.core.ClickArm
import com.mapcontrol.app.core.ClickTargets
import com.mapcontrol.app.core.ScreenLauncher

/** Configuration et test du service d'accessibilité qui appuie sur l'interrupteur d'Auto Blocker. */
@Composable
fun AutoClickCard() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var rev by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { rev++ }

    val enabled = remember(rev) { ClickArm.enabled(ctx) }
    val result = remember(rev) { ClickArm.lastResult }
    val dump = remember(rev) { ClickArm.lastDump }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Clic automatique sur Auto Blocker", style = MaterialTheme.typography.titleMedium)
            Text(
                "Un service d'accessibilité, limité à l'appli Auto Blocker, appuie sur l'interrupteur à ta place quand la tuile ouvre la page. " +
                    "Il fonctionne sans Shizuku. Samsung peut encore te demander ton schéma ou ton empreinte : c'est toi qui valides.",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                if (enabled) "Service activé ✓" else "Service désactivé. Réglages d'accessibilité → Applications installées → « Map Control : interrupteur Auto Blocker ».",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            if (!enabled) {
                Text(
                    "Si Android grise l'option (« paramètre restreint ») : Paramètres → Applis → Map Control → ⋮ en haut à droite → « Autoriser les paramètres restreints », puis recommence.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Réglages d'accessibilité") }
                Button(enabled = enabled, onClick = {
                    ClickArm.armIfReady(ctx, ClickTargets.autoBlocker)
                    ScreenLauncher.start(ctx, ScreenLauncher.presets.first().spec)
                }) { Text("Tester le clic") }
            }
            if (result.isNotBlank()) Text(result, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { rev++ }) { Text("Actualiser") }
                if (dump.isNotBlank()) {
                    OutlinedButton(onClick = { clipboard.setText(AnnotatedString(dump)) }) { Text("Copier l'arbre de l'écran") }
                }
            }
            if (dump.isNotBlank()) {
                SelectionContainer {
                    Text(dump.take(1500), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                }
            }
        }
    }
}
