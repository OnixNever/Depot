package com.mapcontrol.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mapcontrol.app.core.Actions
import com.mapcontrol.app.core.Change
import com.mapcontrol.app.core.Entry
import com.mapcontrol.app.core.IconChoices
import com.mapcontrol.app.core.Perm
import com.mapcontrol.app.core.SettingsScanner
import com.mapcontrol.app.core.Slots
import com.mapcontrol.app.core.SwitchAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Step { INTRO, WAITING, RESULTS, NAME, DONE }

/** Assistant : scan « avant » -> l'utilisateur change un réglage -> détection -> nom/icône -> tuile. */
@Composable
fun ScanWizard(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var step by remember { mutableStateOf(if (SettingsScanner.hasPending(ctx)) Step.WAITING else Step.INTRO) }
    var busy by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var scanned by remember { mutableStateOf(0) }
    var changes by remember { mutableStateOf<List<Change>>(emptyList()) }
    var showNoise by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var title by remember { mutableStateOf("") }
    var iconKey by remember { mutableStateOf("swap") }
    var invert by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var doneMsg by remember { mutableStateOf("") }

    fun visible() = changes.filter { showNoise || !it.noisy }

    fun defaultSelection(list: List<Change>): Set<String> {
        val clean = list.filter { !it.noisy }
        val pick = if (clean.size <= 4) clean else clean.filter { it.switchLike }
        return pick.map { it.id }.toSet()
    }

    fun buildEntries(): List<Entry> = changes.filter { it.id in selected }.map {
        // Par défaut « actif » = la valeur obtenue APRÈS le changement de l'utilisateur.
        if (invert) Entry(it.table, it.name, on = it.before, off = it.after)
        else Entry(it.table, it.name, on = it.after, off = it.before)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("← Retour") }
            }
            Text("Nouvelle action", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }

        when (step) {
            Step.INTRO -> item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("1. Scanner", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Map Control prend une photo de tous tes réglages. Tu vas ensuite dans les Paramètres, " +
                                "tu changes UNE seule chose (par exemple le DNS privé), puis tu reviens ici : " +
                                "Map Control repère ce qui a bougé."
                        )
                        Button(
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                busy = true; info = null
                                scope.launch {
                                    scanned = withContext(Dispatchers.IO) { SettingsScanner.startScan(ctx) }
                                    busy = false
                                    step = Step.WAITING
                                }
                            },
                        ) { Text(if (busy) "Scan en cours…" else "Scanner les actions") }
                    }
                }
            }

            Step.WAITING -> item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("2. Change un réglage", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Scan enregistré" + (if (scanned > 0) " ($scanned réglages)" else "") + ". " +
                                "Va dans les Paramètres, bouge le réglage voulu une seule fois, puis reviens ici " +
                                "et appuie sur « J'ai changé le réglage »."
                        )
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            },
                        ) { Text("Ouvrir les Paramètres") }
                        Button(
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                busy = true; info = null
                                scope.launch {
                                    val list = withContext(Dispatchers.IO) { SettingsScanner.detect(ctx) }
                                    changes = list
                                    selected = defaultSelection(list)
                                    showNoise = false
                                    busy = false
                                    step = Step.RESULTS
                                }
                            },
                        ) { Text(if (busy) "Analyse…" else "J'ai changé le réglage") }
                        TextButton(onClick = {
                            SettingsScanner.clearPending(ctx)
                            step = Step.INTRO
                        }) { Text("Annuler ce scan") }
                    }
                }
            }

            Step.RESULTS -> {
                item {
                    Text("3. Ce qui a changé", style = MaterialTheme.typography.titleLarge)
                    val n = visible().size
                    Text(
                        if (n == 0)
                            "Aucun changement détecté. Soit le réglage n'est pas stocké dans les réglages Android " +
                                "(c'est le cas du Wi-Fi, du Bluetooth, des données mobiles…), soit tu n'as rien changé. " +
                                "Tu peux recommencer."
                        else
                            "Coche les réglages à piloter. Les interrupteurs (0/1) sont en haut de liste.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = showNoise, onCheckedChange = { showNoise = it })
                        Text("  Afficher aussi les valeurs qui bougent seules", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                items(visible(), key = { it.id }) { c ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = c.id in selected,
                                onCheckedChange = { on -> selected = if (on) selected + c.id else selected - c.id },
                            )
                            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                                Text(c.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${c.table} · ${c.before ?: "(absent)"} → ${c.after ?: "(absent)"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { step = Step.WAITING }) { Text("Refaire le changement") }
                        Button(
                            enabled = selected.isNotEmpty(),
                            onClick = {
                                if (title.isBlank()) title = "Action " + (Actions.all(ctx).size + 1)
                                testResult = null
                                step = Step.NAME
                            },
                        ) { Text("Continuer") }
                    }
                }
            }

            Step.NAME -> {
                item {
                    Text("4. Nom et icône", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Nom de la tuile") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(IconChoices.all) { (key, res) ->
                            FilledIconToggleButton(checked = key == iconKey, onCheckedChange = { iconKey = key }) {
                                Icon(painterResource(res), contentDescription = key)
                            }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = invert, onCheckedChange = { invert = it; testResult = null })
                        Text(
                            "  Tuile « active » = état d'avant mon changement",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    Text(
                        "Réglages pilotés : " + changes.filter { it.id in selected }.joinToString { it.name },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val granted = Perm.granted(ctx)
                        OutlinedButton(
                            enabled = granted,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                val tmp = SwitchAction("test", 0, title, iconKey, buildEntries())
                                testResult = Actions.toggle(ctx, tmp).fold(
                                    onSuccess = { if (it) "Test : réglage mis sur ACTIF." else "Test : réglage mis sur INACTIF." },
                                    onFailure = { "Échec : ${it.message}" },
                                )
                            },
                        ) { Text("Tester (bascule le réglage)") }
                        if (!granted) {
                            Text(
                                "Autorisation manquante : le test et la tuile ne fonctionneront qu'après l'étape d'autorisation de l'écran d'accueil.",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        testResult?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            enabled = title.isNotBlank(),
                            onClick = {
                                val a = Actions.add(ctx, title.trim(), iconKey, buildEntries())
                                if (a == null) {
                                    info = "Nombre maximum d'actions atteint (${Actions.MAX_SLOTS}). Supprime-en une."
                                } else {
                                    SettingsScanner.clearPending(ctx)
                                    Slots.setEnabled(ctx, a.slot, true)
                                    Slots.refreshTile(ctx, a.slot)
                                    doneMsg = "Action « ${a.title} » créée."
                                    step = Step.DONE
                                    Slots.requestAdd(ctx, a) { msg -> doneMsg = "Action « ${a.title} » créée.\n$msg" }
                                }
                            },
                        ) { Text("Créer la tuile") }
                        info?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        TextButton(onClick = { step = Step.RESULTS }) { Text("← Retour aux réglages détectés") }
                    }
                }
            }

            Step.DONE -> item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Terminé", style = MaterialTheme.typography.titleLarge)
                        Text(doneMsg)
                        Button(modifier = Modifier.fillMaxWidth(), onClick = onClose) { Text("Voir mes actions") }
                    }
                }
            }
        }
    }
}
