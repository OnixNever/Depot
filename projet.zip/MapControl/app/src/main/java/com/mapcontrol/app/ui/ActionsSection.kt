package com.mapcontrol.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.mapcontrol.app.core.Actions
import com.mapcontrol.app.core.ClickArm
import com.mapcontrol.app.core.ClickTargets
import com.mapcontrol.app.core.IconChoices
import com.mapcontrol.app.core.Perm
import com.mapcontrol.app.core.ScreenLauncher
import com.mapcontrol.app.core.Slots
import com.mapcontrol.app.core.SwitchAction

/** Carte d'une action apprise : état, bascule, ajout au panneau, renommage, suppression. */
@Composable
fun ActionCard(action: SwitchAction, tick: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf(action.title) }

    val isLaunch = action.launch != null
    val ready = remember(tick, rev) { isLaunch || Perm.granted(ctx) }
    val active = remember(tick, rev) { !isLaunch && ready && Actions.isActive(ctx, action) }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            TileHeader(
                iconRes = IconChoices.res(action.icon),
                title = action.title,
                status = when {
                    isLaunch && action.clickSwitch -> "Bascule la page automatiquement"
                    isLaunch -> "Ouvre une page des Paramètres"
                    !ready -> "Configuration requise"
                    active -> "Activé"
                    else -> "Désactivé"
                },
                detail = if (isLaunch) null else action.entries.joinToString { it.name },
                active = active,
            )
            Spacer(Modifier.height(16.dp))
            Button(
                enabled = ready,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    message = if (isLaunch) {
                        if (action.clickSwitch) ClickTargets.forSpec(action.launch.orEmpty())?.let { ClickArm.armIfReady(ctx, it) }
                        ScreenLauncher.start(ctx, action.launch.orEmpty()).exceptionOrNull()?.message
                    } else {
                        Actions.toggle(ctx, action).exceptionOrNull()?.message
                    }
                    Slots.refreshTile(ctx, action.slot)
                    rev++
                },
            ) { Text(if (isLaunch) (if (action.clickSwitch) "Basculer" else "Ouvrir") else "Changer") }
            message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

            Row {
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Masquer" else "Personnaliser") }
                TextButton(onClick = {
                    Slots.setEnabled(ctx, action.slot, true)
                    Slots.requestAdd(ctx, action) { message = it }
                }) { Text("Ajouter au panneau") }
            }
            AnimatedVisibility(expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = {
                            draft = it
                            if (it.isNotBlank()) {
                                Actions.update(ctx, action.copy(title = it))
                                Slots.refreshTile(ctx, action.slot)
                            }
                        },
                        label = { Text("Nom de la tuile") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(IconChoices.all) { (key, res) ->
                            FilledIconToggleButton(
                                checked = key == action.icon,
                                onCheckedChange = {
                                    Actions.update(ctx, action.copy(icon = key))
                                    Slots.refreshTile(ctx, action.slot)
                                    onChanged()
                                },
                            ) { Icon(painterResource(res), contentDescription = key) }
                        }
                    }
                    if (isLaunch) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Appuyer aussi sur l'interrupteur (service d'accessibilité)",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                            )
                            Switch(
                                checked = action.clickSwitch,
                                onCheckedChange = {
                                    Actions.update(ctx, action.copy(clickSwitch = it))
                                    onChanged()
                                },
                            )
                        }
                    }
                    OutlinedButton(onClick = { confirmDelete = true }) { Text("Supprimer cette action") }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer « ${action.title} » ?") },
            text = { Text("La tuile disparaîtra du panneau. Le réglage reste dans son état actuel.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    Actions.remove(ctx, action)
                    Slots.setEnabled(ctx, action.slot, false)
                    onChanged()
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}
