package com.mapcontrol.app.tiles

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.mapcontrol.app.core.Prefs
import com.mapcontrol.app.core.SwitchModule
import com.mapcontrol.app.core.TileLaunch

/** Logique commune à toutes les tuiles de modules : une sous-classe ne fournit que son module. */
abstract class BaseTileService : TileService() {
    abstract val module: SwitchModule

    override fun onStartListening() = refresh()

    override fun onClick() {
        if (module.tileClick(this)) { refresh(); return }
        if (!module.isReady(this)) { TileLaunch.openApp(this); return }
        module.toggle(this)
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val ready = module.isReady(this)
        val state = if (ready) module.current(this) else null
        tile.label = Prefs.title(this, module)
        tile.icon = Icon.createWithResource(this, Prefs.iconRes(this, module))
        tile.state = if (state?.active == true) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.subtitle = state?.label ?: "Configuration requise"
        tile.updateTile()
    }
}
