package com.mapcontrol.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mapcontrol.app.core.Actions
import com.mapcontrol.app.core.Perm
import com.mapcontrol.app.zones.ExitMode
import com.mapcontrol.app.zones.Kind
import com.mapcontrol.app.zones.Need
import com.mapcontrol.app.zones.Schedule
import com.mapcontrol.app.zones.Zone
import com.mapcontrol.app.zones.ZoneAction
import com.mapcontrol.app.zones.ZoneActionType
import com.mapcontrol.app.zones.ZoneCatalog
import com.mapcontrol.app.zones.ZoneColors
import com.mapcontrol.app.zones.ZoneEngine
import com.mapcontrol.app.zones.ZonePerms
import com.mapcontrol.app.zones.ZoneStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Pastilles de couleur (utilisées sur la carte et dans l'éditeur). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorPicker(selected: Int, onPick: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ZoneColors.PALETTE.forEach { c ->
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                    .then(if (c == selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                    .clickable { onPick(c) }
            )
        }
    }
}

/** Éditeur d'une zone : nom, couleur, et la liste des réglages appliqués à l'entrée / à la sortie. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ZoneEditor(zoneId: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var zone by remember { mutableStateOf(ZoneStore.byId(ctx, zoneId)) }
    var tick by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    // Réglages dépliés : tout est déplié s'il y en a peu, replié sinon (lisible même avec une vingtaine de réglages).
    var openIds by remember {
        val acts = zone?.actions ?: emptyList()
        mutableStateOf(if (acts.size <= 2) acts.map { it.id }.toSet() else emptySet<String>())
    }
    val scope = rememberCoroutineScope()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    val z = zone
    if (z == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    fun save(n: Zone) { zone = n; ZoneStore.upsert(ctx, n) }

    fun runTest(entering: Boolean) {
        if (busy) return
        busy = true
        message = "Test en cours…"
        scope.launch(Dispatchers.IO) {
            val lines = if (entering) ZoneEngine.enter(ctx, z, track = false) else ZoneEngine.exit(ctx, z, track = false)
            withContext(Dispatchers.Main) { message = lines.joinToString("\n"); busy = false }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("← Retour à la carte") }
            }
        }
        item {
            OutlinedTextField(
                value = z.name, onValueChange = { save(z.copy(name = it)) },
                label = { Text("Nom de la zone") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
        }
        item { ColorPicker(z.color) { save(z.copy(color = it)) } }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Zone active", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                Switch(checked = z.enabled, onCheckedChange = { save(z.copy(enabled = it)) })
            }
        }
        item { ScheduleCard(z.schedule) { save(z.copy(schedule = it)) } }
        item {
            SectionTitle(
                "Réglages de cette zone",
                "Touche un réglage pour le déplier ou le replier. Replié, il affiche juste ce qui se passe à l'entrée et à la sortie.",
            )
        }
        if (z.actions.size > 1) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { openIds = emptySet() }, modifier = Modifier.weight(1f)) { Text("Tout replier") }
                    OutlinedButton(onClick = { openIds = z.actions.map { it.id }.toSet() }, modifier = Modifier.weight(1f)) { Text("Tout déplier") }
                }
            }
        }
        if (z.actions.isEmpty()) {
            item { Text("Aucun réglage pour l'instant.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(z.actions, key = { it.id }) { a ->
            ActionCard(
                a = a, tick = tick,
                expanded = a.id in openIds,
                onToggle = { openIds = if (a.id in openIds) openIds - a.id else openIds + a.id },
                onChange = { n -> save(z.copy(actions = z.actions.map { if (it.id == a.id) n else it })) },
                onDelete = { save(z.copy(actions = z.actions.filter { it.id != a.id })) },
            )
        }
        item { Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Ajouter un réglage") } }
        item {
            SectionTitle("Tester", "Applique tout de suite les réglages pour vérifier qu'ils marchent (sans bouger).")
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { runTest(true) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("▶ Entrée") }
                OutlinedButton(onClick = { runTest(false) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("▶ Sortie") }
            }
        }
        message?.let { m -> item { Text(m, style = MaterialTheme.typography.bodySmall) } }
        item {
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) { Text("Supprimer cette zone") }
        }
    }

    if (showAdd) {
        AddActionDialog(
            onDismiss = { showAdd = false },
            onPick = { t ->
                val param = when (t.kind) {
                    Kind.LEARNED -> Actions.all(ctx).firstOrNull { it.launch == null }?.id
                    Kind.SETTING -> "global|"
                    else -> null
                }
                if (t.kind == Kind.LEARNED && param == null) {
                    message = "Aucune action apprise : crée d'abord une tuile « réglage on/off » avec le scanner."
                } else {
                    val na = ZoneAction(type = t.id, enter = t.defaultValue(param), param = param)
                    save(z.copy(actions = z.actions + na))
                    openIds = openIds + na.id // le nouveau réglage s'ouvre pour être configuré
                }
                showAdd = false
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer la zone ?") },
            text = { Text(z.name) },
            confirmButton = {
                TextButton(onClick = {
                    if (z.id in ZoneStore.insideIds(ctx)) Thread { ZoneEngine.exit(ctx, z) }.start()
                    ZoneStore.remove(ctx, z.id)
                    confirmDelete = false
                    onClose()
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }
}

/** Résumé d'une ligne affiché quand le réglage est replié. */
private fun summary(ctx: Context, t: ZoneActionType, a: ZoneAction): String {
    val enter = if (a.enter == null) "inchangé" else t.describe(ctx, a.enter, a.param)
    val exit = when (a.exitMode) {
        ExitMode.RESTORE -> if (a.enter == null) "inchangé" else "retour à l'état d'avant"
        ExitMode.SET -> t.describe(ctx, a.exit, a.param)
        ExitMode.NOTHING -> "inchangé"
    }
    return "Entrée : $enter  ·  Sortie : $exit"
}

private fun needWarning(ctx: Context, t: ZoneActionType): String? = when (t.need) {
    Need.SECURE -> if (!Perm.granted(ctx)) "⚠ Autorisation « Modifier les réglages » à accorder (Shizuku, une seule fois : carte « À configurer » de l'accueil)." else null
    Need.DND -> if (!ZonePerms.dnd(ctx)) "⚠ Accès « Ne pas déranger » à accorder (⚙ Autorisations, sur la carte)." else null
    else -> null
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ActionCard(
    a: ZoneAction, tick: Int, expanded: Boolean, onToggle: () -> Unit,
    onChange: (ZoneAction) -> Unit, onDelete: () -> Unit,
) {
    val ctx = LocalContext.current
    val t = ZoneCatalog.byId(a.type)
    val warn = remember(tick, a.type) { if (t != null) needWarning(ctx, t) else null }
    ElevatedCard(Modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // En-tête : toujours visible, toucher pour déplier / replier.
            Row(Modifier.fillMaxWidth().clickable { onToggle() }, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        (if (warn != null) "⚠ " else "") + (t?.title ?: a.type),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        if (t == null) "Réglage inconnu" else if (expanded) t.category else summary(ctx, t, a),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(if (expanded) "▾" else "▸", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!expanded) return@Column
            if (t == null) {
                Text("Créé par une autre version de l'appli : tu peux seulement le retirer.", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) { Text("Retirer ce réglage") }
                return@Column
            }
            NeedNote(t, tick)
            ParamEditor(t, a, onChange)

            Text("À l'entrée", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = a.enter == null, onClick = { onChange(a.copy(enter = null)) }, label = { Text("Ne rien changer") })
                FilterChip(
                    selected = a.enter != null,
                    onClick = { if (a.enter == null) onChange(a.copy(enter = t.defaultValue(a.param))) },
                    label = { Text("Appliquer") },
                )
            }
            if (a.enter != null) ValueEditor(t, a.enter, a.param) { onChange(a.copy(enter = it)) }

            Text("À la sortie", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = a.exitMode == ExitMode.RESTORE, onClick = { onChange(a.copy(exitMode = ExitMode.RESTORE)) },
                    label = { Text("Revenir à l'état d'avant") },
                )
                FilterChip(
                    selected = a.exitMode == ExitMode.SET,
                    onClick = { onChange(a.copy(exitMode = ExitMode.SET, exit = a.exit ?: t.defaultValue(a.param))) },
                    label = { Text("Appliquer") },
                )
                FilterChip(
                    selected = a.exitMode == ExitMode.NOTHING, onClick = { onChange(a.copy(exitMode = ExitMode.NOTHING)) },
                    label = { Text("Ne rien changer") },
                )
            }
            if (a.exitMode == ExitMode.SET) ValueEditor(t, a.exit ?: t.defaultValue(a.param), a.param) { onChange(a.copy(exit = it)) }
            if (a.exitMode == ExitMode.RESTORE && a.enter == null) {
                Text(
                    "Rien à restaurer : ce réglage n'est pas modifié à l'entrée.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) { Text("Retirer ce réglage") }
        }
    }
}

@Composable
private fun NeedNote(t: ZoneActionType, tick: Int) {
    val ctx = LocalContext.current
    val warn = remember(tick) { needWarning(ctx, t) }
    if (warn != null) Text(warn, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    if (t.note != null) Text(t.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Paramètre propre au type : réglage libre (table + nom) ou action apprise à choisir. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ParamEditor(t: ZoneActionType, a: ZoneAction, onChange: (ZoneAction) -> Unit) {
    val ctx = LocalContext.current
    when (t.kind) {
        Kind.LEARNED -> {
            val learned = remember { Actions.all(ctx).filter { it.launch == null } }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                learned.forEach { l ->
                    FilterChip(selected = a.param == l.id, onClick = { onChange(a.copy(param = l.id)) }, label = { Text(l.title) })
                }
            }
        }
        Kind.SETTING -> {
            val parts = (a.param ?: "global|").split("|", limit = 2)
            val table = parts[0]
            val name = parts.getOrElse(1) { "" }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("global", "secure", "system").forEach { tb ->
                    FilterChip(selected = table == tb, onClick = { onChange(a.copy(param = "$tb|$name")) }, label = { Text(tb) })
                }
            }
            OutlinedTextField(
                value = name, onValueChange = { onChange(a.copy(param = "$table|${it.trim()}")) },
                label = { Text("Nom du réglage") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
        }
        else -> {}
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ValueEditor(t: ZoneActionType, value: String?, param: String?, onChange: (String) -> Unit) {
    when (t.kind) {
        Kind.SWITCH, Kind.LEARNED -> FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = value == "1", onClick = { onChange("1") }, label = { Text("Activé") })
            FilterChip(selected = value == "0", onClick = { onChange("0") }, label = { Text("Désactivé") })
        }
        Kind.PERCENT -> {
            val v = value?.toFloatOrNull() ?: 50f
            Column {
                Text("${v.roundToInt()} %", style = MaterialTheme.typography.bodyMedium)
                Slider(value = v, onValueChange = { onChange(it.roundToInt().toString()) }, valueRange = 0f..100f)
            }
        }
        Kind.CHOICE -> FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            t.choices.forEach { (k, label) ->
                FilterChip(selected = value == k, onClick = { onChange(k) }, label = { Text(label) })
            }
        }
        Kind.TEXT -> OutlinedTextField(
            value = value ?: "", onValueChange = onChange,
            label = { Text("Texte") }, modifier = Modifier.fillMaxWidth(),
        )
        Kind.APP -> AppField(value ?: "", onChange)
        Kind.SETTING -> OutlinedTextField(
            value = value ?: "", onValueChange = onChange,
            label = { Text("Valeur à écrire") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun AppField(pkg: String, onChange: (String) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val label = remember(pkg) {
        if (pkg.isBlank()) "Choisir une appli"
        else runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
    }
    OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text(label) }
    if (open) {
        var q by remember { mutableStateOf("") }
        val apps = remember {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        }
        val shown = apps.filter { q.isBlank() || it.first.contains(q, ignoreCase = true) }
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text("Choisir une appli") },
            text = {
                Column {
                    OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Chercher") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.size(8.dp))
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(shown, key = { it.second }) { (name, p) ->
                            Text(
                                name, Modifier.fillMaxWidth().clickable { onChange(p); open = false }.padding(vertical = 10.dp),
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Fermer") } },
        )
    }
}

@Composable
private fun AddActionDialog(onDismiss: () -> Unit, onPick: (ZoneActionType) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(q) {
        ZoneCatalog.all.filter { q.isBlank() || it.title.contains(q, true) || it.category.contains(q, true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajouter un réglage") },
        text = {
            Column {
                OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Chercher") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.size(8.dp))
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    list.groupBy { it.category }.forEach { (cat, ts) ->
                        item(key = "c_$cat") {
                            Text(
                                cat, Modifier.padding(top = 10.dp, bottom = 4.dp),
                                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                            )
                        }
                        items(ts, key = { it.id }) { t ->
                            Text(
                                t.title, Modifier.fillMaxWidth().clickable { onPick(t) }.padding(vertical = 10.dp),
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

/** Horaire d'activation facultatif : par défaut la zone est active tout le temps. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ScheduleCard(schedule: Schedule?, onChange: (Schedule?) -> Unit) {
    val ctx = LocalContext.current
    val names = listOf("Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
    fun hm(x: Int) = "%02d:%02d".format(x / 60, x % 60)
    fun pick(initial: Int, onPicked: (Int) -> Unit) {
        android.app.TimePickerDialog(ctx, { _, h, m -> onPicked(h * 60 + m) }, initial / 60, initial % 60, true).show()
    }
    ElevatedCard(Modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Horaires d'activation", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (schedule == null) "Désactivé : la zone est active tout le temps." else schedule.describe(),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = schedule != null, onCheckedChange = { onChange(if (it) Schedule() else null) })
            }
            if (schedule == null) return@Column
            Text("Jours actifs", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                names.forEachIndexed { i, n ->
                    val d = i + 1
                    FilterChip(
                        selected = d in schedule.days,
                        onClick = { onChange(schedule.copy(days = if (d in schedule.days) schedule.days - d else schedule.days + d)) },
                        label = { Text(n) },
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Toute la journée", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                Switch(checked = schedule.allDay, onCheckedChange = { onChange(schedule.copy(allDay = it)) })
            }
            if (!schedule.allDay) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pick(schedule.startMin) { onChange(schedule.copy(startMin = it)) } }, modifier = Modifier.weight(1f)) {
                        Text("De ${hm(schedule.startMin)}")
                    }
                    OutlinedButton(onClick = { pick(schedule.endMin) { onChange(schedule.copy(endMin = it)) } }, modifier = Modifier.weight(1f)) {
                        Text("À ${hm(schedule.endMin)}")
                    }
                }
                if (schedule.endMin <= schedule.startMin) {
                    Text(
                        "La plage passe minuit : elle finit le lendemain, et compte pour le jour où elle commence.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (schedule.days.isEmpty()) {
                Text("⚠ Aucun jour coché : la zone ne s'activera jamais.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Text(
                "Quand le créneau se termine alors que tu es dans la zone, la sortie est appliquée normalement. Quand il commence, l'entrée est appliquée si tu es dedans (vérifié chaque minute).",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
