package com.mapcontrol.app.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager

object Perm {
    /** WRITE_SECURE_SETTINGS : nécessaire pour modifier les réglages (accordée une fois via Shizuku ou adb). */
    fun granted(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
}
