package com.mapcontrol.app.zones

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import com.mapcontrol.app.R

/** Notifications : celle du service (permanente) et celles envoyées par les réglages « Notification » / « Ouvrir une appli ». */
object ZoneNotifier {
    const val CH_SERVICE = "zones_service"
    const val CH_INFO = "zones_info"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Surveillance des zones", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_INFO, "Messages des zones", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun post(ctx: Context, title: String, text: String, tap: PendingIntent? = null) {
        check(ZonePerms.notifications(ctx)) { "Autorisation de notifications manquante" }
        ensureChannels(ctx)
        val n = Notification.Builder(ctx, CH_INFO)
            .setSmallIcon(R.drawable.ic_map)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .apply { if (tap != null) setContentIntent(tap) }
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify((title + text).hashCode(), n)
    }
}
