package com.mapcontrol.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mapcontrol.app.zones.Geo
import com.mapcontrol.app.zones.GeoPt
import com.mapcontrol.app.zones.Zone
import com.mapcontrol.app.zones.ZoneColors
import com.mapcontrol.app.zones.ZoneEngine
import com.mapcontrol.app.zones.ZonePerms
import com.mapcontrol.app.zones.ZoneService
import com.mapcontrol.app.zones.ZoneStore
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import java.io.File

/** Fabrique de la carte OpenStreetMap (osmdroid, sans clé) et fonds de carte proposés. */
object MapFactory {
    /** Satellite Esri (fond d'image, utile pour tracer précisément autour des bâtiments). */
    private val ESRI: ITileSource = object : OnlineTileSourceBase(
        "EsriSatellite", 0, 19, 256, ".jpg",
        arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"),
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String =
            baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" + MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex)
    }

    val STYLES: List<Pair<String, ITileSource>> = listOf(
        "🗺 Plan" to TileSourceFactory.MAPNIK,
        "🛰 Satellite" to ESRI,
        "⛰ Relief" to TileSourceFactory.OpenTopo,
    )

    @SuppressLint("MissingPermission")
    fun lastKnown(ctx: Context): GeoPt? {
        if (!ZonePerms.fine(ctx)) return null
        val lm = ctx.getSystemService(LocationManager::class.java)
        return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
            ?.let { GeoPt(it.latitude, it.longitude) }
    }

    fun create(ctx: Context, overlay: ZonesOverlay, zones: List<Zone>): MapView {
        Configuration.getInstance().apply {
            userAgentValue = "MapControl/1.0 (" + ctx.packageName + ")"
            osmdroidBasePath = File(ctx.cacheDir, "osmdroid")
            osmdroidTileCache = File(ctx.cacheDir, "osmdroid/tiles")
        }
        val map = MapView(ctx)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.isTilesScaledToDpi = true
        map.minZoomLevel = 3.0
        map.maxZoomLevel = 19.0
        map.overlays.add(CopyrightOverlay(ctx))
        map.overlays.add(overlay)
        overlay.me = lastKnown(ctx)
        val start = overlay.me
            ?: zones.firstOrNull { it.points.size >= 3 }?.let { Geo.centroid(it.points) }
            ?: GeoPt(50.8503, 4.3517) // Bruxelles par défaut
        map.controller.setZoom(16.0)
        map.controller.setCenter(GeoPoint(start.lat, start.lon))
        return map
    }
}

private enum class MapMode { VIEW, DRAW, EDIT }

/** Carte plein écran : voir, dessiner, corriger et choisir les zones. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ZonesScreen(tick: Int, onClose: () -> Unit, onEditZone: (String) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    val zones = remember(rev, tick) { ZoneStore.all(ctx) }
    var mode by remember { mutableStateOf(MapMode.VIEW) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var editingId by remember { mutableStateOf<String?>(null) }
    var color by remember { mutableIntStateOf(ZoneColors.PALETTE[0]) }
    var message by remember { mutableStateOf<String?>(null) }
    var styleIdx by remember { mutableIntStateOf(0) }
    var master by remember(tick) { mutableStateOf(ZoneStore.masterOn(ctx)) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showSetup by remember { mutableStateOf(false) }
    var shapeRev by remember { mutableIntStateOf(0) }

    val density = LocalDensity.current.density
    val overlay = remember { ZonesOverlay(density) }
    val mapView = remember { MapFactory.create(ctx, overlay, zones) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { mapView.onResume() }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { mapView.onPause() }
    DisposableEffect(mapView) { onDispose { mapView.onDetach() } }

    SideEffect {
        overlay.zones = zones
        overlay.selectedId = selectedId
        overlay.editingId = editingId
        overlay.drawColor = color
        overlay.mode = when (mode) {
            MapMode.VIEW -> ZonesOverlay.Mode.VIEW
            MapMode.DRAW -> ZonesOverlay.Mode.DRAW
            MapMode.EDIT -> ZonesOverlay.Mode.EDIT
        }
        overlay.onTap = { id -> selectedId = id }
        overlay.onDrawn = { mode = MapMode.EDIT; shapeRev++ }
        overlay.onShapeChanged = { }
        mapView.invalidate()
    }

    fun cancelEdit() {
        overlay.polygon.clear()
        editingId = null
        mode = MapMode.VIEW
        mapView.invalidate()
    }

    fun focus(z: Zone) {
        val pts = z.points.map { GeoPoint(it.lat, it.lon) }
        if (pts.size >= 3) mapView.post { runCatching { mapView.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, 140) } }
    }

    BackHandler(enabled = mode != MapMode.VIEW) { cancelEdit() }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { mapView }, modifier = Modifier.fillMaxSize(), update = { it.invalidate() })

        // ---------- barre du haut ----------
        Surface(
            Modifier.align(Alignment.TopCenter).fillMaxWidth(),
            tonalElevation = 3.dp,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        ) {
            Row(Modifier.padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("← Retour") }
                TextButton(onClick = { showSetup = true }) { Text("⚙ Autorisations") }
                Spacer(Modifier.weight(1f))
                Text(if (master) "Zones actives" else "Zones coupées", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.width(8.dp))
                Switch(checked = master, onCheckedChange = { want ->
                    if (want) {
                        if (!ZonePerms.fine(ctx)) {
                            message = "Autorise d'abord la position."
                            showSetup = true
                        } else {
                            ZoneStore.setMasterOn(ctx, true)
                            val r = runCatching { ZoneService.start(ctx) }
                            if (r.isFailure) message = "Impossible de lancer la surveillance : " + r.exceptionOrNull()?.message
                            master = true
                            onChanged()
                        }
                    } else {
                        ZoneStore.setMasterOn(ctx, false)
                        ZoneService.stop(ctx)
                        master = false
                        onChanged()
                    }
                })
            }
        }

        // ---------- panneau du bas ----------
        Surface(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            tonalElevation = 6.dp,
        ) {
            Column(
                Modifier.padding(16.dp).heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                message?.let { m ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(m, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        TextButton(onClick = { message = null }) { Text("OK") }
                    }
                }

                when (mode) {
                    MapMode.VIEW -> {
                        if (!ZonePerms.fine(ctx) || !ZonePerms.background(ctx)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "⚠ Il manque des autorisations de position pour que les zones marchent en arrière-plan.",
                                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
                                )
                                TextButton(onClick = { showSetup = true }) { Text("Configurer") }
                            }
                        }
                        if (zones.isEmpty()) {
                            Text("Aucune zone pour l'instant. Touche « Nouvelle zone » puis entoure l'endroit avec ton doigt.", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(zones, key = { it.id }) { z ->
                                    FilterChip(
                                        selected = z.id == selectedId,
                                        onClick = { selectedId = z.id; focus(z) },
                                        label = { Text(z.name) },
                                        leadingIcon = { Box(Modifier.size(12.dp).clip(CircleShape).background(Color(z.color))) },
                                    )
                                }
                            }
                        }
                        val sel = zones.firstOrNull { it.id == selectedId }
                        if (sel != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(16.dp).clip(CircleShape).background(Color(sel.color)))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(sel.name, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${sel.actions.size} réglage(s)" + (if (sel.enabled) "" else " · désactivée") +
                                    (sel.schedule?.let { " · ${it.describe()}" + if (sel.enabled && !it.isActive()) " (hors créneau)" else "" } ?: ""),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Switch(checked = sel.enabled, onCheckedChange = {
                                    ZoneStore.upsert(ctx, sel.copy(enabled = it)); rev++; onChanged()
                                })
                            }
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onEditZone(sel.id) }) { Text("Réglages") }
                                OutlinedButton(onClick = {
                                    overlay.polygon.clear(); overlay.polygon.addAll(sel.points)
                                    editingId = sel.id; color = sel.color; mode = MapMode.EDIT; message = null; shapeRev++
                                }) { Text("Corriger le tracé") }
                                OutlinedButton(onClick = { confirmDelete = true }) { Text("Supprimer") }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = {
                                overlay.polygon.clear(); editingId = null; selectedId = null
                                color = ZoneColors.PALETTE[zones.size % ZoneColors.PALETTE.size]
                                mode = MapMode.DRAW; message = null
                            }, modifier = Modifier.weight(1f)) { Text("✏️ Nouvelle zone") }
                            OutlinedButton(onClick = {
                                val p = MapFactory.lastKnown(ctx)
                                if (p == null) message = "Position inconnue : autorise la position et allume le GPS."
                                else {
                                    overlay.me = p
                                    mapView.controller.animateTo(GeoPoint(p.lat, p.lon))
                                    mapView.controller.setZoom(17.0)
                                    mapView.invalidate()
                                }
                            }) { Text("📍") }
                            OutlinedButton(onClick = {
                                styleIdx = (styleIdx + 1) % MapFactory.STYLES.size
                                mapView.setTileSource(MapFactory.STYLES[styleIdx].second)
                            }) { Text(MapFactory.STYLES[styleIdx].first) }
                        }
                    }

                    MapMode.DRAW -> {
                        Text("Entoure la zone avec un doigt. Pour zoomer ou déplacer la carte, utilise deux doigts.", style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(onClick = { cancelEdit() }, modifier = Modifier.fillMaxWidth()) { Text("Annuler") }
                    }

                    MapMode.EDIT -> {
                        @Suppress("UNUSED_EXPRESSION") shapeRev
                        Text(
                            "Glisse les points blancs pour corriger le contour, puis valide. « Redessiner » efface le tracé.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        ColorPicker(color) { color = it }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { cancelEdit() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
                            OutlinedButton(onClick = {
                                overlay.polygon.clear(); mode = MapMode.DRAW; mapView.invalidate()
                            }, modifier = Modifier.weight(1f)) { Text("Redessiner") }
                            Button(onClick = {
                                val poly = overlay.polygon.toList()
                                if (poly.size < 3 || Geo.areaM2(poly) < 50.0) {
                                    message = "Zone trop petite ou invalide : redessine-la."
                                } else {
                                    val id = editingId
                                    if (id == null) {
                                        val z = Zone(ZoneStore.newId(), "Zone ${zones.size + 1}", color, poly)
                                        ZoneStore.upsert(ctx, z)
                                        cancelEdit(); rev++; onChanged()
                                        onEditZone(z.id)
                                    } else {
                                        ZoneStore.byId(ctx, id)?.let { ZoneStore.upsert(ctx, it.copy(points = poly, color = color)) }
                                        cancelEdit(); rev++; onChanged()
                                    }
                                }
                            }, modifier = Modifier.weight(1f)) { Text("Valider") }
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        val sel = zones.firstOrNull { it.id == selectedId }
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer la zone ?") },
            text = { Text(sel?.name ?: "") },
            confirmButton = {
                TextButton(onClick = {
                    if (sel != null) {
                        // Si on était dedans, on remet les réglages d'avant avant d'effacer.
                        if (sel.id in ZoneStore.insideIds(ctx)) Thread { ZoneEngine.exit(ctx, sel) }.start()
                        ZoneStore.remove(ctx, sel.id)
                    }
                    selectedId = null; confirmDelete = false; rev++; onChanged()
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }

    if (showSetup) {
        AlertDialog(
            onDismissRequest = { showSetup = false },
            title = { Text("Autorisations") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { ZonesSetupCard(tick + rev) { rev++; onChanged() } } },
            confirmButton = { TextButton(onClick = { showSetup = false }) { Text("Fermer") } },
        )
    }
}
