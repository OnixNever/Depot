package com.mapcontrol.app.ui

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mapcontrol.app.core.Actions
import com.mapcontrol.app.core.ClickArm
import com.mapcontrol.app.core.ClickTargets
import com.mapcontrol.app.core.ScreenLauncher
import com.mapcontrol.app.core.ScreenTarget
import com.mapcontrol.app.core.Slots

/**
 * Trouve un écran de réglages (ex. Auto Blocker de One UI), le teste, et crée une tuile du panneau qui l'ouvre.
 * Ne modifie aucun réglage : la tuile ouvre simplement la page.
 */
@Composable
fun ScreenFinder(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf("Auto Blocker") }
    var query by remember { mutableStateOf("blocker") }
    var results by remember { mutableStateOf<List<ScreenTarget>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var click by remember { mutableStateOf(false) }

    fun search() {
        searching = true
        info = null
        Thread {
            val r = ScreenLauncher.discover(ctx, query.split(',', ' ', ';'))
            Handler(Looper.getMainLooper()).post {
                results = r
                searching = false
                if (r.isEmpty()) info = "Aucun écran trouvé pour « $query ». Essaie un autre mot : auto, secur, protect, knox…"
            }
        }.start()
    }

    fun test(t: ScreenTarget) {
        if (click) ClickTargets.forSpec(t.spec)?.let { ClickArm.armIfReady(ctx, it) }
        info = ScreenLauncher.start(ctx, t.spec).fold(
            onSuccess = { "Écran ouvert. Reviens à Map Control pour créer la tuile si c'était le bon." },
            onFailure = { it.message },
        )
    }

    fun create(t: ScreenTarget) {
        val a = Actions.add(ctx, title.trim().ifBlank { "Écran" }, "shield", emptyList(), t.spec, clickSwitch = click)
        if (a == null) {
            info = "Nombre maximum d'actions atteint (${Actions.MAX_SLOTS}). Supprime-en une."
        } else {
            Slots.setEnabled(ctx, a.slot, true)
            Slots.refreshTile(ctx, a.slot)
            Slots.requestAdd(ctx, a) { info = "« ${a.title} » créée. $it" }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onClose) { Text("← Retour") }
                Text("Trouver un écran de réglages", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Crée une tuile qui ouvre directement une page des Paramètres (par exemple Auto Blocker). " +
                        "Elle ne change aucun réglage : Samsung peut te demander ton code ou ton empreinte sur cette page.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("Nom de la tuile") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item { AutoClickCard() }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = click, onCheckedChange = { click = it })
                Text(
                    "La tuile appuie aussi sur l'interrupteur de la page (nécessite le service d'accessibilité ; vaut aussi pour « Tester »)",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        item { Text("Raccourcis sûrs", style = MaterialTheme.typography.titleMedium) }
        items(ScreenLauncher.presets, key = { it.spec }) { t -> TargetCard(t, ::test, ::create) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Chercher l'écran exact (Samsung)", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("Mot du nom de l'écran") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(onClick = { search() }, enabled = !searching, modifier = Modifier.fillMaxWidth()) {
                    Text(if (searching) "Recherche…" else "Chercher")
                }
            }
        }
        info?.let { item { Text(it, style = MaterialTheme.typography.bodyMedium) } }
        items(results, key = { it.spec }) { t -> TargetCard(t, ::test, ::create) }
    }
}

@Composable
private fun TargetCard(t: ScreenTarget, onTest: (ScreenTarget) -> Unit, onCreate: (ScreenTarget) -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(t.label, style = MaterialTheme.typography.bodyLarge)
            if (!t.exported) {
                Text(
                    "Non exporté : Android refusera probablement de l'ouvrir depuis Map Control.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onTest(t) }) { Text("Tester") }
                Button(onClick = { onCreate(t) }) { Text("Créer la tuile") }
            }
        }
    }
}
