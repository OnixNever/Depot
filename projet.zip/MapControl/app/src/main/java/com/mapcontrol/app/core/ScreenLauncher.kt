package com.mapcontrol.app.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** Un écran de réglages que l'on peut ouvrir. [spec] est stocké dans l'action : "component:pkg/classe" ou "action:android.settings.X". */
data class ScreenTarget(val label: String, val spec: String, val exported: Boolean)

/**
 * Ouvre un écran de réglages précis (ex. la page Auto Blocker de One UI) sans rien modifier :
 * l'utilisateur fait lui-même le geste (et l'authentification éventuelle demandée par Samsung).
 */
object ScreenLauncher {
    private const val COMPONENT = "component:"
    private const val ACTION = "action:"

    /** Raccourcis sûrs, présents sur tout Android : à utiliser en attendant d'avoir trouvé l'écran exact. */
    val presets: List<ScreenTarget> = listOf(
        ScreenTarget(
            "Auto Blocker (Samsung, appli « rampart »)",
            COMPONENT + "com.samsung.android.rampart/com.samsung.android.rampart.ui.MainSettingActivity",
            true,
        ),
        ScreenTarget("Sécurité et confidentialité (page parente d'Auto Blocker)", ACTION + "android.settings.SECURITY_SETTINGS", true),
        ScreenTarget("Installer des applis inconnues", ACTION + "android.settings.MANAGE_UNKNOWN_APP_SOURCES", true),
        ScreenTarget("Options pour les développeurs", ACTION + "android.settings.APPLICATION_DEVELOPMENT_SETTINGS", true),
    )

    fun intentFor(spec: String): Intent? = when {
        spec.startsWith(COMPONENT) -> {
            val cn = ComponentName.unflattenFromString(spec.removePrefix(COMPONENT))
            cn?.let { Intent().setComponent(it) }
        }
        spec.startsWith(ACTION) -> Intent(spec.removePrefix(ACTION))
        else -> null
    }?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun componentSpec(pkg: String, cls: String) = COMPONENT + ComponentName(pkg, cls).flattenToString()

    /** Ouvre l'écran depuis une Activity ou un Service. */
    fun start(ctx: Context, spec: String): Result<Unit> = runCatching {
        val i = intentFor(spec) ?: error("Raccourci invalide")
        ctx.startActivity(i)
    }.recoverCatching {
        error("Impossible d'ouvrir cet écran : ${it.message ?: it.javaClass.simpleName}")
    }

    /**
     * Cherche, dans les applis de réglages (Android + Samsung), les écrans dont le nom contient un des [keywords].
     * Bloquant (parcourt les paquets) : à appeler hors thread principal.
     */
    fun discover(ctx: Context, keywords: List<String>): List<ScreenTarget> {
        val kws = keywords.map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (kws.isEmpty()) return emptyList()
        val pm = ctx.packageManager
        val out = ArrayList<ScreenTarget>()
        val pkgs = runCatching { pm.getInstalledPackages(0) }.getOrDefault(emptyList())
            .map { it.packageName }
            .filter { p ->
                p == "com.android.settings" ||
                    (p.startsWith("com.samsung.") &&
                        listOf("setting", "secur", "knox", "sm", "guard", "rampart").any { p.contains(it) }) ||
                    // Un mot cherché qui figure dans le nom du paquet suffit (ex. « rampart »).
                    (p.startsWith("com.samsung.") && kws.any { p.lowercase().contains(it) })
            }
        for (p in pkgs) {
            val info = runCatching { pm.getPackageInfo(p, PackageManager.GET_ACTIVITIES) }.getOrNull() ?: continue
            for (a in info.activities.orEmpty()) {
                val short = a.name.substringAfterLast('.')
                if (kws.none { short.lowercase().contains(it) || a.name.lowercase().contains(it) || p.lowercase().contains(it) }) continue
                out += ScreenTarget(
                    label = "$short  ·  $p",
                    spec = componentSpec(p, a.name),
                    exported = a.exported,
                )
            }
        }
        // Les écrans ouvrables depuis une autre appli d'abord.
        return out.sortedWith(compareBy({ !it.exported }, { it.label })).take(80)
    }
}
