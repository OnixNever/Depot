package com.mapcontrol.app.ui

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mapcontrol.app.core.Actions
import com.mapcontrol.app.core.ClickArm
import com.mapcontrol.app.core.Modules
import com.mapcontrol.app.core.Perm
import com.mapcontrol.app.core.Prefs
import com.mapcontrol.app.core.SettingsScanner
import com.mapcontrol.app.core.Slots
import com.mapcontrol.app.zones.ZonePerms
import com.mapcontrol.app.zones.ZoneService
import com.mapcontrol.app.zones.ZoneStore
import androidx.compose.material3.Switch

/** Écrans de l'appli. */
private enum class Screen { HOME, ADD, SCAN, FINDER, PROBE, ZONES, ZONE_EDIT }

@Composable
fun MapControlApp() {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    var tick by remember { mutableIntStateOf(0) }
    var screen by rememberSaveable { mutableStateOf(if (SettingsScanner.hasPending(ctx)) Screen.SCAN else Screen.HOME) }
    var editId by rememberSaveable { mutableStateOf("") }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        Slots.syncAll(ctx)
        Modules.syncAll(ctx)
        // Si l'interrupteur des zones est allumé mais que le service a été tué, on le relance (l'appli est au premier plan ici).
        if (ZoneStore.masterOn(ctx) && ZonePerms.fine(ctx)) runCatching { ZoneService.start(ctx) }
        tick++
    }
    BackHandler(enabled = screen == Screen.SCAN || screen == Screen.FINDER) { screen = Screen.ADD }
    BackHandler(enabled = screen == Screen.ADD || screen == Screen.PROBE || screen == Screen.ZONES) { screen = Screen.HOME }
    BackHandler(enabled = screen == Screen.ZONE_EDIT) { screen = Screen.ZONES }

    MaterialTheme(colorScheme = scheme) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when (screen) {
                    Screen.SCAN -> ScanWizard(onClose = { screen = Screen.HOME; tick++ })
                    Screen.PROBE -> ShizukuProbe(onClose = { screen = Screen.HOME })
                    Screen.ZONES -> ZonesScreen(
                        tick = tick,
                        onClose = { screen = Screen.HOME; tick++ },
                        onEditZone = { editId = it; screen = Screen.ZONE_EDIT },
                        onChanged = { tick++ },
                    )
                    Screen.ZONE_EDIT -> ZoneEditor(editId, onClose = { screen = Screen.ZONES; tick++ })
                    Screen.FINDER -> ScreenFinder(onClose = { screen = Screen.HOME; tick++ })
                    Screen.ADD -> AddTileHub(
                        onClose = { screen = Screen.HOME },
                        onScan = { screen = Screen.SCAN },
                        onScreen = { screen = Screen.FINDER },
                    )
                    Screen.HOME -> Home(
                        tick = tick,
                        onChanged = { tick++ },
                        onAdd = { screen = Screen.ADD },
                        onProbe = { screen = Screen.PROBE },
                        onZones = { screen = Screen.ZONES },
                    )
                }
            }
        }
    }
}

@Composable
private fun Home(tick: Int, onChanged: () -> Unit, onAdd: () -> Unit, onProbe: () -> Unit, onZones: () -> Unit) {
    val ctx = LocalContext.current
    val modules = remember(tick) { Modules.visible(ctx) }
    val removed = remember(tick) { Modules.removed(ctx) }
    val actions = remember(tick) { Actions.all(ctx) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { Header() }
        item { ZonesCard(tick, onZones, onChanged) }
        item { ZonesJournal(tick, onChanged) }
        item { SetupCard(tick, onChanged) }

        item {
            SectionTitle("Mes tuiles", "Chaque carte est une tuile du panneau rapide. « Ajouter au panneau » la place pour toi.")
        }
        items(modules, key = { "m_" + it.id }) { ModuleCard(it, tick, onChanged) }
        items(actions, key = { "a_" + it.id }) { ActionCard(it, tick, onChanged) }
        item {
            Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("＋ Ajouter une tuile") }
        }

        if (removed.isNotEmpty()) {
            item { SectionTitle("Modules supprimés", "Rétablis un module pour retrouver sa tuile.") }
            items(removed, key = { "r_" + it.id }) { m ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(Prefs.title(ctx, m), style = MaterialTheme.typography.titleMedium)
                            Text(m.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { Modules.setRemoved(ctx, m, false); onChanged() }) { Text("Rétablir") }
                    }
                }
            }
        }

        item { SectionTitle("Outils") }
        item {
            OutlinedButton(onClick = onProbe, modifier = Modifier.fillMaxWidth()) {
                Text("🔎 Sonde Shizuku (trouver où est un réglage)")
            }
        }
    }
}

@Composable
private fun Header() {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text("Map Control", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(
            "Tes zones et tes réglages, en un geste.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Ce qu'il faut activer une fois pour que tout marche. Se replie quand tout est prêt. */
@Composable
private fun SetupCard(tick: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val perm = remember(tick) { Perm.granted(ctx) }
    val access = remember(tick) { ClickArm.enabled(ctx) }
    var showPerm by remember { mutableStateOf(false) }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (perm && access) "Tout est prêt ✓" else "À configurer (une seule fois)",
                style = MaterialTheme.typography.titleMedium,
            )
            StatusRow(
                ok = perm,
                title = "Modifier les réglages",
                detail = "Pour le DNS et les tuiles « réglage on/off ». Accordé une fois via Shizuku, puis Shizuku peut s'arrêter.",
                actionLabel = if (showPerm) "Masquer" else "Configurer",
                onAction = { showPerm = !showPerm },
            )
            AnimatedVisibility(!perm && showPerm) { PermissionSetup { onChanged() } }
            StatusRow(
                ok = access,
                title = "Service d'accessibilité",
                detail = "Pour la tuile Auto Blocker (clic automatique sur l'interrupteur). Limité à cette appli.",
                actionLabel = "Activer",
                onAction = {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
            )
            if (!access) {
                Text(
                    "Si Android grise l'option : Paramètres → Applis → Map Control → ⋮ → « Autoriser les paramètres restreints », puis recommence.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}


/** Raccourci vers la carte + interrupteur principal des zones. */
@Composable
private fun ZonesCard(tick: Int, onOpen: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val zones = remember(tick) { ZoneStore.all(ctx) }
    var on by remember(tick) { mutableStateOf(ZoneStore.masterOn(ctx)) }
    val gps = remember(tick) { ZoneService.gpsOn(ctx) }
    val inside = remember(tick) { ZoneStore.insideIds(ctx) }
    val status = when {
        !on -> "Surveillance coupée"
        !gps -> "GPS coupé : zones en pause"
        else -> {
            val names = zones.filter { it.id in inside }.map { it.name }
            if (names.isEmpty()) "Actif · hors zone" else "Dans : " + names.joinToString(", ")
        }
    }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("🗺 Carte & zones", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "${zones.size} zone(s) · $status",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (on && gps) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = on, onCheckedChange = { want ->
                    if (want && !ZonePerms.fine(ctx)) {
                        onOpen()
                    } else {
                        ZoneStore.setMasterOn(ctx, want)
                        if (want) runCatching { ZoneService.start(ctx) } else ZoneService.stop(ctx)
                        on = want
                        onChanged()
                    }
                })
            }
            Text(
                "Les zones ne tournent que si cet interrupteur et le GPS du téléphone sont allumés. Les tuiles marchent dans tous les cas.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) { Text("Ouvrir la carte") }
        }
    }
}

/** Derniers événements des zones (entrées, sorties, réglages réussis ou refusés). */
@Composable
private fun ZonesJournal(tick: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val lines = remember(tick) { ZoneStore.journal(ctx) }
    if (lines.isEmpty()) return
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Journal des zones", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { ZoneStore.clearJournal(ctx); onChanged() }) { Text("Effacer") }
            }
            lines.take(10).forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
