package com.mapcontrol.app.modules

import android.content.Context
import android.service.quicksettings.TileService
import com.mapcontrol.app.core.ModuleState
import com.mapcontrol.app.core.SwitchModule
import com.mapcontrol.app.core.TileLaunch
import com.mapcontrol.app.tiles.ZonesTileService
import com.mapcontrol.app.zones.ZonePerms
import com.mapcontrol.app.zones.ZoneService
import com.mapcontrol.app.zones.ZoneStore

/**
 * Interrupteur principal des zones. Les zones ne tournent que si cet interrupteur ET le GPS du téléphone sont allumés ;
 * les autres tuiles (DNS, Auto Blocker…) marchent dans tous les cas.
 */
object ZonesModule : SwitchModule {
    override val id = "zones"
    override val defaultTitle = "Zones"
    override val defaultIcon = "map"
    override val tileService = ZonesTileService::class.java
    override val description = "Active ou coupe la surveillance des zones dessinées sur la carte."

    override fun isReady(ctx: Context) = ZonePerms.fine(ctx) && ZoneStore.all(ctx).isNotEmpty()

    override fun current(ctx: Context): ModuleState {
        if (!ZoneStore.masterOn(ctx)) return ModuleState("Désactivé", false)
        if (!ZoneService.gpsOn(ctx)) return ModuleState("GPS coupé", false)
        val inside = ZoneStore.insideIds(ctx)
        val names = ZoneStore.all(ctx).filter { it.id in inside }.map { it.name }
        return ModuleState(if (names.isEmpty()) "Actif · hors zone" else "Dans : " + names.first(), true)
    }

    override fun toggle(ctx: Context): Result<ModuleState> = runCatching {
        check(ZonePerms.fine(ctx)) { "Autorisation de position manquante" }
        val on = !ZoneStore.masterOn(ctx)
        ZoneStore.setMasterOn(ctx, on)
        if (on) ZoneService.start(ctx) else ZoneService.stop(ctx)
        current(ctx)
    }

    /** Depuis la tuile : si Android refuse de lancer le service d'ici, on ouvre l'appli (où l'interrupteur marche toujours). */
    override fun tileClick(service: TileService): Boolean {
        if (!isReady(service)) return false
        val turnOn = !ZoneStore.masterOn(service)
        ZoneStore.setMasterOn(service, turnOn)
        if (turnOn) {
            val ok = runCatching { ZoneService.start(service) }.isSuccess
            if (!ok) {
                ZoneStore.setMasterOn(service, false)
                TileLaunch.openApp(service)
            }
        } else {
            ZoneService.stop(service)
        }
        return true
    }
}
