package com.mapcontrol.app.zones

import java.util.UUID

/** Que faire à la sortie de la zone pour un réglage. */
enum class ExitMode { RESTORE, SET, NOTHING }

/**
 * Un réglage appliqué par une zone.
 * [enter] : valeur à l'entrée (null = ne rien changer). [exitMode] : à la sortie, revenir à l'état d'avant, appliquer [exit], ou rien.
 * [param] : paramètre propre au type (réglage libre « table|nom », id d'une action apprise…).
 */
data class ZoneAction(
    val type: String,
    val enter: String?,
    val exitMode: ExitMode = ExitMode.RESTORE,
    val exit: String? = null,
    val param: String? = null,
    val id: String = UUID.randomUUID().toString().take(8),
)

/**
 * Horaire d'activation d'une zone. Sans horaire (null), la zone est active en permanence.
 * [days] : jours actifs, 1 = lundi … 7 = dimanche (ISO). [startMin]/[endMin] : minutes depuis minuit.
 * Si [allDay], l'heure est ignorée (jours seulement). Si [endMin] <= [startMin], la plage passe minuit
 * (ex. 22:00 → 06:00) et la partie après minuit compte pour le jour où la plage a commencé.
 */
data class Schedule(
    val days: Set<Int> = (1..7).toSet(),
    val allDay: Boolean = true,
    val startMin: Int = 8 * 60,
    val endMin: Int = 18 * 60,
) {
    fun isActive(now: java.util.Calendar = java.util.Calendar.getInstance()): Boolean {
        val dow = ((now.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7) + 1 // Calendar : dim=1 → ISO : lun=1 … dim=7
        if (allDay) return dow in days
        val m = now.get(java.util.Calendar.HOUR_OF_DAY) * 60 + now.get(java.util.Calendar.MINUTE)
        if (startMin == endMin) return dow in days
        return if (startMin < endMin) dow in days && m >= startMin && m < endMin
        else {
            val yesterday = if (dow == 1) 7 else dow - 1
            (dow in days && m >= startMin) || (yesterday in days && m < endMin)
        }
    }

    /** Résumé court : « Lun–Ven · 08:00–18:00 ». */
    fun describe(): String {
        val names = listOf("Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
        val d = days.sorted()
        val dayTxt = when {
            d.size == 7 -> "Tous les jours"
            d.isEmpty() -> "Aucun jour"
            d.size > 2 && d == (d.first()..d.last()).toList() -> "${names[d.first() - 1]}–${names[d.last() - 1]}"
            else -> d.joinToString(", ") { names[it - 1] }
        }
        fun hm(x: Int) = "%02d:%02d".format(x / 60, x % 60)
        return if (allDay) dayTxt else "$dayTxt · ${hm(startMin)}–${hm(endMin)}"
    }
}

data class Zone(
    val id: String,
    val name: String,
    val color: Int,
    val points: List<GeoPt>,
    val enabled: Boolean = true,
    val actions: List<ZoneAction> = emptyList(),
    /** null = active tout le temps (défaut). */
    val schedule: Schedule? = null,
) {
    /** Zone allumée ET dans son créneau d'activation. */
    fun activeNow(now: java.util.Calendar = java.util.Calendar.getInstance()): Boolean =
        enabled && (schedule?.isActive(now) ?: true)
}

object ZoneColors {
    val PALETTE: List<Int> = listOf(
        0xFF1F6FEB, 0xFFE5484D, 0xFF30A46C, 0xFFF5A524, 0xFF8E4EC6,
        0xFF00A2C7, 0xFFE93D82, 0xFF6E56CF, 0xFF7C6A3C, 0xFF687076,
    ).map { it.toInt() }
}
