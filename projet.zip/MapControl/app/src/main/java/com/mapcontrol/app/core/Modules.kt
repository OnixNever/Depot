package com.mapcontrol.app.core

import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.TileService
import com.mapcontrol.app.modules.AutoBlockerModule
import com.mapcontrol.app.modules.DnsModule
import com.mapcontrol.app.modules.ZonesModule

object Modules {
    /** Registre : ajouter ici chaque nouveau module. */
    val all: List<SwitchModule> = listOf(ZonesModule, DnsModule, AutoBlockerModule)

    fun byId(id: String) = all.firstOrNull { it.id == id }

    fun visible(ctx: Context): List<SwitchModule> {
        val gone = Prefs.removedModules(ctx)
        return all.filter { it.id !in gone }
    }

    fun removed(ctx: Context): List<SwitchModule> {
        val gone = Prefs.removedModules(ctx)
        return all.filter { it.id in gone }
    }

    /** Supprime (ou rétablit) un module : sa tuile disparaît (ou redevient disponible) dans l'éditeur du panneau. */
    fun setRemoved(ctx: Context, m: SwitchModule, removed: Boolean) {
        Prefs.setModuleRemoved(ctx, m.id, removed)
        applyEnabled(ctx, m)
    }

    /** Aligne l'état des tuiles intégrées sur les modules supprimés. */
    fun syncAll(ctx: Context) = all.forEach { applyEnabled(ctx, it) }

    private fun applyEnabled(ctx: Context, m: SwitchModule) {
        val on = m.id !in Prefs.removedModules(ctx)
        runCatching {
            ctx.packageManager.setComponentEnabledSetting(
                ComponentName(ctx, m.tileService),
                if (on) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }

    /** Demande au système de rafraîchir la tuile (nom, icône, état). */
    fun refreshTile(ctx: Context, module: SwitchModule) {
        runCatching { TileService.requestListeningState(ctx, ComponentName(ctx, module.tileService)) }
    }

    /** Android 13+ : affiche la demande « Ajouter la tuile ? » ; sinon explique où la glisser. */
    fun requestAdd(ctx: Context, m: SwitchModule, onResult: (String) -> Unit) {
        val title = Prefs.title(ctx, m)
        if (Build.VERSION.SDK_INT < 33) {
            onResult("Déroule le panneau, appuie sur ✎ (modifier) et glisse la tuile « $title » dans le panneau.")
            return
        }
        try {
            val sbm = ctx.getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                ComponentName(ctx, m.tileService),
                title,
                Icon.createWithResource(ctx, Prefs.iconRes(ctx, m)),
                ctx.mainExecutor,
            ) { result: Int ->
                onResult(
                    when (result) {
                        2 -> "Tuile ajoutée au panneau ✓"
                        1 -> "La tuile est déjà dans ton panneau."
                        else -> "Tuile non ajoutée. Panneau → ✎ → glisse « $title »."
                    }
                )
            }
        } catch (t: Throwable) {
            onResult("Ajout automatique impossible. Panneau → ✎ → glisse « $title ».")
        }
    }
}
