package com.mapcontrol.app.core

import android.content.Context
import android.net.Uri
import android.provider.Settings
import org.json.JSONObject
import java.io.File

/** Un réglage qui a changé entre deux scans. */
data class Change(
    val table: String,
    val name: String,
    val before: String?,
    val after: String?,
    /** Probablement un compteur / horodatage qui bouge tout seul. */
    val noisy: Boolean,
) {
    val id get() = "$table/$name"

    /** Ressemble à un interrupteur (0/1, on/off, true/false). */
    val switchLike: Boolean
        get() {
            val a = (before ?: "0").lowercase()
            val b = (after ?: "0").lowercase()
            val set = setOf(a, b)
            return set == setOf("0", "1") || set == setOf("on", "off") || set == setOf("true", "false")
        }
}

/**
 * Lit les trois tables de réglages Android (global, secure, system) et compare deux photos.
 * Seuls les réglages stockés dans ces tables sont détectables (voir README).
 */
object SettingsScanner {
    val TABLES = listOf("global", "secure", "system")

    private fun uri(table: String): Uri = when (table) {
        "global" -> Settings.Global.CONTENT_URI
        "secure" -> Settings.Secure.CONTENT_URI
        else -> Settings.System.CONTENT_URI
    }

    /** Photo de tous les réglages lisibles : clé "table/nom" -> valeur. */
    fun snapshot(ctx: Context): Map<String, String?> {
        val out = HashMap<String, String?>(4096)
        for (t in TABLES) {
            try {
                ctx.contentResolver.query(uri(t), arrayOf("name", "value"), null, null, null)?.use { c ->
                    val ni = c.getColumnIndex("name")
                    val vi = c.getColumnIndex("value")
                    if (ni >= 0 && vi >= 0) {
                        while (c.moveToNext()) out["$t/${c.getString(ni)}"] = c.getString(vi)
                    }
                }
            } catch (_: Throwable) {
            }
        }
        return out
    }

    fun read(ctx: Context, table: String, name: String): String? = runCatching {
        val cr = ctx.contentResolver
        when (table) {
            "global" -> Settings.Global.getString(cr, name)
            "secure" -> Settings.Secure.getString(cr, name)
            else -> Settings.System.getString(cr, name)
        }
    }.getOrNull()

    // Entrées de journalisation/métadonnées : elles ne pilotent pas une fonction utilisateur.
    private val DENY = setOf(
        "device_provisioned", "user_setup_complete",
        "setting_change_history", "settings_change_history"
    )

    private fun isMetadataKey(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("setting_change_history") ||
            n.contains("settings_change_history") ||
            n.contains("change_history") ||
            n.endsWith("_history")
    }

    fun write(ctx: Context, table: String, name: String, value: String?): Result<Unit> = runCatching {
        check(table in TABLES) { "Table Android non prise en charge : $table" }
        check(name.isNotBlank()) { "Nom de réglage vide" }
        check(name !in DENY && !isMetadataKey(name)) { "Entrée d’historique/métadonnée refusée : $name" }
        val cr = ctx.contentResolver
        val ok = when (table) {
            "global" -> Settings.Global.putString(cr, name, value)
            "secure" -> Settings.Secure.putString(cr, name, value)
            "system" -> Settings.System.putString(cr, name, value)
            else -> false
        }
        check(ok) { "Android a refusé l’écriture de « $name » ($table)." }

        // Ne jamais annoncer un succès uniquement parce que putString() a renvoyé true.
        // Relire la valeur stockée permet de détecter les écritures ignorées ou réécrites.
        val actual = read(ctx, table, name)
        check(actual == value) {
            "Écriture non confirmée pour « $name » ($table) : demandé « ${value ?: "(absent)"} », " +
                "valeur relue « ${actual ?: "(absent)"} ». Ce réglage peut être protégé ou contrôlé par un service système."
        }
    }

    // ---- Scan en deux temps, conservé sur disque (l'appli peut être tuée pendant qu'on est dans les Paramètres) ----

    private fun beforeFile(ctx: Context) = File(ctx.filesDir, "scan_before.json")
    private fun volatileFile(ctx: Context) = File(ctx.filesDir, "scan_volatile.json")

    fun hasPending(ctx: Context) = beforeFile(ctx).exists()

    fun clearPending(ctx: Context) {
        beforeFile(ctx).delete(); volatileFile(ctx).delete()
    }

    /**
     * Étape 1 : photo « avant ». On en prend une seconde ~1,5 s plus tard : les réglages qui bougent
     * tout seuls entre les deux (compteurs, horloges) sont mémorisés comme bruit. Bloquant : à appeler hors thread principal.
     */
    fun startScan(ctx: Context): Int {
        val a = snapshot(ctx)
        Thread.sleep(1500)
        val b = snapshot(ctx)
        val volatile = (a.keys + b.keys).filter { a[it] != b[it] }
        val o = JSONObject()
        for ((k, v) in a) o.put(k, v ?: JSONObject.NULL)
        beforeFile(ctx).writeText(o.toString())
        volatileFile(ctx).writeText(volatile.joinToString("\n"))
        return a.size
    }

    /** Étape 2 : photo « après » et comparaison avec « avant ». Bloquant. */
    fun detect(ctx: Context): List<Change> {
        val f = beforeFile(ctx)
        if (!f.exists()) return emptyList()
        val o = JSONObject(f.readText())
        val before = HashMap<String, String?>()
        for (k in o.keys()) before[k] = if (o.isNull(k)) null else o.getString(k)
        val volatile = volatileFile(ctx).takeIf { it.exists() }?.readLines()?.toSet() ?: emptySet()
        val after = snapshot(ctx)
        return diff(before, after, volatile)
    }

    private val NOISE_NAME = Regex("""(timestamp|_time_ms|_millis|last_|_last|uptime|elapsed|nonce|counter|_count$|^count_)""")
    private val EPOCH = Regex("""^\d{12,}$""")

    fun diff(before: Map<String, String?>, after: Map<String, String?>, volatile: Set<String>): List<Change> {
        val out = ArrayList<Change>()
        for (k in before.keys + after.keys) {
            val b = before[k]
            val a = after[k]
            if ((b ?: "") == (a ?: "")) continue
            val slash = k.indexOf('/')
            if (slash < 0) continue
            val table = k.substring(0, slash)
            val name = k.substring(slash + 1)
            // Ne jamais proposer une entrée de journal comme action à basculer.
            if (isMetadataKey(name)) continue
            val noisy = k in volatile ||
                NOISE_NAME.containsMatchIn(name) ||
                (b != null && a != null && EPOCH.matches(b) && EPOCH.matches(a))
            out += Change(table, name, b, a, noisy)
        }
        // Interrupteurs d'abord, puis le reste, puis le bruit ; ordre alphabétique à égalité.
        return out.sortedWith(
            compareBy<Change>({ if (it.noisy) 2 else if (it.switchLike) 0 else 1 }, { it.id })
        )
    }
}
