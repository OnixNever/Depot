package com.mapcontrol.app.modules

import android.content.ComponentName
import android.content.Context
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mapcontrol.app.core.ClickArm
import com.mapcontrol.app.core.ClickTargets
import com.mapcontrol.app.core.ModuleState
import com.mapcontrol.app.core.Prefs
import com.mapcontrol.app.core.ScreenLauncher
import com.mapcontrol.app.core.SwitchModule
import com.mapcontrol.app.core.TileLaunch
import com.mapcontrol.app.tiles.AutoBlockerTileService
import com.mapcontrol.app.ui.AutoClickCard

/**
 * Bascule d'Auto Blocker (Samsung). Android ne laisse pas une appli le changer directement : la tuile ouvre
 * la page, le service d'accessibilité appuie sur l'interrupteur, tu valides ton schéma, et la page se referme.
 */
object AutoBlockerModule : SwitchModule {
    override val id = "autoblocker"
    override val defaultTitle = "Auto Blocker"
    override val defaultIcon = "shield"
    override val tileService = AutoBlockerTileService::class.java
    override val description = "Bascule l'Auto Blocker de Samsung depuis le panneau."

    private val spec = ScreenLauncher.componentSpec(
        ClickTargets.autoBlocker.pkg,
        "com.samsung.android.rampart.ui.MainSettingActivity",
    )

    override fun isReady(ctx: Context) = ClickArm.enabled(ctx)

    override fun current(ctx: Context): ModuleState {
        if (!isReady(ctx)) return ModuleState("Configuration requise", false)
        return when (Prefs.autoBlockerState(ctx)) {
            true -> ModuleState("Activé", true)
            false -> ModuleState("Désactivé", false)
            null -> ModuleState("Appuie pour basculer", false)
        }
    }

    /** Appelé par le service chaque fois qu'il voit l'interrupteur : garde la tuile à jour. */
    fun rememberState(ctx: Context, on: Boolean) {
        if (Prefs.autoBlockerState(ctx) == on) return
        Prefs.setAutoBlockerState(ctx, on)
        runCatching { TileService.requestListeningState(ctx, ComponentName(ctx, AutoBlockerTileService::class.java)) }
    }

    override fun tileClick(service: TileService): Boolean {
        if (!isReady(service)) return false
        ClickArm.armIfReady(service, ClickTargets.autoBlocker)
        if (!TileLaunch.open(service, spec)) {
            Toast.makeText(service, "Page Auto Blocker introuvable sur ce téléphone", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    override fun toggle(ctx: Context): Result<ModuleState> = runCatching {
        check(isReady(ctx)) { "Active d'abord le service d'accessibilité : voir « Personnaliser »." }
        ClickArm.armIfReady(ctx, ClickTargets.autoBlocker)
        ScreenLauncher.start(ctx, spec).getOrThrow()
        current(ctx)
    }

    @Composable
    override fun Extra(onChanged: () -> Unit) {
        val ctx = LocalContext.current
        var close by remember { mutableStateOf(Prefs.autoClose(ctx)) }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Refermer la page une fois l'interrupteur basculé",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = close, onCheckedChange = { close = it; Prefs.setAutoClose(ctx, it); onChanged() })
            }
            AutoClickCard()
        }
    }
}
