package com.mapcontrol.app.core

import android.content.Context
import com.mapcontrol.app.R

/** Icônes proposées pour les tuiles. */
object IconChoices {
    val all: List<Pair<String, Int>> = listOf(
        "globe" to R.drawable.ic_globe,
        "shield" to R.drawable.ic_shield,
        "lock" to R.drawable.ic_lock,
        "wifi" to R.drawable.ic_wifi,
        "bolt" to R.drawable.ic_bolt,
        "swap" to R.drawable.ic_swap,
        "moon" to R.drawable.ic_moon,
        "sun" to R.drawable.ic_sun,
        "bell" to R.drawable.ic_bell,
        "bulb" to R.drawable.ic_bulb,
        "eye" to R.drawable.ic_eye,
        "map" to R.drawable.ic_map,
    )
    fun res(key: String): Int = all.firstOrNull { it.first == key }?.second ?: R.drawable.ic_globe
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("switcher", Context.MODE_PRIVATE)

    fun title(c: Context, m: SwitchModule): String =
        sp(c).getString("title_${m.id}", null)?.takeIf { it.isNotBlank() } ?: m.defaultTitle
    fun rawTitle(c: Context, m: SwitchModule): String = sp(c).getString("title_${m.id}", null) ?: m.defaultTitle
    fun setTitle(c: Context, m: SwitchModule, v: String) = sp(c).edit().putString("title_${m.id}", v).apply()

    fun iconKey(c: Context, m: SwitchModule): String = sp(c).getString("icon_${m.id}", null) ?: m.defaultIcon
    fun iconRes(c: Context, m: SwitchModule): Int = IconChoices.res(iconKey(c, m))
    fun setIcon(c: Context, m: SwitchModule, key: String) = sp(c).edit().putString("icon_${m.id}", key).apply()

    fun dnsHost(c: Context): String = sp(c).getString("dns_host", "") ?: ""
    fun setDnsHost(c: Context, v: String) = sp(c).edit().putString("dns_host", v).apply()

    /** Modules intégrés que l'utilisateur a supprimés (rétablissables depuis l'accueil). */
    fun removedModules(c: Context): Set<String> = sp(c).getStringSet("removed_modules", emptySet())?.toSet() ?: emptySet()
    fun setModuleRemoved(c: Context, id: String, removed: Boolean) {
        val s = removedModules(c).toMutableSet()
        if (removed) s += id else s -= id
        sp(c).edit().putStringSet("removed_modules", s).apply()
    }

    /** Auto Blocker : refermer la page une fois l'interrupteur basculé. */
    fun autoClose(c: Context): Boolean = sp(c).getBoolean("ab_autoclose", true)
    fun setAutoClose(c: Context, v: Boolean) = sp(c).edit().putBoolean("ab_autoclose", v).apply()

    /** Dernier état d'Auto Blocker vu par le service (null = jamais vu). */
    fun autoBlockerState(c: Context): Boolean? =
        if (sp(c).contains("ab_state")) sp(c).getBoolean("ab_state", false) else null
    fun setAutoBlockerState(c: Context, on: Boolean) = sp(c).edit().putBoolean("ab_state", on).apply()
}
