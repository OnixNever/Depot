package com.mapcontrol.app.core

import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.provider.Settings

/**
 * État partagé entre les tuiles / l'appli et le service d'accessibilité [AutoClickService].
 *
 * Déroulé d'un clic : IDLE → [arm] → WAIT_PAGE (le service attend la page et appuie sur l'interrupteur)
 * → WAIT_CHANGE (il attend que l'interrupteur change, le temps que tu valides ton schéma) → IDLE.
 */
object ClickArm {
    enum class Phase { IDLE, WAIT_PAGE, WAIT_CHANGE }

    private const val PAGE_WINDOW_MS = 12_000L
    private const val CHANGE_WINDOW_MS = 25_000L

    @Volatile var lastDump: String = ""
    @Volatile var lastResult: String = ""
    @Volatile var phase: Phase = Phase.IDLE
        private set
    @Volatile var target: ClickTarget? = null
        private set
    @Volatile var closeAfter: Boolean = true
        private set
    /** État de l'interrupteur au moment du clic (pour détecter le changement). */
    @Volatile var wasChecked: Boolean = false
        private set
    @Volatile private var deadline = 0L

    private fun now() = SystemClock.elapsedRealtime()

    fun arm(t: ClickTarget, closeAfter: Boolean) {
        this.target = t
        this.closeAfter = closeAfter
        lastDump = ""
        lastResult = "En attente de la page…"
        phase = Phase.WAIT_PAGE
        deadline = now() + PAGE_WINDOW_MS
    }

    fun clicked(before: Boolean) {
        wasChecked = before
        phase = Phase.WAIT_CHANGE
        deadline = now() + CHANGE_WINDOW_MS
    }

    fun finish() { phase = Phase.IDLE }

    fun overdue() = phase != Phase.IDLE && now() > deadline

    fun active() = phase != Phase.IDLE && now() <= deadline

    /** Le service est-il activé dans les réglages d'accessibilité ? */
    fun enabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(ctx, AutoClickService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    /** Arme si le service est activé. Renvoie false sinon (la page s'ouvrira sans rien toucher). */
    fun armIfReady(ctx: Context, t: ClickTarget): Boolean {
        if (!enabled(ctx)) {
            lastResult = "Service d'accessibilité non activé : la page s'ouvre mais rien n'est touché."
            return false
        }
        arm(t, Prefs.autoClose(ctx))
        return true
    }
}
