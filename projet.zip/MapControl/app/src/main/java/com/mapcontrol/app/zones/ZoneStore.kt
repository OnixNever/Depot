package com.mapcontrol.app.zones

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Mémorise les zones, l'interrupteur principal, l'état « dedans/dehors », les valeurs d'avant et le journal. */
object ZoneStore {
    private const val NULL_MARK = "\u0000null"
    private val lock = Any()

    private fun sp(c: Context) = c.getSharedPreferences("mapcontrol_zones", Context.MODE_PRIVATE)

    private fun JSONObject.str(k: String): String? = if (!has(k) || isNull(k)) null else getString(k)

    // ---------- zones ----------
    fun all(c: Context): List<Zone> = synchronized(lock) {
        val raw = sp(c).getString("zones", null) ?: return emptyList()
        runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val pts = o.getJSONArray("points")
                val acts = o.optJSONArray("actions") ?: JSONArray()
                Zone(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    color = o.getInt("color"),
                    enabled = o.optBoolean("enabled", true),
                    schedule = o.optJSONObject("schedule")?.let { sc ->
                        val da = sc.optJSONArray("days") ?: JSONArray()
                        Schedule(
                            days = (0 until da.length()).map { da.getInt(it) }.toSet(),
                            allDay = sc.optBoolean("allDay", true),
                            startMin = sc.optInt("start", 8 * 60),
                            endMin = sc.optInt("end", 18 * 60),
                        )
                    },
                    points = (0 until pts.length()).map { j ->
                        val p = pts.getJSONArray(j); GeoPt(p.getDouble(0), p.getDouble(1))
                    },
                    actions = (0 until acts.length()).map { j ->
                        val a = acts.getJSONObject(j)
                        ZoneAction(
                            type = a.getString("type"),
                            enter = a.str("enter"),
                            exitMode = runCatching { ExitMode.valueOf(a.getString("exitMode")) }.getOrDefault(ExitMode.RESTORE),
                            exit = a.str("exit"),
                            param = a.str("param"),
                            id = a.getString("id"),
                        )
                    },
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun save(c: Context, zones: List<Zone>) = synchronized(lock) {
        val arr = JSONArray()
        for (z in zones) {
            val pts = JSONArray()
            z.points.forEach { pts.put(JSONArray().put(it.lat).put(it.lon)) }
            val acts = JSONArray()
            z.actions.forEach { a ->
                acts.put(
                    JSONObject().put("id", a.id).put("type", a.type)
                        .put("enter", a.enter ?: JSONObject.NULL)
                        .put("exitMode", a.exitMode.name)
                        .put("exit", a.exit ?: JSONObject.NULL)
                        .put("param", a.param ?: JSONObject.NULL)
                )
            }
            val o = JSONObject().put("id", z.id).put("name", z.name).put("color", z.color)
                .put("enabled", z.enabled).put("points", pts).put("actions", acts)
            z.schedule?.let { sc ->
                o.put("schedule", JSONObject()
                    .put("days", JSONArray(sc.days.sorted()))
                    .put("allDay", sc.allDay).put("start", sc.startMin).put("end", sc.endMin))
            }
            arr.put(o)
        }
        sp(c).edit().putString("zones", arr.toString()).apply()
    }

    fun byId(c: Context, id: String): Zone? = all(c).firstOrNull { it.id == id }
    fun newId(): String = "z" + System.currentTimeMillis()

    fun upsert(c: Context, z: Zone) {
        val list = all(c)
        save(c, if (list.any { it.id == z.id }) list.map { if (it.id == z.id) z else it } else list + z)
    }

    fun remove(c: Context, id: String) {
        save(c, all(c).filter { it.id != id })
        setInside(c, id, false)
        clearPrev(c, id)
    }

    // ---------- interrupteur principal ----------
    fun masterOn(c: Context): Boolean = sp(c).getBoolean("master", false)
    fun setMasterOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("master", v).apply()

    // ---------- état dedans / dehors ----------
    fun insideIds(c: Context): Set<String> = synchronized(lock) { sp(c).getStringSet("inside", emptySet())?.toSet() ?: emptySet() }
    fun setInside(c: Context, id: String, inside: Boolean) = synchronized(lock) {
        val s = insideIds(c).toMutableSet()
        if (inside) s += id else s -= id
        sp(c).edit().putStringSet("inside", s).apply()
    }

    // ---------- valeurs d'avant (pour « revenir à l'état d'avant ») ----------
    /** [value] peut être null (réglage absent) : on le retient quand même. */
    fun savePrev(c: Context, zoneKey: String, actionId: String, value: String?) =
        sp(c).edit().putString("prev_${zoneKey}_$actionId", value ?: NULL_MARK).apply()

    /** Renvoie null s'il n'y a rien de mémorisé, sinon un Pair(valeur ou null). */
    fun takePrev(c: Context, zoneKey: String, actionId: String): Pair<String?, Boolean>? {
        val k = "prev_${zoneKey}_$actionId"
        val raw = sp(c).getString(k, null) ?: return null
        sp(c).edit().remove(k).apply()
        return (if (raw == NULL_MARK) null else raw) to true
    }

    fun clearPrev(c: Context, zoneKey: String) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("prev_${zoneKey}_") }.forEach { e.remove(it) }
        e.apply()
    }

    // ---------- journal ----------
    fun log(c: Context, text: String) = synchronized(lock) {
        val stamp = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE).format(Date())
        val arr = JSONArray()
        arr.put("$stamp  $text")
        val old = sp(c).getString("journal", null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        if (old != null) for (i in 0 until minOf(old.length(), 59)) arr.put(old.getString(i))
        sp(c).edit().putString("journal", arr.toString()).apply()
    }

    fun journal(c: Context): List<String> = synchronized(lock) {
        val old = sp(c).getString("journal", null)?.let { runCatching { JSONArray(it) }.getOrNull() } ?: return emptyList()
        (0 until old.length()).map { old.getString(it) }
    }

    fun clearJournal(c: Context) = sp(c).edit().remove("journal").apply()
}
