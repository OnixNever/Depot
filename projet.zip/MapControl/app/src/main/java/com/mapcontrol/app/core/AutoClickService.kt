package com.mapcontrol.app.core

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.mapcontrol.app.modules.AutoBlockerModule

/**
 * Appuie sur l'interrupteur principal d'une page d'une autre appli (voir [ClickTargets]) quand une tuile l'a « armé ».
 * Il ne voit que les applis de la liste. Il ne contourne aucune sécurité : si Samsung demande ton schéma ou
 * ton empreinte, c'est toi qui valides. Une fois l'interrupteur basculé, il referme la page (réglable).
 * En dehors des clics, il se contente de lire l'état de l'interrupteur pour garder la tuile à jour.
 */
class AutoClickService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var scheduled = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = serviceInfo ?: return
        info.packageNames = ClickTargets.all.map { it.pkg }.toTypedArray()
        serviceInfo = info
    }

    override fun onUnbind(intent: Intent?): Boolean {
        handler.removeCallbacksAndMessages(null)
        scheduled = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (ClickTargets.byPackage(pkg) == null) return
        schedule(if (ClickArm.active()) 450 else 700)
    }

    private fun schedule(delayMs: Long) {
        if (scheduled) return
        scheduled = true
        handler.postDelayed({ scheduled = false; attempt() }, delayMs)
    }

    private fun attempt() {
        if (ClickArm.overdue()) { onTimeout(); return }
        val busy = ClickArm.active()

        val root = rootInActiveWindow
        val target = ClickTargets.byPackage(root?.packageName?.toString())
        if (root == null || target == null) { if (busy) schedule(400); return }

        val sw = pickSwitch(root, target)
        if (sw == null) {
            if (busy) { ClickArm.lastDump = dumpOf(root); schedule(400) }
            return
        }
        val checked = sw.isChecked
        if (target.id == ClickTargets.autoBlocker.id) AutoBlockerModule.rememberState(this, checked)

        when (ClickArm.phase) {
            ClickArm.Phase.WAIT_PAGE -> {
                if (ClickArm.target?.id != target.id) return
                ClickArm.lastDump = dumpOf(root)
                if (clickNode(sw)) {
                    ClickArm.clicked(checked)
                    ClickArm.lastResult = "Clic envoyé. Valide ton schéma ou ton empreinte si Samsung le demande…"
                    schedule(500)
                } else {
                    ClickArm.finish()
                    ClickArm.lastResult = "Interrupteur trouvé mais le clic a été refusé. Copie l'arbre de l'écran pour qu'on l'analyse."
                }
            }
            ClickArm.Phase.WAIT_CHANGE -> {
                if (checked != ClickArm.wasChecked) {
                    ClickArm.finish()
                    ClickArm.lastResult = "Interrupteur : ${label(ClickArm.wasChecked)} → ${label(checked)} ✓"
                    if (ClickArm.closeAfter) handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 400)
                } else {
                    schedule(400)
                }
            }
            ClickArm.Phase.IDLE -> {}
        }
    }

    private fun label(on: Boolean) = if (on) "activé" else "désactivé"

    private fun onTimeout() {
        when (ClickArm.phase) {
            ClickArm.Phase.WAIT_PAGE ->
                ClickArm.lastResult = "Temps écoulé : interrupteur introuvable. Copie l'arbre de l'écran pour qu'on l'analyse."
            ClickArm.Phase.WAIT_CHANGE ->
                ClickArm.lastResult = "Rien n'a changé (validation non faite ?). La page est laissée ouverte."
            ClickArm.Phase.IDLE -> {}
        }
        ClickArm.finish()
    }

    // --- Recherche de l'interrupteur ---

    private fun isSwitch(n: AccessibilityNodeInfo): Boolean {
        val cls = n.className?.toString().orEmpty()
        return cls.contains("Switch", ignoreCase = true) ||
            cls.contains("ToggleButton", ignoreCase = true) ||
            (n.isCheckable && !cls.contains("CheckBox", ignoreCase = true) && !cls.contains("RadioButton", ignoreCase = true))
    }

    private fun collectSwitches(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (isSwitch(n) && n.isVisibleToUser) out += n
        for (i in 0 until n.childCount) n.getChild(i)?.let { collectSwitches(it, out) }
    }

    private fun subtreeText(n: AccessibilityNodeInfo, sb: StringBuilder, depth: Int = 0) {
        if (sb.length > 600 || depth > 6) return
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) n.getChild(i)?.let { subtreeText(it, sb, depth + 1) }
    }

    private fun pickSwitch(root: AccessibilityNodeInfo, target: ClickTarget): AccessibilityNodeInfo? {
        val all = ArrayList<AccessibilityNodeInfo>()
        collectSwitches(root, all)
        if (all.isEmpty()) return null
        if (all.size == 1) return all[0]
        // Plusieurs : on préfère celui dont la ligne (parents proches) mentionne le mot-clé de la cible.
        for (s in all) {
            var p: AccessibilityNodeInfo? = s
            for (i in 0 until 3) {
                p = p?.parent ?: break
                val sb = StringBuilder()
                subtreeText(p, sb)
                if (target.keywords.any { k -> sb.toString().contains(k, ignoreCase = true) }) return s
            }
        }
        // Sinon le plus haut sur l'écran (interrupteur principal en général).
        val r = Rect()
        return all.minByOrNull { n -> n.getBoundsInScreen(r); r.top }
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 5) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    // --- Diagnostic : arbre de l'écran (pour comprendre si le clic échoue) ---

    private fun dumpOf(root: AccessibilityNodeInfo): String = StringBuilder().also { dump(root, 0, it) }.toString()

    private fun dump(n: AccessibilityNodeInfo, depth: Int, sb: StringBuilder) {
        if (sb.length > 12_000) return
        val r = Rect()
        n.getBoundsInScreen(r)
        sb.append("  ".repeat(depth))
            .append(n.className?.toString()?.substringAfterLast('.') ?: "?")
            .append(" id=").append(n.viewIdResourceName?.substringAfter(":id/") ?: "-")
        n.text?.let { sb.append(" text=\"").append(it).append('"') }
        n.contentDescription?.let { sb.append(" desc=\"").append(it).append('"') }
        if (n.isCheckable) sb.append(" checkable checked=").append(n.isChecked)
        if (n.isClickable) sb.append(" clickable")
        if (!n.isEnabled) sb.append(" disabled")
        sb.append(" [").append(r.left).append(',').append(r.top).append(',').append(r.right).append(',').append(r.bottom).append("]\n")
        for (i in 0 until n.childCount) n.getChild(i)?.let { dump(it, depth + 1, sb) }
    }
}
