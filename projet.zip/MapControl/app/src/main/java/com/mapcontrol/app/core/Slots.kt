package com.mapcontrol.app.core

import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.TileService

/** Gère les emplacements de tuiles : un emplacement n'apparaît dans l'éditeur du panneau que s'il est utilisé. */
object Slots {
    fun component(ctx: Context, slot: Int) =
        ComponentName(ctx.packageName, "com.mapcontrol.app.tiles.Slot${slot}Tile")

    fun setEnabled(ctx: Context, slot: Int, enabled: Boolean) {
        runCatching {
            ctx.packageManager.setComponentEnabledSetting(
                component(ctx, slot),
                if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }

    /** Aligne l'état des emplacements sur les actions existantes. */
    fun syncAll(ctx: Context) {
        val used = Actions.all(ctx).map { it.slot }.toSet()
        for (s in 1..Actions.MAX_SLOTS) setEnabled(ctx, s, s in used)
    }

    fun refreshTile(ctx: Context, slot: Int) {
        runCatching { TileService.requestListeningState(ctx, component(ctx, slot)) }
    }

    /**
     * Android 13+ : affiche la demande « Ajouter la tuile ? » directement.
     * [onResult] reçoit un message prêt à afficher.
     */
    fun requestAdd(ctx: Context, a: SwitchAction, onResult: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < 33) {
            onResult("Déroule le panneau, appuie sur ✎ (modifier) et glisse la tuile « Tuile ${a.slot} » dans le panneau.")
            return
        }
        try {
            val sbm = ctx.getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                component(ctx, a.slot),
                a.title,
                Icon.createWithResource(ctx, IconChoices.res(a.icon)),
                ctx.mainExecutor,
            ) { result: Int ->
                onResult(
                    when (result) {
                        2 -> "Tuile ajoutée au panneau ✓"
                        1 -> "La tuile est déjà dans ton panneau."
                        0 -> "Tuile non ajoutée. Tu peux l'ajouter à la main : panneau → ✎ → « Tuile ${a.slot} »."
                        else -> "Ajout automatique impossible. Panneau → ✎ → glisse « Tuile ${a.slot} »."
                    }
                )
            }
        } catch (t: Throwable) {
            onResult("Ajout automatique impossible. Panneau → ✎ → glisse « Tuile ${a.slot} ».")
        }
    }
}
