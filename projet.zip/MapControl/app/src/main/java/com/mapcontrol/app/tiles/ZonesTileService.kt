package com.mapcontrol.app.tiles

import com.mapcontrol.app.core.SwitchModule
import com.mapcontrol.app.modules.ZonesModule

class ZonesTileService : BaseTileService() {
    override val module: SwitchModule = ZonesModule
}
