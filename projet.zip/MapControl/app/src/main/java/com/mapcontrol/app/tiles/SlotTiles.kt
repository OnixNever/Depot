package com.mapcontrol.app.tiles

// Générés : un emplacement de tuile par classe (le système exige une classe déclarée par tuile).
class Slot1Tile : SlotTileService() { override val slot = 1 }
class Slot2Tile : SlotTileService() { override val slot = 2 }
class Slot3Tile : SlotTileService() { override val slot = 3 }
class Slot4Tile : SlotTileService() { override val slot = 4 }
class Slot5Tile : SlotTileService() { override val slot = 5 }
class Slot6Tile : SlotTileService() { override val slot = 6 }
class Slot7Tile : SlotTileService() { override val slot = 7 }
class Slot8Tile : SlotTileService() { override val slot = 8 }
class Slot9Tile : SlotTileService() { override val slot = 9 }
class Slot10Tile : SlotTileService() { override val slot = 10 }
class Slot11Tile : SlotTileService() { override val slot = 11 }
class Slot12Tile : SlotTileService() { override val slot = 12 }
