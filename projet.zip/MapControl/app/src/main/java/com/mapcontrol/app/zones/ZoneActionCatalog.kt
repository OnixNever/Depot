package com.mapcontrol.app.zones

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.provider.Settings
import com.mapcontrol.app.core.Actions
import com.mapcontrol.app.core.Prefs
import com.mapcontrol.app.core.SettingsScanner
import com.mapcontrol.app.core.ShizukuHelper
import kotlin.math.roundToInt

/** Forme de la valeur d'un réglage (détermine l'éditeur affiché). */
enum class Kind { SWITCH, PERCENT, CHOICE, TEXT, APP, SETTING, LEARNED }

/** Ce qu'il faut pour que le réglage marche. */
enum class Need { NONE, SECURE, DND, SHIZUKU }

/**
 * Un réglage que les zones peuvent appliquer.
 * Convention des valeurs (toujours du texte) : SWITCH « 1 »/« 0 », PERCENT « 0 »..« 100 », CHOICE la clé du choix,
 * TEXT le texte, APP le nom de paquet, SETTING le texte à écrire (le réglage est dans le paramètre « table|nom »),
 * LEARNED « 1 »/« 0 » (le paramètre est l'id d'une action apprise par le scanner).
 */
class ZoneActionType(
    val id: String,
    val category: String,
    val title: String,
    val kind: Kind,
    val need: Need = Need.NONE,
    val choices: List<Pair<String, String>> = emptyList(),
    val note: String? = null,
    /** Vrai si « absent » est une valeur qu'on peut restaurer (réglages Android). */
    val nullRestorable: Boolean = false,
    val read: (Context, String?) -> String? = { _, _ -> null },
    val doApply: (Context, String?, String?) -> Result<Unit>,
) {
    fun defaultValue(param: String?): String = when (kind) {
        Kind.SWITCH, Kind.LEARNED -> "1"
        Kind.PERCENT -> "50"
        Kind.CHOICE -> choices.firstOrNull()?.first ?: ""
        else -> ""
    }

    fun describe(ctx: Context, value: String?, param: String?): String = when {
        value == null -> "—"
        kind == Kind.SWITCH -> if (value == "1") "Activé" else "Désactivé"
        kind == Kind.LEARNED -> {
            val a = Actions.all(ctx).firstOrNull { it.id == param }
            (a?.title ?: "Action") + " : " + (if (value == "1") "activé" else "désactivé")
        }
        kind == Kind.PERCENT -> "$value %"
        kind == Kind.CHOICE -> choices.firstOrNull { it.first == value }?.second ?: value
        kind == Kind.APP -> runCatching {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(value, 0)).toString()
        }.getOrDefault(value)
        kind == Kind.SETTING -> "${param ?: "?"} = $value"
        else -> "« $value »"
    }
}

object ZoneCatalog {
    private inline fun ok(block: () -> Unit): Result<Unit> = runCatching { block() }

    private fun audio(c: Context) = c.getSystemService(AudioManager::class.java)
    private fun nm(c: Context) = c.getSystemService(NotificationManager::class.java)

    // ---------- fabriques ----------
    private fun volume(id: String, title: String, stream: Int, need: Need = Need.NONE) = ZoneActionType(
        id, "Son", title, Kind.PERCENT, need,
        read = { c, _ ->
            val a = audio(c); val max = a.getStreamMaxVolume(stream)
            if (max <= 0) null else (a.getStreamVolume(stream) * 100f / max).roundToInt().toString()
        },
        doApply = { c, v, _ ->
            ok {
                val a = audio(c); val max = a.getStreamMaxVolume(stream)
                val pct = (v?.toIntOrNull() ?: error("Valeur manquante")).coerceIn(0, 100)
                a.setStreamVolume(stream, (max * pct / 100f).roundToInt(), 0)
            }
        },
    )

    /** Réglage Android qui vaut 1/0 (ou [on]/[off]). */
    private fun sw(
        id: String, cat: String, title: String, table: String, name: String,
        on: String = "1", off: String = "0", note: String? = null,
    ) = ZoneActionType(
        id, cat, title, Kind.SWITCH, Need.SECURE, note = note, nullRestorable = true,
        read = { c, _ -> SettingsScanner.read(c, table, name)?.let { if (it == off || it == "0") "0" else "1" } },
        doApply = { c, v, _ -> SettingsScanner.write(c, table, name, if (v == "1") on else off) },
    )

    private fun choiceSetting(
        id: String, cat: String, title: String, table: String, name: String,
        choices: List<Pair<String, String>>, note: String? = null,
    ) = ZoneActionType(
        id, cat, title, Kind.CHOICE, Need.SECURE, choices, note, nullRestorable = true,
        read = { c, _ -> SettingsScanner.read(c, table, name) },
        doApply = { c, v, _ -> SettingsScanner.write(c, table, name, v) },
    )

    private fun shellSwitch(
        id: String, title: String, cmdOn: String, cmdOff: String, current: (Context) -> Boolean?,
    ) = ZoneActionType(
        id, "Connexions (Shizuku)", title, Kind.SWITCH, Need.SHIZUKU,
        note = "Android interdit ce réglage à une appli normale : il passe par Shizuku, qui doit donc tourner à ce moment-là.",
        read = { c, _ -> current(c)?.let { if (it) "1" else "0" } },
        doApply = { _, v, _ -> ShizukuHelper.runShellSync(if (v == "1") cmdOn else cmdOff).map { } },
    )

    private fun globalInt(c: Context, name: String): Int? =
        runCatching { Settings.Global.getInt(c.contentResolver, name) }.getOrNull()

    val all: List<ZoneActionType> = listOf(
        // ===== Son =====
        ZoneActionType(
            "ringer", "Son", "Mode de sonnerie", Kind.CHOICE, Need.DND,
            choices = listOf("2" to "Sonnerie", "1" to "Vibreur", "0" to "Silencieux"),
            read = { c, _ -> audio(c).ringerMode.toString() },
            doApply = { c, v, _ -> ok { audio(c).ringerMode = v?.toIntOrNull() ?: error("Valeur manquante") } },
        ),
        ZoneActionType(
            "dnd", "Son", "Ne pas déranger", Kind.CHOICE, Need.DND,
            choices = listOf("1" to "Désactivé", "2" to "Prioritaires uniquement", "3" to "Silence total", "4" to "Alarmes uniquement"),
            read = { c, _ -> nm(c).currentInterruptionFilter.takeIf { it in 1..4 }?.toString() },
            doApply = { c, v, _ ->
                ok {
                    check(nm(c).isNotificationPolicyAccessGranted) { "Accès « Ne pas déranger » non accordé" }
                    nm(c).setInterruptionFilter(v?.toIntOrNull() ?: error("Valeur manquante"))
                }
            },
        ),
        volume("vol_ring", "Volume de la sonnerie", AudioManager.STREAM_RING, Need.DND),
        volume("vol_notif", "Volume des notifications", AudioManager.STREAM_NOTIFICATION, Need.DND),
        volume("vol_system", "Volume du système", AudioManager.STREAM_SYSTEM, Need.DND),
        volume("vol_media", "Volume multimédia", AudioManager.STREAM_MUSIC),
        volume("vol_alarm", "Volume des alarmes", AudioManager.STREAM_ALARM),
        volume("vol_call", "Volume des appels", AudioManager.STREAM_VOICE_CALL),
        sw("vibrate_ring", "Son", "Vibrer quand ça sonne", "system", "vibrate_when_ringing"),
        sw("haptic", "Son", "Retour haptique (vibration au toucher)", "system", "haptic_feedback_enabled"),
        sw("touch_sounds", "Son", "Sons du toucher", "system", "sound_effects_enabled"),
        sw("lock_sounds", "Son", "Sons de verrouillage de l'écran", "system", "lockscreen_sounds_enabled"),
        sw("dial_tones", "Son", "Tonalités du clavier téléphonique", "system", "dtmf_tone"),

        // ===== Affichage =====
        ZoneActionType(
            "brightness", "Affichage", "Luminosité", Kind.PERCENT, Need.SECURE, nullRestorable = true,
            note = "Si la luminosité automatique est active, ajoute aussi « Luminosité automatique : Désactivée ».",
            read = { c, _ -> SettingsScanner.read(c, "system", "screen_brightness")?.toIntOrNull()?.let { (it * 100f / 255f).roundToInt().toString() } },
            doApply = { c, v, _ ->
                val pct = (v?.toIntOrNull() ?: 50).coerceIn(0, 100)
                SettingsScanner.write(c, "system", "screen_brightness", (255 * pct / 100).coerceIn(1, 255).toString())
            },
        ),
        sw("brightness_auto", "Affichage", "Luminosité automatique", "system", "screen_brightness_mode"),
        choiceSetting(
            "screen_timeout", "Affichage", "Mise en veille de l'écran", "system", "screen_off_timeout",
            listOf("15000" to "15 s", "30000" to "30 s", "60000" to "1 min", "120000" to "2 min", "300000" to "5 min", "600000" to "10 min", "1800000" to "30 min"),
        ),
        sw("auto_rotate", "Affichage", "Rotation automatique", "system", "accelerometer_rotation"),
        choiceSetting(
            "font_scale", "Affichage", "Taille du texte", "system", "font_scale",
            listOf("0.85" to "Petite", "1.0" to "Normale", "1.15" to "Grande", "1.3" to "Très grande", "1.5" to "Énorme"),
        ),
        ZoneActionType(
            "animations", "Affichage", "Animations du système", Kind.CHOICE, Need.SECURE,
            choices = listOf("0" to "Désactivées", "0.5" to "Rapides", "1.0" to "Normales"), nullRestorable = true,
            read = { c, _ -> SettingsScanner.read(c, "global", "window_animation_scale") },
            doApply = { c, v, _ ->
                ok {
                    for (k in listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale"))
                        SettingsScanner.write(c, "global", k, v).getOrThrow()
                }
            },
        ),
        shellSwitch(
            "dark_mode", "Mode sombre", "cmd uimode night yes", "cmd uimode night no",
        ) { c -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES },

        // ===== Connexions (Shizuku) =====
        shellSwitch("wifi", "Wi-Fi", "svc wifi enable", "svc wifi disable") { c ->
            runCatching { (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled }.getOrNull()
        },
        shellSwitch("bluetooth", "Bluetooth", "svc bluetooth enable", "svc bluetooth disable") { c ->
            globalInt(c, "bluetooth_on")?.let { it != 0 }
        },
        shellSwitch("mobile_data", "Données mobiles", "svc data enable", "svc data disable") { c ->
            globalInt(c, "mobile_data")?.let { it != 0 }
        },
        shellSwitch("nfc", "NFC", "svc nfc enable", "svc nfc disable") { c ->
            runCatching { NfcAdapter.getDefaultAdapter(c)?.isEnabled }.getOrNull()
        },
        shellSwitch("airplane", "Mode avion", "cmd connectivity airplane-mode enable", "cmd connectivity airplane-mode disable") { c ->
            globalInt(c, "airplane_mode_on")?.let { it != 0 }
        },

        // ===== Réseau =====
        ZoneActionType(
            "private_dns", "Réseau", "DNS privé", Kind.CHOICE, Need.SECURE,
            choices = listOf("off" to "Désactivé", "opportunistic" to "Automatique", "hostname" to "Serveur perso (celui de la carte DNS)"),
            nullRestorable = true,
            read = { c, _ -> SettingsScanner.read(c, "global", "private_dns_mode") },
            doApply = { c, v, _ ->
                ok {
                    if (v == "hostname") {
                        val host = Prefs.dnsHost(c)
                        check(host.isNotBlank()) { "Aucun serveur DNS perso défini dans la carte DNS" }
                        SettingsScanner.write(c, "global", "private_dns_specifier", host).getOrThrow()
                    }
                    SettingsScanner.write(c, "global", "private_dns_mode", v).getOrThrow()
                }
            },
        ),

        // ===== Système =====
        sw("battery_saver", "Système", "Économiseur de batterie", "global", "low_power", note = "Peut dépendre du constructeur : la valeur est écrite mais certains téléphones l'ignorent."),
        sw("stay_awake", "Système", "Écran allumé pendant la charge", "global", "stay_on_while_plugged_in", on = "7", off = "0"),
        sw("adb", "Système", "Débogage USB", "global", "adb_enabled"),
        sw("show_touches", "Système", "Afficher les pressions à l'écran", "system", "show_touches"),

        // ===== Applis et messages =====
        ZoneActionType(
            "notify", "Applis et messages", "Envoyer une notification", Kind.TEXT, Need.NONE,
            read = { _, _ -> null },
            doApply = { c, v, _ -> ok { ZoneNotifier.post(c, "Map Control", v?.takeIf { it.isNotBlank() } ?: "Zone") } },
        ),
        ZoneActionType(
            "launch_app", "Applis et messages", "Ouvrir une appli", Kind.APP, Need.NONE,
            note = "Android bloque l'ouverture depuis l'arrière-plan : sans l'autorisation « Afficher par-dessus d'autres applis », une notification à toucher est envoyée à la place.",
            read = { _, _ -> null },
            doApply = { c, v, _ ->
                ok {
                    val pkg = v?.takeIf { it.isNotBlank() } ?: error("Aucune appli choisie")
                    val intent = c.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ?: error("Appli introuvable : $pkg")
                    if (ZonePerms.overlay(c)) {
                        c.startActivity(intent)
                    } else {
                        val label = c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
                        val pi = PendingIntent.getActivity(c, pkg.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                        ZoneNotifier.post(c, "Ouvrir $label", "Touche pour ouvrir $label", pi)
                    }
                }
            },
        ),

        // ===== Tes tuiles et réglages libres =====
        ZoneActionType(
            "learned", "Tes actions", "Une action apprise (scanner)", Kind.LEARNED, Need.SECURE,
            note = "Utilise une tuile « réglage on/off » que tu as déjà créée avec le scanner.",
            read = { c, p ->
                Actions.all(c).firstOrNull { it.id == p }?.let { if (Actions.isActive(c, it)) "1" else "0" }
            },
            doApply = { c, v, p ->
                ok {
                    val a = Actions.all(c).firstOrNull { it.id == p } ?: error("Action introuvable (supprimée ?)")
                    check(a.launch == null) { "Cette tuile ouvre un écran : elle ne peut pas être appliquée par une zone" }
                    Actions.apply(c, a, v == "1").getOrThrow()
                }
            },
        ),
        ZoneActionType(
            "custom_setting", "Tes actions", "Réglage Android libre", Kind.SETTING, Need.SECURE, nullRestorable = true,
            note = "Pour les experts : choisis la table (global, secure, system), le nom du réglage et la valeur à écrire.",
            read = { c, p ->
                val (t, n) = (p ?: "|").split("|", limit = 2).let { it[0] to it.getOrElse(1) { "" } }
                if (n.isBlank()) null else SettingsScanner.read(c, t, n)
            },
            doApply = { c, v, p ->
                val (t, n) = (p ?: "|").split("|", limit = 2).let { it[0] to it.getOrElse(1) { "" } }
                SettingsScanner.write(c, t, n, v)
            },
        ),
    )

    fun byId(id: String): ZoneActionType? = all.firstOrNull { it.id == id }
    val categories: List<String> get() = all.map { it.category }.distinct()
}
