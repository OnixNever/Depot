package com.mapcontrol.app.core

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import rikka.shizuku.Shizuku

/** Sert uniquement à s'accorder WRITE_SECURE_SETTINGS une fois ; ensuite Shizuku n'est plus utilisé. */
object ShizukuHelper {
    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4242

    fun isInstalled(ctx: Context): Boolean =
        try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (e: Exception) { false }

    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun hasPermission(): Boolean =
        try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    /**
     * Exécute un script en LECTURE avec les droits shell de Shizuku et renvoie sa sortie (stdout + stderr, tronquée).
     * Le résultat revient sur le thread principal.
     */
    fun runShell(script: String, onDone: (Result<String>) -> Unit) {
        Thread {
            val r = runCatching {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
                )
                m.isAccessible = true
                val p = m.invoke(null, arrayOf("sh", "-c", "($script) 2>&1"), null, null) as Process
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor()
                if (out.length > 20000) out.take(20000) + "\n… (tronqué)" else out
            }
            Handler(Looper.getMainLooper()).post { onDone(r) }
        }.start()
    }

    /** Version synchrone de [runShell] (à appeler hors du thread principal). Échoue si Shizuku ne tourne pas. */
    fun runShellSync(script: String): Result<String> = runCatching {
        check(isRunning()) { "Shizuku n'est pas lancé" }
        check(hasPermission()) { "Shizuku : autorisation manquante pour Map Control" }
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($script) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        check(code == 0) { out.ifBlank { "Échec (code $code)" }.take(200) }
        out
    }

    /** Lance « pm grant » avec les droits shell de Shizuku. Le résultat revient sur le thread principal. */
    fun grantWriteSecureSettings(ctx: Context, onDone: (Result<Unit>) -> Unit) {
        val pkg = ctx.packageName
        Thread {
            val r = runCatching {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
                )
                m.isAccessible = true
                val cmd = arrayOf("sh", "-c", "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
                val p = m.invoke(null, cmd, null, null) as Process
                val err = p.errorStream.bufferedReader().readText()
                val code = p.waitFor()
                if (code != 0) error(err.ifBlank { "Échec (code $code)" })
            }
            Handler(Looper.getMainLooper()).post { onDone(r) }
        }.start()
    }
}
