package com.mapcontrol.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.os.Handler
import android.os.Looper
import com.mapcontrol.app.core.ShizukuHelper

/** Instantané des réglages (3 tables) et des propriétés système, une ligne par valeur. */
private const val SNAPSHOT =
    "settings list global | sed 's/^/global: /'; " +
        "settings list secure | sed 's/^/secure: /'; " +
        "settings list system | sed 's/^/system: /'; " +
        "getprop | sed 's/^/prop: /'; " +
        "dumpsys activity services com.samsung.android.rampart 2>/dev/null | grep -E 'ServiceRecord|isForeground|app=' | sed 's/^/rampart-svc: /' | head -n 20; " +
        "dumpsys package com.samsung.android.rampart 2>/dev/null | grep -E 'enabled=|stopped=|lastUpdateTime' | sed 's/^/rampart-pkg: /' | head -n 10; " +
        "ls -la /data/data/com.samsung.android.rampart/shared_prefs 2>/dev/null | sed 's/^/rampart-prefs: /' | head -n 30; " +
        "cat /data/data/com.samsung.android.rampart/shared_prefs/*.xml 2>/dev/null | sed 's/^/rampart-xml: /' | head -n 200; " +
        "dumpsys activity broadcasts 2>/dev/null | grep -i rampart | sed 's/^/rampart-bc: /' | head -n 20"

/** Cherche tout ce qui ressemble à Auto Blocker dans les réglages, propriétés et paquets. */
private const val REPORT =
    "echo '== réglages =='; (settings list global; settings list secure; settings list system) | grep -i -E 'block|knox|guard|rampart' | head -n 60; " +
        "echo '== propriétés =='; getprop | grep -i -E 'block|knox|rampart' | head -n 30; " +
        "echo '== paquets =='; pm list packages | grep -i -E 'blocker|knox|guard|rampart|samsung.android.settings|samsung.android.sm' | head -n 30; " +
        "echo '== rampart : activités, services, récepteurs, fournisseurs =='; " +
        "dumpsys package com.samsung.android.rampart 2>/dev/null | grep -E 'Activity Resolver|Service Resolver|Receiver Resolver|Provider|Action:|android.intent.action|com.samsung.android.rampart' | head -n 120; " +
        "echo '== rampart : permissions déclarées =='; " +
        "dumpsys package com.samsung.android.rampart 2>/dev/null | grep -E 'declared permissions|permission:|granted=' | head -n 40; " +
        "echo '== rampart : fournisseurs accessibles =='; " +
        "dumpsys package providers 2>/dev/null | grep -i -B1 -A4 rampart | head -n 40"

/** Après 10 s, relève l'écran et les fragments affichés (le temps d'ouvrir la page voulue). */
private const val TOP_PAGE =
    "sleep 10; " +
        "echo '== fenêtre au premier plan =='; dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -n 6; " +
        "echo '== activité au premier plan =='; dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity|ResumedActivity' | head -n 6; " +
        "echo '== intent de la page =='; dumpsys activity activities | grep -E 'mResumedActivity' -A 0 | head -n 2; " +
        "dumpsys activity activities | grep 'intent=' | grep -i -E 'settings|samsung|knox|blocker|rampart' | head -n 10"

@Composable
fun ShizukuProbe(onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var output by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var snapA by remember { mutableStateOf<String?>(null) }
    var snapB by remember { mutableStateOf<String?>(null) }

    /** Vérifie Shizuku puis exécute [script] ; [then] reçoit la sortie. */
    fun exec(script: String, wait: String? = null, then: (String) -> Unit) {
        if (!ShizukuHelper.isRunning()) { status = "Shizuku ne tourne pas : lance-le (débogage sans fil) puis réessaie."; return }
        if (!ShizukuHelper.hasPermission()) {
            ShizukuHelper.requestPermission()
            status = "Autorise Map Control dans Shizuku, puis réessaie."
            return
        }
        busy = true
        status = wait
        ShizukuHelper.runShell(script) { r ->
            busy = false
            r.onSuccess { then(it); status = null }
                .onFailure { status = "Erreur : ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    // --- Enregistrement automatique : une photo toutes les 2 s pendant ~60 s ---
    var recording by remember { mutableStateOf(false) }
    var shots by remember { mutableStateOf(listOf<Pair<Long, String>>()) }
    var failures by remember { mutableStateOf(0) }
    val handler = remember { Handler(Looper.getMainLooper()) }
    var startMs by remember { mutableStateOf(0L) }
    var inFlight by remember { mutableStateOf(false) }

    fun report() {
        val ok = shots
        if (ok.size < 2) {
            output = "Pas assez de photos (${ok.size}). Shizuku était peut-être coupé dès le début."
            return
        }
        // Compare chaque photo à la précédente et ne garde que les changements.
        val sb = StringBuilder()
        sb.append("${ok.size} photos, ${failures} échecs (Shizuku coupé ?).\n\n")
        var found = 0
        for (i in 1 until ok.size) {
            val a = ok[i - 1].second.lines().toSet()
            val b = ok[i].second.lines().toSet()
            val onlyA = (a - b).filter { it.isNotBlank() && !it.startsWith("prop: [ro.") }
            val onlyB = (b - a).filter { it.isNotBlank() && !it.startsWith("prop: [ro.") }
            if (onlyA.isEmpty() && onlyB.isEmpty()) continue
            found++
            val sec = (ok[i].first - ok[0].first) / 1000
            sb.append("== Changement vers t=${sec}s ==\n")
            onlyA.take(40).forEach { sb.append("- ").append(it).append('\n') }
            onlyB.take(40).forEach { sb.append("+ ").append(it).append('\n') }
            sb.append('\n')
        }
        if (found == 0) sb.append("Aucun changement détecté pendant l'enregistrement. Soit Auto Blocker n'a pas été basculé, soit il n'est pas dans les réglages ni les propriétés.")
        output = sb.toString()
    }

    fun stopRecording() {
        recording = false
        handler.removeCallbacksAndMessages(null)
        status = null
        report()
    }

    fun tick() {
        if (!recording) return
        if (System.currentTimeMillis() - startMs > 60_000) { stopRecording(); return }
        if (!inFlight) {
            inFlight = true
            ShizukuHelper.runShell(SNAPSHOT) { r ->
                inFlight = false
                r.onSuccess { shots = shots + (System.currentTimeMillis() to it) }
                    .onFailure { failures += 1 }
            }
        }
        handler.postDelayed({ tick() }, 2000)
    }

    fun startRecording() {
        if (!ShizukuHelper.isRunning()) { status = "Shizuku ne tourne pas : lance-le (débogage sans fil) puis réessaie."; return }
        if (!ShizukuHelper.hasPermission()) { ShizukuHelper.requestPermission(); status = "Autorise Map Control dans Shizuku, puis réessaie."; return }
        shots = emptyList(); failures = 0; output = ""
        startMs = System.currentTimeMillis()
        recording = true
        status = "Enregistrement 60 s : va sur la page Auto Blocker, bascule l'interrupteur, valide, puis reviens ici."
        tick()
    }

    DisposableEffect(Unit) { onDispose { handler.removeCallbacksAndMessages(null) } }

    fun diff() {
        val a = snapA?.lines()?.toSet() ?: return
        val b = snapB?.lines()?.toSet() ?: return
        val onlyA = (a - b).filter { it.isNotBlank() }.sorted()
        val onlyB = (b - a).filter { it.isNotBlank() }.sorted()
        output = buildString {
            append("== Présent seulement dans A (avant) : ${onlyA.size} ==\n")
            onlyA.take(120).forEach { append("- ").append(it).append('\n') }
            append("\n== Présent seulement dans B (après) : ${onlyB.size} ==\n")
            onlyB.take(120).forEach { append("+ ").append(it).append('\n') }
            if (onlyA.isEmpty() && onlyB.isEmpty()) {
                append("\nAucune différence : le réglage n'est ni dans les réglages ni dans les propriétés système.")
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onClose) { Text("← Retour") }
                Text("Sonde Shizuku", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Outil de lecture : il ne modifie rien. Il sert à trouver où Samsung range Auto Blocker.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. Rapport", style = MaterialTheme.typography.titleMedium)
                    Text("Cherche « blocker », « knox », « guard », « rampart » dans les réglages, propriétés et paquets, et liste ce que l'appli Auto Blocker (rampart) déclare : écrans, services, récepteurs, fournisseurs.", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { exec(REPORT) { output = it } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Text("Lancer le rapport")
                    }
                }
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("2. Photos A / B", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Photo A avec Auto Blocker ACTIVÉ. Va le désactiver dans les Paramètres, reviens, puis Photo B. " +
                            "L'appli montre ce qui a changé.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { exec(SNAPSHOT) { snapA = it; output = "Photo A enregistrée (${it.lines().size} lignes)." } }, enabled = !busy) {
                            Text(if (snapA == null) "Photo A" else "Photo A ✓")
                        }
                        OutlinedButton(onClick = { exec(SNAPSHOT) { snapB = it; diff() } }, enabled = !busy && snapA != null) {
                            Text(if (snapB == null) "Photo B" else "Photo B ✓")
                        }
                    }
                }
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("2b. Enregistrement automatique", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Prend une photo toutes les 2 s pendant 60 s. Appuie, puis bascule Auto Blocker dans les Paramètres et reviens. " +
                            "Les changements sont comparés seuls, même si Shizuku se coupe en route.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { startRecording() }, enabled = !recording) { Text("Enregistrer 60 s") }
                        OutlinedButton(onClick = { stopRecording() }, enabled = recording) { Text("Arrêter") }
                    }
                    if (recording) Text("Photos prises : ${shots.size}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("3. Quelle page est ouverte ?", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Appuie, puis ouvre à la main la page Auto Blocker dans les Paramètres et attends 10 secondes. " +
                            "Reviens ici : le résultat donne le nom exact de la page.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Button(
                        onClick = { exec(TOP_PAGE, wait = "Ouvre la page Auto Blocker maintenant (10 s)…") { output = it } },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Lancer (10 s)") }
                }
            }
        }
        status?.let { item { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) } }
        if (output.isNotBlank()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Résultat", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(output)) }) { Text("Copier") }
                    }
                    SelectionContainer {
                        Text(output, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
