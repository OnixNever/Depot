package com.mapcontrol.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** « Ajouter une tuile » : choisir le type de tuile à créer. */
@Composable
fun AddTileHub(onClose: () -> Unit, onScan: () -> Unit, onScreen: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onClose) { Text("← Retour") }
                Text("Ajouter une tuile", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Choisis ce que la tuile doit faire. Elle apparaîtra dans le panneau du haut ; 12 tuiles personnalisées maximum.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Un réglage on / off", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Tu changes un réglage dans les Paramètres, Map Control repère ce qui a bougé et crée la tuile qui le bascule en un geste.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Marche pour les réglages Android classiques. Pas pour le Wi-Fi, le Bluetooth ou les fonctions Samsung protégées.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) { Text("Scanner un réglage") }
                }
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Une page des Paramètres", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "La tuile ouvre directement une page précise (sécurité, options développeur…). Pour une page Auto Blocker, elle peut aussi appuyer sur l'interrupteur à ta place.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(onClick = onScreen, modifier = Modifier.fillMaxWidth()) { Text("Choisir une page") }
                }
            }
        }
    }
}
