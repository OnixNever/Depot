package com.mapcontrol.app.zones

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Relance la surveillance des zones après un redémarrage ou une mise à jour, si l'interrupteur principal était allumé. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (ZoneStore.masterOn(context) && ZonePerms.fine(context)) {
            runCatching { ZoneService.start(context) }
        }
    }
}
