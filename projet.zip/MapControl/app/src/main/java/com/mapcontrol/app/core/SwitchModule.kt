package com.mapcontrol.app.core

import android.content.Context
import android.service.quicksettings.TileService
import androidx.compose.runtime.Composable

/** État affiché : libellé court + actif/inactif (pour la couleur de la tuile). */
data class ModuleState(val label: String, val active: Boolean)

/**
 * Un module = une fonctionnalité intégrée à basculer (DNS, Auto Blocker…).
 * Pour en ajouter un : implémenter cette interface, l'ajouter dans [Modules.all],
 * créer sa classe TileService (3 lignes) et déclarer celle-ci dans le manifeste.
 */
interface SwitchModule {
    val id: String
    val defaultTitle: String
    val defaultIcon: String
    val tileService: Class<out TileService>

    /** Phrase courte affichée sur la carte du module. */
    val description: String

    /** false tant qu'une permission/configuration manque. */
    fun isReady(ctx: Context): Boolean
    fun current(ctx: Context): ModuleState

    /** Passe à l'état suivant et le renvoie. */
    fun toggle(ctx: Context): Result<ModuleState>

    /**
     * Permet à un module de gérer lui-même le clic sur sa tuile (ex. ouvrir une page).
     * Renvoie true si le clic est traité ; sinon la tuile appelle [toggle].
     */
    fun tileClick(service: TileService): Boolean = false

    /** Réglages propres au module, affichés dans « Personnaliser ». */
    @Composable
    fun Extra(onChanged: () -> Unit) {}
}
