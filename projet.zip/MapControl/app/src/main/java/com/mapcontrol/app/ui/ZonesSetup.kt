package com.mapcontrol.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.mapcontrol.app.core.Perm
import com.mapcontrol.app.zones.ZonePerms

/** Les autorisations dont les zones ont besoin, avec un bouton pour chacune. */
@Composable
fun ZonesSetupCard(tick: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    var showShizuku by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { rev++; onChanged() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { rev++ }

    val fine = remember(tick, rev) { ZonePerms.fine(ctx) }
    val bg = remember(tick, rev) { ZonePerms.background(ctx) }
    val notif = remember(tick, rev) { ZonePerms.notifications(ctx) }
    val dnd = remember(tick, rev) { ZonePerms.dnd(ctx) }
    val overlay = remember(tick, rev) { ZonePerms.overlay(ctx) }
    val secure = remember(tick, rev) { Perm.granted(ctx) }

    fun openSettings(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        StatusRow(fine, "Position", "Pour savoir quand tu entres ou sors d'une zone.", "Autoriser") {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            launcher.launch(perms.toTypedArray())
        }
        StatusRow(
            bg, "Position « tout le temps »",
            "Pour que les zones marchent écran éteint et appli fermée. Choisis « Autoriser tout le temps ».",
            "Autoriser",
        ) {
            if (!fine) launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            else launcher.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            StatusRow(notif, "Notifications", "Pour la notification de surveillance et les réglages « Notification ».", "Autoriser") {
                launcher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
            }
        }
        StatusRow(
            dnd, "Ne pas déranger",
            "Pour changer le mode de sonnerie, les volumes sonnerie / notifications et Ne pas déranger.", "Autoriser",
        ) { openSettings(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        StatusRow(
            secure, "Modifier les réglages",
            "Pour la luminosité, le DNS, les animations… Accordé une fois via Shizuku, puis Shizuku peut s'arrêter.", "Configurer",
        ) { showShizuku = !showShizuku }
        AnimatedVisibility(!secure && showShizuku) { PermissionSetup { rev++; onChanged() } }
        StatusRow(
            overlay, "Afficher par-dessus d'autres applis (facultatif)",
            "Pour que « Ouvrir une appli » s'ouvre vraiment, sans passer par une notification.", "Autoriser",
        ) { openSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))) }
        Text(
            "Si la fenêtre de position ne s'affiche pas : Paramètres → Applis → Map Control → Autorisations → Position.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
