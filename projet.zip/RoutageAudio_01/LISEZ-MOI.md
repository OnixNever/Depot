# Routage Audio — prototype de faisabilité (v0.1.0)

Objectif : vérifier qu'une appli normale + Shizuku peut forcer la sortie audio.

## Test
1. Installe l'APK, lance Shizuku (débogage sans fil) et autorise l'appli.
2. Lance une vidéo YouTube.
3. Touche un périphérique dans la liste : le son doit basculer dessus.
4. « Revenir en automatique » annule la règle.
5. Le journal vert en bas affiche les codes retour (copie-le-moi si ça échoue).

## Limite connue
Ce prototype agit sur la strategy MEDIA (toutes les applis média à la fois).
Séparer YouTube de Waze = étape 2 (politique audio dynamique / capture par appli).
Compatible Android 10 à 14 (le Galaxy A50 plafonne à Android 11).
