package com.routage.audio

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var logView: TextView
    private var selected: Int = -1

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
    private val binderListener = Shizuku.OnBinderReceivedListener { refresh() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun card(color: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        cornerRadius = dp(16).toFloat(); setColor(color); setStroke(dp(2), stroke)
    }

    private fun log(s: String) = runOnUiThread { logView.append(s + "\n") }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(TextView(this).apply {
            text = "Routage Audio"; textSize = 28f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Test de faisabilité · sortie « média »"; textSize = 14f
            setTextColor(Color.parseColor("#8B97A6")); setPadding(0, dp(2), 0, dp(16))
        })
        statusView = TextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(statusView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)

        root.addView(button("Revenir en automatique", "#2A3441") {
            Thread { AudioRouter.reset(::log); }.start()
            selected = -1; refresh()
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })

        logView = TextView(this).apply {
            textSize = 11f; setTextColor(Color.parseColor("#6EE7B7")); typeface = Typeface.MONOSPACE
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    private fun button(label: String, color: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        background = card(Color.parseColor(color)); setOnClickListener { onClick() }
    }

    private fun refresh() = runOnUiThread {
        listBox.removeAllViews()
        when {
            !Shizuku.pingBinder() -> {
                statusView.text = "Shizuku n'est pas lancé.\nOuvre Shizuku et démarre-le (débogage sans fil)."
                statusView.background = card(Color.parseColor("#4A2A2A"))
            }
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                statusView.text = "Autoriser Routage Audio dans Shizuku  ›"
                statusView.background = card(Color.parseColor("#4A3B1F"))
                statusView.setOnClickListener { Shizuku.requestPermission(1) }
            }
            else -> {
                statusView.text = "Shizuku connecté ✓"
                statusView.background = card(Color.parseColor("#1F3A33"))
                statusView.setOnClickListener(null)
                showDevices()
            }
        }
    }

    private fun showDevices() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter { it.type != AudioDeviceInfo.TYPE_TELEPHONY }
        devices.forEach { d ->
            val on = selected == d.id
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(14))
                background = card(Color.parseColor("#171C24"), if (on) Color.parseColor("#4FD1C5") else Color.TRANSPARENT)
                setOnClickListener {
                    selected = d.id; refresh()
                    Thread { AudioRouter.route(d, ::log) }.start()
                }
            }
            row.addView(TextView(this).apply {
                text = AudioRouter.typeName(d.type); textSize = 17f; setTextColor(Color.WHITE)
            })
            row.addView(TextView(this).apply {
                text = (d.productName?.toString() ?: "") + if (on) "  ·  actif" else ""
                textSize = 13f; setTextColor(Color.parseColor("#8B97A6"))
            })
            listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
    }
}
