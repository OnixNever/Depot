package com.routage.audio

import android.media.AudioDeviceInfo
import android.os.Build
import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper

/**
 * Prototype : force la sortie du flux « média » (strategy MEDIA) vers un périphérique,
 * en appelant IAudioService avec les droits shell obtenus via Shizuku.
 * Android 10/11 : setPreferredDeviceForStrategy(int, AudioDeviceAttributes)
 * Android 12+   : setPreferredDevicesForStrategy(int, List<AudioDeviceAttributes>)
 */
object AudioRouter {

    init {
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
    }

    private fun audioService(): Any {
        val sm = Class.forName("android.os.ServiceManager")
        val binder = sm.getMethod("getService", String::class.java).invoke(null, "audio") as IBinder
        val wrapped = ShizukuBinderWrapper(binder)
        return Class.forName("android.media.IAudioService\$Stub")
            .getMethod("asInterface", IBinder::class.java)
            .invoke(null, wrapped)!!
    }

    private fun attrs(d: AudioDeviceInfo): Any {
        val c = Class.forName("android.media.AudioDeviceAttributes")
        // ROLE_OUTPUT = 2
        return c.getConstructor(Int::class.java, Int::class.java, String::class.java)
            .newInstance(2, d.type, d.address ?: "")
    }

    /** Retourne l'id de la strategy MEDIA, ou null. */
    fun mediaStrategyId(log: (String) -> Unit): Int? {
        val c = Class.forName("android.media.audiopolicy.AudioProductStrategy")
        val list = c.getMethod("getAudioProductStrategies").invoke(null) as List<*>
        for (s in list) {
            val name = c.getMethod("getName").invoke(s) as String
            val id = c.getMethod("getId").invoke(s) as Int
            log("strategy $id = $name")
            if (name.contains("MEDIA", ignoreCase = true)) return id
        }
        return null
    }

    fun route(device: AudioDeviceInfo, log: (String) -> Unit): Boolean {
        return try {
            val id = mediaStrategyId(log) ?: run { log("strategy MEDIA introuvable"); return false }
            val svc = audioService()
            val a = attrs(device)
            val res: Any? = if (Build.VERSION.SDK_INT >= 31) {
                val m = svc.javaClass.methods.first { it.name == "setPreferredDevicesForStrategy" }
                m.invoke(svc, id, listOf(a))
            } else {
                val m = svc.javaClass.methods.first { it.name == "setPreferredDeviceForStrategy" }
                m.invoke(svc, id, a)
            }
            log("setPreferredDevice… → code retour = $res (0 = OK)")
            res == null || res == 0
        } catch (t: Throwable) {
            log("ERREUR : " + (t.cause ?: t).toString())
            false
        }
    }

    fun reset(log: (String) -> Unit): Boolean {
        return try {
            val id = mediaStrategyId(log) ?: return false
            val svc = audioService()
            val m = svc.javaClass.methods.first { it.name == "removePreferredDeviceForStrategy" }
            val res = m.invoke(svc, id)
            log("retour automatique → code = $res")
            true
        } catch (t: Throwable) {
            log("ERREUR : " + (t.cause ?: t).toString())
            false
        }
    }

    fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Haut-parleur du téléphone"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Écouteur interne"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Casque filaire"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Écouteurs filaires"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (média)"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (appel)"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> "Sortie type $t"
    }
}
