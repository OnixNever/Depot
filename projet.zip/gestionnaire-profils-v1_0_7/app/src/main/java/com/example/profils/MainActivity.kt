package com.example.profils

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import android.util.Xml
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebStorage
import android.webkit.MimeTypeMap
import android.webkit.PermissionRequest
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.security.MessageDigest
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipFile
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser

/** Fichier local reçu d'une autre appli, copié dans le cache de l'appli. */
private class FichierOuvert(val fichier: File, val mime: String, val nom: String)

/** Flux limité à `reste` octets : sert les réponses partielles (« Range ») pour la vidéo et l'audio. */
private class FluxBorne(src: InputStream, private var reste: Long) : FilterInputStream(src) {
    override fun read(): Int {
        if (reste <= 0) return -1
        val b = super.read()
        if (b >= 0) reste--
        return b
    }
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (reste <= 0) return -1
        val n = super.read(b, off, minOf(len.toLong(), reste).toInt())
        if (n > 0) reste -= n
        return n
    }
}

/** Téléchargement d'un blob: en attente de la réponse de la page (voir PontTelechargement). */
private class AttenteBlob(val profilId: String, val url: String, val contentDisposition: String?, val mime: String?)

/** Icônes des deux modes : à changer ici, elles sont reprises partout dans l'appli. */
private const val ICO_STRICT = "🛡️"
private const val ICO_LIBRE = "⚡"

class MainActivity : Activity() {

    companion object {
        /** Faux domaine (en https, donc contexte sécurisé) qui sert les fichiers locaux ouverts depuis d'autres applis. */
        private const val HOTE_FICHIERS = "fichier.local"
        private const val MIME_PPT = "application/vnd.ms-powerpoint"
        private const val MIME_PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        private const val MIME_PPSX = "application/vnd.openxmlformats-officedocument.presentationml.slideshow"
        private val fichiersOuverts = ConcurrentHashMap<String, FichierOuvert>()
        private val rendeursPdf = ConcurrentHashMap<String, PdfRenderer>()
    }

    // ───────── Thème (sombre par défaut, clair en option) ─────────
    private var sombre = true
    private val FOND get() = Color.parseColor(if (sombre) "#121212" else "#F4F5F7")
    private val CARTE get() = Color.parseColor(if (sombre) "#1E1E1E" else "#FFFFFF")
    private val BARRE get() = Color.parseColor(if (sombre) "#181818" else "#E9EBEE")
    private val TEXTE get() = Color.parseColor(if (sombre) "#EEEEEE" else "#1A1A1A")
    private val ATTENUE get() = Color.parseColor(if (sombre) "#9A9A9A" else "#6B6B6B")
    private val themeDialogue get() =
        if (sombre) AlertDialog.THEME_DEVICE_DEFAULT_DARK else AlertDialog.THEME_DEVICE_DEFAULT_LIGHT

    private lateinit var depot: DepotProfils
    private lateinit var depotDl: DepotTelechargements
    private lateinit var reglages: SharedPreferences
    private val profils = mutableListOf<Profil>()

    /** Un onglet = une WebView ; enAttente = adresse à charger au premier affichage. */
    private class Onglet(val wv: WebView, var enAttente: String?, var titre: String = "")
    private val onglets = mutableMapOf<String, MutableList<Onglet>>()

    private var courant: Profil? = null
    private var isolationOk = false

    private lateinit var ecranListe: LinearLayout
    private lateinit var conteneurListe: LinearLayout
    private lateinit var ecranNavigateur: LinearLayout
    private lateinit var conteneurWeb: FrameLayout
    private lateinit var barreOnglets: LinearLayout
    private lateinit var defilOnglets: HorizontalScrollView
    /** true pendant qu'un onglet est déplacé à la main : la barre n'est pas reconstruite. */
    private var glisseOnglet = false
    private lateinit var puce: TextView
    private lateinit var barreUrl: EditText
    private lateinit var etoile: Button
    private lateinit var progression: ProgressBar
    private lateinit var avertissement: TextView

    /** Demandes de permissions Android en cours : code -> suite à exécuter quand le système a répondu. */
    private val suites = HashMap<Int, () -> Unit>()
    private var compteurCodes = 100
    private var dialogueLien: Dialog? = null
    private val handler = Handler(Looper.getMainLooper())

    /** Profils dont le verrou a été levé depuis la dernière sortie de l'appli ou de l'écran du profil. */
    private val deverrouilles = mutableSetOf<String>()

    private val REQ_PHOTO = 4101
    private val REQ_FICHIERS = 4102
    private var rappelPhoto: ((Uri) -> Unit)? = null
    private var rappelFichiers: ValueCallback<Array<Uri>>? = null

    private val attentesBlob = ConcurrentHashMap<String, AttenteBlob>()
    private lateinit var ponts: PontsWeb
    private val pontTelechargement = PontTelechargement(
        { j, d -> blobRecu(j, d) }, { j, r -> blobEchec(j, r) }
    )
    private val cachePhotos = HashMap<String, Pair<Long, Bitmap>>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fond(couleur: Int, rayon: Int) = GradientDrawable().apply {
        setColor(couleur); cornerRadius = dp(rayon).toFloat()
    }

    private fun texteSur(couleur: Int): Int {
        val lum = 0.299 * Color.red(couleur) + 0.587 * Color.green(couleur) + 0.114 * Color.blue(couleur)
        return if (lum > 150) Color.BLACK else Color.WHITE
    }

    /** Mélange une couleur avec du blanc (f = 0 → inchangée, 1 → blanc). */
    private fun eclaircir(c: Int, f: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * f).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * f).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * f).toInt()
    )

    // ───────────────────────── Photo de profil ─────────────────────────

    private fun fichierPhoto(id: String) = File(File(filesDir, "avatars"), "$id.jpg")

    private fun photoDe(p: Profil): Bitmap? {
        val f = fichierPhoto(p.id)
        if (!f.exists()) return null
        val m = f.lastModified()
        cachePhotos[p.id]?.let { if (it.first == m) return it.second }
        val b = BitmapFactory.decodeFile(f.path) ?: return null
        cachePhotos[p.id] = Pair(m, b)
        return b
    }

    private fun enregistrerPhoto(id: String, b: Bitmap) {
        val f = fichierPhoto(id)
        f.parentFile?.mkdirs()
        FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        cachePhotos.remove(id)
    }

    private fun retirerPhoto(id: String) {
        fichierPhoto(id).delete()
        cachePhotos.remove(id)
    }

    /** Lit l'image choisie dans la galerie, la recadre au carré (centre) et la réduit à 320 px. */
    private fun lirePhoto(uri: Uri): Bitmap? {
        val limites = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, limites) }
        var echelle = 1
        while (limites.outWidth / echelle > 1200 && limites.outHeight / echelle > 1200) echelle *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = echelle }
        val src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = try {
            contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
        } catch (e: Exception) { 1 }
        val degres = when (orientation) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        val cote = minOf(src.width, src.height)
        var carre = Bitmap.createBitmap(src, (src.width - cote) / 2, (src.height - cote) / 2, cote, cote)
        if (degres != 0f) {
            carre = Bitmap.createBitmap(carre, 0, 0, carre.width, carre.height, Matrix().apply { postRotate(degres) }, true)
        }
        return Bitmap.createScaledBitmap(carre, 320, 320, true)
    }

    private fun choisirPhoto(suite: (Uri) -> Unit) {
        rappelPhoto = suite
        try {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_PHOTO)
        } catch (e: Exception) {
            rappelPhoto = null
            Toast.makeText(this, "Aucune galerie disponible", Toast.LENGTH_LONG).show()
        }
    }

    private fun photoCirculaire(b: Bitmap, couleur: Int) = ImageView(this).apply {
        setImageBitmap(b); scaleType = ImageView.ScaleType.CENTER_CROP
        setPadding(dp(2), dp(2), dp(2), dp(2))
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(eclaircir(couleur, 0.55f)) }
        outlineProvider = ViewOutlineProvider.BACKGROUND
        clipToOutline = true
    }

    /** « Logo » d'un profil : sa photo si elle en a une, sinon pastille ronde en dégradé de sa couleur avec son initiale. */
    private fun avatar(p: Profil, tailleTexte: Float): View {
        photoDe(p)?.let { return photoCirculaire(it, p.couleur) }
        return TextView(this).apply {
            text = p.nom.take(1).uppercase(); gravity = Gravity.CENTER; textSize = tailleTexte
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(texteSur(p.couleur))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(eclaircir(p.couleur, 0.35f), p.couleur)
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), eclaircir(p.couleur, 0.55f))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        reglages = getSharedPreferences("reglages", MODE_PRIVATE)
        // Nouveau démarrage de l'appli : on purge les anciens fichiers ouverts depuis l'extérieur
        if (fichiersOuverts.isEmpty()) File(cacheDir, "ouverts").deleteRecursively()
        sombre = reglages.getBoolean("sombre", true)
        barresSysteme()
        depot = DepotProfils(this)
        depotDl = DepotTelechargements(this)
        profils.addAll(depot.charger())
        isolationOk = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        // Débogage distant : chrome://inspect sur le PC (console, réseau, éléments) pour toutes les pages
        WebView.setWebContentsDebuggingEnabled(true)
        // Ponts natifs (voix, reconnaissance vocale, notifications, partage) : voir PontsWeb.kt
        ponts = PontsWeb(
            this,
            { js -> runOnUiThread { onglets.values.forEach { l -> l.forEach { it.wv.evaluateJavascript(js, null) } } } },
            { perms, suite -> demanderAndroid(perms, suite) }
        )
        construireUi()
        rafraichirListe()
        // Après un changement de thème, on rouvre le profil qui était affiché
        val id = reglages.getString("reouvrir", "") ?: ""
        if (id.isNotEmpty()) {
            reglages.edit().remove("reouvrir").apply()
            // Changement de thème : l'utilisateur était déjà dans ce profil, le verrou reste levé
            profils.firstOrNull { it.id == id }?.let { deverrouilles.add(it.id); ouvrirProfil(it) }
        }
        if (savedInstanceState == null) traiterLien(intent)
    }

    @Suppress("DEPRECATION")
    private fun barresSysteme() {
        window.statusBarColor = FOND
        window.navigationBarColor = FOND
        window.decorView.systemUiVisibility =
            if (sombre) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }

    private fun changerTheme() {
        reglages.edit().putBoolean("sombre", !sombre).putString("reouvrir", courant?.id ?: "").apply()
        recreate()
    }

    // ───────────────────────── Liens reçus d'autres applications ─────────────────────────

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        traiterLien(intent)
    }

    /**
     * Lien http(s) ou fichier local (HTML, PDF, image, texte, vidéo…) envoyé par une autre appli :
     * on demande dans quel profil l'ouvrir.
     */
    private fun traiterLien(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) return
        val uri = i.data ?: return
        val schema = uri.scheme?.lowercase()
        val type = i.type // à lire AVANT de vider i.data (setData efface le type)
        when (schema) {
            "http", "https" -> {
                i.data = null // consommé : ne sera pas proposé une deuxième fois
                proposerProfils(uri.toString())
            }
            "content", "file" -> {
                i.data = null
                ouvrirFichierLocal(uri, type)
            }
            else -> return
        }
    }

    private fun ouvrirLienDansProfil(p: Profil, url: String) {
        if (courant?.id == p.id) { ouvrirOuAller(url); return }
        ouvrirProfilProtege(p) { ouvrirOuAller(url) }
    }

    private fun normaliser(u: String) = u.substringBefore('#').trimEnd('/')

    /**
     * Lien reçu : si la page est déjà ouverte dans le profil, on bascule dessus ; si le profil n'a
     * qu'un onglet encore sur la page d'accueil, on le réutilise ; sinon seulement, on ouvre un nouvel onglet.
     */
    private fun ouvrirOuAller(url: String) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        fun adresse(i: Int) = liste[i].wv.url ?: liste[i].enAttente ?: p.onglets.getOrNull(i) ?: ""
        val cible = normaliser(url)
        val deja = liste.indices.firstOrNull { normaliser(adresse(it)) == cible }
        if (deja != null) { afficherOnglet(deja); return }
        if (liste.size == 1 && normaliser(adresse(0)) == normaliser(accueil(p))) {
            p.onglets[0] = url
            liste[0].enAttente = null
            afficherOnglet(0)
            liste[0].wv.loadUrl(url)
            return
        }
        nouvelOnglet(url)
    }

    /** Feuille de choix stylisée : un « logo » (initiale sur dégradé) et le nom de chaque profil. */
    private fun proposerProfils(url: String, fichier: String? = null, sousTitre: String? = null) {
        if (profils.isEmpty()) {
            Toast.makeText(this, "Créez d'abord un profil pour pouvoir ouvrir ce lien", Toast.LENGTH_LONG).show()
            return
        }
        dialogueLien?.dismiss()
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val uri = Uri.parse(url)

        val carte = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fond(CARTE, 26)
            setPadding(dp(18), dp(20), dp(18), dp(14))
        }
        carte.addView(TextView(this).apply {
            text = if (fichier != null) "Ouvrir ce fichier avec…" else "Ouvrir ce lien avec…"; textSize = 20f; setTextColor(TEXTE)
            setTypeface(typeface, Typeface.BOLD)
        })
        val lien = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fond(FOND, 14)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        lien.addView(TextView(this).apply {
            text = if (fichier != null) "📄  $fichier" else "🔗  ${uri.host ?: url}"; textSize = 15f; setTextColor(TEXTE)
            setSingleLine(); ellipsize = TextUtils.TruncateAt.END
        })
        lien.addView(TextView(this).apply {
            text = sousTitre ?: url; textSize = 11f; setTextColor(ATTENUE)
            setSingleLine(); ellipsize = TextUtils.TruncateAt.END
        })
        carte.addView(lien, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(12) })

        val rangees = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        profils.forEach { p ->
            val ligne = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = fond(BARRE, 18); setPadding(dp(12), dp(10), dp(14), dp(10))
                setOnClickListener { d.dismiss(); ouvrirLienDansProfil(p, url) }
            }
            ligne.addView(avatar(p, 20f), LinearLayout.LayoutParams(dp(52), dp(52)))
            val textes = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
            textes.addView(TextView(this).apply {
                text = p.nom; textSize = 17f; setTextColor(TEXTE); setSingleLine()
                ellipsize = TextUtils.TruncateAt.END
            })
            textes.addView(TextView(this).apply {
                text = (if (p.libre) "$ICO_LIBRE Mode libre" else "$ICO_STRICT Mode strict") + (if (p.verrouille) "  ·  🔒" else "")
                textSize = 12f; setTextColor(ATTENUE)
            })
            ligne.addView(textes, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ligne.addView(TextView(this).apply { text = "›"; textSize = 26f; setTextColor(ATTENUE) })
            rangees.addView(ligne, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val hauteurMax = (resources.displayMetrics.heightPixels * 0.5).toInt()
        val defil = object : ScrollView(this) {
            override fun onMeasure(largeur: Int, hauteur: Int) {
                super.onMeasure(largeur, View.MeasureSpec.makeMeasureSpec(hauteurMax, View.MeasureSpec.AT_MOST))
            }
        }
        defil.addView(rangees)
        carte.addView(defil, LinearLayout.LayoutParams(-1, -2))
        carte.addView(bouton("Annuler", Color.TRANSPARENT, ATTENUE) { d.dismiss() },
            LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(4) })

        val cadre = FrameLayout(this).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(carte, FrameLayout.LayoutParams(-1, -2))
        }
        d.setContentView(cadre)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
        }
        d.setOnDismissListener { if (dialogueLien === d) dialogueLien = null }
        dialogueLien = d
        d.show()
    }

    // ───────────────────────── Fichiers locaux (HTML, PDF, images, texte, vidéo…) ─────────────────────────

    /** Nom d'affichage du fichier reçu (colonne DISPLAY_NAME, sinon fin du chemin). */
    private fun nomDuFichier(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrBlank()) return n.replace('/', '_')
                    }
                }
            } catch (e: Exception) { /* on retombe sur le chemin */ }
        }
        val fin = uri.lastPathSegment?.substringAfterLast('/')
        return if (fin.isNullOrBlank()) "fichier" else fin
    }

    private fun detecterMime(typeIntent: String?, uri: Uri, nom: String): String {
        val generiques = setOf("", "*/*", "application/octet-stream", "binary/octet-stream")
        var m: String? = typeIntent?.lowercase()?.takeIf { it !in generiques }
        if (m == null && uri.scheme == "content") {
            m = try { contentResolver.getType(uri)?.lowercase()?.takeIf { it !in generiques } } catch (e: Exception) { null }
        }
        if (m == null) {
            val ext = nom.substringAfterLast('.', "").lowercase()
            m = when (ext) {
                "md", "markdown", "log", "csv" -> "text/plain"
                "json" -> "application/json"
                "ppt", "pps" -> MIME_PPT
                "pptx" -> MIME_PPTX
                "ppsx" -> MIME_PPSX
                else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            }
        }
        return m ?: "application/octet-stream"
    }

    private fun estPptx(mime: String) = mime == MIME_PPTX || mime == MIME_PPSX

    private fun estAffichable(mime: String) =
        mime == "application/pdf" || estPptx(mime) || mime.startsWith("text/") || mime.startsWith("image/") ||
        mime.startsWith("video/") || mime.startsWith("audio/") ||
        mime == "application/json" || mime == "application/xml" || mime == "application/xhtml+xml" ||
        mime == "application/javascript" || mime.endsWith("+json") || mime.endsWith("+xml")

    /** Type annoncé à la WebView : le texte brut (json, xml, csv, md…) est affiché tel quel au lieu d'être téléchargé. */
    private fun mimeAffichage(mime: String): String = when {
        mime == "text/html" || mime == "application/xhtml+xml" || mime == "image/svg+xml" -> mime
        mime.startsWith("text/") -> "text/plain"
        mime == "application/json" || mime == "application/xml" || mime == "application/javascript" ||
            mime.endsWith("+json") || mime.endsWith("+xml") -> "text/plain"
        else -> mime
    }

    private fun libelleType(mime: String) = when {
        mime == "application/pdf" -> "Document PDF"
        estPptx(mime) -> "Présentation PowerPoint"
        mime == "text/html" || mime == "application/xhtml+xml" -> "Page web (HTML)"
        mime.startsWith("image/") -> "Image"
        mime.startsWith("video/") -> "Vidéo"
        mime.startsWith("audio/") -> "Audio"
        else -> "Texte"
    }

    /**
     * Fichier reçu d'une autre appli : copié dans le cache, puis ouvert dans un onglet du profil choisi
     * via une adresse https://fichier.local/… servie par l'appli elle-même (voir reponseFichierLocal).
     */
    private fun ouvrirFichierLocal(uri: Uri, typeIntent: String?) {
        if (profils.isEmpty()) {
            Toast.makeText(this, "Créez d'abord un profil pour pouvoir ouvrir ce fichier", Toast.LENGTH_LONG).show()
            return
        }
        val nom = nomDuFichier(uri)
        val mime = detecterMime(typeIntent, uri, nom)
        if (mime == MIME_PPT) {
            Toast.makeText(this, "L'ancien format .ppt n'est pas pris en charge : enregistrez la présentation en .pptx, ou ouvrez-la avec une autre appli", Toast.LENGTH_LONG).show()
            return
        }
        if (!estAffichable(mime)) {
            Toast.makeText(this, "Ce type de fichier ($mime) ne peut pas être affiché ici", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Chargement du fichier…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val id = UUID.randomUUID().toString().replace("-", "").take(10)
                val dossier = File(cacheDir, "ouverts").apply { mkdirs() }
                val cible = File(dossier, id)
                val entree = contentResolver.openInputStream(uri) ?: throw IOException("fichier illisible")
                entree.use { src -> cible.outputStream().use { dst -> src.copyTo(dst) } }
                fichiersOuverts[id] = FichierOuvert(cible, mime, nom)
                val url = "https://$HOTE_FICHIERS/$id/${Uri.encode(nom)}"
                runOnUiThread { if (!isFinishing && !isDestroyed) proposerProfils(url, nom, libelleType(mime)) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Impossible de lire ce fichier : ${e.message ?: "accès refusé"}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun estUrlFichier(url: String) = Uri.parse(url).host == HOTE_FICHIERS

    private fun fichierConnu(url: String): Boolean {
        val id = Uri.parse(url).pathSegments.firstOrNull() ?: return false
        return fichiersOuverts.containsKey(id)
    }

    private fun reponseMessage(code: Int, raison: String, texte: String): WebResourceResponse {
        val html = "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"></head>" +
            "<body style=\"font-family:sans-serif;padding:24px;color:#888\">" + TextUtils.htmlEncode(texte) + "</body></html>"
        return WebResourceResponse("text/html", "utf-8", code, raison, mutableMapOf<String, String>(),
            ByteArrayInputStream(html.toByteArray(Charsets.UTF_8)))
    }

    /** Appelée pour chaque requête des onglets : sert les fichiers locaux, laisse passer tout le reste (null). */
    private fun reponseFichierLocal(rq: WebResourceRequest): WebResourceResponse? {
        if (rq.url.host != HOTE_FICHIERS) return null
        val seg = rq.url.pathSegments
        if (seg.firstOrNull() == "_pdfjs") return ressourcePdfjs(seg.drop(1).joinToString("/"))
        val id = seg.firstOrNull()
        val fo = if (id != null) fichiersOuverts[id] else null
        if (id == null || fo == null || seg.size < 2) {
            return reponseMessage(404, "Not Found", "Fichier introuvable ou expiré. Rouvrez-le depuis votre gestionnaire de fichiers.")
        }
        return try {
            when {
                seg.size >= 3 && seg[1] == "page" -> pagePdfJpeg(id, fo, seg[2].substringBefore('.').toIntOrNull() ?: -1)
                fo.mime == "application/pdf" && seg[1] == "~brut" -> fichierBrut(fo, rq)
                fo.mime == "application/pdf" && seg[1] == "~simple" -> visionneusePdf(id, fo)
                fo.mime == "application/pdf" -> visionneusePdfJs(id, fo)
                estPptx(fo.mime) -> visionneusePptx(fo)
                else -> fichierBrut(fo, rq)
            }
        } catch (e: Exception) {
            reponseMessage(500, "Error", "Impossible de lire ce fichier.")
        }
    }

    /** Fichier servi tel quel, avec prise en charge des plages d'octets (lecture/avance rapide vidéo et audio). */
    private fun fichierBrut(fo: FichierOuvert, rq: WebResourceRequest): WebResourceResponse {
        val mime = mimeAffichage(fo.mime)
        val encodage: String? = if (mime == "text/plain") "utf-8" else null
        val taille = fo.fichier.length()
        val entetes = mutableMapOf("Accept-Ranges" to "bytes")
        val plage = rq.requestHeaders?.entries?.firstOrNull { it.key.equals("Range", ignoreCase = true) }?.value
        if (plage != null && plage.startsWith("bytes=") && taille > 0) {
            val bornes = plage.removePrefix("bytes=").substringBefore(",").trim().split("-")
            val debut: Long
            var fin: Long
            if (bornes[0].isEmpty()) {
                val n = bornes.getOrNull(1)?.toLongOrNull() ?: taille
                debut = (taille - n).coerceAtLeast(0L)
                fin = taille - 1
            } else {
                debut = bornes[0].toLongOrNull() ?: 0L
                fin = bornes.getOrNull(1)?.toLongOrNull() ?: (taille - 1)
            }
            fin = minOf(fin, taille - 1)
            if (debut in 0L..fin) {
                val flux = FileInputStream(fo.fichier)
                flux.channel.position(debut)
                entetes["Content-Range"] = "bytes $debut-$fin/$taille"
                entetes["Content-Length"] = (fin - debut + 1).toString()
                return WebResourceResponse(mime, encodage, 206, "Partial Content", entetes, FluxBorne(flux, fin - debut + 1))
            }
        }
        entetes["Content-Length"] = taille.toString()
        return WebResourceResponse(mime, encodage, 200, "OK", entetes, FileInputStream(fo.fichier))
    }

    // ----- Visionneuse PowerPoint (.pptx) : texte et images de chaque diapositive, sans mise en page d'origine -----

    private fun nomLocal(n: String?) = (n ?: "").substringAfter(':')

    /** Relations d'une diapositive : identifiant (rId…) -> chemin de l'image dans l'archive. */
    private fun relationsDiapo(zip: ZipFile, numero: Int): Map<String, String> {
        val rels = HashMap<String, String>()
        val entree = zip.getEntry("ppt/slides/_rels/slide$numero.xml.rels") ?: return rels
        zip.getInputStream(entree).use { flux ->
            val x = Xml.newPullParser()
            x.setInput(flux, "UTF-8")
            var ev = x.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && nomLocal(x.name) == "Relationship") {
                    var id: String? = null
                    var cible: String? = null
                    for (k in 0 until x.attributeCount) {
                        when (nomLocal(x.getAttributeName(k))) {
                            "Id" -> id = x.getAttributeValue(k)
                            "Target" -> cible = x.getAttributeValue(k)
                        }
                    }
                    if (id != null && cible != null) {
                        // « ../media/image1.png » -> « ppt/media/image1.png »
                        rels[id] = if (cible.startsWith("/")) cible.removePrefix("/")
                                   else "ppt/" + cible.removePrefix("../")
                    }
                }
                ev = x.next()
            }
        }
        return rels
    }

    private fun imageEnLigne(zip: ZipFile, chemin: String): String? {
        val type = when (chemin.substringAfterLast('.', "").lowercase()) {
            "png" -> "image/png"; "jpg", "jpeg" -> "image/jpeg"; "gif" -> "image/gif"
            "webp" -> "image/webp"; "svg" -> "image/svg+xml"
            else -> return null // emf, wmf… : non affichables
        }
        val e = zip.getEntry(chemin) ?: return null
        if (e.size > 6L * 1024 * 1024) return null
        val octets = zip.getInputStream(e).use { it.readBytes() }
        return "data:$type;base64," + Base64.encodeToString(octets, Base64.NO_WRAP)
    }

    private fun htmlDiapo(zip: ZipFile, numero: Int): String {
        val rels = relationsDiapo(zip, numero)
        val sb = StringBuilder()
        val entree = zip.getEntry("ppt/slides/slide$numero.xml") ?: return ""
        zip.getInputStream(entree).use { flux ->
            val x = Xml.newPullParser()
            x.setInput(flux, "UTF-8")
            val para = StringBuilder()
            var ev = x.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (nomLocal(x.name)) {
                        "t" -> para.append(x.nextText())
                        "br" -> para.append('\n')
                        "blip" -> {
                            var rid: String? = null
                            for (k in 0 until x.attributeCount) {
                                if (nomLocal(x.getAttributeName(k)) == "embed") rid = x.getAttributeValue(k)
                            }
                            val src = rid?.let { rels[it] }?.let { imageEnLigne(zip, it) }
                            if (src != null) sb.append("<img src=\"").append(src).append("\">")
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG && nomLocal(x.name) == "p") {
                    val t = para.toString().trim()
                    if (t.isNotEmpty()) {
                        sb.append("<p>").append(TextUtils.htmlEncode(t).replace("\n", "<br>")).append("</p>")
                    }
                    para.setLength(0)
                }
                ev = x.next()
            }
        }
        return sb.toString()
    }

    private fun visionneusePptx(fo: FichierOuvert): WebResourceResponse {
        val diapos = TreeMap<Int, String>()
        try {
            ZipFile(fo.fichier).use { zip ->
                val motif = Regex("ppt/slides/slide(\\d+)\\.xml")
                val numeros = zip.entries().toList().mapNotNull { motif.matchEntire(it.name)?.groupValues?.get(1)?.toIntOrNull() }
                for (n in numeros.sorted()) diapos[n] = htmlDiapo(zip, n)
            }
        } catch (e: Exception) {
            return reponseMessage(200, "OK", "Impossible de lire cette présentation (fichier abîmé ou protégé).")
        }
        if (diapos.isEmpty()) return reponseMessage(200, "OK", "Aucune diapositive trouvée dans ce fichier.")
        val html = StringBuilder()
        html.append("<!doctype html><html><head><meta charset=\"utf-8\">")
        html.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
        html.append("<title>").append(TextUtils.htmlEncode(fo.nom)).append("</title><style>")
        html.append(":root{color-scheme:light dark}body{font-family:sans-serif;margin:0;padding:12px;background:#f2f2f2;color:#222}")
        html.append(".d{background:#fff;border-radius:12px;padding:14px 16px;margin:0 0 12px;box-shadow:0 1px 4px #0003}")
        html.append(".n{font-size:12px;color:#888;margin:0 0 8px}p{margin:6px 0;line-height:1.4}img{max-width:100%;height:auto;display:block;margin:8px 0}")
        html.append("@media(prefers-color-scheme:dark){body{background:#111;color:#ddd}.d{background:#1e1e1e}}")
        html.append("</style></head><body>")
        for ((n, contenu) in diapos) {
            html.append("<div class=\"d\"><div class=\"n\">Diapositive ").append(n).append("</div>")
            html.append(if (contenu.isBlank()) "<p style=\"color:#888\">(aucun texte ni image affichable)</p>" else contenu)
            html.append("</div>")
        }
        html.append("</body></html>")
        return WebResourceResponse("text/html", "utf-8", 200, "OK", mutableMapOf<String, String>(),
            ByteArrayInputStream(html.toString().toByteArray(Charsets.UTF_8)))
    }

    // ----- Lecteur PDF intégré : pdf.js (dossier assets/pdfjs) avec recherche et sélection de texte -----

    private fun couleurCss(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    /** Fichiers de pdf.js, servis depuis les assets de l'appli à l'adresse https://fichier.local/_pdfjs/… */
    private fun ressourcePdfjs(chemin: String): WebResourceResponse {
        if (chemin.isEmpty() || chemin.contains("..")) return reponseMessage(404, "Not Found", "Ressource introuvable")
        return try {
            val flux = assets.open("pdfjs/$chemin")
            val type = when (chemin.substringAfterLast('.', "").lowercase()) {
                "mjs", "js" -> "text/javascript"
                "css" -> "text/css"
                "png" -> "image/png"
                "gif" -> "image/gif"
                "svg" -> "image/svg+xml"
                "html" -> "text/html"
                else -> "application/octet-stream"
            }
            WebResourceResponse(type, if (type.startsWith("text/")) "utf-8" else null, 200, "OK", mutableMapOf<String, String>(), flux)
        } catch (e: IOException) {
            reponseMessage(404, "Not Found", "Ressource introuvable")
        }
    }

    /** Page du lecteur PDF : le modèle viewer.html des assets, aux couleurs du thème. */
    private fun visionneusePdfJs(id: String, fo: FichierOuvert): WebResourceResponse {
        val modele = assets.open("pdfjs/viewer.html").use { String(it.readBytes(), Charsets.UTF_8) }
        val html = modele
            .replace("{{FOND}}", couleurCss(FOND)).replace("{{BARRE}}", couleurCss(BARRE))
            .replace("{{TEXTE}}", couleurCss(TEXTE)).replace("{{ATT}}", couleurCss(ATTENUE))
            .replace("{{ID}}", id).replace("{{NOM}}", TextUtils.htmlEncode(fo.nom))
        return WebResourceResponse("text/html", "utf-8", 200, "OK", mutableMapOf<String, String>(),
            ByteArrayInputStream(html.toByteArray(Charsets.UTF_8)))
    }

    // ----- Lecteur PDF de secours (PdfRenderer d'Android) : une page web qui affiche chaque page en image, sans recherche -----

    private fun rendeurPdf(id: String, fo: FichierOuvert): PdfRenderer = synchronized(rendeursPdf) {
        rendeursPdf[id] ?: PdfRenderer(ParcelFileDescriptor.open(fo.fichier, ParcelFileDescriptor.MODE_READ_ONLY))
            .also { rendeursPdf[id] = it }
    }

    /** Page HTML du lecteur : les pages sont chargées à la demande (loading=lazy), zoom par pincement. */
    private fun visionneusePdf(id: String, fo: FichierOuvert): WebResourceResponse {
        val r = try {
            rendeurPdf(id, fo)
        } catch (e: SecurityException) {
            return reponseMessage(200, "OK", "Ce PDF est protégé par un mot de passe : il n'est pas encore pris en charge.")
        }
        val fondPage = String.format("#%06X", FOND and 0xFFFFFF)
        val html = StringBuilder()
        html.append("<!doctype html><html><head><meta charset=\"utf-8\">")
        html.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=6, user-scalable=yes\">")
        html.append("<title>").append(TextUtils.htmlEncode(fo.nom)).append("</title><style>")
        html.append("html,body{margin:0;background:").append(fondPage).append("}")
        html.append(".t{font:13px sans-serif;color:#9a9a9a;padding:8px 12px}")
        html.append(".p{display:block;width:100%;height:auto;margin:0 0 6px 0;background:#fff}")
        html.append("</style></head><body><div class=\"t\">").append(TextUtils.htmlEncode(fo.nom))
        html.append(" · ").append(r.pageCount).append(" page(s)</div>")
        synchronized(r) {
            for (i in 0 until r.pageCount) {
                val page = r.openPage(i)
                try {
                    html.append("<img class=\"p\" loading=\"lazy\" alt=\"Page ").append(i + 1)
                    html.append("\" style=\"aspect-ratio:").append(page.width).append('/').append(page.height)
                    html.append("\" src=\"page/").append(i).append(".jpg\">")
                } finally {
                    page.close()
                }
            }
        }
        html.append("</body></html>")
        return WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(html.toString().toByteArray(Charsets.UTF_8)))
    }

    /** Une page du PDF en JPEG, à deux fois la largeur de l'écran pour rester nette quand on zoome. */
    private fun pagePdfJpeg(id: String, fo: FichierOuvert, n: Int): WebResourceResponse {
        val r = rendeurPdf(id, fo)
        if (n < 0 || n >= r.pageCount) return reponseMessage(404, "Not Found", "Page introuvable")
        val sortie = ByteArrayOutputStream()
        try {
            synchronized(r) {
                val page = r.openPage(n)
                try {
                    var l = (resources.displayMetrics.widthPixels * 2).coerceIn(1000, 2400)
                    var h = (l.toLong() * page.height / page.width).toInt().coerceAtLeast(1)
                    val maxPixels = 12_000_000.0 // plafond mémoire pour les pages très longues
                    if (l.toDouble() * h > maxPixels) {
                        val k = Math.sqrt(maxPixels / (l.toDouble() * h))
                        l = (l * k).toInt().coerceAtLeast(1)
                        h = (h * k).toInt().coerceAtLeast(1)
                    }
                    val bmp = Bitmap.createBitmap(l, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp.compress(Bitmap.CompressFormat.JPEG, 88, sortie)
                    bmp.recycle()
                } finally {
                    page.close()
                }
            }
        } catch (e: OutOfMemoryError) {
            return reponseMessage(500, "Error", "Mémoire insuffisante pour afficher cette page.")
        }
        return WebResourceResponse("image/jpeg", null, ByteArrayInputStream(sortie.toByteArray()))
    }

    // ───────────────────────── Interface ─────────────────────────

    private fun bouton(label: String, couleur: Int = CARTE, texte: Int = TEXTE, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(texte); isAllCaps = false
        background = fond(couleur, 12); setOnClickListener { action() }
    }

    private fun construireUi() {
        val racine = FrameLayout(this).apply { setBackgroundColor(FOND) }

        // ----- Écran 1 : liste des profils -----
        ecranListe = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(16)) }
        val entete = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        entete.addView(TextView(this).apply { text = "Profils"; textSize = 28f; setTextColor(TEXTE) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        entete.addView(bouton("⚙") { dialogueReglages() }, LinearLayout.LayoutParams(dp(48), dp(40)))
        ecranListe.addView(entete)
        avertissement = TextView(this).apply {
            text = "⚠ Isolation indisponible sur cet appareil (WebView trop ancienne) : les profils partageraient leurs cookies."
            setTextColor(Color.parseColor("#FFB84D")); textSize = 12f
            setPadding(0, dp(8), 0, dp(8))
            visibility = if (isolationOk) View.GONE else View.VISIBLE
        }
        ecranListe.addView(avertissement)
        conteneurListe = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0) }
        ecranListe.addView(ScrollView(this).apply { addView(conteneurListe) }, LinearLayout.LayoutParams(-1, 0, 1f))
        ecranListe.addView(bouton("＋  Nouveau profil", Color.parseColor("#2D4F99"), Color.WHITE) { protege { dialogueProfil(null) } },
            LinearLayout.LayoutParams(-1, dp(52)))
        racine.addView(ecranListe, FrameLayout.LayoutParams(-1, -1))

        // ----- Écran 2 : navigateur -----
        ecranNavigateur = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val haut = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(BARRE); setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        haut.addView(bouton("←") { afficherListe() }, LinearLayout.LayoutParams(dp(48), dp(40)))
        puce = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { dialogueChangerProfil() }
        }
        haut.addView(puce, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)).apply { setMargins(dp(6), 0, dp(6), 0) })
        barreUrl = EditText(this).apply {
            setTextColor(TEXTE); setHintTextColor(ATTENUE); hint = "Adresse ou recherche"
            textSize = 13f; setSingleLine(); inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO; background = fond(CARTE, 10)
            setPadding(dp(12), 0, dp(12), 0)
            setOnEditorActionListener { _, _, _ ->
                naviguer(text.toString().trim())
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(windowToken, 0)
                true
            }
        }
        haut.addView(barreUrl, LinearLayout.LayoutParams(0, dp(40), 1f))
        etoile = bouton("☆") { basculerFavori() }
        etoile.setOnLongClickListener { ecranFavoris(); true }
        haut.addView(etoile, LinearLayout.LayoutParams(dp(44), dp(40)).apply { leftMargin = dp(6) })
        haut.addView(bouton("⚙") { menuNavigateur() }, LinearLayout.LayoutParams(dp(48), dp(40)).apply { leftMargin = dp(6) })
        ecranNavigateur.addView(haut)

        barreOnglets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        defilOnglets = HorizontalScrollView(this).apply {
            setBackgroundColor(BARRE); isHorizontalScrollBarEnabled = false; addView(barreOnglets)
        }
        ecranNavigateur.addView(defilOnglets, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        progression = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        ecranNavigateur.addView(progression, LinearLayout.LayoutParams(-1, dp(3)))
        conteneurWeb = FrameLayout(this)
        ecranNavigateur.addView(conteneurWeb, LinearLayout.LayoutParams(-1, 0, 1f))
        racine.addView(ecranNavigateur, FrameLayout.LayoutParams(-1, -1))

        setContentView(racine)
    }

    private fun rafraichirListe() {
        conteneurListe.removeAllViews()
        if (profils.isEmpty()) {
            conteneurListe.addView(TextView(this).apply {
                text = "Aucun profil. Créez-en un pour commencer."
                setTextColor(ATTENUE); setPadding(0, dp(12), 0, 0)
            })
        }
        profils.forEach { p ->
            val ligne = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = fond(CARTE, 14); setPadding(dp(14), dp(14), dp(14), dp(14))
                setOnClickListener { ouvrirProfilProtege(p) }
                setOnLongClickListener { protege { dialogueProfil(p) }; true }
            }
            ligne.addView(avatar(p, 18f), LinearLayout.LayoutParams(dp(44), dp(44)))
            val textes = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
            textes.addView(TextView(this).apply { text = p.nom; textSize = 17f; setTextColor(TEXTE) })
            textes.addView(TextView(this).apply {
                text = "Micro ${if (p.micro || p.libre) "✓" else "✗"}  ·  Caméra ${if (p.camera || p.libre) "✓" else "✗"}  ·  ${Profil.moteur(p.moteur).nom}${if (p.libre) "  ·  $ICO_LIBRE Libre" else ""}${if (p.verrouille) "  ·  🔒" else ""}"
                textSize = 12f; setTextColor(ATTENUE)
            })
            ligne.addView(textes, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ligne.addView(TextView(this).apply {
                text = "⋮"; textSize = 22f; setTextColor(ATTENUE); setPadding(dp(12), 0, dp(4), 0)
                setOnClickListener { protege { dialogueProfil(p) } }
            })
            conteneurListe.addView(ligne, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
    }

    // ───────────────────────── Code maître ─────────────────────────

    private fun hacher(code: String, sel: String): String =
        MessageDigest.getInstance("SHA-256").digest((sel + code).toByteArray()).joinToString("") { "%02x".format(it) }

    private fun codeDefini() = reglages.getString("codeHash", null) != null

    private fun champCode(titre: String, message: String?, ok: (String) -> Unit) {
        val champ = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "Code"; setTextColor(TEXTE); setHintTextColor(ATTENUE); setSingleLine()
        }
        val boite = LinearLayout(this).apply { setPadding(dp(22), dp(10), dp(22), 0); addView(champ, LinearLayout.LayoutParams(-1, -2)) }
        val b = AlertDialog.Builder(this, themeDialogue).setTitle(titre).setView(boite)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("OK") { _, _ -> ok(champ.text.toString()) }
        if (message != null) b.setMessage(message)
        b.show()
    }

    /** Exécute l'action seulement si le code maître est correct (ou le crée à la première utilisation). */
    private fun protege(action: () -> Unit) {
        val h = reglages.getString("codeHash", null)
        if (h == null) { creerCode(action); return }
        champCode("Code maître", null) { c ->
            if (hacher(c, reglages.getString("codeSel", "") ?: "") == h) action()
            else Toast.makeText(this, "Code incorrect", Toast.LENGTH_SHORT).show()
        }
    }

    private fun creerCode(apres: () -> Unit) {
        champCode("Créer le code maître", "Il protège la création des profils et le réglage de leurs autorisations. 4 caractères minimum.") { c1 ->
            if (c1.length < 4) {
                Toast.makeText(this, "Code trop court", Toast.LENGTH_SHORT).show()
            } else {
                champCode("Confirmer le code", null) { c2 ->
                    if (c1 != c2) {
                        Toast.makeText(this, "Les deux codes sont différents", Toast.LENGTH_SHORT).show()
                    } else {
                        val octets = ByteArray(16).also { SecureRandom().nextBytes(it) }
                        val sel = octets.joinToString("") { "%02x".format(it) }
                        reglages.edit().putString("codeSel", sel).putString("codeHash", hacher(c1, sel)).apply()
                        Toast.makeText(this, "Code maître enregistré", Toast.LENGTH_SHORT).show()
                        apres()
                    }
                }
            }
        }
    }

    // ───────────────────────── Dialogues ─────────────────────────

    private fun interrupteur(label: String, etat: Boolean) = Switch(this).apply {
        text = label; isChecked = etat; setTextColor(TEXTE); setPadding(0, dp(10), 0, dp(10))
    }

    private fun dialogueReglages() {
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Paramètres")
            .setItems(arrayOf(
                if (sombre) "Passer en mode clair" else "Passer en mode sombre",
                if (codeDefini()) "Modifier le code maître" else "Créer le code maître"
            )) { _, i ->
                if (i == 0) changerTheme()
                else if (codeDefini()) protege { creerCode { } } else creerCode { }
            }
            .show()
    }

    /** Création (existant = null) ou modification d'un profil (appelé via protege()). */
    private fun dialogueProfil(existant: Profil?) {
        val boite = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(10), dp(22), 0) }
        val champNom = EditText(this).apply {
            hint = "Nom du profil"; setSingleLine(); setText(existant?.nom ?: "")
            setTextColor(TEXTE); setHintTextColor(ATTENUE)
        }
        boite.addView(champNom)
        var couleurChoisie = existant?.couleur ?: Profil.COULEURS[profils.size % Profil.COULEURS.size]
        var photoNouvelle: Bitmap? = null
        var photoRetiree = false
        var vType = existant?.verrou ?: ""
        var vSel = existant?.verrouSel ?: ""
        var vHash = existant?.verrouHash ?: ""
        var dlg: AlertDialog? = null

        val apercu = FrameLayout(this)
        val selecteur = SelecteurCouleur(this)
        fun photoCourante(): Bitmap? =
            photoNouvelle ?: (if (!photoRetiree && existant != null) photoDe(existant) else null)
        fun majApercu() {
            apercu.removeAllViews()
            val ph = photoCourante()
            if (ph != null) {
                apercu.addView(photoCirculaire(ph, couleurChoisie), FrameLayout.LayoutParams(-1, -1))
            } else {
                apercu.addView(TextView(this).apply {
                    gravity = Gravity.CENTER; textSize = 18f
                    text = champNom.text.toString().trim().ifEmpty { "?" }.take(1).uppercase()
                    background = fond(couleurChoisie, 22)
                    setTextColor(texteSur(couleurChoisie))
                }, FrameLayout.LayoutParams(-1, -1))
            }
        }
        selecteur.couleur = couleurChoisie
        selecteur.auChangement = { c -> couleurChoisie = c; majApercu() }
        majApercu()
        val rangee = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(10)) }
        rangee.addView(apercu, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
        Profil.COULEURS.forEach { c ->
            val v = View(this).apply {
                background = fond(c, 16)
                setOnClickListener { couleurChoisie = c; selecteur.couleur = c; majApercu() }
            }
            rangee.addView(v, LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(8) })
        }
        boite.addView(rangee)
        boite.addView(selecteur, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Photo de profil (galerie)
        val rangeePhoto = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        rangeePhoto.addView(bouton("📷  Choisir une photo") {
            choisirPhoto { uri ->
                Thread {
                    val b = try { lirePhoto(uri) } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
                    runOnUiThread {
                        if (b == null) {
                            Toast.makeText(this, "Image illisible", Toast.LENGTH_SHORT).show()
                        } else {
                            photoNouvelle = b; photoRetiree = false; majApercu()
                        }
                    }
                }.start()
            }
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(8) })
        rangeePhoto.addView(bouton("Retirer") { photoNouvelle = null; photoRetiree = true; majApercu() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        boite.addView(rangeePhoto)

        val swMicro = interrupteur("Autoriser le micro", existant?.micro ?: false)
        val swCam = interrupteur("Autoriser la caméra", existant?.camera ?: false)
        boite.addView(swMicro); boite.addView(swCam)

        // Verrou du profil
        fun libelleVerrou() = when (vType) {
            "code" -> "🔒  Verrou : code"
            "schema" -> "🔒  Verrou : schéma"
            else -> "🔓  Verrou : aucun"
        }
        val btnVerrou = bouton(libelleVerrou()) { }
        btnVerrou.setOnClickListener {
            AlertDialog.Builder(this, themeDialogue)
                .setTitle("Verrou du profil")
                .setItems(arrayOf("Aucun verrou", "Verrouiller par un code", "Verrouiller par un schéma")) { _, i ->
                    when (i) {
                        0 -> { vType = ""; vSel = ""; vHash = ""; btnVerrou.text = libelleVerrou() }
                        1 -> dialogueCreerCodeProfil { c ->
                            vSel = nouveauSel(); vHash = hacher(c, vSel); vType = "code"; btnVerrou.text = libelleVerrou()
                        }
                        2 -> dialogueCreerSchema { sch ->
                            vSel = nouveauSel(); vHash = hacher(sch, vSel); vType = "schema"; btnVerrou.text = libelleVerrou()
                        }
                    }
                }
                .show()
        }
        boite.addView(btnVerrou, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })

        if (existant != null) {
            boite.addView(bouton("⧉  Dupliquer ce profil") { dlg?.dismiss(); dupliquer(existant) },
                LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        }

        val b = AlertDialog.Builder(this, themeDialogue)
            .setTitle(if (existant == null) "Nouveau profil" else "Profil « ${existant.nom} »")
            .setView(ScrollView(this).apply { addView(boite) })
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val nom = champNom.text.toString().trim().ifEmpty { "Profil ${profils.size + 1}" }
                val cible: Profil
                if (existant == null) {
                    cible = Profil.nouveau(nom, couleurChoisie, swMicro.isChecked, swCam.isChecked)
                    profils.add(cible)
                } else {
                    cible = existant
                    existant.nom = nom; existant.couleur = couleurChoisie
                    existant.micro = swMicro.isChecked; existant.camera = swCam.isChecked
                    if (courant?.id == existant.id) majPuce()
                }
                cible.verrou = vType; cible.verrouSel = vSel; cible.verrouHash = vHash
                val ph = photoNouvelle
                if (ph != null) enregistrerPhoto(cible.id, ph) else if (photoRetiree) retirerPhoto(cible.id)
                depot.sauver(profils); rafraichirListe()
            }
        if (existant != null) b.setNeutralButton("Supprimer") { _, _ -> confirmerSuppression(existant) }
        val fenetre = b.create()
        dlg = fenetre
        fenetre.show()
    }

    private fun confirmerSuppression(p: Profil) {
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Supprimer « ${p.nom} » ?")
            .setMessage("Les cookies, connexions et données de ce profil seront effacés définitivement.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Supprimer") { _, _ -> supprimerProfil(p) }
            .show()
    }

    private fun dialogueChangerProfil() {
        if (profils.isEmpty()) return
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Changer de profil")
            .setItems(profils.map { (if (it.verrouille) "🔒 " else "") + it.nom }.toTypedArray()) { _, i ->
                if (profils[i].id != courant?.id) ouvrirProfilProtege(profils[i])
            }
            .show()
    }

    /** Menu ⚙ du navigateur : interrupteur Mode libre, puis onglets et paramètres (les autorisations restent à l'extérieur). */
    private fun menuNavigateur() {
        val p = courant ?: return
        val libelles = arrayOf(
            "Nouvel onglet",
            "Actualiser",
            "★ Favoris (${p.favoris.size})",
            "⬇ Téléchargements",
            "🧹 Effacer cookies et données de site",
            "🔒 DNS privé (réglage du téléphone)",
            "Moteur de recherche : ${Profil.moteur(p.moteur).nom}",
            if (sombre) "Passer en mode clair" else "Passer en mode sombre",
            "Fermer cet onglet"
        )
        val actions = listOf<() -> Unit>(
            { nouvelOnglet() },
            { wvActif()?.reload() },
            { ecranFavoris() },
            { ecranTelechargements() },
            { confirmer("Effacer les cookies ?", "« ${p.nom} » sera déconnecté de tous les sites. Les favoris sont conservés.", "Effacer") { effacerDonneesSite(p) } },
            { dialogueDns() },
            { dialogueMoteur(p) },
            { changerTheme() },
            { fermerOnglet(p.actif) }
        )
        val colonne = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        lateinit var dialogue: AlertDialog
        colonne.addView(Switch(this).apply {
            text = "$ICO_LIBRE Mode libre"; textSize = 16f; setTextColor(TEXTE)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            isChecked = p.libre
            setOnCheckedChangeListener { _, voulu -> dialogue.dismiss(); if (voulu != p.libre) basculerMode(p) }
        })
        libelles.forEachIndexed { i, texte ->
            colonne.addView(TextView(this).apply {
                text = texte; textSize = 16f; setTextColor(TEXTE)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                setOnClickListener { dialogue.dismiss(); actions[i]() }
            })
        }
        dialogue = AlertDialog.Builder(this, themeDialogue)
            .setTitle("Profil « ${p.nom} »")
            .setView(ScrollView(this).apply { addView(colonne) })
            .create()
        dialogue.show()
    }

    /** Une appli ne peut pas imposer le DNS chiffré : c'est un réglage Android (DNS privé), qui protège aussi la WebView. */
    private fun dialogueDns() {
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("DNS privé (DNS sur TLS)")
            .setMessage("Android chiffre les noms de sites que vous visitez si vous activez « DNS privé ».\n\nSamsung : Paramètres → Connexions → Plus de paramètres de connexion → DNS privé → Nom d'hôte du fournisseur, puis saisir par exemple :\n• dns.quad9.net\n• dns.adguard-dns.com (bloque aussi des pubs)\n\nCe réglage s'applique à tout le téléphone, donc aussi à cette appli.")
            .setPositiveButton("Ouvrir les réglages") { _, _ ->
                try { startActivity(android.content.Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)) } catch (e: Exception) { }
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun dialogueMoteur(p: Profil) {
        val noms = Profil.MOTEURS.map { it.nom }.toTypedArray()
        val actuel = Profil.MOTEURS.indexOfFirst { it.id == p.moteur }.coerceAtLeast(0)
        AlertDialog.Builder(this, themeDialogue)
            .setTitle("Moteur de recherche")
            .setSingleChoiceItems(noms, actuel) { d, i ->
                p.moteur = Profil.MOTEURS[i].id
                depot.sauver(profils); rafraichirListe(); d.dismiss()
            }
            .show()
    }

    /** Strict → libre : code maître. Libre → strict : immédiat. */
    private fun basculerMode(p: Profil) {
        if (p.libre) { definirMode(p, false); return }
        protege { definirMode(p, true) }
    }

    private fun definirMode(p: Profil, libre: Boolean) {
        p.libre = libre
        depot.sauver(profils)
        // Mode libre : on demande tout de suite au système l'accès au micro (une seule fois)
        if (libre) demanderAndroid(listOf(Manifest.permission.RECORD_AUDIO)) { }
        onglets[p.id]?.forEach { appliquerMode(it.wv, p) }
        majPuce()
        wvActif()?.reload()
        majGardeActive()
        Toast.makeText(this, if (libre) "Mode libre activé" else "Mode strict activé", Toast.LENGTH_SHORT).show()
    }

    // ───────────────────────── Profils et onglets ─────────────────────────

    private fun afficherListe() {
        fermerToutesPopups()
        courant?.let { deverrouilles.remove(it.id) }
        courant = null
        ecranNavigateur.visibility = View.GONE
        ecranListe.visibility = View.VISIBLE
        rafraichirListe()
    }

    private fun majPuce() {
        val p = courant ?: return
        puce.text = if (p.libre) "$ICO_LIBRE ${p.nom}" else p.nom
        puce.background = fond(p.couleur, 17)
        puce.setTextColor(texteSur(p.couleur))
    }

    private fun accueil(p: Profil) = Profil.moteur(p.moteur).accueil

    private fun wvActif(): WebView? {
        val p = courant ?: return null
        return onglets[p.id]?.getOrNull(p.actif)?.wv
    }

    private fun estActif(p: Profil, o: Onglet) =
        courant?.id == p.id && onglets[p.id]?.getOrNull(p.actif) === o

    private fun ouvrirProfil(p: Profil) {
        fermerToutesPopups()
        deverrouilles.retainAll { it == p.id }
        courant = p
        if (p.onglets.isEmpty()) p.onglets.add(accueil(p))
        val liste = onglets.getOrPut(p.id) {
            p.onglets.map { creerOnglet(p, it) }.toMutableList()
        }
        ecranListe.visibility = View.GONE
        ecranNavigateur.visibility = View.VISIBLE
        majPuce()
        afficherOnglet(p.actif.coerceIn(0, liste.size - 1))
    }

    private fun afficherOnglet(i: Int) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        fermerToutesPopups()
        p.actif = i
        depot.sauver(profils)
        val o = liste[i]
        conteneurWeb.removeAllViews()
        (o.wv.parent as? ViewGroup)?.removeView(o.wv)
        conteneurWeb.addView(o.wv, FrameLayout.LayoutParams(-1, -1))
        o.enAttente?.let { o.enAttente = null; o.wv.loadUrl(it) }
        barreUrl.setText(o.wv.url ?: p.onglets.getOrNull(i) ?: "")
        progression.visibility = View.GONE
        majBarreOnglets()
        majEtoile()
    }

    private fun nouvelOnglet(url: String? = null) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        val u = url ?: accueil(p)
        p.onglets.add(u)
        liste.add(creerOnglet(p, u))
        afficherOnglet(liste.size - 1)
    }

    private fun fermerOnglet(i: Int) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        if (i !in liste.indices) return
        val o = liste.removeAt(i)
        p.onglets.removeAt(i)
        (o.wv.parent as? ViewGroup)?.removeView(o.wv)
        o.wv.destroy()
        if (liste.isEmpty()) {
            val u = accueil(p)
            p.onglets.add(u)
            liste.add(creerOnglet(p, u))
            afficherOnglet(0)
        } else {
            var a = p.actif
            if (i < a) a--
            afficherOnglet(a.coerceIn(0, liste.size - 1))
        }
    }

    private fun majBarreOnglets() {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        if (glisseOnglet) return
        barreOnglets.removeAllViews()
        liste.forEachIndexed { i, o ->
            val actifOnglet = i == p.actif
            val couleurTexte = if (actifOnglet) texteSur(p.couleur) else TEXTE
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = fond(if (actifOnglet) p.couleur else CARTE, 10)
                setPadding(dp(12), 0, dp(4), 0)
            }
            rendreGlissable(chip, i)
            val url = o.wv.url ?: p.onglets.getOrNull(i) ?: ""
            val titre = o.titre.ifEmpty {
                val h = Uri.parse(url).host
                if (h == HOTE_FICHIERS) (Uri.parse(url).lastPathSegment ?: "Fichier") else (h ?: "Nouvel onglet")
            }
            chip.addView(TextView(this).apply {
                text = if (titre.length > 16) titre.take(15) + "…" else titre
                textSize = 12f; setTextColor(couleurTexte); setSingleLine()
            })
            chip.addView(TextView(this).apply {
                text = "✕"; textSize = 13f; setTextColor(couleurTexte); gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener { fermerOnglet(i) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
            barreOnglets.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)).apply { rightMargin = dp(6) })
        }
        barreOnglets.addView(TextView(this).apply {
            text = "＋"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(TEXTE)
            background = fond(CARTE, 10); setOnClickListener { nouvelOnglet() }
        }, LinearLayout.LayoutParams(dp(40), dp(34)))
    }

    /** Déplace l'onglet de la position `de` vers `vers` (liste des WebView et liste sauvegardée), l'onglet actif reste le même. */
    private fun deplacerOnglet(de: Int, vers: Int) {
        val p = courant ?: return
        val liste = onglets[p.id] ?: return
        if (de !in liste.indices || vers !in liste.indices || de == vers) return
        val actifObj = liste.getOrNull(p.actif)
        val o = liste.removeAt(de); liste.add(vers, o)
        val u = p.onglets.removeAt(de); p.onglets.add(vers, u)
        p.actif = actifObj?.let { liste.indexOf(it) }?.takeIf { it >= 0 } ?: p.actif.coerceIn(0, liste.size - 1)
        depot.sauver(profils)
        majBarreOnglets()
    }

    /**
     * Toucher = afficher l'onglet. Appui long puis glisser = changer sa place dans la barre
     * (les autres onglets s'écartent ; la barre défile près des bords).
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun rendreGlissable(chip: View, i: Int) {
        val marge = dp(6)
        val seuil = ViewConfiguration.get(this).scaledTouchSlop
        var x0 = 0f; var y0 = 0f; var contenu0 = 0f; var derniereX = 0f
        var glisse = false
        var cible = i
        val loc = IntArray(2)

        fun xContenu(rawX: Float): Float { barreOnglets.getLocationOnScreen(loc); return rawX - loc[0] }
        fun nbOnglets() = courant?.let { onglets[it.id]?.size } ?: 0

        fun suivre() {
            val n = nbOnglets()
            if (n == 0 || n > barreOnglets.childCount) return
            val dx = xContenu(derniereX) - contenu0
            chip.translationX = dx
            val centre = chip.left + chip.width / 2f + dx
            cible = (0 until n).count { k ->
                if (k == i) false else { val v = barreOnglets.getChildAt(k); v.left + v.width / 2f < centre }
            }
            val pas = (chip.width + marge).toFloat()
            for (k in 0 until n) {
                if (k == i) continue
                barreOnglets.getChildAt(k).translationX = when {
                    i < cible && k in (i + 1)..cible -> -pas
                    cible < i && k in cible until i -> pas
                    else -> 0f
                }
            }
        }

        val boucle = object : Runnable {
            override fun run() {
                if (!glisse) return
                defilOnglets.getLocationOnScreen(loc)
                val xr = derniereX - loc[0]
                if (xr < dp(48)) defilOnglets.scrollBy(-dp(10), 0)
                else if (xr > defilOnglets.width - dp(48)) defilOnglets.scrollBy(dp(10), 0)
                suivre()
                chip.postDelayed(this, 16)
            }
        }

        fun terminer(valider: Boolean) {
            glisse = false
            chip.removeCallbacks(boucle)
            for (k in 0 until barreOnglets.childCount) barreOnglets.getChildAt(k).translationX = 0f
            chip.alpha = 1f; chip.elevation = 0f
            glisseOnglet = false
            if (valider && cible != i) deplacerOnglet(i, cible) else majBarreOnglets()
        }

        val declencher = Runnable {
            glisse = true; glisseOnglet = true; cible = i
            chip.parent?.requestDisallowInterceptTouchEvent(true)
            chip.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            chip.alpha = 0.9f; chip.elevation = dp(8).toFloat()
            chip.post(boucle)
        }

        chip.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    glisse = false; cible = i
                    x0 = e.rawX; y0 = e.rawY; derniereX = e.rawX; contenu0 = xContenu(e.rawX)
                    v.postDelayed(declencher, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    derniereX = e.rawX
                    if (!glisse && (Math.abs(e.rawX - x0) > seuil || Math.abs(e.rawY - y0) > seuil)) v.removeCallbacks(declencher)
                }
                MotionEvent.ACTION_UP -> {
                    v.removeCallbacks(declencher)
                    if (glisse) terminer(true) else afficherOnglet(i)
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(declencher)
                    if (glisse) terminer(false)
                }
            }
            true
        }
    }

    private fun naviguer(saisie: String) {
        if (saisie.isEmpty()) return
        val p = courant ?: return
        val url = when {
            saisie.startsWith("http://") || saisie.startsWith("https://") -> saisie
            !saisie.contains(" ") && saisie.contains(".") -> "https://$saisie"
            else -> Profil.moteur(p.moteur).recherche + java.net.URLEncoder.encode(saisie, "UTF-8")
        }
        wvActif()?.loadUrl(url)
    }

    // ───────────────────────── WebView par onglet ─────────────────────────

    /** Applique profil, cookies et réglages. setProfile doit précéder tout autre usage de la WebView. */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configurer(wv: WebView, p: Profil) {
        if (isolationOk) {
            ProfileStore.getInstance().getOrCreateProfile(p.nomInterne)
            WebViewCompat.setProfile(wv, p.nomInterne)
        }
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            // Fonctions web de base, dans les deux modes
            @Suppress("DEPRECATION") databaseEnabled = true
            setGeolocationEnabled(true)
            useWideViewPort = true
            loadWithOverviewMode = true
            // Indispensable pour la connexion Google (fenêtre pop-up qui renvoie le résultat à la page)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            // Zoom par pincement (PDF, pages web, images)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Google refuse la connexion dans une WebView « brute » : on retire les marqueurs « wv »
            userAgentString = userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        }
        wv.setBackgroundColor(FOND)
        wv.addJavascriptInterface(pontTelechargement, "AppDl")
        // Ponts natifs + script injecté au tout début de chaque page (avant ses propres scripts)
        wv.addJavascriptInterface(ponts.pontPour { p.libre || p.micro }, "AppNatif")
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(wv, ponts.script, setOf("*"))
        }
        wv.setDownloadListener { url, agent, contentDisposition, mime, _ ->
            telecharger(p, wv, url, agent, contentDisposition, mime)
        }
        appliquerMode(wv, p)
    }

    /**
     * Mode strict (par défaut) : cookies tiers refusés, Safe Browsing actif, accès fichiers fermé.
     * Mode libre : cookies tiers acceptés, Safe Browsing coupé, accès fichiers ouvert (vos propres pages).
     */
    private val scriptsProtection = java.util.WeakHashMap<WebView, androidx.webkit.ScriptHandler>()

    private fun appliquerMode(wv: WebView, p: Profil) {
        // Anti-empreinte : actif en strict, retiré en libre (vos propres pages)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            scriptsProtection.remove(wv)?.remove()
            if (!p.libre) scriptsProtection[wv] = WebViewCompat.addDocumentStartJavaScript(wv, Protection.SCRIPT_ANTI_EMPREINTE, setOf("*"))
        }
        if (isolationOk) {
            ProfileStore.getInstance().getOrCreateProfile(p.nomInterne)
                .cookieManager.setAcceptThirdPartyCookies(wv, p.libre)
        } else {
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, p.libre)
        }
        with(wv.settings) {
            safeBrowsingEnabled = !p.libre
            allowFileAccess = p.libre
            allowContentAccess = p.libre
            @Suppress("DEPRECATION") allowFileAccessFromFileURLs = p.libre
            @Suppress("DEPRECATION") allowUniversalAccessFromFileURLs = p.libre
            mixedContentMode = if (p.libre) android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                               else android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
    }

    private fun creerOnglet(p: Profil, url: String): Onglet {
        val wv = WebView(this)
        configurer(wv, p)
        // Un fichier local ouvert avant la fermeture de l'appli n'existe plus : on retombe sur l'accueil
        val cible = if (estUrlFichier(url) && !fichierConnu(url)) accueil(p) else url
        val o = Onglet(wv, cible)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                lienExterne(request.url.toString())
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (!p.libre && Protection.doitBloquer(request)) return Protection.reponseVide()
                return reponseFichierLocal(request)
            }
            override fun onPageFinished(view: WebView, u: String) {
                view.evaluateJavascript(ponts.script, null) // filet de sécurité (le script ne s'applique qu'une fois)
                if (u.startsWith("http")) {
                    val i = onglets[p.id]?.indexOf(o) ?: -1
                    if (i >= 0 && i < p.onglets.size) { p.onglets[i] = u; depot.sauver(profils) }
                }
                if (estActif(p, o)) { barreUrl.setText(u); majEtoile() }
                sauverCookies()
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, progress: Int) {
                if (!estActif(p, o)) return
                progression.progress = progress
                progression.visibility = if (progress in 1..99) View.VISIBLE else View.GONE
            }
            override fun onReceivedTitle(view: WebView, title: String?) {
                o.titre = title ?: ""
                if (courant?.id == p.id) majBarreOnglets()
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { traiterDemande(p, request) }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                runOnUiThread { traiterGeoloc(p, origin, callback) }
            }
            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                runOnUiThread { afficherPleinEcran(view, callback) }
            }
            override fun onHideCustomView() {
                runOnUiThread { quitterPleinEcran() }
            }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                return ouvrirPopup(p, resultMsg)
            }
            override fun onShowFileChooser(view: WebView, rappel: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
                return choisirFichiers(rappel, params)
            }
        }
        return o
    }

    // ───────────────────────── Plein écran (vidéos, jeux, pages) ─────────────────────────

    private var vuePleinEcran: View? = null
    private var rappelPleinEcran: WebChromeClient.CustomViewCallback? = null

    private fun afficherPleinEcran(vue: View, rappel: WebChromeClient.CustomViewCallback) {
        if (vuePleinEcran != null) { rappel.onCustomViewHidden(); return }
        vuePleinEcran = vue
        rappelPleinEcran = rappel
        vue.setBackgroundColor(android.graphics.Color.BLACK)
        (window.decorView as FrameLayout).addView(
            vue, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(android.view.WindowInsets.Type.systemBars())
                it.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    private fun quitterPleinEcran() {
        val v = vuePleinEcran ?: return
        (window.decorView as FrameLayout).removeView(v)
        vuePleinEcran = null
        rappelPleinEcran?.onCustomViewHidden()
        rappelPleinEcran = null
        barresSysteme()
    }

    /**
     * Liens qui ne sont pas des pages web (mailto:, tel:, sms:, geo:, intent:, market:…) : la WebView ne sait pas
     * les ouvrir et afficherait une erreur (ou quitterait la page). On les confie à l'appli Android adaptée.
     * Renvoie true si le lien a été pris en charge ici (la WebView ne doit pas le charger), false pour une page web normale.
     */
    private val schemasWeb = setOf("http", "https", "file", "about", "data", "blob", "javascript", "content", "view-source", "chrome")

    private fun lienExterne(url: String): Boolean {
        val u = Uri.parse(url)
        val schema = u.scheme?.lowercase() ?: return false
        if (schema in schemasWeb) return false
        try {
            val i = when (schema) {
                "intent" -> Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE); component = null; selector = null
                }
                "mailto" -> Intent(Intent.ACTION_SENDTO, u)
                else -> Intent(Intent.ACTION_VIEW, u)
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Aucune appli pour ouvrir ce lien ($schema:)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Lien impossible à ouvrir", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    /** Pop-up (connexion Google, etc.) : WebView enfant du MÊME profil, posée par-dessus la page. */
    private fun ouvrirPopup(p: Profil, resultMsg: android.os.Message): Boolean {
        val popup = WebView(this)
        configurer(popup, p)
        val zone = FrameLayout(this).apply { setBackgroundColor(FOND); isClickable = true }
        popup.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                lienExterne(request.url.toString())
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (!p.libre && Protection.doitBloquer(request)) Protection.reponseVide() else null
        }
        popup.webChromeClient = object : WebChromeClient() {
            override fun onCloseWindow(window: WebView) {
                runOnUiThread { fermerPopup(window) }
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { traiterDemande(p, request) }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                runOnUiThread { traiterGeoloc(p, origin, callback) }
            }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, msg: android.os.Message): Boolean {
                return ouvrirPopup(p, msg)
            }
        }
        zone.addView(popup, FrameLayout.LayoutParams(-1, -1))
        zone.tag = popup
        conteneurWeb.addView(zone, FrameLayout.LayoutParams(-1, -1))
        val transport = resultMsg.obj as WebView.WebViewTransport
        transport.webView = popup
        resultMsg.sendToTarget()
        return true
    }

    private fun fermerPopup(popup: WebView) {
        val zone = popup.parent as? ViewGroup ?: return
        (zone.parent as? ViewGroup)?.removeView(zone)
        zone.removeAllViews()
        popup.destroy()
    }

    private fun fermerToutesPopups() {
        while (true) { fermerPopup(popupOuverte() ?: break) }
    }

    /** Pop-up la plus récente du conteneur, si elle existe. */
    private fun popupOuverte(): WebView? {
        for (i in conteneurWeb.childCount - 1 downTo 0) {
            val t = conteneurWeb.getChildAt(i).tag
            if (t is WebView) return t
        }
        return null
    }

    private fun detruire(o: Onglet) {
        (o.wv.parent as? ViewGroup)?.removeView(o.wv)
        o.wv.destroy()
    }

    private fun supprimerProfil(p: Profil) {
        if (courant?.id == p.id) fermerToutesPopups()
        onglets.remove(p.id)?.forEach { detruire(it) }
        if (isolationOk) {
            try {
                val store = ProfileStore.getInstance()
                // Efface d'abord les données (au cas où la suppression échoue), puis supprime le profil
                store.getProfile(p.nomInterne)?.let {
                    it.cookieManager.removeAllCookies(null)
                    it.webStorage.deleteAllData()
                }
                store.deleteProfile(p.nomInterne)
            } catch (e: Exception) {
                Toast.makeText(this, "Profil retiré (données à purger au prochain démarrage)", Toast.LENGTH_LONG).show()
            }
        }
        profils.removeAll { it.id == p.id }
        depot.sauver(profils)
        depot.oublier(p.id)
        depotDl.oublier(p.id)
        retirerPhoto(p.id)
        deverrouilles.remove(p.id)
        if (courant?.id == p.id) afficherListe() else rafraichirListe()
    }

    // ───────────────────────── Verrou de profil (code ou schéma, le code maître ouvre toujours) ─────────────────────────

    private fun nouveauSel(): String {
        val octets = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return octets.joinToString("") { "%02x".format(it) }
    }

    private fun codeMaitreOk(c: String): Boolean {
        val h = reglages.getString("codeHash", null) ?: return false
        return hacher(c, reglages.getString("codeSel", "") ?: "") == h
    }

    /** Ouvre le profil, après avoir levé son verrou s'il en a un. `suite` s'exécute une fois le profil ouvert. */
    private fun ouvrirProfilProtege(p: Profil, suite: () -> Unit = {}) {
        if (!p.verrouille || p.id in deverrouilles) { ouvrirProfil(p); suite(); return }
        demanderDeverrouillage(p) { deverrouilles.add(p.id); ouvrirProfil(p); suite() }
    }

    private fun demanderDeverrouillage(p: Profil, ok: () -> Unit) {
        if (p.verrou == "schema") { dialogueSchemaDeverrouillage(p, ok); return }
        champCode("Profil « ${p.nom} »", "Code du profil (ou code maître).") { c ->
            if (hacher(c, p.verrouSel) == p.verrouHash || codeMaitreOk(c)) ok()
            else Toast.makeText(this, "Code incorrect", Toast.LENGTH_SHORT).show()
        }
    }

    private fun boiteSchema(message: TextView, vue: SchemaVue) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(10), dp(22), dp(6))
        addView(message)
        addView(vue, LinearLayout.LayoutParams(dp(250), dp(250)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
    }

    private fun messageSchema(texte: String) = TextView(this).apply {
        text = texte; setTextColor(ATTENUE); gravity = Gravity.CENTER; textSize = 14f
    }

    private fun dialogueSchemaDeverrouillage(p: Profil, ok: () -> Unit) {
        val message = messageSchema("Dessinez le schéma du profil")
        val vue = SchemaVue(this, Color.parseColor("#4F8CFF"), ATTENUE)
        val d = AlertDialog.Builder(this, themeDialogue)
            .setTitle("Profil « ${p.nom} »")
            .setView(boiteSchema(message, vue))
            .setNegativeButton("Annuler", null)
            .setNeutralButton("Code maître") { _, _ ->
                champCode("Code maître", null) { c ->
                    if (codeMaitreOk(c)) ok() else Toast.makeText(this, "Code incorrect", Toast.LENGTH_SHORT).show()
                }
            }
            .create()
        vue.auFini = { pts ->
            if (hacher(pts.joinToString("-"), p.verrouSel) == p.verrouHash) {
                d.dismiss(); ok()
            } else {
                message.text = "Schéma incorrect"; message.setTextColor(Color.parseColor("#FF6B6B"))
                handler.postDelayed({ vue.effacer() }, 500)
            }
        }
        d.show()
    }

    private fun dialogueCreerSchema(ok: (String) -> Unit) {
        var premier: String? = null
        val message = messageSchema("Dessinez un schéma (4 points minimum)")
        val vue = SchemaVue(this, Color.parseColor("#4F8CFF"), ATTENUE)
        val d = AlertDialog.Builder(this, themeDialogue)
            .setTitle("Schéma du profil")
            .setView(boiteSchema(message, vue))
            .setNegativeButton("Annuler", null)
            .create()
        vue.auFini = { pts ->
            val s = pts.joinToString("-")
            if (pts.size < 4) {
                message.text = "Trop court : 4 points minimum"
                handler.postDelayed({ vue.effacer() }, 500)
            } else if (premier == null) {
                premier = s
                message.text = "Dessinez-le encore une fois pour confirmer"
                handler.postDelayed({ vue.effacer() }, 300)
            } else if (premier == s) {
                d.dismiss(); ok(s)
            } else {
                premier = null
                message.text = "Les deux schémas sont différents, recommencez"
                handler.postDelayed({ vue.effacer() }, 500)
            }
        }
        d.show()
    }

    private fun dialogueCreerCodeProfil(ok: (String) -> Unit) {
        champCode("Code du profil", "4 caractères minimum. Le code maître permet toujours d'ouvrir le profil.") { c1 ->
            if (c1.length < 4) {
                Toast.makeText(this, "Code trop court", Toast.LENGTH_SHORT).show()
            } else {
                champCode("Confirmer le code", null) { c2 ->
                    if (c1 != c2) Toast.makeText(this, "Les deux codes sont différents", Toast.LENGTH_SHORT).show()
                    else ok(c1)
                }
            }
        }
    }

    /** Copie d'un profil : mêmes réglages, favoris, photo et verrou. Les connexions ne sont pas copiées. */
    private fun dupliquer(p: Profil) {
        val c = Profil(
            Profil.nouveauId(), p.nom + " (copie)", p.couleur, p.micro, p.camera, p.moteur,
            mutableListOf(), 0, p.libre, p.verrou, p.verrouSel, p.verrouHash
        )
        c.favoris.addAll(p.favoris)
        val f = fichierPhoto(p.id)
        if (f.exists()) {
            try {
                val cible = fichierPhoto(c.id)
                cible.parentFile?.mkdirs()
                f.copyTo(cible, true)
            } catch (e: Exception) { /* la copie se passera de photo */ }
        }
        profils.add(profils.indexOf(p) + 1, c)
        depot.sauver(profils); depot.sauverFavoris(c)
        rafraichirListe()
        Toast.makeText(this, "Profil dupliqué (sans connexions)", Toast.LENGTH_LONG).show()
    }

    // ───────────────────────── Écrans en liste : favoris, téléchargements ─────────────────────────

    /** Écran plein : titre, boutons d'action en haut, liste défilante. `remplir` reconstruit la liste. */
    private inner class EcranListe(titre: String) {
        val dialogue = Dialog(
            this@MainActivity,
            if (sombre) android.R.style.Theme_DeviceDefault_NoActionBar else android.R.style.Theme_DeviceDefault_Light_NoActionBar
        )
        private val actions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        private val liste = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(12))
        }
        var remplir: (LinearLayout) -> Unit = { }

        init {
            val racine = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(FOND) }
            val entete = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(14), dp(8), dp(6))
            }
            entete.addView(bouton("←") { dialogue.dismiss() }, LinearLayout.LayoutParams(dp(48), dp(40)))
            entete.addView(TextView(this@MainActivity).apply {
                text = titre; textSize = 20f; setTextColor(TEXTE); setSingleLine()
                ellipsize = TextUtils.TruncateAt.END; setPadding(dp(10), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            racine.addView(entete)
            racine.addView(HorizontalScrollView(this@MainActivity).apply {
                isHorizontalScrollBarEnabled = false; setPadding(dp(12), 0, dp(12), dp(8)); addView(actions)
            }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            racine.addView(ScrollView(this@MainActivity).apply { addView(liste) }, LinearLayout.LayoutParams(-1, 0, 1f))
            dialogue.setContentView(racine)
            dialogue.window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                statusBarColor = FOND; navigationBarColor = FOND
            }
        }

        fun action(label: String, f: () -> Unit) {
            actions.addView(bouton(label) { f() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply { rightMargin = dp(8) })
        }

        fun rafraichir() { liste.removeAllViews(); remplir(liste) }

        fun afficher() { rafraichir(); dialogue.show() }
    }

    private fun texteVide(t: String) = TextView(this).apply {
        text = t; setTextColor(ATTENUE); textSize = 14f; setPadding(dp(4), dp(16), dp(4), dp(16))
    }

    private fun enteteJour(t: String) = TextView(this).apply {
        text = t; setTextColor(ATTENUE); textSize = 12f; setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(4), dp(14), dp(4), dp(6))
    }

    private fun ajouterLigne(l: LinearLayout, titre: String, sous: String?, clic: () -> Unit,
                             croix: (() -> Unit)? = null, appui: (() -> Unit)? = null) {
        val ligne = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = fond(CARTE, 12); setPadding(dp(14), dp(10), dp(6), dp(10))
            setOnClickListener { clic() }
            if (appui != null) setOnLongClickListener { appui(); true }
        }
        val textes = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textes.addView(TextView(this).apply {
            text = titre; textSize = 15f; setTextColor(TEXTE); setSingleLine(); ellipsize = TextUtils.TruncateAt.END
        })
        if (sous != null) textes.addView(TextView(this).apply {
            text = sous; textSize = 11f; setTextColor(ATTENUE); setSingleLine(); ellipsize = TextUtils.TruncateAt.END
        })
        ligne.addView(textes, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (croix != null) ligne.addView(TextView(this).apply {
            text = "✕"; textSize = 16f; setTextColor(ATTENUE); setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { croix() }
        })
        l.addView(ligne, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
    }

    private fun confirmer(titre: String, message: String, libelle: String, action: () -> Unit) {
        AlertDialog.Builder(this, themeDialogue)
            .setTitle(titre).setMessage(message)
            .setNegativeButton("Annuler", null)
            .setPositiveButton(libelle) { _, _ -> action() }
            .show()
    }

    // ----- Favoris -----

    private fun urlFavorisable(): String? {
        val u = wvActif()?.url ?: return null
        return if (u.startsWith("http://") || u.startsWith("https://")) u else null
    }

    private fun basculerFavori(ajouterSeulement: Boolean = false) {
        val p = courant ?: return
        val u = urlFavorisable()
        if (u == null) {
            Toast.makeText(this, "Cette page ne peut pas être mise en favori", Toast.LENGTH_SHORT).show()
            return
        }
        val existant = p.favoris.firstOrNull { it.url == u }
        if (existant != null) {
            if (ajouterSeulement) {
                Toast.makeText(this, "Déjà dans les favoris", Toast.LENGTH_SHORT).show(); return
            }
            p.favoris.remove(existant)
            Toast.makeText(this, "Retiré des favoris", Toast.LENGTH_SHORT).show()
        } else {
            p.favoris.add(0, Favori(wvActif()?.title ?: "", u))
            Toast.makeText(this, "Ajouté aux favoris", Toast.LENGTH_SHORT).show()
        }
        depot.sauverFavoris(p)
        majEtoile()
    }

    private fun majEtoile() {
        val p = courant
        val u = wvActif()?.url
        etoile.text = if (p != null && u != null && p.favoris.any { it.url == u }) "★" else "☆"
    }

    private fun ecranFavoris() {
        val p = courant ?: return
        val e = EcranListe("★ Favoris · ${p.nom}")
        e.action("＋ Ajouter cette page") { basculerFavori(true); e.rafraichir() }
        e.remplir = { l ->
            if (p.favoris.isEmpty()) l.addView(texteVide("Aucun favori. Touchez ☆ dans la barre d'adresse pour en ajouter un."))
            p.favoris.toList().forEach { f ->
                ajouterLigne(l, f.titre.ifEmpty { f.url }, f.url,
                    { e.dialogue.dismiss(); wvActif()?.loadUrl(f.url) },
                    { p.favoris.remove(f); depot.sauverFavoris(p); majEtoile(); e.rafraichir() })
            }
        }
        e.afficher()
    }

    /** Cookies, connexions et stockage des sites de ce profil (les favoris restent). */
    private fun effacerDonneesSite(p: Profil) {
        try {
            if (isolationOk) {
                ProfileStore.getInstance().getProfile(p.nomInterne)?.let {
                    it.cookieManager.removeAllCookies(null)
                    it.webStorage.deleteAllData()
                }
            } else {
                CookieManager.getInstance().removeAllCookies(null)
                WebStorage.getInstance().deleteAllData()
            }
            onglets[p.id]?.forEach { it.wv.clearCache(true) }
            sauverCookies()
            Toast.makeText(this, "Cookies et données de site effacés", Toast.LENGTH_SHORT).show()
            wvActif()?.reload()
        } catch (e: Exception) {
            Toast.makeText(this, "Effacement impossible : ${e.message ?: "erreur"}", Toast.LENGTH_LONG).show()
        }
    }

    // ----- Téléchargements -----

    private fun libelleTelechargement(t: Telechargement): String {
        val date = SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(t.date))
        val etat = if (t.id < 0) "✓ Enregistré" else {
            val s = Telechargeur.etat(this, t.id)
            when {
                s == null -> "Fichier supprimé ou introuvable"
                s.code == DownloadManager.STATUS_SUCCESSFUL -> "✓ Terminé"
                s.code == DownloadManager.STATUS_FAILED -> "✗ Échec"
                s.code == DownloadManager.STATUS_PAUSED -> "⏸ En pause"
                s.code == DownloadManager.STATUS_PENDING -> "En attente…"
                s.total > 0 -> "Téléchargement… ${s.octets * 100 / s.total} %"
                else -> "Téléchargement…"
            }
        }
        return "$etat  ·  $date"
    }

    private fun enCours(t: Telechargement): Boolean {
        val c = Telechargeur.etat(this, t.id)?.code ?: return false
        return c == DownloadManager.STATUS_PENDING || c == DownloadManager.STATUS_RUNNING || c == DownloadManager.STATUS_PAUSED
    }

    private fun ecranTelechargements() {
        val p = courant ?: return
        val e = EcranListe("⬇ Téléchargements · ${p.nom}")
        e.action("Ouvrir le dossier Téléchargements") { Telechargeur.ouvrirDossier(this) }
        e.action("Vider la liste") {
            confirmer("Vider la liste ?", "Les fichiers déjà téléchargés restent sur le téléphone.", "Vider") {
                depotDl.sauver(p.id, emptyList()); e.rafraichir()
            }
        }
        e.remplir = { l ->
            val liste = depotDl.liste(p.id)
            if (liste.isEmpty()) l.addView(texteVide("Aucun téléchargement dans ce profil. Les fichiers vont dans le dossier Téléchargements du téléphone."))
            liste.forEach { t ->
                ajouterLigne(l, t.nom, libelleTelechargement(t),
                    {
                        if (enCours(t)) Toast.makeText(this, "Téléchargement en cours…", Toast.LENGTH_SHORT).show()
                        else if (!Telechargeur.ouvrir(this, t)) Toast.makeText(this, "Impossible d'ouvrir ce fichier (supprimé ou aucune appli compatible)", Toast.LENGTH_LONG).show()
                    },
                    null,
                    {
                        AlertDialog.Builder(this, themeDialogue).setTitle(t.nom)
                            .setItems(arrayOf("Retirer de la liste", "Supprimer aussi le fichier")) { _, i ->
                                if (i == 1) Telechargeur.supprimerFichier(this, t)
                                val reste = depotDl.liste(p.id)
                                reste.removeAll { it.id == t.id && it.uri == t.uri && it.date == t.date }
                                depotDl.sauver(p.id, reste)
                                e.rafraichir()
                            }.show()
                    })
            }
        }
        // Tant qu'un téléchargement est en cours, la liste se met à jour toute seule
        val suivi = object : Runnable {
            override fun run() {
                if (!e.dialogue.isShowing) return
                if (depotDl.liste(p.id).any { enCours(it) }) {
                    e.rafraichir()
                    handler.postDelayed(this, 1500)
                }
            }
        }
        e.afficher()
        handler.postDelayed(suivi, 1500)
    }

    private fun noterTelechargement(p: Profil, t: Telechargement) {
        val liste = depotDl.liste(p.id)
        liste.add(0, t)
        while (liste.size > Telechargeur.LISTE_MAX) liste.removeAt(liste.size - 1)
        depotDl.sauver(p.id, liste)
    }

    /** Stockage public : demandé seulement sur Android 8 et 9 (depuis Android 10, le dossier Téléchargements est libre d'accès). */
    private fun avecStockage(suite: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 29) { suite(); return }
        demanderAndroid(listOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) suite()
            else Toast.makeText(this, "Autorisez l'accès au stockage pour télécharger (Réglages → Applis → Gestionnaire de Profils)", Toast.LENGTH_LONG).show()
        }
    }

    private fun cookiesDe(p: Profil, url: String): String? = try {
        if (isolationOk) ProfileStore.getInstance().getOrCreateProfile(p.nomInterne).cookieManager.getCookie(url)
        else CookieManager.getInstance().getCookie(url)
    } catch (e: Exception) { null }

    /** Appelé par une page qui propose un fichier à télécharger (lien, bouton « Télécharger », blob, data:). */
    private fun telecharger(p: Profil, wv: WebView, url: String, agent: String?, contentDisposition: String?, mime: String?) {
        when {
            url.startsWith("blob:") -> avecStockage { telechargerBlob(p, wv, url, contentDisposition, mime) }
            url.startsWith("data:") -> avecStockage {
                Thread {
                    try {
                        val (type, octets) = Telechargeur.decoderDataUrl(url) ?: throw IOException("données illisibles")
                        val nom = Telechargeur.nomFichier("telechargement", contentDisposition, type)
                        val t = Telechargeur.enregistrer(this, octets, nom, type)
                        runOnUiThread {
                            noterTelechargement(p, t)
                            Toast.makeText(this, "« ${t.nom} » enregistré dans Téléchargements", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this, "Téléchargement impossible : ${e.message ?: "erreur"}", Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
            url.startsWith("http://") || url.startsWith("https://") -> avecStockage {
                try {
                    val t = Telechargeur.demarrer(this, url, agent, contentDisposition, mime, cookiesDe(p, url), wv.url)
                    noterTelechargement(p, t)
                    Toast.makeText(this, "Téléchargement de « ${t.nom} » lancé (voir ⚙ → Téléchargements)", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Téléchargement impossible : ${e.message ?: "erreur"}", Toast.LENGTH_LONG).show()
                }
            }
            else -> Toast.makeText(this, "Ce type d'adresse ne peut pas être téléchargé", Toast.LENGTH_LONG).show()
        }
    }

    /** Un blob: n'existe que dans la page : on lui demande de nous remettre son contenu (jeton à usage unique). */
    private fun telechargerBlob(p: Profil, wv: WebView, url: String, contentDisposition: String?, mime: String?) {
        val jeton = UUID.randomUUID().toString()
        attentesBlob[jeton] = AttenteBlob(p.id, url, contentDisposition, mime)
        val js = "(function(){var J=" + JSONObject.quote(jeton) + ";" +
            "fetch(" + JSONObject.quote(url) + ").then(function(r){return r.blob();}).then(function(b){" +
            "if(b.size>52428800){AppDl.echec(J,'fichier trop volumineux (50 Mo maximum)');return;}" +
            "var f=new FileReader();" +
            "f.onloadend=function(){AppDl.recevoir(J,String(f.result));};" +
            "f.onerror=function(){AppDl.echec(J,'lecture impossible');};" +
            "f.readAsDataURL(b);" +
            "}).catch(function(e){AppDl.echec(J,String(e));});})();"
        wv.evaluateJavascript(js, null)
    }

    private fun blobRecu(jeton: String, donnees: String) {
        val a = attentesBlob.remove(jeton) ?: return
        try {
            val d = Telechargeur.decoderDataUrl(donnees) ?: throw IOException("données illisibles")
            val type = if (d.first == "application/octet-stream" && !a.mime.isNullOrBlank()) a.mime else d.first
            val nom = Telechargeur.nomFichier(a.url, a.contentDisposition, type)
            val t = Telechargeur.enregistrer(this, d.second, nom, type)
            runOnUiThread {
                profils.firstOrNull { it.id == a.profilId }?.let { noterTelechargement(it, t) }
                Toast.makeText(this, "« ${t.nom} » enregistré dans Téléchargements", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Téléchargement impossible : ${e.message ?: "erreur"}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun blobEchec(jeton: String, raison: String) {
        if (attentesBlob.remove(jeton) == null) return
        runOnUiThread { Toast.makeText(this, "Téléchargement impossible : $raison", Toast.LENGTH_LONG).show() }
    }

    // ----- Envoi de fichiers (champs « parcourir » des pages) et photo de profil -----

    private fun choisirFichiers(rappel: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
        rappelFichiers?.onReceiveValue(null)
        rappelFichiers = rappel
        try {
            startActivityForResult(params.createIntent(), REQ_FICHIERS)
        } catch (e: Exception) {
            rappelFichiers = null
            rappel.onReceiveValue(null)
            Toast.makeText(this, "Aucun sélecteur de fichiers disponible", Toast.LENGTH_LONG).show()
        }
        return true
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(code: Int, resultat: Int, data: Intent?) {
        super.onActivityResult(code, resultat, data)
        if (code == REQ_PHOTO) {
            val suite = rappelPhoto
            rappelPhoto = null
            val u = data?.data
            if (resultat == RESULT_OK && u != null) suite?.invoke(u)
        } else if (code == REQ_FICHIERS) {
            val r = rappelFichiers
            rappelFichiers = null
            r?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultat, data))
        }
    }

    // ───────────────────────── Permissions par profil ─────────────────────────

    /** Autorisation Android correspondant à une ressource WebView (null = aucune requise). */
    private fun permissionAndroid(ressource: String): String? = when (ressource) {
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        else -> null
    }

    /** Strict : seulement ce que les cases du profil autorisent. Libre : tout ce que la page demande. */
    private fun ressourceAutorisee(p: Profil, ressource: String): Boolean = when {
        p.libre -> true
        ressource == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID -> true
        ressource == PermissionRequest.RESOURCE_AUDIO_CAPTURE -> p.micro
        ressource == PermissionRequest.RESOURCE_VIDEO_CAPTURE -> p.camera
        else -> false
    }

    /** Demande au système les autorisations manquantes (plusieurs demandes peuvent se chevaucher), puis exécute la suite. */
    private fun demanderAndroid(perms: List<String>, suite: () -> Unit) {
        val manquantes = perms.distinct().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (manquantes.isEmpty()) { suite(); return }
        val code = ++compteurCodes
        suites[code] = suite
        requestPermissions(manquantes.toTypedArray(), code)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        suites.remove(code)?.invoke()
    }

    private fun traiterDemande(p: Profil, demande: PermissionRequest) {
        val voulues = demande.resources.filter { ressourceAutorisee(p, it) }
        if (voulues.isEmpty()) {
            try { demande.deny() } catch (e: Exception) { }
            Toast.makeText(this, "Accès refusé pour « ${p.nom} » (case micro / caméra décochée, profil en strict)", Toast.LENGTH_LONG).show()
            return
        }
        demanderAndroid(voulues.mapNotNull { permissionAndroid(it) }) {
            val accordees = voulues.filter { r ->
                permissionAndroid(r)?.let { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED } ?: true
            }
            try {
                if (accordees.isEmpty()) {
                    demande.deny()
                    Toast.makeText(this, "Android refuse l'accès : Réglages → Applis → Gestionnaire de Profils → Autorisations", Toast.LENGTH_LONG).show()
                } else {
                    demande.grant(accordees.toTypedArray())
                    if (accordees.size < voulues.size) {
                        Toast.makeText(this, "Une des autorisations (micro ou caméra) manque côté Android", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) { /* demande déjà annulée par la page */ }
        }
    }

    private fun traiterGeoloc(p: Profil, origine: String, rappel: GeolocationPermissions.Callback) {
        if (!p.libre) { rappel.invoke(origine, false, false); return }
        demanderAndroid(listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) {
            val ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            rappel.invoke(origine, ok, false)
        }
    }

    // ───────────────────────── Cycle de vie ─────────────────────────

    /**
     * Écrit les cookies (connexions) sur le disque. Sans cela, Android les garde en mémoire et peut les perdre
     * si l'appli est fermée ou tuée : on se retrouve déconnecté à la réouverture.
     */
    private fun sauverCookies() {
        try {
            if (isolationOk) {
                val store = ProfileStore.getInstance()
                profils.forEach { store.getProfile(it.nomInterne)?.cookieManager?.flush() }
            } else {
                CookieManager.getInstance().flush()
            }
        } catch (e: Exception) { /* pas bloquant */ }
    }

    override fun onPause() {
        super.onPause()
        // Les pages d'un profil en mode libre ne sont jamais mises en pause (le son et le micro continuent en arrière-plan)
        onglets.forEach { (id, l) -> if (profils.none { it.id == id && it.libre }) l.forEach { it.wv.onPause() } }
        sauverCookies()
    }
    override fun onStop() {
        sauverCookies()
        // En quittant l'appli, les profils verrouillés se reverrouillent (sauf pendant une demande d'autorisation ou un choix de fichier)
        val vraiDepart = !isChangingConfigurations && suites.isEmpty() && rappelFichiers == null && rappelPhoto == null
        if (vraiDepart) {
            deverrouilles.clear()
            // Économie de batterie : appli quittée = plus rien ne doit tourner (voix, micro, minuteurs JavaScript des pages).
            // Seul un appel en cours (WebRTC) garde les pages actives.
            // Sauf si un profil en mode libre est ouvert : rien n'est alors coupé.
            if (!libreActif()) {
                ponts.arreterEnArrierePlan()
                if (!appelEnCours()) pagesEnPause(true)
            }
        }
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        pagesEnPause(false)
    }

    /** Un profil en mode libre est-il ouvert (ses pages sont chargées) ? */
    private fun libreActif(): Boolean = profils.any { it.libre && onglets.containsKey(it.id) }

    /** Service de garde (notification permanente) : lancé seulement tant qu'un profil libre est ouvert, pour qu'Android ne gèle pas l'appli. */
    private fun majGardeActive() {
        try {
            val i = android.content.Intent(this, GardeActive::class.java)
            if (libreActif()) startForegroundService(i) else stopService(i)
        } catch (e: Exception) { /* pas bloquant */ }
    }

    /** Un appel (voix sur IP) est-il en cours ? Le mode audio quitte alors « normal ». */
    private fun appelEnCours(): Boolean =
        (getSystemService(AUDIO_SERVICE) as android.media.AudioManager).mode != android.media.AudioManager.MODE_NORMAL

    /** pauseTimers/resumeTimers agissent sur TOUTES les WebView de l'appli : il suffit d'en appeler une. */
    private fun pagesEnPause(pause: Boolean) {
        val wv = onglets.values.firstOrNull { it.isNotEmpty() }?.firstOrNull()?.wv ?: return
        try { if (pause) wv.pauseTimers() else wv.resumeTimers() } catch (e: Exception) { }
    }
    override fun onResume() {
        super.onResume()
        onglets.values.forEach { l -> l.forEach { it.wv.onResume() } }
        majGardeActive()
        courant?.let { if (it.verrouille && it.id !in deverrouilles) afficherListe() }
    }

    override fun onDestroy() {
        ponts.liberer()
        if (isFinishing) try { stopService(android.content.Intent(this, GardeActive::class.java)) } catch (e: Exception) { }
        dialogueLien?.dismiss()
        onglets.values.forEach { l -> l.forEach { detruire(it) } }
        onglets.clear()
        if (isFinishing) { // fermeture définitive (pas un simple changement de thème)
            rendeursPdf.values.forEach { try { it.close() } catch (e: Exception) { } }
            rendeursPdf.clear()
            fichiersOuverts.clear()
            File(cacheDir, "ouverts").deleteRecursively()
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (vuePleinEcran != null) { quitterPleinEcran(); return }
        val p = courant
        if (p == null) { super.onBackPressed(); return }
        popupOuverte()?.let { fermerPopup(it); return }
        val wv = wvActif()
        if (wv != null && wv.canGoBack()) wv.goBack() else afficherListe()
    }
}
