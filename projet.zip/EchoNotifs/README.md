# Écho Notifs (v0.2.2)

Appli Android qui lit tes notifications dans l'oreille.

- Interrupteur général en haut de l'écran ; liste de tes applis à cocher.
- Annonce courte avec l'expéditeur : « Message WhatsApp envoyé par X », « Message vocal WhatsApp envoyé par X »,
  « Mail Gmail envoyé par X ».
- Les appels (entrants, en cours, manqués) ne déclenchent aucune annonce : la notif de l'appel suffit.
- Réponses : double clic sur l'écouteur, boutons Lire / Ne pas lire à l'écran, ou voix.
- Texte : lu à voix haute. Vocal WhatsApp : le fichier du vocal reçu est joué directement par l'appli
  (écran verrouillé OK, toujours le bon message). Autres applis : ouverture de la conversation.
- Mode « toujours actif » ou « seulement avec un périphérique audio » (filaire ou Bluetooth).
- Choix de la voix, vitesse, hauteur. Thème clair/sombre du système.

## Autorisations (carte « Autorisations » dans l'appli)
Notifications, affichage par-dessus, micro, **accès à tous les fichiers** (nécessaire pour les vocaux écran verrouillé),
accessibilité (secours), batterie sans limite.

## Compiler
Projet Gradle standard (AGP 8.5.2, Kotlin 2.0.20, Compose, minSdk 26, targetSdk 34, JDK 17, Gradle 8.7+).

## Anti-spam (v0.2.2)
- Un message n'est annoncé qu'une fois, même si WhatsApp republie la notif (vidéo, miniature…).
- Une seule annonce en attente par conversation, file limitée à 5.
- Si tu lis la conversation toi-même, l'annonce en attente est annulée.
- Les notifs techniques de WhatsApp (sauvegarde, vérification, WhatsApp Web, téléchargements) et les barres de progression sont ignorées.
