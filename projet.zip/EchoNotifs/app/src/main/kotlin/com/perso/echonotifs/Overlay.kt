package com.perso.echonotifs

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Petite fenêtre par-dessus la page en cours : « Lire » / « Ne pas lire ». */
class Overlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null

    fun canDraw() = Settings.canDrawOverlays(ctx)

    fun show(title: String, subtitle: String, onRead: () -> Unit, onSkip: () -> Unit) {
        if (!canDraw()) return
        hide()
        val d = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(18), px(20), px(16))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0B2A3A.toInt(), 0xFF0E5F6B.toInt())
            ).apply { cornerRadius = px(26).toFloat() }
            elevation = px(12).toFloat()
        }
        val t = TextView(ctx).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        }
        val s = TextView(ctx).apply {
            text = subtitle
            setTextColor(0xFFB8D4DC.toInt())
            textSize = 14f
            setPadding(0, px(2), 0, px(14))
        }
        fun btn(label: String, bg: Int, fg: Int, click: () -> Unit) = Button(ctx).apply {
            text = label
            isAllCaps = false
            setTextColor(fg)
            background = GradientDrawable().apply {
                setColor(bg)
                cornerRadius = px(16).toFloat()
            }
            setOnClickListener { click() }
        }

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            btn("Lire", 0xFF5CE1C8.toInt(), 0xFF00382E.toInt()) { onRead() },
            LinearLayout.LayoutParams(0, px(48), 1f).apply { rightMargin = px(8) }
        )
        row.addView(
            btn("Ne pas lire", 0x33FFFFFF, Color.WHITE) { onSkip() },
            LinearLayout.LayoutParams(0, px(48), 1f).apply { leftMargin = px(8) }
        )
        root.addView(t)
        root.addView(s)
        root.addView(row)

        val lp = WindowManager.LayoutParams(
            (ctx.resources.displayMetrics.widthPixels * 0.92f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = px(48)
        }
        try {
            wm.addView(root, lp)
            view = root
        } catch (_: Exception) {
        }
    }

    fun hide() {
        view?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
    }
}
