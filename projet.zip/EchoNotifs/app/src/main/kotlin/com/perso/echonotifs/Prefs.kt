package com.perso.echonotifs

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("echo", Context.MODE_PRIVATE)

    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var masterOn: Boolean
        get() = bool("master", true)
        set(v) = putBool("master", v)

    /** true = seulement quand un périphérique audio est connecté ; false = toujours */
    var headsetOnly: Boolean
        get() = bool("headsetOnly", true)
        set(v) = putBool("headsetOnly", v)

    var useHeadsetButton: Boolean
        get() = bool("useHeadsetButton", true)
        set(v) = putBool("useHeadsetButton", v)

    var useOverlay: Boolean
        get() = bool("useOverlay", true)
        set(v) = putBool("useOverlay", v)

    var useVoice: Boolean
        get() = bool("useVoice", true)
        set(v) = putBool("useVoice", v)

    var apps: Set<String>
        get() = sp.getStringSet("apps", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("apps", HashSet(v)).apply() }

    var voiceName: String?
        get() = sp.getString("voiceName", null)
        set(v) { sp.edit().putString("voiceName", v).apply() }

    var rate: Float
        get() = sp.getFloat("rate", 1.0f)
        set(v) { sp.edit().putFloat("rate", v).apply() }

    var pitch: Float
        get() = sp.getFloat("pitch", 1.0f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }

    var timeoutSec: Int
        get() = sp.getInt("timeoutSec", 12)
        set(v) { sp.edit().putInt("timeoutSec", v).apply() }

    var yesWords: String
        get() = sp.getString("yesWords", "lis,lire,vas-y,vas y,oui,ok,d'accord,go") ?: ""
        set(v) { sp.edit().putString("yesWords", v).apply() }

    var noWords: String
        get() = sp.getString("noWords", "non,pas,ignore,annule,laisse,stop") ?: ""
        set(v) { sp.edit().putString("noWords", v).apply() }
}
