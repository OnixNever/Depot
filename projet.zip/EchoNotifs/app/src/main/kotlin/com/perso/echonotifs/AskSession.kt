package com.perso.echonotifs

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.KeyEvent

/**
 * Une question « Tu veux que je le lise ? » avec trois façons de répondre :
 * double clic sur l'écouteur, boutons à l'écran, ou voix.
 */
class AskSession(
    private val ctx: Context,
    private val prefs: Prefs,
    private val overlay: Overlay,
    private val onAnswer: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var done = false
    private var ms: MediaSession? = null
    private var rec: SpeechRecognizer? = null
    private var lastClick = 0L
    private var attempts = 0
    private val timeout = Runnable { finish(false) }

    fun begin(title: String, subtitle: String) {
        if (prefs.useHeadsetButton) startMedia()
        if (prefs.useOverlay) overlay.show(title, subtitle, { finish(true) }, { finish(false) })
    }

    /** À appeler quand l'annonce vocale est terminée. */
    fun listen() {
        if (done) return
        main.postDelayed(timeout, prefs.timeoutSec * 1000L)
        if (prefs.useVoice) startRecognizer()
    }

    fun cancel() {
        if (done) return
        done = true
        cleanup()
    }

    private fun finish(read: Boolean) {
        if (done) return
        done = true
        cleanup()
        onAnswer(read)
    }

    private fun cleanup() {
        main.removeCallbacksAndMessages(null)
        overlay.hide()
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
        try { ms?.isActive = false; ms?.release() } catch (_: Exception) {}
        ms = null
    }

    // ---- Bouton de l'écouteur ----
    private fun startMedia() {
        val s = MediaSession(ctx, "EchoNotifs")
        s.setCallback(object : MediaSession.Callback() {
            @Suppress("DEPRECATION")
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                val ev = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                    ?: return false
                if (ev.action != KeyEvent.ACTION_DOWN) return true
                when (ev.keyCode) {
                    // Beaucoup d'écouteurs envoient « suivant » pour un double clic
                    KeyEvent.KEYCODE_MEDIA_NEXT -> main.post { finish(true) }
                    // … et « précédent » pour un triple clic : on le prend comme « ne pas lire »
                    KeyEvent.KEYCODE_MEDIA_PREVIOUS -> main.post { finish(false) }
                    KeyEvent.KEYCODE_HEADSETHOOK,
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                    KeyEvent.KEYCODE_MEDIA_PLAY,
                    KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        val now = System.currentTimeMillis()
                        if (now - lastClick < 450) main.post { finish(true) }
                        lastClick = now
                    }
                }
                return true
            }
        })
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                        PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or
                        PlaybackState.ACTION_SKIP_TO_PREVIOUS
                )
                .setState(PlaybackState.STATE_PLAYING, 0, 1f)
                .build()
        )
        s.isActive = true
        ms = s
    }

    // ---- Voix ----
    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onError(error: Int) = retry()
        override fun onResults(results: Bundle?) {
            val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()
            val d = decide(heard)
            if (d != null) finish(d) else retry()
        }
    }

    private fun startRecognizer() {
        if (done) return
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return
        val r = rec ?: SpeechRecognizer.createSpeechRecognizer(ctx).also {
            it.setRecognitionListener(listener)
            rec = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        try { r.startListening(i) } catch (_: Exception) {}
    }

    private fun retry() {
        if (done) return
        if (++attempts < 3) main.postDelayed({ startRecognizer() }, 400)
    }

    private fun words(s: String) = s.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    /** true = lire, false = ne pas lire, null = rien compris. Les mots « non » passent en premier. */
    private fun decide(heard: List<String>): Boolean? {
        val no = words(prefs.noWords)
        val yes = words(prefs.yesWords)
        for (h in heard.map { it.lowercase() }) {
            if (no.any { h.contains(it) }) return false
            if (yes.any { h.contains(it) }) return true
        }
        return null
    }
}
