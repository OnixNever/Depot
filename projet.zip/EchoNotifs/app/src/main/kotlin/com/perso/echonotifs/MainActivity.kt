package com.perso.echonotifs

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = Prefs(this)
        setContent { EchoTheme { Home(prefs, tick.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }
}

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap?)

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            AppItem(
                ri.loadLabel(pm).toString(),
                ri.activityInfo.packageName,
                runCatching { ri.loadIcon(pm).toBitmap(88, 88).asImageBitmap() }.getOrNull()
            )
        }
        .sortedBy { it.label.lowercase() }
}

private fun a11yOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return false
    return s.split(':').any { it.contains(ctx.packageName, true) && it.contains("PlayVocalService") }
}

@Composable
fun Home(prefs: Prefs, tick: Int) {
    val ctx = LocalContext.current
    var local by remember { mutableIntStateOf(0) }

    var master by remember { mutableStateOf(prefs.masterOn) }
    var headsetOnly by remember { mutableStateOf(prefs.headsetOnly) }
    var useButton by remember { mutableStateOf(prefs.useHeadsetButton) }
    var useOverlay by remember { mutableStateOf(prefs.useOverlay) }
    var useVoice by remember { mutableStateOf(prefs.useVoice) }
    var yes by remember { mutableStateOf(prefs.yesWords) }
    var no by remember { mutableStateOf(prefs.noWords) }
    var timeout by remember { mutableFloatStateOf(prefs.timeoutSec.toFloat()) }
    var rate by remember { mutableFloatStateOf(prefs.rate) }
    var pitch by remember { mutableFloatStateOf(prefs.pitch) }
    var voiceName by remember { mutableStateOf(prefs.voiceName) }
    var selected by remember { mutableStateOf(prefs.apps) }
    var query by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var voices by remember { mutableStateOf(emptyList<Voice>()) }

    val speaker = remember { Speaker(ctx.applicationContext) }
    DisposableEffect(Unit) {
        speaker.onReady = { voices = speaker.frenchVoices() }
        onDispose { speaker.shutdown() }
    }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { local++ }

    val listenerOk = remember(tick, local) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val overlayOk = remember(tick, local) { Settings.canDrawOverlays(ctx) }
    val micOk = remember(tick, local) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }
    val a11yOk = remember(tick, local) { a11yOn(ctx) }
    val filesOk = remember(tick, local) { WaVoice.hasAccess() }
    val battOk = remember(tick, local) {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val pkgUri = Uri.parse("package:${ctx.packageName}")

    val filtered = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Header() }

            item {
                MasterCard(master) {
                    master = it
                    prefs.masterOn = it
                }
            }

            item {
                SectionCard("Autorisations") {
                    PermRow("Accès aux notifications", "Pour voir arriver tes notifs", listenerOk) {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }
                    PermRow("Affichage par-dessus", "La fenêtre Lire / Ne pas lire", overlayOk) {
                        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri))
                    }
                    PermRow("Micro", "Pour répondre à la voix", micOk) {
                        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                        permLauncher.launch(p.toTypedArray())
                    }
                    PermRow("Accès à tous les fichiers", "Pour lire les vocaux WhatsApp, même écran verrouillé", filesOk) {
                        if (Build.VERSION.SDK_INT >= 30) {
                            ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkgUri))
                        }
                    }
                    PermRow("Service d'accessibilité", "Secours : appuie sur Lire dans WhatsApp si le fichier est introuvable", a11yOk) {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    PermRow("Batterie sans limite", "Pour que le service reste actif écran éteint", battOk) {
                        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri))
                    }
                    Text(
                        "Si Android grise une option : Infos de l'appli ▸ ⋮ ▸ Autoriser les paramètres restreints.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                SectionCard("Quand lire ?") {
                    ChoiceRow("Toujours actif", "Même sans casque", !headsetOnly) {
                        headsetOnly = false; prefs.headsetOnly = false
                    }
                    ChoiceRow(
                        "Seulement avec un périphérique audio",
                        "Casque, écouteurs ou enceinte, filaire ou Bluetooth",
                        headsetOnly
                    ) { headsetOnly = true; prefs.headsetOnly = true }
                }
            }

            item {
                SectionCard("Comment répondre") {
                    SwitchRow("Double clic sur l'écouteur", "Pour dire « lis-le »", useButton) {
                        useButton = it; prefs.useHeadsetButton = it
                    }
                    SwitchRow("Fenêtre à l'écran", "Deux boutons : Lire / Ne pas lire", useOverlay) {
                        useOverlay = it; prefs.useOverlay = it
                    }
                    SwitchRow("Commande vocale", "Dis « vas-y » ou « lis-le »", useVoice) {
                        useVoice = it; prefs.useVoice = it
                    }
                    OutlinedTextField(
                        value = yes, onValueChange = { yes = it; prefs.yesWords = it },
                        label = { Text("Mots pour lire (séparés par des virgules)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = no, onValueChange = { no = it; prefs.noWords = it },
                        label = { Text("Mots pour ne pas lire") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Attente de ta réponse : ${timeout.toInt()} s", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = timeout, onValueChange = { timeout = it },
                        valueRange = 5f..30f,
                        onValueChangeFinished = { prefs.timeoutSec = timeout.toInt() }
                    )
                }
            }

            item {
                SectionCard("Voix de lecture") {
                    var open by remember { mutableStateOf(false) }
                    val idx = voices.indexOfFirst { it.name == voiceName }
                    val label = if (idx >= 0) "Voix ${idx + 1} · ${voices[idx].locale.toLanguageTag()}"
                    else "Voix par défaut du téléphone"
                    Box {
                        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                            DropdownMenuItem(
                                text = { Text("Voix par défaut du téléphone") },
                                onClick = { voiceName = null; prefs.voiceName = null; open = false }
                            )
                            voices.forEachIndexed { i, v ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            "Voix ${i + 1} · ${v.locale.toLanguageTag()}" +
                                                if (v.isNetworkConnectionRequired) " · en ligne" else ""
                                        )
                                    },
                                    onClick = { voiceName = v.name; prefs.voiceName = v.name; open = false }
                                )
                            }
                        }
                    }
                    Text("Vitesse", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = rate, onValueChange = { rate = it },
                        valueRange = 0.6f..1.6f,
                        onValueChangeFinished = { prefs.rate = rate }
                    )
                    Text("Hauteur (plus bas = plus doux)", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = pitch, onValueChange = { pitch = it },
                        valueRange = 0.7f..1.3f,
                        onValueChangeFinished = { prefs.pitch = pitch }
                    )
                    Button(
                        onClick = { speaker.speak("Bonjour, voici un exemple de lecture.") { } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Écouter un exemple") }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    Text(
                        "Applications lues (${selected.size} cochée${if (selected.size > 1) "s" else ""})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        label = { Text("Rechercher une application") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            items(filtered, key = { it.pkg }) { app ->
                val on = app.pkg in selected
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().clickable {
                        selected = if (on) selected - app.pkg else selected + app.pkg
                        prefs.apps = selected
                    }
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        app.icon?.let {
                            Image(bitmap = it, contentDescription = null, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.width(14.dp))
                        }
                        Text(app.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        Checkbox(checked = on, onCheckedChange = null)
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0B2A3A), Color(0xFF0E7C86)))),
            contentAlignment = Alignment.Center
        ) { Text("💬", fontSize = 24.sp) }
        Spacer(Modifier.width(14.dp))
        Column {
            Text("Écho Notifs", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "Tes notifications, lues dans l'oreille",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MasterCard(on: Boolean, onChange: (Boolean) -> Unit) {
    val bg = if (on) Modifier.background(Brush.linearGradient(listOf(Color(0xFF0B2A3A), Color(0xFF0E7C86))))
    else Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
    val fg = if (on) Color.White else MaterialTheme.colorScheme.onSurface
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).then(bg).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Lecture des notifications", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = fg)
                Text(
                    if (on) "Active : je t'annonce tes notifs" else "En pause : tout est coupé",
                    style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.8f)
                )
            }
            Switch(checked = on, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceRow(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PermRow(title: String, why: String, ok: Boolean, action: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(if (ok) Color(0xFF3DDC97) else Color(0xFFFFB020)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(why, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!ok) FilledTonalButton(onClick = action) { Text("Autoriser") }
        else Text("OK", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
    }
}
