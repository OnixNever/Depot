package com.perso.echonotifs

import android.app.ActivityOptions
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.io.File

class NotifListener : NotificationListenerService() {

    private data class Item(
        val pkg: String,
        val sender: String,
        val text: String,
        val kind: Kind,
        val appLabel: String,
        val category: String?,
        val pi: PendingIntent?,
        val durMs: Long?,
        val postTime: Long,
        val count: Int = 1
    )

    /** Un message d'une conversation (une notif en contient souvent plusieurs). */
    private data class Msg(val sender: String, val text: String, val ts: Long)

    private companion object {
        const val CALL_NONE = 0
        const val CALL_MISSED = 1
        const val CALL_LIVE = 2
        const val BURST_DELAY_MS = 1200L
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs
    private lateinit var speaker: Speaker
    private lateinit var overlay: Overlay
    private lateinit var focus: FocusHolder
    private val queue = ArrayDeque<Item>()
    private val seen = LinkedHashMap<String, Long>()
    private var busy = false
    private var current: Item? = null
    private var session: AskSession? = null
    private var player: MediaPlayer? = null
    private val finishTask = Runnable { finishItem() }
    // Petit délai avant d'annoncer : laisse une rafale de messages arriver pour les regrouper
    private val startTask = Runnable { next() }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        speaker = Speaker(this)
        overlay = Overlay(this)
        focus = FocusHolder(this)
    }

    override fun onListenerConnected() {
        startKeepAlive()
        // Les messages déjà présents dans les notifs ne sont pas des nouveautés : on ne les relit pas
        try {
            activeNotifications?.forEach { sbn ->
                if (sbn.packageName == packageName) return@forEach
                extract(sbn).forEach { m -> seen[sig(sbn, m)] = 0L }
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        session?.cancel()
        stopPlayer()
        overlay.hide()
        focus.release()
        speaker.shutdown()
        super.onDestroy()
    }

    // ---------- Réception ----------
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!prefs.masterOn) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification

        // Appel : on ne dit rien, et on coupe toute question en cours pour que tu puisses décrocher
        val call = callState(sbn)
        if (call != CALL_NONE) {
            if (call == CALL_LIVE) main.post { abortForCall() }
            return
        }

        if (sbn.packageName !in prefs.apps) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return

        val msgs = extract(sbn)
        if (msgs.isEmpty()) return

        // Chaque message n'est annoncé qu'une seule fois, même si la notif est mise à jour
        // 15 fois (la mémoire n'expire pas : plus de ré-annonce tardive).
        val fresh = msgs.filter { m ->
            val k = sig(sbn, m)
            if (seen.containsKey(k)) false else { seen[k] = SystemClock.elapsedRealtime(); true }
        }
        while (seen.size > 500) seen.remove(seen.keys.first())
        if (fresh.isEmpty()) return

        if (prefs.headsetOnly && !AudioUtil.deviceConnected(this)) return

        val items = fresh.map { m ->
            val kind = Classifier.kind(m.text)
            Item(
                pkg = sbn.packageName,
                sender = m.sender,
                text = m.text,
                kind = kind,
                appLabel = appLabel(sbn.packageName),
                category = n.category,
                pi = n.contentIntent,
                durMs = if (kind == Kind.VOICE) Classifier.durationMs(m.text) else null,
                postTime = sbn.postTime
            )
        }
        main.post {
            items.forEach { queue.addLast(it) }
            if (!busy) {
                main.removeCallbacks(startTask)
                main.postDelayed(startTask, BURST_DELAY_MS)
            }
        }
    }

    private fun sig(sbn: StatusBarNotification, m: Msg) = sbn.key + "|" + m.ts + "|" + m.sender + "|" + m.text

    /** Tous les messages de la notif (pas seulement le dernier), du plus ancien au plus récent. */
    private fun extract(sbn: StatusBarNotification): List<Msg> {
        val n = sbn.notification
        val ex = n.extras
        var sender = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
        if (sender.isBlank()) sender = "quelqu'un"
        val out = ArrayList<Msg>()
        try {
            @Suppress("DEPRECATION")
            val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            if (arr != null && arr.isNotEmpty()) {
                for (m in Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr)) {
                    val t = m.text?.toString().orEmpty()
                    if (t.isBlank()) continue
                    val who = if (Build.VERSION.SDK_INT >= 28) m.senderPerson?.name?.toString() else null
                    out.add(Msg(if (who.isNullOrBlank()) sender else who, t, m.timestamp))
                }
            }
        } catch (_: Exception) {
        }
        if (out.isEmpty()) {
            val t = text
            if (t.isBlank() && ex.getCharSequence(Notification.EXTRA_TITLE).isNullOrBlank()) return emptyList()
            out.add(Msg(sender, t, n.`when`))
        }
        return out
    }

    private val dialerPkgs = setOf(
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
        "com.samsung.android.incallui", "com.android.server.telecom", "com.android.incallui",
        "com.android.phone", "com.android.contacts"
    )
    private val callText = Regex(
        "appels? (vocal |vidéo |video |whatsapp )*(manqué|manqués|entrant|en cours)|" +
            "(missed|incoming|ongoing) (voice |video |whatsapp )*call|appel en cours",
        RegexOption.IGNORE_CASE
    )
    private val missedText = Regex("manqué|missed", RegexOption.IGNORE_CASE)
    private val answerAct = Regex("répondre|answer|décrocher", RegexOption.IGNORE_CASE)
    private val rejectAct = Regex("refuser|rejeter|decline|reject", RegexOption.IGNORE_CASE)
    private val hangAct = Regex("décrocher|raccrocher|hang ?up", RegexOption.IGNORE_CASE)

    /** CALL_NONE = pas un appel ; CALL_MISSED = appel manqué ; CALL_LIVE = sonnerie ou appel en cours. */
    private fun callState(sbn: StatusBarNotification): Int {
        val n = sbn.notification
        val ex = n.extras
        val cat = n.category
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val blob = "$title $text $sub"
        val missed = cat == "missed_call" || (blob.length <= 120 && missedText.containsMatchIn(blob))

        var call = false
        if (cat == Notification.CATEGORY_CALL || cat == "missed_call") call = true
        else if (sbn.packageName in dialerPkgs) call = true
        else if (Build.VERSION.SDK_INT >= 31 && (ex.containsKey(Notification.EXTRA_CALL_TYPE) ||
                ex.getString(Notification.EXTRA_TEMPLATE)?.endsWith("CallStyle") == true)) call = true
        else {
            // Canal de notif d'appel (WhatsApp, Signal, Telegram… : « voip », « call »…)
            val ch = n.channelId.orEmpty().lowercase()
            if (ch.contains("voip") || ch.contains("call")) call = true
        }
        if (!call) {
            // Boutons typiques d'une sonnerie : Répondre + Refuser, Raccrocher…
            val acts = n.actions?.mapNotNull { it.title?.toString() }.orEmpty()
            val hasMessages = ex.containsKey(Notification.EXTRA_MESSAGES)
            if (!hasMessages && acts.isNotEmpty() &&
                (acts.any { hangAct.containsMatchIn(it) } ||
                    (acts.any { answerAct.containsMatchIn(it) } && acts.any { rejectAct.containsMatchIn(it) }))
            ) call = true
        }
        if (!call) {
            // Certaines applis (WhatsApp…) classent l'appel comme un simple message
            val short = (title.length <= 60 && callText.containsMatchIn(title)) ||
                (text.length <= 60 && callText.containsMatchIn(text))
            if (short) call = true
        }
        if (!call) return CALL_NONE
        return if (missed) CALL_MISSED else CALL_LIVE
    }

    /** Un appel arrive : on arrête de parler, de demander, et on vide la file. */
    private fun abortForCall() {
        main.removeCallbacks(startTask)
        queue.clear()
        if (!busy) return
        session?.cancel()
        session = null
        speaker.stop()
        finishItem()
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) {
        pkg
    }

    // ---------- Annonce courte ----------
    private fun announce(i: Item): String {
        val l = i.appLabel.lowercase()
        val app = if (l.contains("message") || l.contains("sms")) "" else i.appLabel
        val msgLike = i.category == Notification.CATEGORY_MESSAGE ||
            i.category == Notification.CATEGORY_EMAIL || i.kind != Kind.TEXT
        val mail = i.category == Notification.CATEGORY_EMAIL
        val s = when {
            !msgLike -> "Notification ${i.appLabel} : ${i.sender}"
            i.kind == Kind.TEXT && i.count > 1 ->
                "${i.count} ${if (mail) "mails" else "messages"} $app envoyés par ${i.sender}"
            i.kind == Kind.VOICE -> "Message vocal $app envoyé par ${i.sender}"
            i.kind == Kind.IMAGE -> "Image $app envoyée par ${i.sender}"
            i.kind == Kind.VIDEO -> "Vidéo $app envoyée par ${i.sender}"
            i.kind == Kind.FILE -> "Fichier $app envoyé par ${i.sender}"
            i.category == Notification.CATEGORY_EMAIL -> "Mail $app envoyé par ${i.sender}"
            else -> "Message $app envoyé par ${i.sender}"
        }
        return s.replace(Regex("\\s+"), " ").trim()
    }

    // ---------- File d'attente ----------
    private fun next() {
        if (busy) return
        var item = queue.removeFirstOrNull() ?: return
        // Plusieurs textes du même expéditeur en attente : une seule annonce, tout est lu d'un coup
        if (item.kind == Kind.TEXT) {
            val first = item
            val same = queue.filter { it.kind == Kind.TEXT && it.pkg == first.pkg && it.sender == first.sender }
            if (same.isNotEmpty()) {
                queue.removeAll { q -> same.any { it === q } }
                val all = listOf(first) + same
                item = first.copy(text = all.joinToString(". ") { it.text }, count = all.size)
            }
        }
        if (!prefs.masterOn || (prefs.headsetOnly && !AudioUtil.deviceConnected(this))) {
            queue.clear()
            return
        }
        busy = true
        current = item
        focus.take(false)
        val line = announce(item)

        val s = AskSession(this, prefs, overlay) { read -> onAnswer(item, read) }
        session = s
        s.begin(line, "Lire ce message ?")
        speaker.speak(line) { s.listen() }
    }

    private fun onAnswer(item: Item, read: Boolean) {
        speaker.stop()
        session = null
        if (!read) {
            finishItem()
            return
        }
        when (item.kind) {
            Kind.TEXT -> speaker.speak(item.text.ifBlank { item.sender }.take(if (item.count > 1) 2000 else 700)) { finishItem() }
            Kind.VOICE -> playVoice(item)
            else -> {
                speaker.speak("Je l'ouvre.") { }
                open(item)
                scheduleFinish(2500)
            }
        }
    }

    private fun scheduleFinish(ms: Long) {
        main.removeCallbacks(finishTask)
        main.postDelayed(finishTask, ms)
    }

    private fun finishItem() {
        main.removeCallbacks(finishTask)
        stopPlayer()
        focus.release()
        current = null
        busy = false
        next()
    }

    // ---------- Vocaux ----------
    private fun playVoice(item: Item) {
        focus.take(true) // les autres sons se coupent le temps du vocal
        if (item.pkg.startsWith("com.whatsapp") && WaVoice.hasAccess()) {
            // On joue nous-mêmes le fichier du vocal reçu : marche écran verrouillé
            // et lit exactement le bon message.
            Thread {
                var f: File? = null
                for (t in 0 until 16) {
                    f = WaVoice.find(item.pkg, item.postTime)
                    if (f != null) break
                    Thread.sleep(500)
                }
                val found = f
                main.post {
                    if (current !== item) return@post
                    if (found != null) playFile(found, item) else openFallback(item)
                }
            }.start()
            return
        }
        openFallback(item)
    }

    private fun playFile(f: File, item: Item) {
        WaVoice.markPlayed(f)
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { finishItem() }
            mp.setOnErrorListener { _, _, _ ->
                stopPlayer()
                openFallback(item)
                true
            }
            mp.prepare()
            mp.start()
            scheduleFinish(mp.duration + 8_000L) // filet de sécurité
        } catch (_: Exception) {
            stopPlayer()
            openFallback(item)
        }
    }

    /** Dernier recours : ouvrir WhatsApp et appuyer sur Lire (impossible si le téléphone est verrouillé). */
    private fun openFallback(item: Item) {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) {
            speaker.speak("Déverrouille ton téléphone pour écouter ce vocal.") { finishItem() }
            return
        }
        PlayVocalService.arm()
        wake()
        open(item)
        scheduleFinish((item.durMs ?: 40_000L) + 6_000L)
    }

    private fun stopPlayer() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun open(item: Item) {
        val pi = item.pi ?: return
        try {
            val opts = if (Build.VERSION.SDK_INT >= 34) {
                ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    ).toBundle()
            } else null
            pi.send(this, 0, null, null, null, null, opts)
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun wake() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "echo:wake"
            ).acquire(8000)
        } catch (_: Exception) {
        }
    }

    // ---------- Service au premier plan ----------
    private fun startKeepAlive() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("keep", "Service actif", NotificationManager.IMPORTANCE_MIN)
            )
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notif = Notification.Builder(this, "keep")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Écho Notifs est actif")
                .setContentText("Prêt à lire tes notifications")
                .setOngoing(true)
                .setContentIntent(open)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, notif)
            }
        } catch (_: Exception) {
        }
    }
}
