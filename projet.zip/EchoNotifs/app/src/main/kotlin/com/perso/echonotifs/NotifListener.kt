package com.perso.echonotifs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.io.File

class NotifListener : NotificationListenerService() {

    private data class Item(
        val key: String,
        val pkg: String,
        val sender: String,
        val text: String,
        val kind: Kind,
        val appLabel: String,
        val category: String?,
        val pi: PendingIntent?,
        val durMs: Long?,
        val postTime: Long
    )

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs
    private lateinit var speaker: Speaker
    private lateinit var overlay: Overlay
    private lateinit var focus: FocusHolder
    private val queue = ArrayDeque<Item>()
    private val seen = LinkedHashMap<String, Long>()
    private val lastStamp = HashMap<String, Long>()
    private var asking = false
    private var busy = false
    private var current: Item? = null
    private var session: AskSession? = null
    private var player: MediaPlayer? = null
    private val finishTask = Runnable { finishItem() }

    // Notif « lecture en cours » : balayer vers la gauche (ou bouton Arrêter) coupe tout
    private val stopAction = "com.perso.echonotifs.STOP_READING"
    private val playingId = 2
    private var playingShown = false
    private var openedByUs = false
    private var stopReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        speaker = Speaker(this)
        overlay = Overlay(this)
        focus = FocusHolder(this)
        val rcv = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                main.post { stopEverything() }
            }
        }
        stopReceiver = rcv
        val f = IntentFilter(stopAction)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(rcv, f)
    }

    override fun onListenerConnected() {
        startKeepAlive()
    }

    override fun onDestroy() {
        try { stopReceiver?.let { unregisterReceiver(it) } } catch (_: Exception) {}
        hidePlayingNotif()
        main.removeCallbacksAndMessages(null)
        session?.cancel()
        stopPlayer()
        overlay.hide()
        focus.release()
        speaker.shutdown()
        super.onDestroy()
    }

    // ---------- Réception ----------
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!prefs.masterOn) return
        if (sbn.packageName == packageName) return
        if (sbn.packageName !in prefs.apps) return
        val n = sbn.notification
        val cat = n.category
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        // Les appels créent déjà leur propre notif : on ne dit rien
        if (isCall(sbn)) return

        val ex = n.extras
        // Barres de progression (envoi, téléchargement, sauvegarde…) : jamais des messages
        if (ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0 ||
            ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) return
        val hasMessages = try {
            @Suppress("DEPRECATION")
            (ex.getParcelableArray(Notification.EXTRA_MESSAGES)?.isNotEmpty() == true)
        } catch (_: Exception) { false }
        // Notifs techniques de WhatsApp (sauvegarde, vérification, WhatsApp Web…) : on ne dit rien
        if (isWhatsAppSystem(sbn, hasMessages)) return
        var sender = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        var text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()

        var stamp = 0L

        // Dernier message de la conversation : vrai expéditeur (même dans un groupe) et vrai texte
        try {
            @Suppress("DEPRECATION")
            val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            if (arr != null && arr.isNotEmpty()) {
                val last = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr).lastOrNull()
                if (last != null) {
                    stamp = last.timestamp
                    last.text?.toString()?.takeIf { it.isNotBlank() }?.let { text = it }
                    val who = if (Build.VERSION.SDK_INT >= 28) last.senderPerson?.name?.toString() else null
                    if (!who.isNullOrBlank()) sender = who
                }
            }
        } catch (_: Exception) {
        }
        if (sender.isBlank() && text.isBlank()) return
        if (sender.isBlank()) sender = "quelqu'un"

        // Anti-spam : WhatsApp republie la même notif plusieurs fois (vidéo qui se télécharge,
        // miniature, lecture…). Un message n'est annoncé qu'une seule fois.
        val now = SystemClock.elapsedRealtime()
        if (stamp != 0L) {
            // Vrai horodatage du message : on n'annonce que ce qui est plus récent que le dernier annoncé
            val last = lastStamp[sbn.key]
            if (last != null && stamp <= last) return
            lastStamp[sbn.key] = stamp
            while (lastStamp.size > 200) lastStamp.remove(lastStamp.keys.first())
        } else {
            // Pas d'horodatage fiable : l'heure de la notif change à chaque mise à jour, on l'ignore
            val sig = sbn.key + "|" + text
            if (seen[sig]?.let { now - it < 120_000 } == true) return
            seen[sig] = now
            while (seen.size > 200) seen.remove(seen.keys.first())
        }

        if (prefs.headsetOnly && !AudioUtil.deviceConnected(this)) return

        val kind = Classifier.kind(text)
        val item = Item(
            key = sbn.key,
            pkg = sbn.packageName,
            sender = sender,
            text = text,
            kind = kind,
            appLabel = appLabel(sbn.packageName),
            category = cat,
            pi = n.contentIntent,
            durMs = if (kind == Kind.VOICE) Classifier.durationMs(text) else null,
            postTime = sbn.postTime
        )
        main.post {
            // Une seule annonce en attente par conversation : la plus récente remplace l'ancienne
            // (sauf une réaction, qui ne doit pas écraser un vrai message encore en attente)
            if (item.kind != Kind.REACTION) queue.removeAll { it.key == item.key }
            if (current?.key == item.key && current?.kind == item.kind && item.kind != Kind.TEXT) return@post
            queue.addLast(item)
            while (queue.size > 5) queue.removeFirst()
            next()
        }
    }

    // Notif retirée (tu as lu la conversation toi-même) : on n'annonce plus rien pour elle
    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val key = sbn.key
        main.post {
            queue.removeAll { it.key == key }
            val c = current
            // Si on attend encore ta réponse, on abandonne. Si c'est nous qui avons ouvert la conversation, on continue.
            if (asking && c != null && c.key == key) {
                session?.cancel()
                session = null
                speaker.stop()
                finishItem()
            } else if (!asking && busy && c != null && c.key == key && !openedByUs) {
                // Tu as ouvert la conversation toi-même pendant la lecture : on coupe
                stopEverything()
            }
        }
    }

    private val waSystemChannel = Regex(
        "backup|restore|download|upload|sync|web|connected|check|progress|silent|critical",
        RegexOption.IGNORE_CASE
    )
    private val waSystemText = Regex(
        "sauvegarde|backup|restaur|restor|vérification des nouveaux|checking for new|whatsapp web|" +
            "connecté|connected|télécharg|download|synchronis|en cours d'envoi|sending|mise à jour|updating",
        RegexOption.IGNORE_CASE
    )
    private val waSystemCats = setOf(
        Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE, Notification.CATEGORY_STATUS,
        Notification.CATEGORY_SYSTEM, Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_ERROR,
        Notification.CATEGORY_RECOMMENDATION, Notification.CATEGORY_EVENT
    )

    /** Notifs techniques de WhatsApp (pas un message) : sauvegarde, vérification, WhatsApp Web… */
    private fun isWhatsAppSystem(sbn: StatusBarNotification, hasMessages: Boolean): Boolean {
        if (!sbn.packageName.startsWith("com.whatsapp")) return false
        if (hasMessages) return false // un vrai message a toujours son contenu de conversation
        val n = sbn.notification
        val cat = n.category
        if (cat != null && cat in waSystemCats) return true
        if (cat == Notification.CATEGORY_MESSAGE) return false
        val ch = n.channelId.orEmpty()
        if (waSystemChannel.containsMatchIn(ch)) return true
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (waSystemText.containsMatchIn("$title $text")) return true
        return title.isBlank() || title.equals(appLabel(sbn.packageName), ignoreCase = true)
    }

    private val dialerPkgs = setOf(
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
        "com.samsung.android.incallui", "com.android.server.telecom", "com.android.incallui",
        "com.android.phone", "com.android.contacts"
    )
    private val callText = Regex(
        "appel (vocal |vidéo |video )?(manqué|entrant)|(missed|incoming) (voice |video )?call|appel en cours",
        RegexOption.IGNORE_CASE
    )

    /** Appel entrant, en cours ou manqué : la notif système suffit. */
    private fun isCall(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification
        val cat = n.category
        if (cat == Notification.CATEGORY_CALL || cat == "missed_call") return true
        if (sbn.packageName in dialerPkgs) return true
        val ex = n.extras
        if (Build.VERSION.SDK_INT >= 31 && ex.containsKey(Notification.EXTRA_CALL_TYPE)) return true
        // Certaines applis (WhatsApp…) classent l'appel manqué comme un simple message
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        return text.length <= 40 && callText.containsMatchIn(text)
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) {
        pkg
    }

    // ---------- Annonce courte ----------
    private fun announce(i: Item): String {
        val l = i.appLabel.lowercase()
        val app = if (l.contains("message") || l.contains("sms")) "" else i.appLabel
        val msgLike = i.category == Notification.CATEGORY_MESSAGE ||
            i.category == Notification.CATEGORY_EMAIL || i.kind != Kind.TEXT
        val s = when {
            i.kind == Kind.REACTION -> reactionLine(i)
            !msgLike -> "Notification ${i.appLabel} : ${i.sender}"
            i.kind == Kind.VOICE -> "Message vocal $app envoyé par ${i.sender}"
            i.kind == Kind.IMAGE -> "Image $app envoyée par ${i.sender}"
            i.kind == Kind.VIDEO -> "Vidéo $app envoyée par ${i.sender}"
            i.kind == Kind.FILE -> "${i.sender} t'a envoyé ${Classifier.fileTypeLabel(i.text) ?: "un fichier"}"
            i.category == Notification.CATEGORY_EMAIL -> "Mail $app envoyé par ${i.sender}"
            else -> "Message $app envoyé par ${i.sender}"
        }
        return s.replace(Regex("\\s+"), " ").trim()
    }

    /** « X a réagi à ton vocal / message / image », sans lire le contenu. */
    private fun reactionLine(i: Item): String {
        val what = when (Classifier.reactedKind(i.text)) {
            Kind.VOICE -> "ton vocal"
            Kind.IMAGE -> "ton image"
            Kind.VIDEO -> "ta vidéo"
            Kind.FILE -> "ton fichier"
            else -> "ton message"
        }
        return "${i.sender} a réagi à $what"
    }

    // ---------- File d'attente ----------
    private fun next() {
        if (busy) return
        val item = queue.removeFirstOrNull() ?: return
        if (!prefs.masterOn || (prefs.headsetOnly && !AudioUtil.deviceConnected(this))) {
            queue.clear()
            return
        }
        busy = true
        current = item
        focus.take(false)
        val line = announce(item)

        // Réaction ou fichier : on l'annonce, point. Pas de question, pas de lecture, WhatsApp n'est jamais ouvert.
        if (item.kind == Kind.REACTION || item.kind == Kind.FILE) {
            asking = false
            speaker.speak(line) { finishItem() }
            return
        }
        asking = true

        val s = AskSession(this, prefs, overlay) { read -> onAnswer(item, read) }
        session = s
        s.begin(line, "Lire ce message ?")
        speaker.speak(line) { s.listen() }
    }

    private fun onAnswer(item: Item, read: Boolean) {
        speaker.stop()
        session = null
        asking = false
        if (!read) {
            finishItem()
            return
        }
        showPlayingNotif(item)
        when (item.kind) {
            Kind.TEXT -> speaker.speak(item.text.ifBlank { item.sender }.take(700)) { finishItem() }
            Kind.VOICE -> playVoice(item)
            else -> {
                // Jamais d'ouverture de WhatsApp (ça mettrait le vu) : on dit juste ce que c'est
                val what = when (item.kind) {
                    Kind.IMAGE -> "C'est une image"
                    Kind.VIDEO -> "C'est une vidéo"
                    Kind.FILE -> "C'est un fichier"
                    else -> "Je ne peux pas le lire"
                }
                speaker.speak("$what, ouvre-la toi-même pour la voir.") { finishItem() }
            }
        }
    }

    private fun scheduleFinish(ms: Long) {
        main.removeCallbacks(finishTask)
        main.postDelayed(finishTask, ms)
    }

    private fun finishItem() {
        main.removeCallbacks(finishTask)
        stopPlayer()
        speaker.stop()
        hidePlayingNotif()
        openedByUs = false
        focus.release()
        current = null
        busy = false
        asking = false
        next()
    }

    // ---------- Arrêt manuel + notif « lecture en cours » ----------
    private fun stopEverything() {
        queue.clear()
        session?.cancel()
        session = null
        speaker.stop()
        main.removeCallbacks(finishTask)
        finishItem()
    }

    private fun showPlayingNotif(item: Item) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("playing", "Lecture en cours", NotificationManager.IMPORTANCE_LOW)
            )
            val stop = PendingIntent.getBroadcast(
                this, 1, Intent(stopAction).setPackage(packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, "playing")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Lecture en cours")
                .setContentText(item.sender)
                .setOngoing(false)
                .setOnlyAlertOnce(true)
                .setDeleteIntent(stop) // balayage vers la gauche = couper
                .addAction(Notification.Action.Builder(null, "Arrêter", stop).build())
                .build()
            nm.notify(playingId, n)
            playingShown = true
        } catch (_: Exception) {
        }
    }

    private fun hidePlayingNotif() {
        if (!playingShown) return
        try { getSystemService(NotificationManager::class.java).cancel(playingId) } catch (_: Exception) {}
        playingShown = false
    }

    // ---------- Vocaux ----------
    private fun playVoice(item: Item) {
        focus.take(true) // les autres sons se coupent le temps du vocal
        if (item.pkg.startsWith("com.whatsapp") && WaVoice.hasAccess()) {
            // On joue nous-mêmes le fichier du vocal reçu : marche écran verrouillé
            // et lit exactement le bon message.
            Thread {
                var f: File? = null
                for (t in 0 until 16) {
                    f = WaVoice.find(item.pkg, item.postTime)
                    if (f != null) break
                    Thread.sleep(500)
                }
                val found = f
                main.post {
                    if (current !== item) return@post
                    if (found != null) playFile(found, item) else openFallback(item)
                }
            }.start()
            return
        }
        openFallback(item)
    }

    private fun playFile(f: File, item: Item) {
        WaVoice.markPlayed(f)
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { finishItem() }
            mp.setOnErrorListener { _, _, _ ->
                stopPlayer()
                openFallback(item)
                true
            }
            mp.prepare()
            mp.start()
            scheduleFinish(mp.duration + 8_000L) // filet de sécurité
        } catch (_: Exception) {
            stopPlayer()
            openFallback(item)
        }
    }

    /**
     * Vocal impossible à jouer directement (fichier introuvable, accès aux fichiers refusé, autre appli) :
     * on n'ouvre JAMAIS la conversation, parce que ça mettrait le « vu ». On le dit, c'est tout.
     */
    private fun openFallback(item: Item) {
        val raison = if (item.pkg.startsWith("com.whatsapp") && !WaVoice.hasAccess())
            "Je n'ai pas l'accès aux fichiers pour lire ce vocal."
        else
            "Je n'ai pas retrouvé ce vocal."
        speaker.speak("$raison Ouvre-le toi-même.") { finishItem() }
    }

    private fun stopPlayer() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    // ---------- Service au premier plan ----------
    private fun startKeepAlive() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("keep", "Service actif", NotificationManager.IMPORTANCE_MIN)
            )
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notif = Notification.Builder(this, "keep")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Écho Notifs est actif")
                .setContentText("Prêt à lire tes notifications")
                .setOngoing(true)
                .setContentIntent(open)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, notif)
            }
        } catch (_: Exception) {
        }
    }
}
