package com.perso.echonotifs

enum class Kind(val label: String) {
    TEXT("un message texte"),
    VOICE("un vocal"),
    IMAGE("une image"),
    VIDEO("une vidéo"),
    FILE("un fichier")
}

object Classifier {
    private val voice = Regex("vocal|voice|audio|🎤|🎙|🎧", RegexOption.IGNORE_CASE)
    private val video = Regex("vidéo|video|🎥|📹|gif", RegexOption.IGNORE_CASE)
    private val image = Regex("photo|image|📷|📸|sticker|autocollant", RegexOption.IGNORE_CASE)
    private val file = Regex("document|fichier|file|pdf|📄|📎", RegexOption.IGNORE_CASE)
    private val dur = Regex("(\\d{1,2}):(\\d{2})")

    /** WhatsApp met juste « 🎤 0:12 », « Photo », « Document »… : on ne classe que les textes courts. */
    fun kind(text: String): Kind {
        val t = text.trim()
        if (t.length > 45) return Kind.TEXT
        return when {
            voice.containsMatchIn(t) -> Kind.VOICE
            video.containsMatchIn(t) -> Kind.VIDEO
            image.containsMatchIn(t) -> Kind.IMAGE
            file.containsMatchIn(t) -> Kind.FILE
            else -> Kind.TEXT
        }
    }

    fun durationMs(text: String): Long? {
        val m = dur.find(text) ?: return null
        val (min, sec) = m.destructured
        return (min.toLong() * 60 + sec.toLong()) * 1000
    }
}
