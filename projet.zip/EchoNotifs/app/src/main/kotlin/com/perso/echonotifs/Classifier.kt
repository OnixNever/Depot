package com.perso.echonotifs

enum class Kind(val label: String) {
    TEXT("un message texte"),
    VOICE("un vocal"),
    IMAGE("une image"),
    VIDEO("une vidéo"),
    FILE("un fichier"),
    REACTION("une réaction")
}

object Classifier {
    private val voice = Regex("vocal|voice|audio|🎤|🎙|🎧", RegexOption.IGNORE_CASE)
    private val video = Regex("vidéo|video|🎥|📹|gif", RegexOption.IGNORE_CASE)
    private val image = Regex("photo|image|📷|📸|sticker|autocollant", RegexOption.IGNORE_CASE)
    private val file = Regex("document|fichier|file|pdf|📄|📎", RegexOption.IGNORE_CASE)
    // Nom de fichier WhatsApp : « 📄 Facture_mars.pdf », « rapport.docx · 2 pages · 1,2 Mo »…
    private val fileName = Regex(
        "[^\\s/\\\\]+\\.(pdf|docx?|xlsx?|pptx?|odt|ods|odp|txt|rtf|csv|zip|rar|7z|apk|epub|json|xml|html?)\\b",
        RegexOption.IGNORE_CASE
    )
    private val exts = "pdf|docx?|xlsx?|pptx?|odt|ods|odp|txt|rtf|csv|zip|rar|7z|apk|epub|json|xml|html?"
    private val fileOnly = Regex(
        "^[^\\p{L}\\p{N}]*.{1,100}?\\.($exts)\\b.{0,30}$",
        RegexOption.IGNORE_CASE
    )
    private val dur = Regex("(\\d{1,2}):(\\d{2})")

    // Réaction WhatsApp à un message : « A réagi 👍 à : 🎤 0:12 », « Reacted 😂 to "…" », « a réagi avec ❤️ à… »
    private val reaction = Regex(
        "a réagi|ont réagi|réagi (avec|par|à)|reacted|reaction|réaction",
        RegexOption.IGNORE_CASE
    )

    /** Texte d'une réaction (même long, car il cite le message d'origine). */
    fun isReaction(text: String): Boolean = reaction.containsMatchIn(text.trim().take(80))

    /** Le message d'origine auquel la personne a réagi, pour savoir si c'était un vocal, une image… */
    fun reactedKind(text: String): Kind {
        val after = text.substringAfter("à :", text).substringAfter("to:", text)
        return when {
            voice.containsMatchIn(after) -> Kind.VOICE
            video.containsMatchIn(after) -> Kind.VIDEO
            image.containsMatchIn(after) -> Kind.IMAGE
            file.containsMatchIn(after) -> Kind.FILE
            else -> Kind.TEXT
        }
    }

    /** WhatsApp met juste « 🎤 0:12 », « Photo », « Document »… : on ne classe que les textes courts. */
    fun kind(text: String): Kind {
        val t = text.trim()
        if (isReaction(t)) return Kind.REACTION
        // Nom de fichier (« 📄 Facture mars.pdf », « rapport.docx · 2 pages ») : un fichier, même long
        if (fileOnly.containsMatchIn(t)) return Kind.FILE
        if (t.length > 45) return Kind.TEXT
        return when {
            voice.containsMatchIn(t) -> Kind.VOICE
            video.containsMatchIn(t) -> Kind.VIDEO
            image.containsMatchIn(t) -> Kind.IMAGE
            file.containsMatchIn(t) -> Kind.FILE
            else -> Kind.TEXT
        }
    }

    /** Type de fichier lisible (« un PDF », « un document Word »…), ou null si on ne sait pas. */
    fun fileTypeLabel(text: String): String? {
        val ext = (fileOnly.find(text.trim()) ?: fileName.find(text))?.groupValues?.get(1)?.lowercase()
        if (ext != null) return when (ext) {
            "pdf" -> "un PDF"
            "doc", "docx", "odt", "rtf" -> "un document Word"
            "xls", "xlsx", "ods", "csv" -> "un fichier Excel"
            "ppt", "pptx", "odp" -> "une présentation PowerPoint"
            "txt" -> "un fichier texte"
            "zip", "rar", "7z" -> "une archive"
            "apk" -> "une application Android"
            "epub" -> "un livre numérique"
            else -> "un fichier $ext"
        }
        val t = text.lowercase()
        return when {
            "pdf" in t -> "un PDF"
            "word" in t -> "un document Word"
            "excel" in t -> "un fichier Excel"
            "powerpoint" in t -> "une présentation PowerPoint"
            else -> null
        }
    }

    fun durationMs(text: String): Long? {
        val m = dur.find(text) ?: return null
        val (min, sec) = m.destructured
        return (min.toLong() * 60 + sec.toLong()) * 1000
    }
}
