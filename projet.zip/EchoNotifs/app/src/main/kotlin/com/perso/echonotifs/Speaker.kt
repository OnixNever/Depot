package com.perso.echonotifs

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID

class Speaker(ctx: Context) {
    private val app = ctx.applicationContext
    private val prefs = Prefs(app)
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false

    var onReady: (() -> Unit)? = null
        set(v) {
            field = v
            if (ready) v?.invoke()
        }

    init {
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                applyVoice()
                onReady?.invoke()
            }
        }
    }

    fun applyVoice() {
        val t = tts ?: return
        try {
            t.setLanguage(Locale.FRANCE)
            prefs.voiceName?.let { n ->
                t.voices?.firstOrNull { it.name == n }?.let { t.setVoice(it) }
            }
            t.setSpeechRate(prefs.rate)
            t.setPitch(prefs.pitch)
            t.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
        } catch (_: Exception) {
        }
    }

    fun frenchVoices(): List<Voice> =
        try {
            tts?.voices?.filter { it.locale.language == "fr" }?.sortedBy { it.name } ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }

    fun speak(text: String, done: () -> Unit) {
        val t = tts
        if (t == null || !ready) {
            main.post(done)
            return
        }
        applyVoice()
        val id = UUID.randomUUID().toString()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == id) main.post(done)
            }

            @Suppress("OVERRIDE_DEPRECATION")
            override fun onError(utteranceId: String?) {
                if (utteranceId == id) main.post(done)
            }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
