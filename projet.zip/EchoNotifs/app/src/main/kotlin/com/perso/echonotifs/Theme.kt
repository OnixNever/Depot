package com.perso.echonotifs

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF5CE1C8),
    onPrimary = Color(0xFF00382E),
    secondary = Color(0xFF7AA8FF),
    background = Color(0xFF0E1621),
    onBackground = Color(0xFFE6EDF5),
    surface = Color(0xFF16212F),
    onSurface = Color(0xFFE6EDF5),
    surfaceVariant = Color(0xFF1F2D40),
    onSurfaceVariant = Color(0xFF9BB0C6),
    outline = Color(0xFF3A4C63)
)

private val Light = lightColorScheme(
    primary = Color(0xFF00796B),
    onPrimary = Color.White,
    secondary = Color(0xFF2F5FD0),
    background = Color(0xFFF3F7FA),
    onBackground = Color(0xFF0E1621),
    surface = Color.White,
    onSurface = Color(0xFF0E1621),
    surfaceVariant = Color(0xFFE3ECF3),
    onSurfaceVariant = Color(0xFF51647A),
    outline = Color(0xFFB5C4D3)
)

@Composable
fun EchoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = Typography(),
        content = content
    )
}
