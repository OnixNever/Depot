package com.perso.echonotifs

import android.os.Build
import android.os.Environment
import java.io.File
import kotlin.math.abs

/**
 * Retrouve le fichier du vocal WhatsApp qui vient d'arriver, pour le lire directement
 * (écran verrouillé, conversation fermée ou ouverte au mauvais endroit : peu importe).
 * Nécessite « Accès à tous les fichiers » (Android 11+).
 */
object WaVoice {
    private val normal = listOf(
        "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes",
        "WhatsApp/Media/WhatsApp Voice Notes"
    )
    private val business = listOf(
        "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Voice Notes",
        "WhatsApp Business/Media/WhatsApp Business Voice Notes"
    )
    private val played = HashSet<String>()

    fun hasAccess(): Boolean =
        Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    fun markPlayed(f: File) {
        played.add(f.path)
        while (played.size > 100) played.remove(played.first())
    }

    /** Le fichier non encore lu dont l'heure est la plus proche de celle de la notification. */
    fun find(pkg: String, postTime: Long): File? {
        val base = Environment.getExternalStorageDirectory()
        val dirs = if (pkg == "com.whatsapp.w4b") business else normal
        var best: File? = null
        var bestGap = Long.MAX_VALUE
        for (rel in dirs) {
            val dir = File(base, rel)
            if (!dir.isDirectory) continue
            for (f in dir.walkTopDown().maxDepth(2)) {
                if (!f.isFile || f.path in played) continue
                val ext = f.extension.lowercase()
                if (ext != "opus" && ext != "ogg" && ext != "m4a" && ext != "aac") continue
                val d = f.lastModified() - postTime
                if (d < -20_000 || d > 90_000) continue
                if (abs(d) < bestGap) {
                    bestGap = abs(d)
                    best = f
                }
            }
        }
        return best
    }
}
