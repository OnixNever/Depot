package com.perso.echonotifs

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Optionnel : une fois WhatsApp ouvert sur un vocal, appuie sur le bouton « Lire »
 * du message vocal le plus bas à l'écran (le plus récent).
 * N'agit que dans les secondes qui suivent une demande de l'appli.
 */
class PlayVocalService : AccessibilityService() {

    companion object {
        @Volatile
        private var armedUntil = 0L

        fun arm(ms: Long = 25_000L) {
            armedUntil = SystemClock.elapsedRealtime() + ms
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (SystemClock.elapsedRealtime() > armedUntil) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val best = findPlay(root) ?: return
        var target: AccessibilityNodeInfo? = best
        while (target != null && !target.isClickable) target = target.parent
        if (target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) armedUntil = 0L
    }

    override fun onInterrupt() {}

    private fun findPlay(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestTop = Int.MIN_VALUE
        val r = Rect()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val d = n.contentDescription?.toString()?.lowercase().orEmpty()
            if ((d.startsWith("lire") && d.contains("message vocal")) || d.contains("play voice message")) {
                n.getBoundsInScreen(r)
                if (r.top > bestTop) {
                    bestTop = r.top
                    best = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return best
    }
}
