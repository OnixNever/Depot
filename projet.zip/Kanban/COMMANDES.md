# Commandes externes Kanban (v1.7)

Deux façons de piloter l'appli (Tasker, Gemini, adb...) :

1. Intent : action `com.kanban.comptes.CMD`, extras texte :
   a = create | rename | remind | done | cancel | move
   name = nom du projet (recherche souple : accents/majuscules ignorés, nom partiel accepté)
   newName = nouveau nom (rename)
   account = compte (create, move)
   min = minutes, h = heures, at = heure précise HH:MM (remind, create)
   note = note du rappel (facultatif)
   quiet = true pour que l'appli repasse en arrière-plan après la commande

2. Lien : kanban://cmd?a=create&name=Mon%20projet&account=Compte%201&h=5&note=truc

Tests adb :
adb shell am start -a com.kanban.comptes.CMD -n com.kanban.comptes/.MainActivity --es a create --es name "Test" --es h 5
adb shell am start -a com.kanban.comptes.CMD -n com.kanban.comptes/.MainActivity --es a done --es name "Test"
adb shell am start -a android.intent.action.VIEW -d "kanban://cmd?a=remind&name=Test&min=30"
