package com.kanban.comptes

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        i.getStringExtra("id")?.let { Alarms.done(c, it) }
        val project = i.getStringExtra("title") ?: ""
        val account = i.getStringExtra("text") ?: ""
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("rappels", "Rappels", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, "rappels")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Tu peux reprendre : $project")
            .setContentText(if (account.isNotEmpty()) "Avec le compte $account" else "")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), n)
    }
}
