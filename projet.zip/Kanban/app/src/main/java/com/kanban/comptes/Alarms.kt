package com.kanban.comptes

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

/** Programme les rappels et les garde en mémoire pour les remettre après un redémarrage. */
object Alarms {
    private fun prefs(c: Context) = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)

    private fun pi(c: Context, id: String, title: String, text: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra("id", id).putExtra("title", title).putExtra("text", text)
        return PendingIntent.getBroadcast(
            c, id.hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun set(c: Context, id: String, title: String, text: String, at: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = pi(c, id, title, text)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        else
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        prefs(c).edit().putString(id, JSONObject().put("t", title).put("x", text).put("a", at).toString()).apply()
    }

    fun cancel(c: Context, id: String) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, id, "", ""))
        prefs(c).edit().remove(id).apply()
    }

    fun done(c: Context, id: String) {
        prefs(c).edit().remove(id).apply()
    }

    fun restore(c: Context) {
        val now = System.currentTimeMillis()
        for ((id, v) in prefs(c).all.toList()) {
            try {
                val o = JSONObject(v as String)
                val at = o.getLong("a")
                // rappel manqué pendant que le téléphone était éteint : on le déclenche tout de suite
                set(c, id, o.getString("t"), o.getString("x"), if (at > now) at else now + 3000)
            } catch (e: Exception) {
                prefs(c).edit().remove(id).apply()
            }
        }
    }
}
