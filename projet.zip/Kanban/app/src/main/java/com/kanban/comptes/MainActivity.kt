package com.kanban.comptes

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingCmd: String? = null

    /** Transforme un intent (action com.kanban.comptes.CMD ou lien kanban://...) en commande JSON. */
    @Suppress("DEPRECATION")
    private fun cmdFrom(i: Intent?): String? {
        if (i == null) return null
        val o = JSONObject()
        val d = i.data
        if (d != null && d.scheme == "kanban") {
            for (k in d.queryParameterNames) d.getQueryParameter(k)?.let { o.put(k, it) }
            if (!o.has("a") && !d.host.isNullOrEmpty()) o.put("a", d.host)
        } else if (i.action == "com.kanban.comptes.CMD") {
            val ex = i.extras ?: return null
            for (k in ex.keySet()) ex.get(k)?.let { o.put(k, it.toString()) }
        } else return null
        return if (o.has("a")) o.toString() else null
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        val c = cmdFrom(i) ?: return
        setIntent(Intent())
        web.evaluateJavascript("window.kbCmd&&window.kbCmd(JSON.parse(" + JSONObject.quote(c) + "))", null)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(Bridge(), "Android")
        // Nécessaire pour <input type="file"> (import d'images depuis la galerie)
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p.createIntent(), 7); true
                } catch (e: Exception) {
                    fileCb = null; false
                }
            }
        }
        pendingCmd = cmdFrom(intent)
        setIntent(Intent())
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 7) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCb = null
        } else super.onActivityResult(req, res, data)
    }

    @Deprecated("simple et sans dépendance")
    override fun onBackPressed() {
        web.evaluateJavascript("window.goBack&&window.goBack()") { if (it != "true") finish() }
    }

    inner class Bridge {
        // Sauvegarde native : un vrai fichier, écrit de façon synchrone (le localStorage
        // d'un WebView en file:// peut ne pas être relu ou être perdu si l'appli est tuée)
        @JavascriptInterface
        @Synchronized
        fun loadData(): String {
            for (n in arrayOf("kb.json", "kb.bak")) {
                try {
                    val f = File(filesDir, n)
                    if (f.exists()) {
                        val t = f.readText()
                        if (t.startsWith("{")) return t
                    }
                } catch (e: Exception) { }
            }
            return ""
        }

        @JavascriptInterface
        @Synchronized
        fun saveData(json: String): Boolean {
            return try {
                val cur = File(filesDir, "kb.json")
                val tmp = File(filesDir, "kb.tmp")
                tmp.writeText(json)
                if (cur.exists()) cur.copyTo(File(filesDir, "kb.bak"), overwrite = true)
                tmp.renameTo(cur)
            } catch (e: Exception) { false }
        }

        @JavascriptInterface
        fun setReminder(id: String, title: String, text: String, note: String, at: Double) {
            Alarms.set(this@MainActivity, id, title, text, note, at.toLong())
        }

        @JavascriptInterface
        fun cancelReminder(id: String) {
            Alarms.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun takeCmd(): String {
            val c = pendingCmd ?: ""
            pendingCmd = null
            return c
        }

        @JavascriptInterface
        fun toBack() {
            runOnUiThread { moveTaskToBack(true) }
        }

        @JavascriptInterface
        fun vibrate(ms: Int) {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
