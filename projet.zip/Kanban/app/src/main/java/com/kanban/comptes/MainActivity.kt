package com.kanban.comptes

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(Bridge(), "Android")
        // Nécessaire pour <input type="file"> (import d'images depuis la galerie)
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p.createIntent(), 7); true
                } catch (e: Exception) {
                    fileCb = null; false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 7) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCb = null
        } else super.onActivityResult(req, res, data)
    }

    @Deprecated("simple et sans dépendance")
    override fun onBackPressed() {
        web.evaluateJavascript("window.goBack&&window.goBack()") { if (it != "true") finish() }
    }

    inner class Bridge {
        @JavascriptInterface
        fun setReminder(id: String, title: String, text: String, at: Double) {
            Alarms.set(this@MainActivity, id, title, text, at.toLong())
        }

        @JavascriptInterface
        fun cancelReminder(id: String) {
            Alarms.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun vibrate(ms: Int) {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
