package com.routage.audio

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {

    // ───────────── Modèle ─────────────
    private class Dev(val type: Int, val address: String, val name: String)
    private class Entry(val pkg: String, var dev: Dev?)
    private class AppItem(val pkg: String, val label: String, val icon: Drawable)

    private val entries = ArrayList<Entry>()
    private var mic: Dev? = null
    private val prefs by lazy { getSharedPreferences("routes", MODE_PRIVATE) }

    // ───────────── État ─────────────
    private lateinit var statusView: TextView
    private lateinit var body: LinearLayout
    private var svc: IUserService? = null
    private var binding = false
    private val journal = StringBuilder()
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val reapply = Runnable { refresh(); applyAll(); applyMic() }

    // ───────────── Couleurs ─────────────
    private val CARD = Color.parseColor("#171C24")
    private val SHEET = Color.parseColor("#1B212B")
    private val BADGE = Color.parseColor("#26303D")
    private val TEAL = Color.parseColor("#4FD1C5")
    private val ORANGE = Color.parseColor("#F6AD55")
    private val GRAY = Color.parseColor("#8B97A6")

    // ───────────── Shizuku ─────────────
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
    private val binderListener = Shizuku.OnBinderReceivedListener { refresh() }

    private val conn: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = IUserService.Stub.asInterface(b); binding = false
            log("Service Shizuku prêt")
            refresh(); applyAll(); applyMic()
        }
        override fun onServiceDisconnected(n: ComponentName?) { svc = null; binding = false }
    }

    private val devCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = schedule()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = schedule()
    }

    private fun schedule() { handler.removeCallbacks(reapply); handler.postDelayed(reapply, 800) }

    // ───────────── Utilitaires UI ─────────────
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun box(color: Int, radius: Int = 16, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply { cornerRadius = dp(radius).toFloat(); setColor(color); setStroke(dp(2), stroke) }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun badge(emoji: String): TextView = TextView(this).apply {
        text = emoji; textSize = 20f; gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BADGE) }
    }

    private fun lp(w: Int, h: Int, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { bottomMargin = dp(bottom) }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    private fun log(s: String) {
        synchronized(journal) {
            journal.append(s.trimEnd()).append('\n')
            if (journal.length > 8000) journal.delete(0, journal.length - 6000)
        }
    }

    // ───────────── Applis & appareils ─────────────
    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun iconOf(pkg: String): Drawable = try {
        packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) { packageManager.defaultActivityIcon }

    private fun outputs(): List<AudioDeviceInfo> {
        val ok = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLE_SPEAKER,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_ACCESSORY, AudioDeviceInfo.TYPE_HDMI,
            AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL,
            AudioDeviceInfo.TYPE_HEARING_AID
        )
        return (getSystemService(AUDIO_SERVICE) as AudioManager)
            .getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in ok }
    }

    private fun devOf(d: AudioDeviceInfo): Dev {
        val name = if (d.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER || d.type == AudioDeviceInfo.TYPE_BUILTIN_MIC) AudioRouter.typeName(d.type)
        else d.productName?.toString()?.takeIf { it.isNotBlank() } ?: AudioRouter.typeName(d.type)
        return Dev(d.type, d.address ?: "", name)
    }

    private fun inputs(): List<AudioDeviceInfo> {
        val ok = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_MIC, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET
        )
        return (getSystemService(AUDIO_SERVICE) as AudioManager)
            .getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in ok }
    }

    private fun isMicConnected(d: Dev): Boolean = inputs().any { it.type == d.type && (it.address ?: "") == d.address }

    private fun isConnected(d: Dev): Boolean = outputs().any { it.type == d.type && (it.address ?: "") == d.address }

    private fun subOf(d: Dev): String = AudioRouter.typeName(d.type).let { if (it == d.name) "" else it }

    private fun emoji(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "📱"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_HEARING_AID -> "🎧"
        AudioDeviceInfo.TYPE_BLE_SPEAKER -> "🔊"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> "🔌"
        AudioDeviceInfo.TYPE_HDMI -> "📺"
        else -> "🔈"
    }

    // ───────────── Sauvegarde ─────────────
    private fun devJson(d: Dev?): JSONObject =
        JSONObject().put("type", d?.type ?: -1).put("address", d?.address ?: "").put("name", d?.name ?: "")

    private fun devFrom(o: JSONObject): Dev? =
        if (o.optInt("type", -1) >= 0) Dev(o.getInt("type"), o.optString("address"), o.optString("name")) else null

    private fun load() {
        entries.clear()
        try {
            val arr = JSONArray(prefs.getString("apps", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                entries.add(Entry(o.getString("pkg"), devFrom(o)))
            }
            mic = devFrom(JSONObject(prefs.getString("mic", "{}") ?: "{}"))
        } catch (e: Exception) { log("Lecture sauvegarde : $e") }
    }

    private fun save() {
        val arr = JSONArray()
        entries.forEach { e -> arr.put(devJson(e.dev).put("pkg", e.pkg)) }
        prefs.edit().putString("apps", arr.toString()).putString("mic", devJson(mic).toString()).apply()
    }

    // ───────────── Routage ─────────────
    private fun applyAll() {
        val s = svc ?: return
        val out = outputs()
        val sb = StringBuilder()
        entries.forEach { e ->
            val d = e.dev ?: return@forEach
            if (out.none { it.type == d.type && (it.address ?: "") == d.address }) return@forEach
            val uid = try { packageManager.getApplicationInfo(e.pkg, 0).uid } catch (x: Exception) { return@forEach }
            sb.appendLine("${e.pkg}|$uid|${d.type}|${d.address}")
        }
        val spec = sb.toString()
        worker.execute {
            val r = try { if (spec.isBlank()) s.clearApps() else s.routeApps(spec) } catch (t: Throwable) { "ERREUR : $t" }
            log(r)
            if (r.contains("ERREUR") || r.contains("refusée") || r.contains("Aucun mix"))
                toast("Routage impossible — voir « Journal » en bas")
        }
    }

    private fun applyMic() {
        val s = svc ?: return
        val m = mic
        val usable = m != null && isMicConnected(m)
        worker.execute {
            val r = try {
                if (m != null && usable) s.setMic(m.type, m.address) else s.clearMic()
            } catch (t: Throwable) { "ERREUR : $t" }
            log(r)
            if (r.contains("ERREUR") || r.contains("refusé")) toast("Micro refusé — voir « Journal » en bas")
        }
    }

    private fun allAuto() {
        entries.forEach { it.dev = null }
        mic = null
        save(); refresh()
        val s = svc ?: return
        worker.execute {
            try { log(s.clearApps()); log(s.reset()); log(s.clearMic()) } catch (t: Throwable) { log("ERREUR : $t") }
            toast("Tout est en automatique")
        }
    }

    private fun removeEntry(e: Entry) {
        val routed = e.dev != null
        entries.remove(e); save(); refresh()
        if (routed) applyAll()
    }

    // ───────────── Cycle de vie ─────────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(44), dp(20), dp(28))
        }
        root.addView(tv("Routage Audio", 28f, Color.WHITE, true), lp(-1, -2, 14))
        statusView = TextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(statusView, lp(-1, -2, 18))
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(body)
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        (getSystemService(AUDIO_SERVICE) as AudioManager).registerAudioDeviceCallback(devCb, null)
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        handler.removeCallbacks(reapply)
        (getSystemService(AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(devCb)
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        worker.shutdown()
        super.onDestroy()
    }

    // ───────────── Écran principal ─────────────
    private fun setStatus(s: String, color: String, onClick: (() -> Unit)? = null) {
        statusView.text = s
        statusView.background = box(Color.parseColor(color), 16)
        statusView.setOnClickListener(onClick?.let { c -> View.OnClickListener { c() } })
    }

    private fun refresh(): Unit = runOnUiThread {
        body.removeAllViews()
        when {
            !Shizuku.pingBinder() ->
                setStatus("Shizuku n'est pas lancé.\nOuvre Shizuku et démarre-le.", "#4A2A2A")
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                setStatus("Autoriser Routage Audio dans Shizuku  ›", "#4A3B1F") { Shizuku.requestPermission(1) }
            svc == null -> {
                setStatus("Connexion au service Shizuku…", "#4A3B1F")
                if (!binding) {
                    binding = true
                    try {
                        Shizuku.bindUserService(
                            Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
                                .daemon(true).processNameSuffix("audio").debuggable(false).version(2),
                            conn
                        )
                    } catch (t: Throwable) { binding = false; log("bindUserService : $t") }
                }
            }
            else -> {
                setStatus("Shizuku connecté ✓", "#1F3A33")
                buildBody()
            }
        }
    }

    private fun buildBody() {
        body.addView(TextView(this).apply {
            text = "Tout en automatique"; textSize = 15f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            background = box(Color.parseColor("#1F6F5C"), 16)
            setOnClickListener { allAuto() }
        }, lp(-1, dp(52), 22))

        body.addView(tv("Micro", 18f, Color.WHITE, true), lp(-1, -2, 10))
        body.addView(micRow(), lp(-1, -2, 22))

        body.addView(tv("Applications", 18f, Color.WHITE, true), lp(-1, -2, 10))
        if (entries.isEmpty())
            body.addView(tv("Ajoute une application pour choisir sa sortie audio.", 14f, GRAY), lp(-1, -2, 14))
        entries.forEach { body.addView(appRow(it), lp(-1, -2, 10)) }

        body.addView(TextView(this).apply {
            text = "＋  Ajouter une application"; textSize = 15f; setTextColor(TEAL)
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.parseColor("#3A4452"), dp(8).toFloat(), dp(6).toFloat())
            }
            setOnClickListener { pickApp() }
        }, lp(-1, dp(58), 18))

        body.addView(tv("Journal", 12f, GRAY).apply {
            gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener { showJournal() }
        })
    }

    private fun appRow(e: Entry): View {
        val d = e.dev
        val connected = d == null || isConnected(d)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(4), dp(12))
            background = box(CARD, 16, when { d == null -> Color.TRANSPARENT; connected -> TEAL; else -> ORANGE })
            setOnClickListener { chooseDevice(e) }
        }
        row.addView(ImageView(this).apply { setImageDrawable(iconOf(e.pkg)) }, LinearLayout.LayoutParams(dp(46), dp(46)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
        t.addView(tv(appLabel(e.pkg), 17f, Color.WHITE, true))
        val (sub, color) = when {
            d == null -> "Automatique" to GRAY
            !connected -> (d.name + " · non connecté") to ORANGE
            else -> (d.name + subOf(d).let { if (it.isEmpty()) "" else " · $it" }) to TEAL
        }
        t.addView(tv(sub, 13f, color))
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(tv("✕", 16f, GRAY).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { removeEntry(e) }
        })
        return row
    }

    private fun micRow(): View {
        val m = mic
        val connected = m == null || isMicConnected(m)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = box(CARD, 16, when { m == null -> Color.TRANSPARENT; connected -> TEAL; else -> ORANGE })
            setOnClickListener { chooseMic() }
        }
        row.addView(badge("🎙️"), LinearLayout.LayoutParams(dp(46), dp(46)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
        t.addView(tv("Micro (toutes les applis)", 17f, Color.WHITE, true))
        val (sub, color) = when {
            m == null -> "Automatique" to GRAY
            !connected -> (m.name + " · non connecté") to ORANGE
            else -> (m.name + subOf(m).let { if (it.isEmpty()) "" else " · $it" }) to TEAL
        }
        t.addView(tv(sub, 13f, color))
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun showJournal() {
        val text = synchronized(journal) { journal.toString() }.ifBlank { "(vide)" }
        val dlg = AlertDialog.Builder(this).setTitle("Journal").setMessage(text)
            .setPositiveButton("Fermer", null).show()
        dlg.findViewById<TextView>(android.R.id.message)?.apply { setTextIsSelectable(true); textSize = 11f; typeface = Typeface.MONOSPACE }
    }

    // ───────────── Fenêtre : choix du périphérique ─────────────
    private fun optionRow(emoji: String, title: String, sub: String, selected: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(16), dp(12))
            background = box(CARD, 16, if (selected) TEAL else Color.TRANSPARENT)
            setOnClickListener { onClick() }
        }
        row.addView(badge(emoji), LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
        t.addView(tv(title, 16f, Color.WHITE))
        if (sub.isNotEmpty()) t.addView(tv(sub, 12f, GRAY))
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        if (selected) row.addView(tv("✓", 20f, TEAL, true))
        return row
    }

    private fun sheetHead(icon: View, title: String, sub: String): View {
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        ht.addView(tv(title, 18f, Color.WHITE, true))
        ht.addView(tv(sub, 13f, GRAY))
        head.addView(ht)
        return head
    }

    private fun openSheet(head: View, fill: (LinearLayout, () -> Unit) -> Unit) {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val r = dp(24).toFloat()
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(24))
            background = GradientDrawable().apply { setColor(SHEET); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        sheet.addView(View(this).apply { background = box(Color.parseColor("#3A4452"), 2) },
            LinearLayout.LayoutParams(dp(40), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(16) })
        sheet.addView(head, lp(-1, -2, 16))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fill(list) { dlg.dismiss() }
        sheet.addView(ScrollView(this).apply { addView(list) })
        dlg.setContentView(sheet)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setWindowAnimations(android.R.style.Animation_InputMethod)
            setDimAmount(0.6f)
        }
        dlg.show()
    }

    private fun chooseDevice(e: Entry) {
        val icon = ImageView(this).apply { setImageDrawable(iconOf(e.pkg)) }
        openSheet(sheetHead(icon, appLabel(e.pkg), "Sortie audio (média, appels, navigation)")) { list, close ->
            fun pick(d: Dev?) { e.dev = d; save(); close(); refresh(); applyAll() }
            list.addView(optionRow("✨", "Automatique", "Suit le réglage du téléphone", e.dev == null) { pick(null) }, lp(-1, -2, 8))
            outputs().forEach { d ->
                val dev = devOf(d)
                val sel = e.dev?.let { it.type == dev.type && it.address == dev.address } == true
                list.addView(optionRow(emoji(d.type), dev.name, subOf(dev), sel) { pick(dev) }, lp(-1, -2, 8))
            }
        }
    }

    private fun chooseMic() {
        openSheet(sheetHead(badge("🎙️"), "Micro", "Réglage commun à toutes les applis")) { list, close ->
            fun pick(d: Dev?) { mic = d; save(); close(); refresh(); applyMic() }
            list.addView(optionRow("✨", "Automatique", "Suit le réglage du téléphone", mic == null) { pick(null) }, lp(-1, -2, 8))
            inputs().forEach { d ->
                val dev = devOf(d)
                val sel = mic?.let { it.type == dev.type && it.address == dev.address } == true
                list.addView(optionRow("🎙️", dev.name, subOf(dev), sel) { pick(dev) }, lp(-1, -2, 8))
            }
        }
    }

    // ───────────── Page : importer une application ─────────────
    private inner class AppAdapter(val all: List<AppItem>) : BaseAdapter() {
        var shown: List<AppItem> = all
        fun filter(q: String) {
            val s = q.trim().lowercase()
            shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) }
            notifyDataSetChanged()
        }
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val a = shown[position]
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(10), dp(8), dp(10))
            }
            row.addView(ImageView(this@MainActivity).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(44), dp(44)))
            row.addView(tv(a.label, 16f, Color.WHITE).apply { setPadding(dp(16), 0, 0, 0) })
            return row
        }
    }

    private fun pickApp() {
        val dlg = Dialog(this, android.R.style.Theme_Material_NoActionBar)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(36), dp(16), dp(8))
            setBackgroundColor(Color.parseColor("#0E1116"))
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(tv("←", 24f, Color.WHITE).apply {
            setPadding(dp(8), dp(8), dp(20), dp(8)); setOnClickListener { dlg.dismiss() }
        })
        bar.addView(tv("Ajouter une application", 20f, Color.WHITE, true))
        page.addView(bar, lp(-1, -2, 12))

        val search = EditText(this).apply {
            hint = "Rechercher"; setHintTextColor(GRAY); setTextColor(Color.WHITE); textSize = 16f
            setSingleLine(); background = box(CARD, 14); setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        page.addView(search, lp(-1, -2, 8))

        val loading = tv("Chargement…", 14f, GRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(30), 0, 0) }
        page.addView(loading)
        val lv = ListView(this).apply { divider = null; dividerHeight = 0 }
        page.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))

        dlg.setContentView(page)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.parseColor("#0E1116")))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.show()

        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val items = pm.queryIntentActivities(intent, 0)
                .distinctBy { it.activityInfo.packageName }
                .filter { ri -> ri.activityInfo.packageName != packageName && entries.none { e -> e.pkg == ri.activityInfo.packageName } }
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                loading.visibility = View.GONE
                val adapter = AppAdapter(items)
                lv.adapter = adapter
                search.addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { adapter.filter(s?.toString() ?: "") }
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                })
                lv.setOnItemClickListener { _, _, pos, _ ->
                    val item = adapter.shown[pos]
                    val e = Entry(item.pkg, null)
                    entries.add(e); save(); dlg.dismiss(); refresh()
                    chooseDevice(e)
                }
            }
        }.start()
    }
}
