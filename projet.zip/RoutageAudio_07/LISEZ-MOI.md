# Routage Audio v0.5.0

- Sortie par appli : tout le son de l'appli (média, appels, navigation) vise l'appareil choisi ;
  les autres profils du même appareil (ex. « appel » d'écouteurs Bluetooth) sont autorisés aussi.
- Micro : réglage séparé de la sortie. Il est COMMUN à toutes les applis (Android ne sait pas
  choisir un micro par appli de façon fiable). Appliqué aux usages micro, vocal, reconnaissance,
  communication et enregistrement.
- « Tout en automatique » remet sorties, applis et micro en automatique.
- Tout est sauvegardé et ré-appliqué à l'ouverture ; le service Shizuku garde le routage actif
  appli fermée (tant que Shizuku tourne).
- « Journal » (en bas) : détail technique en cas de problème.
