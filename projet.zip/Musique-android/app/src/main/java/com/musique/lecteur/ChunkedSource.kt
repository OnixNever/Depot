package com.musique.lecteur

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InputStream

/**
 * Source de données pour ExoPlayer : lit un flux audio YouTube par tranches de 1 Mo demandées via le
 * paramètre « range » de l'URL — exactement la technique du téléchargement (et de NewPipe).
 * Sans ça, YouTube bride les flux lus d'un seul tenant : le son s'arrête, silence, puis reprend.
 * Chaque tranche est une requête neuve, à pleine vitesse ; ExoPlayer garde ~2 minutes d'avance.
 */
@UnstableApi
class ChunkedSource : BaseDataSource(true) {

    private companion object { const val CHUNK = 1L * 1024 * 1024 }

    private var uri: Uri? = null
    private var base = ""
    private var total = -1L          // taille totale (paramètre clen de l'URL), -1 si inconnue
    private var pos = 0L             // position absolue du prochain octet à lire
    private var limit = -1L          // fin demandée (exclue), -1 = jusqu'au bout
    private var chunkEnd = 0L
    private var lastChunk = false
    private var done = false
    private var opened = false
    private var resp: Response? = null
    private var body: InputStream? = null

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        val s = dataSpec.uri.toString()
        base = s.replace(Regex("([?&])range=[^&]*"), "$1").trimEnd('&', '?')
        total = Regex("[?&]clen=(\\d+)").find(s)?.groupValues?.get(1)?.toLongOrNull() ?: -1L
        pos = dataSpec.position
        limit = when {
            dataSpec.length != C.LENGTH_UNSET.toLong() -> pos + dataSpec.length
            total >= 0 -> total
            else -> -1L
        }
        transferInitializing(dataSpec)
        closeBody()
        chunkEnd = pos
        lastChunk = false
        done = false
        opened = true
        transferStarted(dataSpec)
        return if (limit >= 0) maxOf(0L, limit - pos) else C.LENGTH_UNSET.toLong()
    }

    private fun openChunk(): Boolean {
        closeBody()
        if (limit >= 0 && pos >= limit) return false
        var to = pos + CHUNK - 1
        if (total >= 0) to = minOf(to, total - 1)
        val req = Request.Builder().url("$base&range=$pos-$to").header("User-Agent", Yt.UA).build()
        val r = Yt.client.newCall(req).execute()
        if (r.code == 416) { r.close(); return false }
        if (r.code != 200 && r.code != 206) { val c = r.code; r.close(); throw IOException("HTTP $c") }
        val b = r.body
        if (b == null) { r.close(); throw IOException("Réponse vide") }
        resp = r
        body = b.byteStream()
        chunkEnd = to + 1
        val len = b.contentLength()
        lastChunk = total < 0 && len >= 0 && len < (to - pos + 1)   // taille inconnue : tranche courte = fin
        return true
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        while (true) {
            if (limit >= 0 && pos >= limit) return C.RESULT_END_OF_INPUT
            if (body == null || pos >= chunkEnd) {
                if (done) return C.RESULT_END_OF_INPUT
                if (!openChunk()) return C.RESULT_END_OF_INPUT
            }
            var want = length.toLong()
            if (limit >= 0) want = minOf(want, limit - pos)
            want = minOf(want, chunkEnd - pos)
            val n = body!!.read(buffer, offset, want.toInt())
            if (n < 0) {
                closeBody()
                if (total < 0) return C.RESULT_END_OF_INPUT         // taille inconnue : fin du flux
                if (pos >= chunkEnd) continue                         // tranche finie normalement
                throw IOException("Flux interrompu")                  // coupé en route : ExoPlayer réessaie
            }
            pos += n
            bytesTransferred(n)
            if (lastChunk && pos >= chunkEnd) done = true
            return n
        }
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        closeBody()
        uri = null
        if (opened) { opened = false; transferEnded() }
    }

    private fun closeBody() {
        try { body?.close() } catch (_: Exception) {}
        try { resp?.close() } catch (_: Exception) {}
        body = null; resp = null
    }
}
