package com.musique.lecteur

import android.content.Context
import android.content.Intent
import org.json.JSONObject

/**
 * Lien entre les commandes vocales (Kotlin) et l'interface (la page web).
 *  - la page envoie son contexte (écran affiché, playlist ouverte, playlist d'ajout) via Bridge.vcCtx ;
 *  - les commandes demandent une navigation : exécutée tout de suite si l'écran est là,
 *    sinon gardée en attente et jouée dès que l'appli s'ouvre.
 */
object Ui {
    @Volatile var view = "lib"
    @Volatile var curPl = ""
    @Volatile var target = ""

    /** Renseigné par MainActivity tant que l'écran existe. */
    @Volatile var runJs: ((String) -> Unit)? = null
    @Volatile private var pendingJs: String? = null

    fun alive() = runJs != null

    fun js(code: String) { runJs?.invoke(code) }

    fun libChanged() = js("window.__lib&&window.__lib()")

    private fun navJs(what: String, arg: String) =
        "window.__nav&&window.__nav(" + JSONObject.quote(what) + "," + JSONObject.quote(arg) + ")"

    /** what : lib | pl (arg = id de playlist) | search (arg = recherche) | player | queue | back */
    fun nav(ctx: Context, what: String, arg: String = "") {
        when (what) {
            "lib" -> { view = "lib" }
            "pl" -> { view = "pl"; curPl = arg }
            "search" -> { view = "search" }
        }
        val code = navJs(what, arg)
        if (runJs != null) { js(code); return }
        pendingJs = code
        openApp(ctx)
    }

    fun openApp(ctx: Context) {
        try { ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) {}
    }

    /** Appelé quand la page est chargée : joue la navigation demandée pendant que l'appli était fermée. */
    fun flush() {
        val p = pendingJs ?: return
        pendingJs = null
        js(p)
    }

    fun reset() { view = "lib"; curPl = "" }
}
