package com.musique.lecteur

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Icône « Onyx » (nom modifiable dans l'appli) (et raccourci d'appui long) : ouvre l'appli et lance tout de suite l'écoute. Dis « Ok Google, ouvre Onyx ». */
class VoiceLauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra("voice", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        finish()
    }
}
