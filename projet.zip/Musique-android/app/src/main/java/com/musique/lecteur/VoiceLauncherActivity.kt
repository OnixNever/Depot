package com.musique.lecteur

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Raccourci d'appui long « Commande vocale » : ouvre l'appli et lance tout de suite l'écoute. Par la voix, dis « Ok Google, ouvre Onyx Music » (détecté dans MainActivity). */
class VoiceLauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra("voice", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        finish()
    }
}
