package com.musique.lecteur

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.random.Random

/**
 * Bibliothèque : playlists ordonnées, pistes ordonnées, un seul fichier library.json (écrit via un
 * fichier temporaire puis renommé, jamais à moitié écrit).
 *
 * Piste = { y: id YouTube | u: lien d'un fichier du téléphone, n: titre, a: artiste, d: durée en s }.
 * Une piste YouTube est lue en streaming ; si son fichier existe dans files/dl/, elle est lue hors ligne.
 * Les fichiers téléchargés sont partagés entre playlists (clés = id YouTube).
 */
class Library(ctx: Context) {

    private val file = File(ctx.filesDir, "library.json")
    private val dlDir = File(ctx.filesDir, "dl").apply { mkdirs() }
    private var root: JSONObject = load()

    private fun load(): JSONObject = try {
        if (file.exists()) JSONObject(file.readText()) else JSONObject().put("pl", JSONArray())
    } catch (_: Exception) { JSONObject().put("pl", JSONArray()) }

    private fun save() {
        val tmp = File(file.parentFile, "library.json.tmp")
        tmp.writeText(root.toString())
        if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
    }

    private fun pls(): JSONArray = root.getJSONArray("pl")
    private fun find(id: String): JSONObject? {
        val a = pls()
        for (i in 0 until a.length()) if (a.getJSONObject(i).optString("id") == id) return a.getJSONObject(i)
        return null
    }

    // ---------- fichiers téléchargés ----------
    private fun safe(k: String) = k.replace(Regex("[^A-Za-z0-9_-]"), "_")
    fun dl(y: String) = File(dlDir, safe(y) + ".m4a")
    fun part(y: String) = File(dlDir, safe(y) + ".part")
    fun isOffline(y: String) = y.isNotEmpty() && dl(y).exists()
    fun finishDl(y: String): Boolean {
        val p = part(y); val d = dl(y)
        d.delete()
        return p.exists() && p.renameTo(d)
    }
    fun dlRemove(y: String) { try { dl(y).delete() } catch (_: Exception) {} }
    fun dlBytes(): Long = dlDir.listFiles()?.filter { it.name.endsWith(".m4a") }?.sumOf { it.length() } ?: 0L

    private fun referenced(y: String): Boolean {
        val a = pls()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i).getJSONArray("tracks")
            for (j in 0 until t.length()) if (t.getJSONObject(j).optString("y") == y) return true
        }
        return false
    }
    private fun dropIfOrphan(t: JSONObject) {
        val y = t.optString("y")
        if (y.isNotEmpty() && !referenced(y)) dlRemove(y)
    }

    fun newId(prefix: String) = prefix + System.currentTimeMillis().toString(36) + Random.nextInt(46656).toString(36)

    // ---------- lecture pour l'interface ----------
    @Synchronized
    fun get(): String {
        val out = JSONArray()
        val a = pls()
        for (i in 0 until a.length()) {
            val p = JSONObject(a.getJSONObject(i).toString())
            val t = p.getJSONArray("tracks")
            for (j in 0 until t.length()) {
                val o = t.getJSONObject(j)
                o.put("off", isOffline(o.optString("y")))
            }
            out.put(p)
        }
        return JSONObject().put("pl", out).put("dlBytes", dlBytes()).toString()
    }

    // ---------- playlists ----------
    @Synchronized
    fun plCreate(name: String): String {
        val id = newId("pl")
        pls().put(JSONObject().put("id", id).put("name", name.trim().ifBlank { "Nouvelle playlist" }).put("tracks", JSONArray()))
        save(); return id
    }

    @Synchronized
    fun plRename(id: String, name: String) {
        val p = find(id) ?: return
        val n = name.trim()
        if (n.isNotEmpty()) { p.put("name", n); save() }
    }

    @Synchronized
    fun plMove(from: Int, to: Int) {
        val a = pls()
        if (from !in 0 until a.length() || to !in 0 until a.length()) return
        root.put("pl", moved(a, from, to)); save()
    }

    @Synchronized
    fun plDelete(id: String) {
        val a = pls()
        val keep = JSONArray()
        var gone: JSONObject? = null
        for (i in 0 until a.length()) {
            val p = a.getJSONObject(i)
            if (p.optString("id") == id) gone = p else keep.put(p)
        }
        root.put("pl", keep); save()
        val t = gone?.getJSONArray("tracks") ?: return
        for (j in 0 until t.length()) dropIfOrphan(t.getJSONObject(j))
    }

    // ---------- pistes ----------
    private fun clean(o: JSONObject) = JSONObject().put("n", o.optString("n", "Sans titre")).put("a", o.optString("a"))
        .put("d", o.optLong("d")).apply {
            if (o.optString("y").isNotEmpty()) put("y", o.optString("y"))
            if (o.optString("u").isNotEmpty()) put("u", o.optString("u"))
        }

    @Synchronized
    fun trAdd(plId: String, tracks: JSONArray): Int {
        val t = find(plId)?.getJSONArray("tracks") ?: return 0
        for (i in 0 until tracks.length()) t.put(clean(tracks.getJSONObject(i)))
        save(); return tracks.length()
    }

    @Synchronized
    fun trRemove(plId: String, idx: Int) {
        val p = find(plId) ?: return
        val t = p.getJSONArray("tracks")
        if (idx !in 0 until t.length()) return
        val gone = t.getJSONObject(idx)
        t.remove(idx); save()
        dropIfOrphan(gone)
    }

    @Synchronized
    fun trMove(plId: String, from: Int, to: Int) {
        val p = find(plId) ?: return
        val t = p.getJSONArray("tracks")
        if (from !in 0 until t.length() || to !in 0 until t.length()) return
        p.put("tracks", moved(t, from, to)); save()
    }

    /** Déplace (copy = false) ou copie (copy = true) une piste vers une autre playlist. */
    @Synchronized
    fun trTransfer(src: String, idx: Int, dst: String, copy: Boolean) {
        if (src == dst) return
        val s = find(src)?.getJSONArray("tracks") ?: return
        val d = find(dst)?.getJSONArray("tracks") ?: return
        if (idx !in 0 until s.length()) return
        d.put(JSONObject(s.getJSONObject(idx).toString()).also { it.remove("off") })
        if (!copy) s.remove(idx)
        save()
    }

    private fun moved(a: JSONArray, from: Int, to: Int): JSONArray {
        val l = ArrayList<Any>()
        for (i in 0 until a.length()) l.add(a.get(i))
        val x = l.removeAt(from)
        l.add(to, x)
        return JSONArray(l)
    }

    /** Toutes les pistes YouTube d'une playlist pas encore téléchargées (pour « tout télécharger »). */
    @Synchronized
    fun missing(plId: String): JSONArray {
        val out = JSONArray()
        val t = find(plId)?.getJSONArray("tracks") ?: return out
        for (j in 0 until t.length()) {
            val o = t.getJSONObject(j)
            val y = o.optString("y")
            if (y.isNotEmpty() && !isOffline(y)) out.put(JSONObject().put("y", y).put("n", o.optString("n")))
        }
        return out
    }

    /** Supprime les fichiers hors ligne d'une playlist (les pistes restent, lues en streaming). */
    @Synchronized
    fun dlRemovePlaylist(plId: String) {
        val t = find(plId)?.getJSONArray("tracks") ?: return
        for (j in 0 until t.length()) dlRemove(t.getJSONObject(j).optString("y"))
    }
}
