package com.musique.lecteur

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Pont JavaScript -> Android (exposé dans la page sous le nom « Android »). */
class Bridge(private val activity: MainActivity) {

    private val lib get() = Engine.lib
    private val net = Executors.newCachedThreadPool()
    private val cancels = ConcurrentHashMap<Int, AtomicBoolean>()

    /** Chaque changement du lecteur est poussé tel quel à la page. */
    private val listener: () -> Unit = {
        val wv = activity.web
        val js = "window.__p&&window.__p(" + Engine.stateJson().toString() + ")"
        wv.post { wv.evaluateJavascript(js, null) }
    }

    init { Engine.listeners.add(listener) }

    fun shutdown() {
        Engine.listeners.remove(listener)
        net.shutdown()
    }

    private fun js(code: String) { val wv = activity.web; wv.post { wv.evaluateJavascript(code, null) } }
    fun reply(reqId: Int, ok: Boolean, payload: String) = js("window.__cb&&window.__cb($reqId,$ok,${JSONObject.quote(payload)})")
    private fun libChanged() = js("window.__lib&&window.__lib()")

    // ---------------- bibliothèque ----------------
    @JavascriptInterface fun libGet(): String = lib.get()
    @JavascriptInterface fun plCreate(name: String): String = lib.plCreate(name)
    @JavascriptInterface fun plRename(id: String, name: String) { lib.plRename(id, name) }
    @JavascriptInterface fun plMove(from: Int, to: Int) { lib.plMove(from, to) }
    @JavascriptInterface fun plDelete(id: String) { lib.plDelete(id) }
    @JavascriptInterface fun trAdd(plId: String, tracksJson: String): Int = try { lib.trAdd(plId, JSONArray(tracksJson)) } catch (_: Exception) { 0 }
    @JavascriptInterface fun trRemove(plId: String, idx: Int) { lib.trRemove(plId, idx) }
    @JavascriptInterface fun trMove(plId: String, from: Int, to: Int) { lib.trMove(plId, from, to) }
    @JavascriptInterface fun trTransfer(src: String, idx: Int, dst: String, copy: Boolean) { lib.trTransfer(src, idx, dst, copy) }
    @JavascriptInterface fun dlRemove(y: String) { lib.dlRemove(y) }
    @JavascriptInterface fun dlRemovePlaylist(plId: String) { lib.dlRemovePlaylist(plId) }
    @JavascriptInterface fun dlMissing(plId: String): String = lib.missing(plId).toString()

    /** Choix de musiques du téléphone : pointées (jamais copiées), ajoutées à la playlist plId. */
    @JavascriptInterface fun pickLocal(reqId: Int, plId: String) { activity.runOnUiThread { activity.pickMusic(reqId, plId) } }

    // ---------------- lecteur ----------------
    private fun tracks(json: String): List<Engine.T> {
        val a = JSONArray(json)
        return (0 until a.length()).map { Engine.T.from(a.getJSONObject(it)) }
    }

    @JavascriptInterface fun pPlay(tracksJson: String, start: Int) { try { Engine.playList(tracks(tracksJson), start) } catch (_: Exception) {} }
    @JavascriptInterface fun pEnqueue(trackJson: String, next: Boolean) { try { Engine.enqueue(Engine.T.from(JSONObject(trackJson)), next) } catch (_: Exception) {} }
    @JavascriptInterface fun pToggle() { Engine.toggle() }
    @JavascriptInterface fun pNext() { Engine.next() }
    @JavascriptInterface fun pPrev() { Engine.prev() }
    @JavascriptInterface fun pSeek(ms: Int) { Engine.seek(ms) }
    @JavascriptInterface fun pRepeat(mode: String, count: Int) { Engine.setRepeat(mode, count) }
    @JavascriptInterface fun pShuffle(on: Boolean) { Engine.setShuffle(on) }
    @JavascriptInterface fun pJump(orderPos: Int) { Engine.jumpTo(orderPos) }
    @JavascriptInterface fun pRemove(orderPos: Int) { Engine.removeAt(orderPos) }
    @JavascriptInterface fun pClear() { Engine.clear() }
    @JavascriptInterface fun pState(): String = Engine.stateJson().toString()
    @JavascriptInterface fun pQueue(): String = Engine.queueJson().toString()

    // ---------------- YouTube ----------------
    /** Mots-clés, lien de vidéo ou lien de playlist → { kind, name, items:[{id,title,channel,dur}] } */
    @JavascriptInterface
    fun ytSearch(reqId: Int, query: String) {
        net.execute {
            try { reply(reqId, true, Yt.lookup(query).toString()) }
            catch (e: Throwable) { reply(reqId, false, Yt.explain(e)) }
        }
    }

    @JavascriptInterface fun dlCancel(reqId: Int) { cancels[reqId]?.set(true) }

    /**
     * Télécharge des pistes pour l'écoute hors ligne, une par une. Chaque fichier terminé est gardé tout de suite :
     * si ça s'interrompt, ce qui est déjà là reste. Progression -> window.__dlProg, fin -> window.__cb.
     */
    @JavascriptInterface
    fun dlTracks(reqId: Int, itemsJson: String) {
        val flag = AtomicBoolean(false)
        cancels[reqId] = flag
        activity.runOnUiThread { activity.setKeepScreenOn(true) }
        net.execute {
            var ok = 0; var failed = 0; var lastErr = ""
            try {
                val items = JSONArray(itemsJson)
                val n = items.length()
                for (i in 0 until n) {
                    if (flag.get()) break
                    val o = items.getJSONObject(i)
                    val y = o.getString("y")
                    val title = o.optString("n", "YouTube")
                    if (lib.isOffline(y)) { ok++; continue }
                    prog(reqId, i, n, 0, title)
                    val part = lib.part(y)
                    try {
                        part.delete()
                        var last = -2
                        Yt.download("https://www.youtube.com/watch?v=$y", part, { flag.get() }) { p ->
                            if (p != last) { last = p; prog(reqId, i, n, p, title) }
                        }
                        if (!lib.finishDl(y)) throw IllegalStateException("Impossible d'enregistrer le fichier.")
                        ok++
                        libChanged()
                    } catch (e: Throwable) {
                        try { part.delete() } catch (_: Exception) {}
                        if (flag.get()) break
                        failed++
                        lastErr = Yt.explain(e)
                    }
                }
                reply(reqId, true, JSONObject().put("ok", ok).put("failed", failed).put("total", n)
                    .put("cancelled", flag.get()).put("err", lastErr).toString())
            } catch (e: Throwable) {
                reply(reqId, false, Yt.explain(e))
            } finally {
                cancels.remove(reqId)
                activity.runOnUiThread { activity.setKeepScreenOn(false) }
            }
        }
    }

    private fun prog(reqId: Int, i: Int, n: Int, pct: Int, title: String) =
        js("window.__dlProg&&window.__dlProg($reqId,$i,$n,$pct,${JSONObject.quote(title)})")
}
