package com.musique.lecteur

import android.app.Activity
import android.os.Bundle

/**
 * Reçoit les demandes de l'assistant Google / Gemini quand il sait « parler » à une appli de musique :
 *  - « Joue X sur Musique »     → android.media.action.MEDIA_PLAY_FROM_SEARCH (lecture directe, sans écran)
 *  - « Cherche X sur Musique »  → com.google.android.gms.actions.SEARCH_ACTION (ouvre la recherche de l'appli)
 */
class AssistantActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val i = intent
        val app = applicationContext
        try {
            Engine.init(app)
            val q = i?.getStringExtra("query")
            when (i?.action) {
                "android.media.action.MEDIA_PLAY_FROM_SEARCH" -> Voice.playFromSearch(app, q, i.extras)
                "com.google.android.gms.actions.SEARCH_ACTION" -> Voice.openSearch(app, q.orEmpty())
            }
        } catch (_: Throwable) {}
        finish()
    }
}
