package com.musique.lecteur

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.net.URL

/**
 * Service de premier plan : garde la lecture vivante écran éteint / appli fermée, affiche le lecteur dans la
 * notification (pochette, précédent, pause, suivant, fermer) et expose une MediaSession (écran verrouillé, casque Bluetooth).
 * Le lecteur lui-même est Engine : ici on ne fait que refléter son état.
 */
class PlayService : Service() {

    companion object {
        private const val CHANNEL = "lecture"
        private const val NOTIF_ID = 7
        private const val A_TOGGLE = "com.musique.lecteur.TOGGLE"
        private const val A_NEXT = "com.musique.lecteur.NEXT"
        private const val A_PREV = "com.musique.lecteur.PREV"
        private const val A_CLOSE = "com.musique.lecteur.CLOSE"

        fun ensure(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, PlayService::class.java)) } catch (_: Exception) {}
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var session: MediaSession
    private val listener: () -> Unit = { refresh() }
    private var artFor = ""
    private var art: Bitmap? = null
    private var inForeground = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Engine.init(applicationContext)
        createChannel()
        session = MediaSession(this, "musique").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { Engine.play() }
                override fun onPause() { Engine.pause() }
                override fun onSkipToNext() { Engine.next() }
                override fun onSkipToPrevious() { Engine.prev() }
                override fun onSeekTo(pos: Long) { Engine.seek(pos.toInt()) }
                override fun onStop() { Engine.clear() }
            })
            isActive = true
        }
        Engine.listeners.add(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Android impose d'appeler startForeground tout de suite après startForegroundService
        goForeground(buildNotification())
        when (intent?.action) {
            A_TOGGLE -> Engine.toggle()
            A_NEXT -> Engine.next()
            A_PREV -> Engine.prev()
            A_CLOSE -> Engine.clear()
        }
        main.post { refresh() }
        return START_NOT_STICKY
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTIF_ID, n)
        inForeground = true
    }

    private fun refresh() {
        val t = Engine.cur()
        if (t == null) {
            inForeground = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        loadArt(t)
        val playing = Engine.isPlaying()
        try {
            session.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, t.n)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, t.a)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, t.d * 1000L)
                    .apply { art?.let { putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) } }
                    .build()
            )
            session.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP
                    )
                    .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, Engine.position().toLong(), if (playing) 1f else 0f)
                    .build()
            )
        } catch (_: Exception) {}
        val n = buildNotification()
        if (inForeground) (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, n)
        else goForeground(n)
    }

    /** Pochette de la vidéo, chargée en tâche de fond puis rafraîchie. */
    private fun loadArt(t: Engine.T) {
        if (t.y.isEmpty() || artFor == t.y) return
        artFor = t.y
        art = null
        val y = t.y
        Thread {
            try {
                val bmp = URL("https://i.ytimg.com/vi/$y/mqdefault.jpg").openStream().use { BitmapFactory.decodeStream(it) }
                if (bmp != null) main.post { if (artFor == y) { art = bmp; refresh() } }
            } catch (_: Exception) {}
        }.start()
    }

    private fun pi(code: Int, action: String) = PendingIntent.getService(
        this, code, Intent(this, PlayService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildNotification(): Notification {
        val t = Engine.cur()
        val playing = Engine.isPlaying()
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle(t?.n ?: "Musique")
            .setContentText(t?.a ?: "")
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setLocalOnly(true)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false)
        art?.let { b.setLargeIcon(it) }
        @Suppress("DEPRECATION")
        b.addAction(android.R.drawable.ic_media_previous, "Précédent", pi(1, A_PREV))
        @Suppress("DEPRECATION")
        b.addAction(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, if (playing) "Pause" else "Lecture", pi(2, A_TOGGLE))
        @Suppress("DEPRECATION")
        b.addAction(android.R.drawable.ic_media_next, "Suivant", pi(3, A_NEXT))
        @Suppress("DEPRECATION")
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fermer", pi(4, A_CLOSE))
        b.setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Lecture", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Contrôles de lecture"
            ch.setShowBadge(false)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
    }

    override fun onDestroy() {
        Engine.listeners.remove(listener)
        try { session.isActive = false; session.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
