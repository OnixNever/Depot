package com.musique.lecteur

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Menu de choix de la sortie audio (voiture, casque Bluetooth, haut-parleur…), en feuille qui monte du bas.
 * Ouvert depuis : le bouton « Sortie » de la notification, le bouton des contrôles média (panneau déroulant),
 * et visible aussi sur l'écran verrouillé, sans avoir à taper le schéma / code.
 */
class OutputActivity : Activity() {

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun bg(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun iconOf(kind: String) = when (kind) {
        "auto" -> R.drawable.ic_o_auto
        "phone" -> R.drawable.ic_o_phone
        "bt" -> R.drawable.ic_o_bluetooth
        "wired" -> R.drawable.ic_o_headphones
        else -> R.drawable.ic_o_speaker
    }

    private fun icon(res: Int, color: Int) = ImageView(this).apply { setImageResource(res); setColorFilter(color) }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // affichage par-dessus l'écran verrouillé, sans demander le code
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)

        Engine.init(applicationContext)
        val list = Engine.outputsList()
        val cur = Engine.outKeyNow()

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            setOnClickListener { finish() }
            setOnApplyWindowInsetsListener { v, ins -> v.setPadding(0, 0, 0, ins.systemWindowInsetBottom); ins }
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(Color.parseColor("#141420"), 26)
            setPadding(dp(10), dp(8), dp(10), dp(12))
            isClickable = true   // un tap sur la carte ne ferme pas la fenêtre
            elevation = dp(8).toFloat()
        }

        // petite poignée
        card.addView(View(this).apply { background = bg(Color.parseColor("#3a3a58"), 3) },
            LinearLayout.LayoutParams(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(4); bottomMargin = dp(10) })

        card.addView(TextView(this).apply {
            text = "Sortie audio"
            setTextColor(Color.parseColor("#f5f5fb"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), 0, dp(12), dp(8))
        })

        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (o in list) {
            val sel = o.key == cur
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(14), 0)
                background = bg(if (sel) Color.parseColor("#2a2150") else Color.parseColor("#1c1c2c"), 16)
                isClickable = true
                setOnClickListener {
                    Engine.setOutput(o.key)
                    finish()
                }
            }
            row.addView(icon(iconOf(o.kind), Color.parseColor(if (sel) "#b79cff" else "#c4c4dc")),
                LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(14) })
            row.addView(TextView(this).apply {
                text = o.name
                setTextColor(Color.parseColor("#f5f5fb"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                if (sel) typeface = Typeface.DEFAULT_BOLD
                maxLines = 2
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (sel) row.addView(icon(R.drawable.ic_o_check, Color.parseColor("#b79cff")), LinearLayout.LayoutParams(dp(24), dp(24)))
            rows.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)).apply { bottomMargin = dp(6) })
        }
        card.addView(ScrollView(this).apply { addView(rows); isVerticalScrollBarEnabled = false },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(10), dp(40), dp(10), dp(12))
        })
        setContentView(root)
    }
}
