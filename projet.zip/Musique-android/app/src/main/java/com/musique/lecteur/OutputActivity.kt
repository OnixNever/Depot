package com.musique.lecteur

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle

/**
 * Fenêtre minuscule ouverte par le bouton « Sortie » de la notification :
 * liste les périphériques audio (voiture, casque Bluetooth, haut-parleur…) et applique le choix.
 */
class OutputActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(applicationContext)
        val list = Engine.outputsList()
        val cur = Engine.outKeyNow()
        val checked = list.indexOfFirst { it.key == cur }.coerceAtLeast(0)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Sortie audio")
            .setSingleChoiceItems(list.map { it.name }.toTypedArray(), checked) { d, which ->
                Engine.setOutput(list[which].key)
                d.dismiss()
            }
            .setNegativeButton("Annuler", null)
            .setOnDismissListener { finish() }
            .show()
    }
}
