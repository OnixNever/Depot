package com.musique.lecteur

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import okhttp3.Request as OkRequest

/**
 * Recherche et téléchargement audio YouTube, entièrement sur le téléphone, sans clé d'API ni quota :
 * on utilise NewPipeExtractor (la bibliothèque de l'appli NewPipe). Rien n'est lancé tant que
 * l'utilisateur ne touche pas « Chercher » / « Ajouter ».
 */
object Yt {

    const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
    private const val CHUNK = 2L * 1024 * 1024

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    @Volatile private var ready = false

    @Synchronized
    private fun init() {
        if (ready) return
        NewPipe.init(Dl(client), Localization("fr", "FR"))
        ready = true
    }

    /** Pont entre NewPipeExtractor et OkHttp. */
    private class Dl(private val http: OkHttpClient) : Downloader() {
        override fun execute(request: Request): Response {
            val url = request.url()
            val data = request.dataToSend()
            val body = if (data != null) data.toRequestBody(null) else null
            val b = OkRequest.Builder().method(request.httpMethod(), body).url(url).header("User-Agent", UA)
            for ((name, values) in request.headers()) {
                b.removeHeader(name)
                for (v in values) b.addHeader(name, v)
            }
            http.newCall(b.build()).execute().use { r ->
                if (r.code == 429) throw ReCaptchaException("YouTube demande une vérification (trop de requêtes)", url)
                val text = r.body?.string() ?: ""
                return Response(r.code, r.message, r.headers.toMultimap(), text, r.request.url.toString())
            }
        }
    }

    fun looksLikeUrl(s: String): Boolean =
        Regex("^(https?://)?([a-z0-9-]+\\.)?(youtube\\.com|youtu\\.be)/", RegexOption.IGNORE_CASE).containsMatchIn(s.trim())

    private fun videoId(url: String): String? =
        Regex("(?:v=|youtu\\.be/|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})").find(url)?.groupValues?.get(1)

    private fun itemJson(id: String, title: String, channel: String, dur: Long) =
        JSONObject().put("id", id).put("title", title).put("channel", channel).put("dur", dur)

    /** Recherche de vidéos par mots-clés → [{id,title,channel,dur}] */
    fun search(query: String): JSONArray {
        init()
        val svc = ServiceList.YouTube
        val handler = svc.searchQHFactory.fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        val info = SearchInfo.getInfo(svc, handler)
        val out = JSONArray()
        for (it in info.relatedItems) {
            if (it !is StreamInfoItem) continue
            val id = videoId(it.url) ?: continue
            out.put(itemJson(id, it.name ?: "", it.uploaderName ?: "", it.duration))
            if (out.length() >= 15) break
        }
        return out
    }

    private const val MAX_PLAYLIST = 300

    /** Lien de playlist (hors « mix » automatiques RD…, infinis) ? */
    fun isPlaylistUrl(s: String): Boolean {
        val id = Regex("[?&]list=([A-Za-z0-9_-]+)").find(s)?.groupValues?.get(1) ?: return false
        return !id.startsWith("RD")
    }

    /** Playlist YouTube → {kind:"playlist", name, items:[{id,title,channel,dur}]} (jusqu'à 300 pistes). */
    fun playlist(link: String): JSONObject {
        init()
        val id = Regex("[?&]list=([A-Za-z0-9_-]+)").find(link)?.groupValues?.get(1)
            ?: throw IllegalStateException("Lien de playlist non reconnu.")
        val url = "https://www.youtube.com/playlist?list=$id"
        val svc = ServiceList.YouTube
        val info = PlaylistInfo.getInfo(svc, url)
        val out = JSONArray()
        fun addAll(list: List<StreamInfoItem>) {
            for (x in list) {
                val vid = videoId(x.url) ?: continue
                out.put(itemJson(vid, x.name ?: "", x.uploaderName ?: "", x.duration))
            }
        }
        addAll(info.relatedItems)
        var page = info.nextPage
        while (page != null && out.length() < MAX_PLAYLIST) {
            val more = PlaylistInfo.getMoreItems(svc, url, page)
            if (more.items.isEmpty()) break
            addAll(more.items)
            page = more.nextPage
        }
        if (out.length() == 0) throw IllegalStateException("Playlist vide ou privée.")
        return JSONObject().put("kind", "playlist").put("name", info.name ?: "Playlist").put("items", out)
    }

    /** Point d'entrée unique de la barre : mots-clés, lien de vidéo ou lien de playlist. */
    fun lookup(query: String): JSONObject {
        val q = query.trim()
        if (looksLikeUrl(q)) {
            if (isPlaylistUrl(q)) return playlist(q)
            return JSONObject().put("kind", "video").put("name", "").put("items", JSONArray().put(resolve(q)))
        }
        return JSONObject().put("kind", "search").put("name", q).put("items", search(q))
    }

    /** Lien collé → une seule entrée, même format que la recherche. */
    fun resolve(link: String): JSONObject {
        init()
        var u = link.trim()
        if (!u.startsWith("http", ignoreCase = true)) u = "https://$u"
        val info = StreamInfo.getInfo(ServiceList.YouTube, u)
        val id = videoId(info.url ?: u) ?: videoId(u) ?: throw IllegalStateException("Lien YouTube non reconnu.")
        return itemJson(id, info.name ?: "", info.uploaderName ?: "", info.duration)
    }

    /**
     * Télécharge la meilleure piste audio dans [dest] (fichier temporaire). Renvoie le titre.
     * Aucune limite de durée (la lecture se fait en flux, pas en mémoire).
     * [cancelled] est testé à chaque tranche ; [progress] reçoit un pourcentage (0-99), ou -1 si inconnu.
     */
    fun download(url: String, dest: File, cancelled: () -> Boolean, progress: (Int) -> Unit): String {
        init()
        val info = StreamInfo.getInfo(ServiceList.YouTube, url)
        if (info.duration <= 0) throw IllegalStateException("Les directs ne sont pas pris en charge.")

        val streams = info.audioStreams.filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val pick = streams.filter { it.format?.suffix == "m4a" }.maxByOrNull { it.averageBitrate }
            ?: streams.maxByOrNull { it.averageBitrate }
            ?: throw IllegalStateException("Aucune piste audio utilisable pour cette vidéo.")
        val base = pick.content

        val estimate = if (pick.averageBitrate > 0) info.duration * pick.averageBitrate * 1000L / 8L else -1L
        val free = (dest.parentFile ?: dest).usableSpace
        if (free < maxOf(estimate, 5L * 1024 * 1024) + 50L * 1024 * 1024)
            throw IllegalStateException("Plus assez de place sur le téléphone.")

        var start = 0L
        FileOutputStream(dest).use { out ->
            while (true) {
                if (cancelled()) throw IllegalStateException("Annulé.")
                val end = start + CHUNK - 1
                // même technique que NewPipe : tranche demandée via le paramètre « range » de l'URL
                val req = OkRequest.Builder().url("$base&range=$start-$end").header("User-Agent", UA).build()
                var got = 0L
                client.newCall(req).execute().use { r ->
                    if (r.code == 416 || (start > 0 && (r.code == 400 || r.code == 404))) return@use
                    if (r.code != 200 && r.code != 206) throw IOException("HTTP ${r.code}")
                    val body = r.body ?: throw IOException("Réponse vide")
                    got = body.byteStream().copyTo(out)
                }
                start += got
                if (estimate > 0) progress(minOf(99L, start * 100L / estimate).toInt()) else progress(-1)
                if (got < CHUNK) break
            }
        }
        if (dest.length() < 10_000) throw IOException("Fichier audio incomplet.")
        return info.name ?: "YouTube"
    }

    /** URL directe du flux audio (lecture en streaming, rien n'est stocké). Valable quelques heures. */
    fun streamUrl(videoId: String): String {
        init()
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$videoId")
        if (info.duration <= 0) throw IllegalStateException("Les directs ne sont pas pris en charge.")
        val streams = info.audioStreams.filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val pick = streams.filter { it.format?.suffix == "m4a" }.maxByOrNull { it.averageBitrate }
            ?: streams.maxByOrNull { it.averageBitrate }
            ?: throw IllegalStateException("Aucune piste audio utilisable pour cette vidéo.")
        return pick.content
    }

    /** Message lisible en français pour l'écran. */
    fun explain(e: Throwable): String = when {
        e is IllegalStateException -> e.message ?: "Erreur."
        e is java.net.UnknownHostException || e is java.net.SocketTimeoutException || e is java.net.ConnectException ->
            "Pas de connexion internet."
        e is ReCaptchaException -> "YouTube bloque temporairement les requêtes. Réessaie dans quelques minutes."
        e is IOException -> "Erreur réseau : ${e.message ?: ""}".trim()
        e.javaClass.simpleName.contains("AgeRestricted") -> "Vidéo réservée aux adultes (non disponible)."
        e.javaClass.simpleName.contains("ContentNotAvailable") || e.javaClass.simpleName.contains("Unavailable") ->
            "Vidéo indisponible (privée, bloquée dans ton pays ou supprimée)."
        else -> "YouTube a changé son format ou refuse la demande. Mets à jour NewPipeExtractor dans app/build.gradle.kts. (${e.javaClass.simpleName})"
    }
}
