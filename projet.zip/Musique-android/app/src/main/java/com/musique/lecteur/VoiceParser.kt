package com.musique.lecteur

import java.text.Normalizer

/** « De quoi on parle » dans une commande vocale. */
sealed class Ref {
    /** « la », « le », « ça » : le dernier titre dont on a parlé (résultat de recherche, titre ajouté…). */
    object It : Ref()
    /** « ce titre », « la musique en cours » : ce qui joue en ce moment. */
    object Current : Ref()
    /** « le deuxième » (résultat de recherche, ou position dans la playlist selon la commande). */
    data class Nth(val n: Int) : Ref()
    /** Un titre / une recherche nommée (texte normalisé : minuscules, sans accents). */
    data class Named(val name: String) : Ref()
}

/** Commande comprise. Noms de playlist spéciaux : "@here" = la playlist ouverte à l'écran, "@queue" = la file d'attente. */
sealed class Cmd {
    object End : Cmd()
    object Yes : Cmd()
    object No : Cmd()
    object Pause : Cmd()
    object Resume : Cmd()
    object Next : Cmd()
    object Prev : Cmd()
    object Restart : Cmd()
    object StopAll : Cmd()
    object WhatsPlaying : Cmd()
    object ListPlaylists : Cmd()
    data class Shuffle(val on: Boolean) : Cmd()
    data class Repeat(val mode: String, val count: Int) : Cmd()
    /** kind : up | down | max | mute | set */
    data class Volume(val kind: String, val value: Int = 0) : Cmd()
    data class Seek(val deltaSec: Int) : Cmd()
    /** where : app | lib | search | player | queue | back | playlist (arg = nom) */
    data class Nav(val where: String, val arg: String = "") : Cmd()
    data class PlayPlaylist(val name: String, val shuffle: Boolean) : Cmd()
    data class Play(val what: Ref, val inPlaylist: String?, val youtube: Boolean, val shuffle: Boolean) : Cmd()
    data class Search(val query: String) : Cmd()
    data class Add(val what: Ref, val dest: String?) : Cmd()
    data class Remove(val what: Ref, val from: String?) : Cmd()
    /** dir : up | down | first | last | pos */
    data class Move(val what: Ref, val dir: String, val n: Int, val inPlaylist: String?) : Cmd()
    data class MovePlaylist(val name: String, val dir: String, val n: Int) : Cmd()
    data class Transfer(val what: Ref, val dest: String, val copy: Boolean) : Cmd()
    data class Enqueue(val what: Ref, val next: Boolean) : Cmd()
    data class CreatePl(val name: String) : Cmd()
    data class RenamePl(val from: String, val to: String) : Cmd()
    data class DeletePl(val name: String) : Cmd()
    data class Unknown(val text: String) : Cmd()
}

/**
 * Comprend le français parlé tel que le sort la reconnaissance vocale d'Android.
 * Pas d'IA, pas de réseau : un texte entre, une commande sort. Tout est testable sur PC.
 */
object VoiceParser {

    // ------------------------------------------------------------------ outils de texte
    /** Minuscules, sans accents, ponctuation → espaces. « Enlève-la ! » → « enleve la ». */
    fun norm(s: String): String {
        var t = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace("œ", "oe").replace("æ", "ae")
        return t.replace(Regex("[^a-z0-9]+"), " ").trim()
    }

    private val NUM = mapOf(
        "un" to 1, "une" to 1, "deux" to 2, "trois" to 3, "quatre" to 4, "cinq" to 5, "six" to 6, "sept" to 7, "huit" to 8,
        "neuf" to 9, "dix" to 10, "quinze" to 15, "vingt" to 20, "trente" to 30, "quarante" to 40, "cinquante" to 50, "soixante" to 60
    )
    private fun num(s: String): Int? = s.toIntOrNull() ?: NUM[s]

    private val ORD = mapOf(
        "premier" to 1, "premiere" to 1, "1er" to 1, "1ere" to 1,
        "deuxieme" to 2, "second" to 2, "seconde" to 2, "2eme" to 2, "2e" to 2,
        "troisieme" to 3, "3eme" to 3, "3e" to 3, "quatrieme" to 4, "4eme" to 4, "4e" to 4, "cinquieme" to 5, "5eme" to 5, "5e" to 5
    )

    private fun words(s: String) = if (s.isEmpty()) emptyList() else s.split(" ")
    private fun onlyWords(n: String, allowed: Set<String>) = words(n).all { it in allowed }

    // ------------------------------------------------------------------ nettoyage d'entrée
    private val LEAD = Regex("""^(?:(?:ok|okay|alors|bon|et|euh|donc|maintenant|hey|gemini|google|dis|dites|s il te plait|s il vous plait|stp|svp)\s+)+""")
    private val POLITE = Regex("""^(?:(?:peux tu|pourrais tu|pouvez vous|pourriez vous|tu peux|tu pourrais|est ce que tu peux|veux tu|voudrais tu|je veux|je voudrais|j aimerais|je souhaite|il faut|faut|on va|je vais)\s+)+""")
    private val TAIL = Regex("""(?:\s+(?:s il te plait|s il vous plait|stp|svp|merci|please))+$""")

    // ------------------------------------------------------------------ expressions simples
    private val R_END = Regex("""^(?:merci(?: beaucoup)?|c est bon|c est tout|c est fini|termine|fini|ferme|fermer|quitte|quitter|au revoir|a plus|a plus tard|salut|ca suffit|ca sera tout|stop ecoute|arrete d ecouter|arrete d ecoute|ferme l ecoute|rien|plus rien)$""")
    private val R_YES = Regex("""^(?:oui|ouais|yes|d accord|dac|confirme|confirmer|vas y|bien sur|affirmatif|exactement|ok|okay|c est ca)$""")
    private val R_NO = Regex("""^(?:non|nan|nope|annule|annuler|laisse tomber|surtout pas|pas du tout|negatif)$""")
    private val R_PAUSE = Regex("""^(?:pause|mets? en pause|met en pause|mettre en pause|stop|stoppe|arrete|arreter|arrete la musique|arrete le son|arrete ca|coupe|coupe la musique|coupe ca|silence|tais toi)$""")
    private val R_RESUME = Regex("""^(?:reprends|reprend|reprendre|continue|continuer|lecture|play|relance|relancer|remets? la musique|remets? ca|remets|remet|joue|jouer|lance la musique|mets? la musique|mets? de la musique|joue de la musique|joue la musique|demarre|demarre la musique|resume|reprends la lecture|reprends la musique|rallume la musique|play music|lis|lis la musique)$""")
    private val R_STOPALL = Regex("""^(?:arrete tout|vide la file|vide la file d attente|efface la file|efface la file d attente|ferme le lecteur|arrete la lecture|arrete la lecture et vide la file|stop tout)$""")
    private val R_RESTART = Regex("""^(?:recommence|recommencer|redemarre|redemarrer|depuis le debut|au debut|du debut|rejoue|rejoue ca|rejoue la|rejoue le|rejoue depuis le debut|remets? au debut|remets? depuis le debut|reprends depuis le debut|reviens au debut|encore une fois)$""")
    private val R_WHAT = Regex("""^(?:c est quoi|c est quel|c est qui|quel est|quelle est|qu est ce qui joue|qu est ce qui passe|qu est ce que c est|qui chante|ce qui joue|quelle musique|quelle chanson|quel titre|quel morceau).*$""")
    private val R_LISTPL = Regex("""^(?:quelles sont|liste|lis|dis moi|donne moi|enumere)\s+(?:moi\s+)?(?:mes|les|toutes mes)\s+playlists?$""")

    private val R_SH_ON = Regex("""^(?:(?:mets?|met|active|activer|passe|lance|joue|lis)\s+)?(?:(?:en|le|la|ca en|le mode|mode|la lecture|lecture)\s+)*(?:aleatoire|shuffle|melange|melangee|au hasard)$""")
    private val R_SH_OFF = Regex("""^(?:(?:desactive|desactiver|enleve|retire|arrete|arreter|stop|coupe|annule|sans)\s+(?:le\s+|la\s+|l\s+)?(?:mode\s+|lecture\s+)?(?:aleatoire|shuffle|melange)|dans l ordre|en ordre|lecture dans l ordre|remets? dans l ordre|pas aleatoire|plus aleatoire|plus de melange)$""")
    private val R_REP_OFF = Regex("""(?:^|\s)(?:arrete|arreter|stop|desactive|desactiver|enleve|retire|annule|plus de|sans|pas de|ne repete plus)\b.*\b(?:repet\w*|boucle)\b|^(?:ne repete plus|repete plus)$""")

    private val R_SEEK = Regex("""^(avance|avancer|saute|sauter|recule|reculer|retourne|retourner|reviens|revenir)(?: en arriere| en avant)?(?: de| d)?\s+(\d+|un|une|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|quinze|vingt|trente|quarante|cinquante|soixante)\s+(seconde|secondes|sec|minute|minutes|min)(?: en (arriere|avant))?$""")

    private val NEXT_OK = setOf("titre", "musique", "morceau", "chanson", "piste", "suivant", "suivante", "prochain", "prochaine", "next",
        "passe", "passer", "saute", "sauter", "zappe", "change", "au", "a", "la", "le", "cette", "ce", "de", "mets", "met", "va", "vas", "aller", "lance", "joue")
    private val PREV_OK = setOf("titre", "musique", "morceau", "chanson", "piste", "precedent", "precedente", "previous", "reviens", "retourne",
        "au", "a", "la", "le", "d", "avant", "mets", "met", "remets", "remet", "va", "vas", "aller", "lance", "joue", "sur", "cette", "ce", "de")

    // ------------------------------------------------------------------ point d'entrée
    /** Essaie chaque proposition de la reconnaissance vocale (la meilleure d'abord) et garde la première comprise. */
    fun parseBest(alternatives: List<String>): Cmd {
        for (a in alternatives) { val c = parse(a); if (c !is Cmd.Unknown) return c }
        return Cmd.Unknown(alternatives.firstOrNull() ?: "")
    }

    private val SEQ = Regex("""\s+(?:et puis|et|puis|ensuite|apres ca)\s+(?=(?:ouvre|va|vas|lance|joue|ajoute|enleve|retire|cherche|mets|met|monte|descends|deplace|supprime|cree|passe|pause|reprends|recherche|fais)\b)""")

    /** « va dans mon appli et ouvre la playlist rock » → deux commandes à la suite. */
    fun parseMulti(alternatives: List<String>): List<Cmd> {
        for (a in alternatives) {
            val parts = norm(a).split(SEQ)
            if (parts.size > 1) {
                val cmds = parts.map { parse(it) }
                if (cmds.none { it is Cmd.Unknown }) return cmds
            }
        }
        return listOf(parseBest(alternatives))
    }

    fun parse(raw: String): Cmd {
        var n = norm(raw)
        n = n.replace(LEAD, "").replace(POLITE, "").replace(LEAD, "").replace(TAIL, "").trim()
        if (n.isEmpty()) return Cmd.Unknown(raw)

        // --- réponses courtes
        if (R_END.matches(n)) return Cmd.End
        if (R_YES.matches(n)) return Cmd.Yes
        if (R_NO.matches(n)) return Cmd.No

        // --- gestion des playlists (avant « ajoute… » / « supprime… »)
        playlistManagement(raw, n)?.let { return it }

        // --- lecture / réglages simples
        volume(n)?.let { return it }
        if (R_WHAT.matches(n)) return Cmd.WhatsPlaying
        if (R_PAUSE.matches(n)) return Cmd.Pause
        if (R_STOPALL.matches(n)) return Cmd.StopAll
        if (R_RESUME.matches(n)) return Cmd.Resume
        if (R_RESTART.matches(n)) return Cmd.Restart
        if (R_SH_OFF.matches(n)) return Cmd.Shuffle(false)
        if (R_SH_ON.matches(n)) return Cmd.Shuffle(true)
        repeat(n)?.let { return it }
        seek(n)?.let { return it }
        if (n.split(" ").size <= 6) {
            val w = words(n)
            if (w.any { it in setOf("suivant", "suivante", "prochain", "prochaine", "next") } && onlyWords(n, NEXT_OK)) return Cmd.Next
            if (n == "passe" || n == "saute" || n == "zappe" || n == "passe la" || n == "saute la" || n == "change") return Cmd.Next
            if ((w.any { it in setOf("precedent", "precedente", "previous") } && onlyWords(n, PREV_OK)) ||
                Regex("""^(?:la |le )?(?:musique|titre|morceau|chanson)? ?d avant$|^celle d avant$""").matches(n)) return Cmd.Prev
        }

        // --- recherche
        search(n)?.let { return it }

        // --- navigation
        navigation(n)?.let { return it }

        // --- file d'attente : « joue X ensuite »
        val enq = Regex("""^(?:joue|jouer|lance|mets?|met|lis|ecoute)\s+(.+?)\s+(?:ensuite|juste apres|apres|en suivant|a la suite|juste apres celle ci|apres celle ci)$""").find(n)
        if (enq != null) return Cmd.Enqueue(parseRef(enq.groupValues[1]), true)

        // --- transfert vers une autre playlist : « déplace-la vers la playlist rock »
        val tr = Regex("""^(deplace|deplacer|bouge|transfere|transferer|passe|envoie|copie|copier|duplique|dupliquer)\s*(.*)$""").find(n)
        if (tr != null) {
            val (head, pl) = splitPl(tr.groupValues[2])
            if (pl != null && pl != "@here") {
                val copy = tr.groupValues[1].startsWith("copie") || tr.groupValues[1].startsWith("dupli")
                return Cmd.Transfer(parseRef(head), pl, copy)
            }
        }

        // --- déplacer dans la playlist : « monte-la », « mets-la en premier »
        move(n)?.let { return it }

        // --- supprimer
        val rm = Regex("""^(?:enleve|enlever|retire|retirer|supprime|supprimer|efface|effacer|vire|virer|elimine)\s*(.*)$""").find(n)
        if (rm != null) {
            val (head, pl) = splitPl(rm.groupValues[1])
            return Cmd.Remove(parseRef(head), pl)
        }

        // --- ajouter
        val ad = Regex("""^(ajoute|ajouter|rajoute|rajouter|enregistre|enregistrer|garde|garder|sauvegarde|sauvegarder|range|ranger|insere|inserer|mets|met|mettre)\s*(.*)$""").find(n)
        if (ad != null) {
            val verb = ad.groupValues[1]
            val rest = ad.groupValues[2]
            val soft = verb == "mets" || verb == "met" || verb == "mettre"
            if (!soft || splitPl(rest).second != null || Regex("""(?:^|\s)(?:file d attente|la file)$""").containsMatchIn(rest)) return parseAdd(rest)
        }

        // --- lire une playlist
        val pp = Regex("""^(?:fais jouer|mets moi|met moi|lance|lancer|joue|jouer|mets|met|demarre|demarrer|ecoute|ecouter|lis|lire|passe)\s+(?:moi\s+)?(?:la\s+|ma\s+|mon\s+|le\s+|l\s+|les\s+)?(?:playlist|liste de lecture)\b\s*(?:de\s+|d\s+)?(.*)$""").find(n)
        if (pp != null) {
            var name = pp.groupValues[1]
            val sh = SHUF.containsMatchIn(name) || SHUF.containsMatchIn(n)
            name = name.replace(SHUF, " ").trim()
            if (name.isEmpty()) name = "@here"
            return Cmd.PlayPlaylist(name, sh)
        }

        // --- lire un titre / une recherche
        val pl = Regex("""^(?:fais jouer|mets moi|met moi|lance|lancer|joue|jouer|mets|met|demarre|demarrer|ecoute|ecouter|lis|lire|passe)\s+(.+)$""").find(n)
        if (pl != null) {
            var rest = pl.groupValues[1]
            val shuffle = SHUF.containsMatchIn(rest)
            rest = rest.replace(SHUF, " ").trim()
            val yt = Regex("""\b(?:you tube|youtube)\b""").containsMatchIn(rest)
            if (yt) rest = rest.replace(Regex("""\s*\b(?:sur|dans|avec|depuis)\s+(?:you tube|youtube)\b"""), " ").replace(Regex("""\b(?:you tube|youtube)\b"""), " ").trim()
            val (head, inPl) = splitPl(rest)
            val ref = parseRef(head)
            if (ref is Ref.Named && ref.name.isEmpty()) return if (inPl != null) Cmd.PlayPlaylist(inPl, shuffle) else Cmd.Resume
            return Cmd.Play(ref, inPl, yt, shuffle)
        }

        return Cmd.Unknown(raw)
    }

    private val SHUF = Regex("""\b(?:en aleatoire|aleatoire|melangee?|melanger|au hasard|en shuffle|shuffle|dans le desordre)\b""")

    // ------------------------------------------------------------------ volume
    private fun volume(n: String): Cmd? {
        val w = words(n)
        if (w.size > 8) return null
        val m = Regex("""^(?:(?:mets?|met|regle|monte|baisse)\s+)?(?:le\s+)?(?:volume|son)\s+(?:a\s+|au\s+|sur\s+)?(\d{1,3})(?:\s*(?:pour cent|%))?$""").find(n)
        if (m != null) return Cmd.Volume("set", m.groupValues[1].toInt().coerceIn(0, 100))
        if (Regex("""^(?:(?:mets?|met|monte|regle|pousse)\s+)?(?:le\s+)?(?:volume|son)\s+(?:a fond|au max|au maximum|a bloc|maximum|max)$""").matches(n) ||
            Regex("""^(?:volume|son) (?:au )?(?:max|maximum)$""").matches(n)) return Cmd.Volume("max")
        if (Regex("""^(?:coupe le son|coupe le volume|mute|sans le son|mets le son a zero|volume a zero|son a zero)$""").matches(n)) return Cmd.Volume("mute")
        val hasSon = w.any { it == "son" || it == "volume" }
        val up = Regex("""\b(?:plus fort|plus haut|monte|augmente|remonte|pousse)\b""").containsMatchIn(n)
        val down = Regex("""\b(?:moins fort|plus bas|baisse|diminue|reduis|descends|descend|moins de son)\b""").containsMatchIn(n)
        val bare = n in setOf("plus fort", "un peu plus fort", "moins fort", "un peu moins fort", "plus bas", "un peu plus bas", "plus haut", "un peu plus haut", "plus fort s il te plait")
        if ((hasSon || bare) && up && !down) return Cmd.Volume("up")
        if ((hasSon || bare) && down) return Cmd.Volume("down")
        return null
    }

    // ------------------------------------------------------------------ répétition / avance rapide
    private fun repeat(n: String): Cmd? {
        val w = words(n)
        if (w.size > 9 || !Regex("""\b(?:repet\w*|boucle)\b""").containsMatchIn(n)) return null
        if (Regex("""\bplaylist\b""").containsMatchIn(n) && Regex("""^(?:joue|lance|mets?|met)\b""").containsMatchIn(n)) return null
        if (R_REP_OFF.containsMatchIn(n)) return Cmd.Repeat("off", 0)
        val count = Regex("""\b(\d+|deux|trois|quatre|cinq|six|sept|huit|neuf|dix)\s+fois\b""").find(n)?.let { num(it.groupValues[1]) } ?: 0
        val all = Regex("""\b(?:playlist|liste|file|tout|tous|toute|ensemble)\b""").containsMatchIn(n)
        return Cmd.Repeat(if (all) "all" else "one", count)
    }

    private fun seek(n: String): Cmd? {
        val m = R_SEEK.find(n) ?: return null
        val v = num(m.groupValues[2]) ?: return null
        val unit = if (m.groupValues[3].startsWith("min")) 60 else 1
        val back = m.groupValues[1].startsWith("recule") || m.groupValues[1].startsWith("retourne") ||
            m.groupValues[1].startsWith("reviens") || m.groupValues[1].startsWith("revenir") || m.groupValues[4] == "arriere" || n.contains("en arriere")
        return Cmd.Seek(if (back) -v * unit else v * unit)
    }

    // ------------------------------------------------------------------ playlists
    private fun playlistManagement(raw: String, n: String): Cmd? {
        if (R_LISTPL.matches(n)) return Cmd.ListPlaylists

        val cr = Regex("""^(?:cree|creer|fais|faire|ajoute|ajouter|rajoute|nouvelle|nouveau|genere)\s+(?:moi\s+)?(?:une\s+|la\s+)?(?:nouvelle\s+)?playlist\b\s*(?:qui s appelle|nommee|appelee|intitulee|avec le nom|du nom de|nom)?\s*(.*)$""").find(n)
        if (cr != null) {
            val rawName = Regex("""(?i)\bplaylist\b\s*(?:qui\s+s\s*['’]?\s*appelle|nomm[ée]e|appel[ée]e|intitul[ée]e|avec\s+le\s+nom|du\s+nom\s+de|nom)?\s*(.*?)\s*[.!?]*\s*$""").find(raw)
                ?.groupValues?.get(1)?.trim().orEmpty()
            return Cmd.CreatePl(capital(if (rawName.isNotEmpty()) rawName else cr.groupValues[1]))
        }

        val rn = Regex("""^(?:renomme|renommer|rebaptise|change le nom de|appelle)\s+(?:la\s+|ma\s+)?playlist\s+(.+?)\s+(?:en|par|comme)\s+(.+)$""").find(n)
        if (rn != null) {
            val rawTo = Regex("""(?i)\bplaylist\b\s+.+?\s+(?:en|par|comme)\s+(.+?)\s*[.!?]*\s*$""").find(raw)?.groupValues?.get(1)?.trim().orEmpty()
            return Cmd.RenamePl(rn.groupValues[1], capital(if (rawTo.isNotEmpty()) rawTo else rn.groupValues[2]))
        }

        val de = Regex("""^(?:supprime|supprimer|efface|effacer|vire|virer|elimine)\s+(?:completement\s+)?(?:la\s+|ma\s+)?playlist\s+(.+)$""").find(n)
        if (de != null) return Cmd.DeletePl(de.groupValues[1])

        val mp = Regex("""^(?:monte|remonte|descends|descend|redescends|deplace|bouge|mets?|met)\s+(?:la\s+|ma\s+)?playlist\s+(.+?)(?:\s+(vers le haut|vers le bas|en haut|en bas|tout en haut|tout en bas|en premier|en dernier|au debut|a la fin|d un cran vers le haut|d un cran vers le bas|de \w+ crans? vers le (?:haut|bas)))$""").find(n)
        if (mp != null) {
            val d = mp.groupValues[2]
            val up = Regex("""haut|premier|debut""").containsMatchIn(d)
            val extreme = d.contains("tout") || d.contains("premier") || d.contains("dernier") || d.contains("debut") || d.contains("fin")
            val cnt = Regex("""de (\w+) crans?""").find(d)?.let { num(it.groupValues[1]) } ?: 1
            return Cmd.MovePlaylist(mp.groupValues[1], if (extreme) (if (up) "first" else "last") else if (up) "up" else "down", cnt)
        }
        return null
    }

    private fun capital(s: String): String {
        val t = s.trim()
        return if (t.isEmpty()) "Nouvelle playlist" else t.substring(0, 1).uppercase() + t.substring(1)
    }

    // ------------------------------------------------------------------ recherche
    private fun search(n: String): Cmd? {
        val m = Regex("""^(?:(?:fais|fait|lance|effectue|faire|ouvre)\s+(?:moi\s+)?)?(?:une\s+)?(?:recherche|recherches|cherche|chercher|trouve|trouver)\b\s*(.*)$""").find(n) ?: return null
        val q = cleanQuery(m.groupValues[1])
        return if (q.isEmpty()) Cmd.Nav("search") else Cmd.Search(q)
    }

    /** Enlève « sur YouTube », « dans mon application musique », « genre », les articles de tête… */
    fun cleanQuery(s0: String): String {
        var s = s0.trim()
        val loc = Regex("""\s*\b(?:sur|dans|avec|depuis)\s+(?:you tube|youtube|yt|mon application musique|l application musique|l appli musique|mon appli musique|mon application|mon appli|l application|l appli|musique)\b""")
        val lead = Regex("""^(?:moi\s+)?(?:(?:sur|dans)\s+)?(?:(?:youtube|you tube)\s+)?(?:(?:de|d|pour|du|des|la|le|les|l|une|un)\s+)?(?:(?:genre|style|type|musique|titre|chanson|morceau|video|videos)\s+)*(?:(?:de|d|du|des)\s+)?""")
        repeat(3) { s = s.replace(loc, " ").trim().replace(lead, "").trim() }
        return s
    }

    // ------------------------------------------------------------------ navigation
    private fun navigation(n: String): Cmd? {
        val verb = """(?:va|vas|aller|allez|ouvre|ouvrir|affiche|afficher|montre|montrer|passe|retourne|reviens|entre|rentre|emmene moi|amene moi|accede|acceder|bascule)"""
        val prep = """(?:\s+(?:dans|sur|a|au|en|vers))?"""
        val art = """(?:\s+(?:l|la|le|les|mon|ma|mes|l onglet|onglet|ecran|l ecran|la page|page))*"""

        if (Regex("""^(?:retour|retourne|reviens|reviens en arriere|en arriere|ecran precedent|page precedente|ecran d avant|ferme cet ecran|ferme la fenetre|ferme ca)$""").matches(n)) return Cmd.Nav("back")
        if (Regex("""^(?:$verb$prep\s+(?:l |la |mon |ma |le )?(?:(?:application|appli|app)\s+)?(?:de\s+)?musique|(?:lance|lancer|demarre|demarrer|ouvre|ouvrir)\s+(?:l |mon |ma )?(?:application|appli|app)(?:\s+(?:de\s+)?musique)?)$""").matches(n)) return Cmd.Nav("app")
        if (Regex("""^$verb$prep$art\s+(?:recherche|chercher|you tube|youtube)(?:\s+(?:de musique|youtube))?$""").matches(n)) return Cmd.Nav("search")
        if (Regex("""^$verb$prep$art\s+(?:bibliotheque|playlists|listes|liste des playlists|toutes mes playlists|accueil|menu principal|ecran principal|page principale|musiques|musique)$""").matches(n)) return Cmd.Nav("lib")
        if (Regex("""^$verb$prep$art\s+(?:lecteur|ecran de lecture|plein ecran|en cours de lecture|lecture en cours|mini lecteur|lecture)$""").matches(n)) return Cmd.Nav("player")
        if (Regex("""^$verb$prep$art\s+(?:file d attente|file|liste d attente)$""").matches(n)) return Cmd.Nav("queue")

        val pl = Regex("""^$verb$prep(?:\s+(?:la|ma|mon|le|l))?\s+(?:playlist|liste de lecture|dossier)\b\s*(?:de\s+|d\s+)?(.*)$""").find(n)
        if (pl != null) return Cmd.Nav("playlist", pl.groupValues[1].ifEmpty { "@here" })

        // « va dans rock » : le dernier recours, pour les verbes de navigation sans ambiguïté
        val any = Regex("""^(?:va|vas|aller|ouvre|ouvrir|entre|rentre|affiche|montre|accede|acceder)$prep(?:\s+(?:la|ma|mon|le|l|les))?\s+(.+)$""").find(n)
        if (any != null) {
            val name = cleanQuery(any.groupValues[1])
            if (name.isNotEmpty()) return Cmd.Nav("playlist", name)
        }
        return null
    }

    // ------------------------------------------------------------------ déplacer
    private fun move(n: String): Cmd? {
        val vm = Regex("""^(deplace|deplacer|monte|remonte|descends|descend|redescends|bouge|mets|met|place|placer|passe|decale|remets|remet|replace|baisse|range)\s*(.*)$""").find(n) ?: return null
        var rest = vm.groupValues[2]

        val first = Regex("""\b(?:tout en haut|en premier|en premiere position|au debut|en tete|a la premiere place|en haut de la liste|en haut de la playlist)\b""")
        val last = Regex("""\b(?:tout en bas|en dernier|en derniere position|a la fin|a la derniere place|en bas de la liste|en bas de la playlist)\b""")
        val pos1 = Regex("""\b(?:en|a la|a)\s+(?:position|place)\s+(?:numero\s+)?(\d+)\b""")
        val pos2 = Regex("""\b(?:en|a la|a)\s+(\d+)(?:e|eme|ieme|er|ere)?\s+(?:position|place)\b""")
        val up = Regex("""\b(?:vers le haut|plus haut|en haut|au dessus)\b""")
        val down = Regex("""\b(?:vers le bas|plus bas|en bas|en dessous)\b""")
        val cnt = Regex("""\b(?:de\s+)?(\d+|un|une|deux|trois|quatre|cinq|six|sept|huit|neuf|dix)\s+(?:place|places|cran|crans|rang|rangs|position|positions)\b""")

        var dir: String? = null
        var k = 1
        val p = pos1.find(rest) ?: pos2.find(rest)
        when {
            p != null -> { dir = "pos"; k = p.groupValues[1].toInt(); rest = rest.replace(p.value, " ") }
            first.containsMatchIn(rest) -> { dir = "first"; rest = rest.replace(first, " ") }
            last.containsMatchIn(rest) -> { dir = "last"; rest = rest.replace(last, " ") }
            up.containsMatchIn(rest) || vm.groupValues[1] in setOf("monte", "remonte") -> { dir = "up"; rest = rest.replace(up, " ") }
            down.containsMatchIn(rest) || vm.groupValues[1] in setOf("descends", "descend", "redescends", "baisse") -> { dir = "down"; rest = rest.replace(down, " ") }
        }
        if (dir == null) return null
        if (dir == "up" || dir == "down") {
            val c = cnt.find(rest)
            if (c != null) { k = num(c.groupValues[1]) ?: 1; rest = rest.replace(c.value, " ") }
            rest = rest.replace(Regex("""\bd un cran\b|\bd un rang\b|\bun cran\b|\bun peu\b"""), " ")
        }
        rest = rest.replace(Regex("""\bjuste\b"""), " ")
        rest = rest.replace(Regex("\\s+"), " ").trim()
        val (head, pl) = splitPl(rest)
        return Cmd.Move(parseRef(head), dir, k, pl)
    }

    // ------------------------------------------------------------------ ajouter
    private fun parseAdd(rest0: String): Cmd {
        var rest = rest0.trim()
        val q = Regex("""(?:^|\s)(?:a|dans|sur|en|vers)\s+(?:la\s+|ma\s+)?(?:file d attente|file|liste d attente)$""").find(rest)
        if (q != null) return Cmd.Enqueue(parseRef(rest.substring(0, q.range.first).trim()), false)
        var (head, dest) = splitPl(rest)
        if (dest == null) {
            val m = Regex("""^(la|le|les|ca|celle ci|celui ci)\s+(?:dans|a|au|vers|sur)\s+(.+)$""").find(head)
            if (m != null) { head = m.groupValues[1]; dest = m.groupValues[2] }
        }
        return Cmd.Add(parseRef(head), dest)
    }

    // ------------------------------------------------------------------ « ... de la playlist X »
    private val PL_SUFFIX = Regex("""\b(?:dans|de|du|depuis|sur|a|au|vers|en|pour|chez)\s+(?:la\s+|ma\s+|mon\s+|le\s+|cette\s+|ta\s+)?(?:playlist|liste de lecture)\b\s*(.*)$""")

    /** Sépare « ajoute X dans la playlist Y » en (X, Y). Y = "@here" pour « cette playlist ». */
    fun splitPl(s: String): Pair<String, String?> {
        val m = PL_SUFFIX.find(s) ?: return Pair(s.trim(), null)
        val head = s.substring(0, m.range.first).trim()
        var name = m.groupValues[1].trim()
        if (name.isEmpty() || m.value.contains("cette playlist") || Regex("""^(?:ci|actuelle|en cours)\b""").containsMatchIn(name)) name = "@here"
        return Pair(head, name)
    }

    // ------------------------------------------------------------------ « la », « ce titre », « le deuxième », « daft punk »
    private val IT = setOf("", "la", "le", "les", "l", "ca", "cela", "celui ci", "celle ci", "celui la", "celle la", "la ci", "le ci", "ce resultat",
        "ce resultat la", "cette video", "ce truc", "ca la", "la la", "le la")
    private val CURRENT = Regex("""^(?:(?:ce|cet|cette)\s+(?:titre|musique|morceau|chanson|son|air|piste)(?:\s+(?:ci|la))?|(?:la|le)\s+(?:musique|titre|morceau|chanson|piste)\s+(?:en cours|actuelle?|qui joue|qui passe|que j ecoute)|(?:celle|celui)\s+(?:qui joue|en cours|qui passe)|ce qui joue|ce que j ecoute)$""")
    private val NTH1 = Regex("""^(?:(?:le|la|l)\s+)?(premier|premiere|deuxieme|second|seconde|troisieme|quatrieme|cinquieme|1er|1ere|2eme|3eme|4eme|5eme|2e|3e|4e|5e)(?:\s+(?:resultat|video|titre|musique|morceau|chanson|piste))?$""")
    private val NTH2 = Regex("""^(?:le\s+)?(?:resultat|numero|titre|morceau|piste|video)\s+(?:numero\s+)?(\d+)$""")

    fun parseRef(s0: String): Ref {
        val s = s0.trim()
        if (s in IT) return Ref.It
        if (Regex("""^(?:le |la |l )?(?:dernier|derniere)(?: titre| musique| morceau| chanson| resultat)?$""").matches(s)) return Ref.Nth(-1)
        if (CURRENT.matches(s)) return Ref.Current
        NTH1.find(s)?.let { m -> ORD[m.groupValues[1]]?.let { return Ref.Nth(it) } }
        NTH2.find(s)?.let { return Ref.Nth(it.groupValues[1].toInt()) }
        return Ref.Named(cleanQuery(s))
    }

    // ------------------------------------------------------------------ correspondance approximative (noms de playlist, titres)
    private val STOP = setOf("le", "la", "les", "l", "un", "une", "des", "du", "de", "d", "et", "a", "au", "aux", "en", "dans", "sur", "mon", "ma", "mes", "ta", "ton", "the", "of")

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun sim(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        return if (m == 0) 1.0 else 1.0 - lev(a, b).toDouble() / m
    }

    /** 0.0 → rien à voir, 1.0 → identique. Tolère les fautes de la reconnaissance vocale (« rok » → « rock »). */
    fun score(query: String, candidate: String): Double {
        val a = norm(query); val b = norm(candidate)
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        if (b.contains(a) || a.contains(b)) {
            val shorter = minOf(a.length, b.length).toDouble(); val longer = maxOf(a.length, b.length).toDouble()
            return 0.7 + 0.3 * shorter / longer
        }
        val qt = words(a).filter { it !in STOP }.ifEmpty { words(a) }
        val ct = words(b).filter { it !in STOP }.ifEmpty { words(b) }
        var hit = 0.0
        for (q in qt) {
            val best = ct.maxOf { sim(q, it) }
            if (best >= 0.75) hit += best
        }
        val recall = hit / qt.size
        val precision = minOf(1.0, hit / ct.size)
        return 0.75 * recall + 0.25 * precision
    }

    /** Meilleur candidat (indice, score) ou null si rien d'assez proche. */
    fun best(query: String, candidates: List<String>, min: Double = 0.6): Pair<Int, Double>? {
        var bi = -1; var bs = 0.0
        for ((i, c) in candidates.withIndex()) { val s = score(query, c); if (s > bs) { bs = s; bi = i } }
        return if (bi >= 0 && bs >= min) Pair(bi, bs) else null
    }
}
