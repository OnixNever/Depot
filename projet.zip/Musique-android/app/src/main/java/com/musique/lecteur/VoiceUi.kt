package com.musique.lecteur

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * Mode « commande vocale » : un panneau en bas de l'écran, le micro écoute en boucle (reconnaissance vocale gratuite
 * d'Android), Voice exécute chaque phrase, la synthèse vocale d'Android confirme à voix haute, puis ça réécoute.
 * Ça s'arrête avec « merci » / « c'est bon », le bouton Fermer, ou après deux silences.
 */
class VoiceUi(private val act: Activity, private val root: FrameLayout) {

    companion object { const val REQ_MIC = 21 }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var active = false
    private var wantStart = false
    private var silences = 0
    private var misses = 0
    private var retries = 0
    private var afterSpeak: (() -> Unit)? = null
    private var panel: LinearLayout? = null
    private var status: TextView? = null
    private var heard: TextView? = null
    private var reply: TextView? = null

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ panneau
    private fun showPanel() {
        if (panel != null) return
        val p = LinearLayout(act)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(20), dp(16), dp(20), dp(14))
        p.background = GradientDrawable().apply {
            setColor(Color.parseColor("#F2141420")); cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.parseColor("#668B5CF6"))
        }
        p.elevation = dp(16).toFloat()
        fun tv(size: Float, color: String, bold: Boolean = false) = TextView(act).apply {
            textSize = size; setTextColor(Color.parseColor(color)); if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(5), 0, 0)
        }
        val st = tv(18f, "#FFFFFF", true)
        val hd = tv(15f, "#B79CFF")
        val rp = tv(14f, "#D5D6EA")
        val hint = tv(12f, "#8F91AB").apply { text = "Exemples : « lance la playlist rock », « cherche Daft Punk », « ajoute-la », « monte-la », « enlève-la », « suivant »" }
        val close = TextView(act).apply {
            text = "Fermer"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(9), dp(18), dp(9))
            background = GradientDrawable().apply { setColor(Color.parseColor("#272740")); cornerRadius = dp(20).toFloat() }
            setOnClickListener { stop(null) }
        }
        p.addView(st); p.addView(hd); p.addView(rp); p.addView(hint)
        p.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10); gravity = Gravity.END })
        root.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { setMargins(dp(10), 0, dp(10), dp(10)) })
        panel = p; status = st; heard = hd; reply = rp
    }

    private fun hidePanel() { panel?.let { root.removeView(it) }; panel = null; status = null; heard = null; reply = null }

    // ------------------------------------------------------------------ démarrage / arrêt
    fun start() {
        if (active) return
        if (!SpeechRecognizer.isRecognitionAvailable(act)) {
            Toast.makeText(act, "Reconnaissance vocale indisponible : installe ou active l'appli Google.", Toast.LENGTH_LONG).show(); return
        }
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            wantStart = true
            act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        active = true; silences = 0; misses = 0; retries = 0
        showPanel()
        Engine.duck(true)
        initTts()
        listen()
    }

    fun onPermission(granted: Boolean) {
        if (granted && wantStart) { wantStart = false; start() }
        else { wantStart = false; Toast.makeText(act, "Sans le micro, les commandes vocales ne marchent pas.", Toast.LENGTH_LONG).show() }
    }

    fun stop(msg: String?) {
        val was = active
        active = false
        main.removeCallbacksAndMessages(null)
        afterSpeak = null
        try { rec?.cancel(); rec?.destroy() } catch (_: Exception) {}
        rec = null
        try { tts?.stop() } catch (_: Exception) {}
        if (was) Engine.duck(false)
        if (msg != null && panel != null) {
            status?.text = "Écoute arrêtée"; reply?.text = msg
            main.postDelayed({ hidePanel() }, 2500)
        } else hidePanel()
    }

    fun release() { stop(null); try { tts?.shutdown() } catch (_: Exception) {}; tts = null }

    // ------------------------------------------------------------------ voix de synthèse
    private fun initTts() {
        if (tts != null) return
        tts = TextToSpeech(act.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale.FRANCE)
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { finishSpeak() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { finishSpeak() } }
                })
            }
        }
    }

    private val speakTimeout = Runnable { finishSpeak() }

    private fun finishSpeak() {
        main.removeCallbacks(speakTimeout)
        val n = afterSpeak; afterSpeak = null
        n?.invoke()
    }

    private fun speak(text: String, next: () -> Unit) {
        val t = tts
        if (!ttsReady || t == null || text.isBlank()) { next(); return }
        afterSpeak = next
        main.postDelayed(speakTimeout, 4000L + text.length * 90L)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    // ------------------------------------------------------------------ écoute
    private fun listen() {
        if (!active) return
        status?.text = "Je t'écoute…"
        heard?.text = ""
        val r = rec ?: SpeechRecognizer.createSpeechRecognizer(act).also { it.setRecognitionListener(listener); rec = it }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
            if (Build.VERSION.SDK_INT >= 33) putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, Voice.hints(act))
        }
        try { r.startListening(i) } catch (e: Exception) { stop("Le micro n'est pas disponible.") }
    }

    private fun quiet() {
        silences++
        if (silences >= 2) stop("Je n'entends rien, j'arrête l'écoute.") else main.postDelayed({ listen() }, 250)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() { silences = 0 }
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { status?.text = "Je réfléchis…" }
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onPartialResults(b: Bundle?) {
            val s = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!s.isNullOrBlank()) heard?.text = "« $s »"
        }

        override fun onError(code: Int) {
            if (!active) return
            when (code) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> quiet()
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                    if (++retries > 3) stop("La reconnaissance vocale ne répond pas.")
                    else { try { rec?.destroy() } catch (_: Exception) {}; rec = null; main.postDelayed({ listen() }, 600) }
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stop("Autorise le micro pour Musique.")
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                    stop("La reconnaissance vocale a besoin d'internet.")
                SpeechRecognizer.ERROR_AUDIO -> stop("Problème de micro.")
                else -> stop("La reconnaissance vocale a échoué (code $code). Vérifie que le français est installé dans l'appli Google.")
            }
        }

        override fun onResults(b: Bundle?) {
            if (!active) return
            val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            if (list.isEmpty() || list[0].isBlank()) { quiet(); return }
            silences = 0; retries = 0
            heard?.text = "« ${list[0]} »"
            status?.text = "Je m'en occupe…"
            Voice.handleAsync(act, list) { res -> onResult(res) }
        }
    }

    private fun onResult(res: Voice.Res) {
        if (!active) return
        var say = res.say
        if (say.startsWith("Je n'ai pas compris")) {
            misses++
            if (misses >= 3) say += " Essaie : lance la playlist rock, ou : cherche Daft Punk."
        } else misses = 0
        reply?.text = say
        speak(say) { if (res.end) stop(null) else listen() }
    }
}
