package com.musique.lecteur

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    companion object {
        private const val REQ_NOTIF = 12
        private const val REQ_PICK = 13
        private const val REQ_IMPORT = 14
        private const val HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$HOST/assets/www/index.html"
        /** Applis Google qui ouvrent les applis à la voix : appli Google, Gemini, Assistant. */
        private val GOOGLE_PACKAGES = setOf(
            "com.google.android.googlequicksearchbox",
            "com.google.android.apps.bard",
            "com.google.android.apps.googleassistant"
        )
    }

    lateinit var web: WebView
    private lateinit var voice: VoiceUi
    private var autoVoice = false
    private var bridge: Bridge? = null
    private var pickReq = -1
    private var pickPl = ""
    private var importReq = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(applicationContext)

        web = WebView(this)
        val root = FrameLayout(this)
        root.addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        voice = VoiceUi(this, root)
        Ui.runJs = { code -> web.post { web.evaluateJavascript(code, null) } }
        autoVoice = intent?.getBooleanExtra("voice", false) == true || launchedByGoogleAssistant(intent)

        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false

        val loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request == null) return null
                return loader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                Ui.flush()
                if (autoVoice) { autoVoice = false; web.postDelayed({ voice.start() }, 500) }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null || request.url.host == HOST) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (_: Exception) {}
                return true
            }
        }

        bridge = Bridge(this)
        web.addJavascriptInterface(bridge!!, "Android")
        web.loadUrl(START_URL)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
    }

    fun startVoice() = voice.start()

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("voice", false) == true || launchedByGoogleAssistant(intent)) voice.start()
    }

    /**
     * Vrai si l'appli vient d'être ouverte par la voix (« Ok Google, ouvre Onyx Music » / Gemini) :
     * l'appelant (referrer) est alors une appli Google, et l'intent est un simple lancement depuis le lanceur.
     * Un appui sur l'icône (referrer = l'écran d'accueil) ou un retour depuis les applis récentes ne déclenche rien.
     */
    private fun launchedByGoogleAssistant(i: Intent?): Boolean {
        if (i == null) return false
        if (i.action != Intent.ACTION_MAIN || !i.hasCategory(Intent.CATEGORY_LAUNCHER)) return false
        if ((i.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return false
        val ref: Uri? = try {
            @Suppress("DEPRECATION")
            i.getParcelableExtra<Uri>(Intent.EXTRA_REFERRER) ?: referrer
        } catch (_: Exception) { null }
        if (ref == null || ref.scheme != "android-app") return false
        return ref.host in GOOGLE_PACKAGES
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == VoiceUi.REQ_MIC) voice.onPermission(grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
    }

    /** Sélecteur système (audio) : plusieurs fichiers, pointés sans copie via une permission persistante. */
    fun pickMusic(reqId: Int, plId: String) {
        pickReq = reqId
        pickPl = plId
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(i, REQ_PICK) }
        catch (_: Exception) { pickReq = -1; bridge?.reply(reqId, false, "Impossible d'ouvrir le sélecteur de fichiers.") }
    }

    /** Sélecteur de fichier pour importer une playlist exportée (.json ou .zip). */
    fun pickImport(reqId: Int) {
        importReq = reqId
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(i, REQ_IMPORT) }
        catch (_: Exception) { importReq = -1; bridge?.reply(reqId, false, "Impossible d'ouvrir le sélecteur de fichiers.") }
    }

    /** Partage Android (WhatsApp, Bluetooth, Fichiers…) d'un fichier d'export du cache. */
    fun shareFile(f: java.io.File, mime: String) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Partager la playlist"))
        } catch (_: Exception) {}
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n.replace(Regex("\\.[^.]+$"), "")
                }
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "Son du téléphone"
    }

    private fun handlePicked(data: Intent?) {
        val b = bridge
        val req = pickReq
        val pl = pickPl
        pickReq = -1
        if (b == null || req < 0) return
        val uris = ArrayList<Uri>()
        data?.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        data?.data?.let { if (uris.isEmpty()) uris.add(it) }
        val arr = JSONArray()
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            arr.put(JSONObject().put("u", u.toString()).put("n", displayName(u)).put("a", "Téléphone").put("d", 0))
        }
        val n = if (arr.length() > 0) Engine.lib.trAdd(pl, arr) else 0
        b.reply(req, true, n.toString())
    }

    /** Garde l'écran allumé pendant un téléchargement lancé par l'utilisateur. */
    fun setKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_PICK) { handlePicked(if (resultCode == Activity.RESULT_OK) data else null); return }
        if (requestCode == REQ_IMPORT) {
            val req = importReq; importReq = -1
            val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
            if (req >= 0) { if (uri != null) bridge?.runImport(req, uri) else bridge?.reply(req, false, "annulé") }
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    /** Retour : la page ferme d'abord ses fenêtres (lecteur, menus), puis l'appli passe en arrière-plan (la musique continue). */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(function(){try{return window.__back?window.__back():false}catch(e){return false}})()") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.evaluateJavascript("window.__sync&&window.__sync()", null)
    }

    override fun onPause() {
        super.onPause()
        Engine.saveNow()
        voice.stop(null)
        web.onPause()
    }

    override fun onDestroy() {
        Ui.runJs = null
        Ui.reset()
        voice.release()
        bridge?.shutdown()
        (web.parent as? android.view.ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
