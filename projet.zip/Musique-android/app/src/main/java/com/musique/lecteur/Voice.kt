package com.musique.lecteur

import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import java.util.concurrent.Executors

/**
 * Exécute les commandes comprises par VoiceParser sur le lecteur (Engine) et les playlists (Library).
 * Marche avec ou sans écran : l'interface est prévenue quand elle existe (Ui), sinon tout se fait quand même.
 *
 * Mémoire courte : « la » / « le » / « ça » = le dernier titre dont on a parlé (résultat de recherche, titre ajouté…),
 * sinon le titre qui joue. Les questions de suivi (« Dans quelle playlist ? », « Tu confirmes ? ») attendent la réponse suivante.
 */
object Voice {

    class Res(val say: String, val end: Boolean = false)

    private class Pl(val id: String, val name: String, val tracks: List<Engine.T>)
    private class Item(val t: Engine.T, val plId: String?)
    private class Loc(val pl: Pl, val idx: Int, val t: Engine.T)
    private class Hit(val pl: Pl, val idx: Int, val score: Double)

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    @Volatile private var focus: Item? = null
    @Volatile private var results: List<Engine.T> = emptyList()
    @Volatile private var lastPl: String? = null
    @Volatile private var lastPlAt = 0L
    @Volatile private var pending: ((Cmd, String) -> Res?)? = null
    @Volatile private var pendingAt = 0L

    // ------------------------------------------------------------------ points d'entrée
    /** Comprend et exécute en tâche de fond (réseau possible), puis rend la main sur le thread principal. */
    fun handleAsync(ctx: Context, alternatives: List<String>, done: (Res) -> Unit) {
        val app = ctx.applicationContext
        worker.execute {
            val r = handle(app, alternatives)
            main.post { done(r) }
        }
    }

    @Synchronized
    fun handle(ctx: Context, alternatives: List<String>): Res {
        return try {
            Engine.init(ctx.applicationContext)
            val pd = pending
            if (pd != null) {
                pending = null
                if (System.currentTimeMillis() - pendingAt < 45_000) {
                    val r = pd(VoiceParser.parseBest(alternatives), alternatives.firstOrNull().orEmpty())
                    if (r != null) return r
                }
            }
            val said = ArrayList<String>()
            var end = false
            for (c in VoiceParser.parseMulti(alternatives)) {
                val r = run(ctx, c)
                if (r.say.isNotEmpty()) said.add(r.say)
                if (r.end) end = true
                if (pending != null) break
            }
            Res(said.joinToString(" "), end)
        } catch (e: Throwable) {
            Res("Il y a eu un problème : " + (e.message ?: e.javaClass.simpleName))
        }
    }

    /** « Joue X sur Musique » envoyé par l'assistant (Gemini) : aucune interface nécessaire, un Toast confirme. */
    fun playFromSearch(ctx: Context, query: String?, extras: Bundle?) {
        val app = ctx.applicationContext
        worker.execute {
            val res = try {
                synchronized(this) {
                    Engine.init(app)
                    val plName = extras?.getString("android.intent.extra.playlist")
                    val title = extras?.getString("android.intent.extra.title")
                    val artist = extras?.getString("android.intent.extra.artist")
                    val q = listOf(title, artist).filter { !it.isNullOrBlank() }.joinToString(" ").ifBlank { query.orEmpty() }.trim()
                    when {
                        !plName.isNullOrBlank() -> run(app, Cmd.PlayPlaylist(VoiceParser.norm(plName), false))
                        q.isBlank() -> playAnything()
                        else -> {
                            val c = VoiceParser.parse("joue $q")
                            run(app, if (c is Cmd.Unknown) Cmd.Play(Ref.Named(VoiceParser.cleanQuery(VoiceParser.norm(q))), null, false, false) else c)
                        }
                    }
                }
            } catch (e: Throwable) { Res("Impossible de lancer : " + (e.message ?: e.javaClass.simpleName)) }
            toast(app, res.say)
        }
    }

    fun toast(ctx: Context, s: String) {
        if (s.isBlank()) return
        main.post { try { Toast.makeText(ctx.applicationContext, s, Toast.LENGTH_LONG).show() } catch (_: Exception) {} }
    }

    /** Mots que la reconnaissance vocale doit privilégier : noms de playlists + titre en cours. */
    fun hints(ctx: Context): ArrayList<String> {
        val l = ArrayList<String>()
        try {
            Engine.init(ctx.applicationContext)
            for (p in playlists()) l.add(p.name)
            Engine.current()?.let { l.add(it.n) }
        } catch (_: Throwable) {}
        return l
    }

    // ------------------------------------------------------------------ bibliothèque
    private fun playlists(): List<Pl> {
        val a = org.json.JSONObject(Engine.lib.get()).getJSONArray("pl")
        val out = ArrayList<Pl>()
        for (i in 0 until a.length()) {
            val p = a.getJSONObject(i)
            val t = p.getJSONArray("tracks")
            val l = ArrayList<Engine.T>()
            for (j in 0 until t.length()) l.add(Engine.T.from(t.getJSONObject(j)))
            out.add(Pl(p.getString("id"), p.optString("name"), l))
        }
        return out
    }

    private fun same(a: Engine.T, b: Engine.T) = (a.y.isNotEmpty() && a.y == b.y) || (a.u.isNotEmpty() && a.u == b.u)

    private fun short(t: Engine.T): String {
        val s = t.n.replace(Regex("""\s*[\(\[].*?[\)\]]"""), "").trim()
        return if (s.length > 60) s.substring(0, 60) else s
    }

    private fun findPl(name: String, pls: List<Pl>): Pl? {
        if (name == "@here") return pls.firstOrNull { p -> p.id == Ui.curPl }
        if (name == "@queue") return null
        val b = VoiceParser.best(name, pls.map { p -> p.name }) ?: return null
        return pls[b.first]
    }

    private fun remember(pl: Pl) { lastPl = pl.id; lastPlAt = System.currentTimeMillis() }

    /** Où ajouter quand rien n'est précisé : dernière playlist citée, playlist ouverte, playlist d'ajout de la recherche. */
    private fun defaultDest(pls: List<Pl>): Pl? {
        val id = lastPl
        if (id != null && System.currentTimeMillis() - lastPlAt < 15 * 60_000L) pls.firstOrNull { p -> p.id == id }?.let { return it }
        if (Ui.view == "pl") pls.firstOrNull { p -> p.id == Ui.curPl }?.let { return it }
        if (Ui.target.isNotEmpty()) pls.firstOrNull { p -> p.id == Ui.target }?.let { return it }
        return if (pls.size == 1) pls[0] else null
    }

    private fun bestTrack(name: String, pls: List<Pl>): Hit? {
        var best: Hit? = null
        for (pl in pls) for ((i, t) in pl.tracks.withIndex()) {
            var s = VoiceParser.score(name, t.n + " " + t.a)
            if (pl.id == Ui.curPl) s += 0.01
            val b = best
            if (b == null || s > b.score) best = Hit(pl, i, s)
        }
        return best
    }

    private fun trackOf(ref: Ref): Engine.T? = when (ref) {
        is Ref.It -> focus?.t ?: Engine.current()
        is Ref.Current -> Engine.current()
        is Ref.Nth -> { val l = results; if (ref.n < 0) l.lastOrNull() else l.getOrNull(ref.n - 1) }
        is Ref.Named -> null
    }

    // ------------------------------------------------------------------ questions de suivi
    private fun ask(question: String, handler: (Cmd, String) -> Res?): Res {
        pending = handler
        pendingAt = System.currentTimeMillis()
        return Res(question)
    }

    private fun confirm(question: String, yes: () -> Res): Res = ask(question) { cmd, _ ->
        when (cmd) {
            is Cmd.Yes -> yes()
            is Cmd.No, is Cmd.End -> Res("D'accord, je ne touche à rien.")
            else -> null
        }
    }

    private fun askPlaylist(question: String, pls: List<Pl>, then: (Pl) -> Res): Res {
        val names = pls.take(6).joinToString(", ") { p -> p.name }
        return ask("$question $names") { cmd, raw ->
            if (cmd is Cmd.No || cmd is Cmd.End) Res("D'accord, annulé.")
            else {
                val n = VoiceParser.norm(raw).replace(Regex("^(?:(?:dans|a|au|vers|en|la|ma|mon|le|playlist)\\s+)+"), "")
                val m = VoiceParser.best(n, pls.map { p -> p.name }, 0.55)
                if (m == null) Res("Je ne trouve pas cette playlist. Annulé.") else then(pls[m.first])
            }
        }
    }

    // ------------------------------------------------------------------ YouTube
    private class Yres(val kind: String, val name: String, val items: List<Engine.T>)

    private fun ytLookup(q: String): Yres {
        val o = Yt.lookup(q)
        val a = o.getJSONArray("items")
        val l = ArrayList<Engine.T>()
        for (i in 0 until a.length()) {
            val x = a.getJSONObject(i)
            l.add(Engine.T(x.optString("id"), "", x.optString("title"), x.optString("channel"), x.optLong("dur")))
        }
        return Yres(o.optString("kind"), o.optString("name"), l)
    }

    /** Premier résultat YouTube pour « X » ; garde la liste en mémoire pour « le deuxième ». */
    private fun ytFirst(q: String): Engine.T? {
        val r = try { ytLookup(q) } catch (e: Throwable) { throw IllegalStateException(Yt.explain(e)) }
        results = r.items.take(10)
        val t = r.items.firstOrNull() ?: return null
        focus = Item(t, null)
        return t
    }

    // ------------------------------------------------------------------ localiser un titre dans les playlists
    private fun stillThere(loc: Loc): Boolean {
        val cur = playlists().firstOrNull { p -> p.id == loc.pl.id } ?: return false
        val x = cur.tracks.getOrNull(loc.idx) ?: return false
        return same(x, loc.t)
    }

    private fun guard(loc: Loc, f: () -> Res): Res = if (stillThere(loc)) f() else Res("La playlist a changé, redis-le.")

    /** Retrouve (playlist, position) de ce dont on parle, pose une question si c'est ambigu, puis appelle [then]. */
    private fun withLoc(what: Ref, plName: String?, then: (Loc) -> Res): Res {
        val pls = playlists()
        val given: Pl? = if (plName == null) null
            else (findPl(plName, pls) ?: return Res(if (plName == "@here") "Ouvre d'abord une playlist." else "Je ne trouve pas la playlist $plName."))
        if (what is Ref.Nth) {
            val pl = given ?: pls.firstOrNull { p -> Ui.view == "pl" && p.id == Ui.curPl } ?: defaultDest(pls)
                ?: return askPlaylist("Dans quelle playlist ?", pls) { p -> inPlaylist(p, what, then) }
            return inPlaylist(pl, what, then)
        }
        if (what is Ref.Named) {
            if (what.name.isEmpty()) return Res("Quel titre ?")
            val h = bestTrack(what.name, if (given != null) listOf(given) else pls)
            if (h == null || h.score < 0.55) return Res("Je ne trouve pas « ${what.name} » dans tes playlists.")
            return then(Loc(h.pl, h.idx, h.pl.tracks[h.idx]))
        }
        val t = trackOf(what) ?: return Res("De quel titre parles-tu ?")
        val hits = ArrayList<Loc>()
        for (p in pls) for ((i, x) in p.tracks.withIndex()) if (same(x, t)) hits.add(Loc(p, i, x))
        if (hits.isEmpty()) return Res("« ${short(t)} » n'est dans aucune playlist.")
        val pick = (if (given != null) hits.firstOrNull { h -> h.pl.id == given.id } else null)
            ?: (if (given == null) hits.firstOrNull { h -> Ui.view == "pl" && h.pl.id == Ui.curPl } else null)
            ?: (if (hits.size == 1) hits[0] else null)
        if (pick != null) return then(pick)
        if (given != null) return Res("« ${short(t)} » n'est pas dans ${given.name}.")
        return askPlaylist("Il est dans plusieurs playlists. Laquelle ?", hits.map { h -> h.pl }) { p -> then(hits.first { h -> h.pl.id == p.id }) }
    }

    private fun inPlaylist(pl: Pl, what: Ref, then: (Loc) -> Res): Res {
        val nth = what as? Ref.Nth ?: return Res("Je n'ai pas compris lequel.")
        val i = if (nth.n < 0) pl.tracks.size - 1 else nth.n - 1
        if (i !in pl.tracks.indices) return Res("Il n'y a pas de titre numéro ${nth.n} dans ${pl.name}.")
        return then(Loc(pl, i, pl.tracks[i]))
    }

    // ------------------------------------------------------------------ exécution
    private fun run(ctx: Context, c: Cmd): Res {
        return when (c) {
            is Cmd.End -> Res("D'accord.", true)
            is Cmd.Yes -> Res("Je t'écoute.")
            is Cmd.No -> Res("D'accord.")

            is Cmd.Pause -> { Engine.pause(); Res("Pause.") }
            is Cmd.Resume -> if (Engine.current() == null) Res("Rien à reprendre. Dis par exemple : lance la playlist, puis son nom.") else { Engine.play(); Res("C'est reparti.") }
            is Cmd.Next -> { Engine.next(); Res("Suivant.") }
            is Cmd.Prev -> { Engine.prev(); Res("Précédent.") }
            is Cmd.Restart -> { Engine.seek(0); Res("Je recommence le titre.") }
            is Cmd.StopAll -> { Engine.clear(); Res("Lecture arrêtée, file vidée.") }
            is Cmd.Shuffle -> { Engine.setShuffle(c.on); Res(if (c.on) "Lecture aléatoire activée." else "Lecture aléatoire désactivée.") }
            is Cmd.Repeat -> {
                Engine.setRepeat(c.mode, c.count)
                Res(when (c.mode) {
                    "off" -> "Répétition désactivée."
                    "all" -> "Je répète la playlist" + (if (c.count > 0) " ${c.count} fois." else " en boucle.")
                    else -> "Je répète le titre" + (if (c.count > 0) " ${c.count} fois." else " en boucle.")
                })
            }
            is Cmd.Volume -> volume(ctx, c)
            is Cmd.Seek -> {
                Engine.seek((Engine.posNow() + c.deltaSec * 1000).coerceAtLeast(0))
                Res(if (c.deltaSec >= 0) "J'avance de ${spoken(c.deltaSec)}." else "Je recule de ${spoken(-c.deltaSec)}.")
            }
            is Cmd.WhatsPlaying -> {
                val t = Engine.current()
                if (t == null) Res("Rien ne joue.") else Res("C'est " + short(t) + (if (t.a.isNotBlank()) ", de ${t.a}." else "."))
            }
            is Cmd.ListPlaylists -> {
                val pls = playlists()
                if (pls.isEmpty()) Res("Tu n'as pas encore de playlist.")
                else Res("Tu as ${pls.size} playlist" + (if (pls.size > 1) "s : " else " : ") + pls.take(10).joinToString(", ") { p -> p.name } + ".")
            }

            is Cmd.Nav -> nav(ctx, c)
            is Cmd.PlayPlaylist -> playPlaylist(c)
            is Cmd.Play -> play(c)
            is Cmd.Search -> search(ctx, c)
            is Cmd.Enqueue -> enqueue(c)
            is Cmd.Add -> add(c)
            is Cmd.Remove -> withLoc(c.what, c.from) { loc ->
                guard(loc) {
                    Engine.lib.trRemove(loc.pl.id, loc.idx)
                    val f = focus
                    if (f != null && same(f.t, loc.t)) focus = null
                    Ui.libChanged()
                    Res("J'ai retiré « ${short(loc.t)} » de ${loc.pl.name}.")
                }
            }
            is Cmd.Move -> withLoc(c.what, c.inPlaylist) { loc -> guard(loc) { moveTrack(loc, c) } }
            is Cmd.MovePlaylist -> movePlaylist(c)
            is Cmd.Transfer -> transfer(c)
            is Cmd.CreatePl -> {
                val id = Engine.lib.plCreate(c.name)
                lastPl = id; lastPlAt = System.currentTimeMillis()
                Ui.libChanged()
                Res("Playlist « ${c.name} » créée.")
            }
            is Cmd.RenamePl -> {
                val pls = playlists()
                val p = findPl(c.from, pls)
                if (p == null) Res("Je ne trouve pas la playlist ${c.from}.")
                else { Engine.lib.plRename(p.id, c.to); Ui.libChanged(); Res("« ${p.name} » s'appelle maintenant « ${c.to} ».") }
            }
            is Cmd.DeletePl -> {
                val p = findPl(c.name, playlists())
                if (p == null) Res("Je ne trouve pas la playlist ${c.name}.")
                else confirm("Supprimer la playlist ${p.name} et ses téléchargements ? Dis oui pour confirmer.") {
                    Engine.lib.plDelete(p.id)
                    if (lastPl == p.id) lastPl = null
                    if (Ui.curPl == p.id && Ui.view == "pl") Ui.nav(ctx, "lib") else Ui.libChanged()
                    Res("Playlist ${p.name} supprimée.")
                }
            }
            is Cmd.Unknown -> Res(if (c.text.isBlank()) "" else "Je n'ai pas compris : " + c.text + ".")
        }
    }

    private fun spoken(sec: Int): String = if (sec >= 60 && sec % 60 == 0) "${sec / 60} minute" + (if (sec / 60 > 1) "s" else "") else "$sec secondes"

    private fun volume(ctx: Context, c: Cmd.Volume): Res {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        when (c.kind) {
            "up" -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) } }
            "down" -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) } }
            "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
            else -> am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * c.value / 100.0).toInt().coerceIn(0, max), AudioManager.FLAG_SHOW_UI)
        }
        val now = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        return Res(if (c.kind == "mute") "Son coupé." else "Volume à ${if (max > 0) now * 100 / max else 0} pour cent.")
    }

    // ------------------------------------------------------------------ navigation
    private fun nav(ctx: Context, c: Cmd.Nav): Res {
        when (c.where) {
            "app" -> { if (Ui.alive()) return Res("Je suis déjà dans l'appli."); Ui.openApp(ctx); return Res("J'ouvre Musique.") }
            "playlist" -> {
                val pls = playlists()
                val p = findPl(c.arg, pls) ?: return Res(if (c.arg == "@here") "Aucune playlist n'est ouverte." else "Je ne trouve pas la playlist ${c.arg}.")
                remember(p)
                Ui.nav(ctx, "pl", p.id)
                return Res("J'ouvre ${p.name}.")
            }
            "lib" -> { Ui.nav(ctx, "lib"); return Res("Ta bibliothèque.") }
            "search" -> { Ui.nav(ctx, "search"); return Res("La recherche.") }
            "player" -> { Ui.nav(ctx, "player"); return Res("Le lecteur.") }
            "queue" -> { Ui.nav(ctx, "queue"); return Res("La file d'attente.") }
            else -> { Ui.nav(ctx, "back"); return Res("") }
        }
    }

    // ------------------------------------------------------------------ lecture
    private fun playAnything(): Res {
        val all = ArrayList<Engine.T>()
        for (p in playlists()) all.addAll(p.tracks)
        if (all.isEmpty()) return Res("Tu n'as pas encore de musique dans tes playlists.")
        Engine.setShuffle(true)
        Engine.playList(all, 0)
        return Res("Je lance toute ta musique en aléatoire.")
    }

    private fun playPlaylist(c: Cmd.PlayPlaylist): Res {
        val pls = playlists()
        val p = findPl(c.name, pls) ?: return Res(if (c.name == "@here") "Ouvre d'abord une playlist, ou dis son nom." else "Je ne trouve pas la playlist ${c.name}.")
        if (p.tracks.isEmpty()) return Res("La playlist ${p.name} est vide.")
        remember(p)
        if (c.shuffle) Engine.setShuffle(true)
        focus = null
        Engine.playList(p.tracks, 0)
        return Res("Je lance ${p.name}" + (if (c.shuffle) " en aléatoire." else "."))
    }

    private fun play(c: Cmd.Play): Res {
        val pls = playlists()
        if (c.shuffle) Engine.setShuffle(true)
        val w = c.what
        if (w is Ref.Current) { Engine.play(); return Res("C'est reparti.") }
        if (w !is Ref.Named) {
            val t = trackOf(w) ?: return Res("Je ne sais pas quel titre lancer.")
            Engine.playList(listOf(t), 0)
            return Res("Je lance " + short(t) + ".")
        }
        val q = w.name
        if (q.isEmpty()) return Res("Quel titre ?")
        if (c.inPlaylist != null) {
            val p = findPl(c.inPlaylist, pls) ?: return Res("Je ne trouve pas la playlist ${c.inPlaylist}.")
            val h = bestTrack(q, listOf(p))
            if (h == null || h.score < 0.55) return Res("Je ne trouve pas « $q » dans ${p.name}.")
            remember(p); focus = null
            Engine.playList(p.tracks, h.idx)
            return Res("Je lance " + short(p.tracks[h.idx]) + ".")
        }
        if (!c.youtube) {
            val bp = VoiceParser.best(q, pls.map { p -> p.name }, 0.85)
            val bt = bestTrack(q, pls)
            if (bp != null && (bt == null || bp.second >= bt.score)) {
                val p = pls[bp.first]
                if (p.tracks.isNotEmpty()) { remember(p); focus = null; Engine.playList(p.tracks, 0); return Res("Je lance la playlist ${p.name}.") }
            }
            if (bt != null && bt.score >= 0.72) {
                focus = null
                Engine.playList(bt.pl.tracks, bt.idx)
                return Res("Je lance " + short(bt.pl.tracks[bt.idx]) + ".")
            }
        }
        val r = try { ytLookup(q) } catch (e: Throwable) { return Res(Yt.explain(e)) }
        if (r.items.isEmpty()) return Res("Je ne trouve rien pour $q.")
        results = r.items.take(10)
        focus = Item(r.items[0], null)
        if (r.kind == "playlist") { Engine.playList(r.items, 0); return Res("Je lance la playlist YouTube ${r.name}.") }
        Engine.playList(listOf(r.items[0]), 0)
        return Res("Je lance " + short(r.items[0]) + ".")
    }

    private fun search(ctx: Context, c: Cmd.Search): Res {
        val r = try { ytLookup(c.query) } catch (e: Throwable) { return Res(Yt.explain(e)) }
        Ui.nav(ctx, "search", c.query)
        if (r.items.isEmpty()) return Res("Aucun résultat pour ${c.query}.")
        results = r.items.take(10)
        focus = Item(r.items[0], null)
        val top = r.items.take(3).joinToString(". ") { t -> short(t) + (if (t.a.isNotBlank()) ", de " + t.a else "") }
        return Res("J'ai trouvé : $top. Dis « ajoute-la » pour le premier, « joue-la », ou « le deuxième ».")
    }

    private fun enqueue(c: Cmd.Enqueue): Res {
        val t = resolveAnyTrack(c.what) ?: return Res("Je ne sais pas quel titre mettre en file.")
        Engine.enqueue(t, c.next)
        return Res(if (c.next) short(t) + " sera lu ensuite." else short(t) + " ajouté à la file d'attente.")
    }

    /** Titre déjà connu (la, ce titre, le deuxième) ou, pour un nom, d'abord tes playlists, sinon le 1er résultat YouTube. */
    private fun resolveAnyTrack(ref: Ref): Engine.T? {
        if (ref !is Ref.Named) return trackOf(ref)
        if (ref.name.isEmpty()) return null
        val h = bestTrack(ref.name, playlists())
        if (h != null && h.score >= 0.72) return h.pl.tracks[h.idx]
        return ytFirst(ref.name)
    }

    // ------------------------------------------------------------------ édition des playlists
    private fun add(c: Cmd.Add): Res {
        val w = c.what
        val t: Engine.T = when (w) {
            is Ref.Named -> {
                if (w.name.isEmpty()) return Res("Quel titre ?")
                ytFirst(w.name) ?: return Res("Je ne trouve rien pour ${w.name}.")
            }
            else -> trackOf(w) ?: return Res("Je ne sais pas quel titre ajouter. Cherche-le d'abord, ou dis le nom.")
        }
        val pls = playlists()
        if (c.dest == null) {
            val d = defaultDest(pls)
            if (d != null) return addTo(t, d)
            if (pls.isEmpty()) return Res("Tu n'as pas encore de playlist. Dis : crée une playlist, puis son nom.")
            return askPlaylist("Dans quelle playlist ?", pls) { p -> addTo(t, p) }
        }
        val d = findPl(c.dest, pls)
        if (d != null) return addTo(t, d)
        if (c.dest == "@here") return Res("Ouvre d'abord une playlist, ou dis son nom.")
        val rawName = c.dest.replaceFirstChar { ch -> ch.uppercase() }
        return confirm("Je ne trouve pas la playlist ${c.dest}. Je la crée ?") {
            val id = Engine.lib.plCreate(rawName)
            val fresh = playlists().firstOrNull { p -> p.id == id }
            if (fresh == null) Res("Je n'ai pas pu créer la playlist.") else addTo(t, fresh)
        }
    }

    private fun addTo(t: Engine.T, pl: Pl): Res {
        remember(pl)
        if (pl.tracks.any { x -> same(x, t) }) { focus = Item(t, pl.id); return Res("« ${short(t)} » est déjà dans ${pl.name}.") }
        Engine.lib.trAdd(pl.id, JSONArray().put(t.json()))
        focus = Item(t, pl.id)
        Ui.libChanged()
        return Res("J'ai ajouté « ${short(t)} » à ${pl.name}.")
    }

    private fun moveTrack(loc: Loc, c: Cmd.Move): Res {
        val size = loc.pl.tracks.size
        val to = when (c.dir) {
            "up" -> loc.idx - c.n
            "down" -> loc.idx + c.n
            "first" -> 0
            "last" -> size - 1
            else -> c.n - 1
        }.coerceIn(0, size - 1)
        if (to == loc.idx) return Res(when (c.dir) { "up", "first" -> "Il est déjà tout en haut."; "down", "last" -> "Il est déjà tout en bas."; else -> "Il est déjà à cette place." })
        Engine.lib.trMove(loc.pl.id, loc.idx, to)
        remember(loc.pl)
        focus = Item(loc.t, loc.pl.id)
        Ui.libChanged()
        val where = when {
            to == 0 -> "tout en haut"
            to == size - 1 -> "tout en bas"
            else -> "en position ${to + 1}"
        }
        return Res("« ${short(loc.t)} » est maintenant $where dans ${loc.pl.name}.")
    }

    private fun movePlaylist(c: Cmd.MovePlaylist): Res {
        val pls = playlists()
        val p = findPl(c.name, pls) ?: return Res("Je ne trouve pas la playlist ${c.name}.")
        val i = pls.indexOfFirst { x -> x.id == p.id }
        val to = when (c.dir) { "up" -> i - c.n; "down" -> i + c.n; "first" -> 0; else -> pls.size - 1 }.coerceIn(0, pls.size - 1)
        if (to == i) return Res("Elle est déjà à cette place.")
        Engine.lib.plMove(i, to)
        Ui.libChanged()
        return Res("${p.name} est maintenant en position ${to + 1}.")
    }

    private fun transfer(c: Cmd.Transfer): Res {
        val pls = playlists()
        val dst = findPl(c.dest, pls) ?: return Res("Je ne trouve pas la playlist ${c.dest}.")
        return withLoc(c.what, null) { loc ->
            guard(loc) {
                if (loc.pl.id == dst.id) Res("Il est déjà dans ${dst.name}.")
                else {
                    Engine.lib.trTransfer(loc.pl.id, loc.idx, dst.id, c.copy)
                    remember(dst)
                    focus = Item(loc.t, dst.id)
                    Ui.libChanged()
                    Res("« ${short(loc.t)} » " + (if (c.copy) "copié" else "déplacé") + " vers ${dst.name}.")
                }
            }
        }
    }

    /** Pour SEARCH_ACTION (Gemini) : ouvre la recherche de l'appli avec les mots demandés. */
    fun openSearch(ctx: Context, query: String) {
        Ui.nav(ctx.applicationContext, "search", query)
    }
}
