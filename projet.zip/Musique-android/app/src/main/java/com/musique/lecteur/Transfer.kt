package com.musique.lecteur

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Export / import de playlists entre téléphones.
 *  - Export léger (.json) : seulement les titres YouTube (identifiants), quelques Ko.
 *  - Export complet (.zip) : les titres YouTube restent des liens ; les titres sans source YouTube
 *    (fichiers du téléphone) sont embarqués avec leur fichier audio.
 *  - Import : lit un .json ou un .zip, crée une nouvelle playlist (les fichiers audio du zip sont copiés dans l'appli).
 */
object Transfer {
    private const val FORMAT = "musique-playlist"

    class Out(val file: File, val mime: String, val skipped: Int, val missing: Int)
    class Imp(val id: String, val name: String, val count: Int, val files: Int)

    private fun safeName(s: String): String =
        s.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_").trim().take(40).ifEmpty { "playlist" }

    private fun link(o: JSONObject) = JSONObject().put("y", o.optString("y")).put("n", o.optString("n", "Sans titre"))
        .put("a", o.optString("a")).put("d", o.optLong("d"))

    fun export(ctx: Context, lib: Library, plId: String, full: Boolean): Out {
        val snap = lib.snapshot(plId) ?: throw IllegalStateException("Playlist introuvable.")
        val name = snap.optString("name", "playlist")
        val tracks = snap.getJSONArray("tracks")
        val dir = File(ctx.cacheDir, "export").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val base = safeName(name)
        val hasLocal = (0 until tracks.length()).any { tracks.getJSONObject(it).optString("y").isEmpty() }

        // Léger : liens YouTube seulement
        if (!full || !hasLocal) {
            val out = JSONArray(); var skipped = 0
            for (i in 0 until tracks.length()) {
                val o = tracks.getJSONObject(i)
                if (o.optString("y").isNotEmpty()) out.put(link(o)) else skipped++
            }
            if (out.length() == 0) throw IllegalStateException("Aucun titre YouTube à exporter : choisis « Tout exporter ».")
            val f = File(dir, "$base.musique.json")
            f.writeText(JSONObject().put("format", FORMAT).put("v", 1).put("name", name).put("tracks", out).toString())
            return Out(f, "application/json", skipped, 0)
        }

        // Complet : liens + fichiers audio des titres sans source YouTube
        val f = File(dir, "$base.musique.zip")
        val out = JSONArray(); var missing = 0; var k = 0
        ZipOutputStream(FileOutputStream(f).buffered()).use { z ->
            z.setLevel(Deflater.NO_COMPRESSION) // l'audio est déjà compressé
            for (i in 0 until tracks.length()) {
                val o = tracks.getJSONObject(i)
                if (o.optString("y").isNotEmpty()) { out.put(link(o)); continue }
                val u = o.optString("u")
                try {
                    val uri = Uri.parse(u)
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(ctx.contentResolver.getType(uri)) ?: "m4a"
                    val entry = "files/" + (++k) + "." + ext
                    val ins = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException()
                    z.putNextEntry(ZipEntry(entry))
                    ins.use { it.copyTo(z) }
                    z.closeEntry()
                    out.put(JSONObject().put("n", o.optString("n", "Sans titre")).put("a", o.optString("a"))
                        .put("d", o.optLong("d")).put("f", entry))
                } catch (_: Exception) { missing++ }
            }
            z.putNextEntry(ZipEntry("playlist.json"))
            z.write(JSONObject().put("format", FORMAT).put("v", 1).put("name", name).put("full", true).put("tracks", out).toString().toByteArray())
            z.closeEntry()
        }
        return Out(f, "application/zip", 0, missing)
    }

    fun importFrom(ctx: Context, lib: Library, uri: Uri): Imp {
        val ins = BufferedInputStream(ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Fichier illisible."))
        ins.mark(4)
        val b0 = ins.read(); val b1 = ins.read()
        ins.reset()
        val isZip = b0 == 'P'.code && b1 == 'K'.code
        val dir = File(lib.importsDir, lib.newId("i"))
        var text: String? = null
        if (isZip) {
            ZipInputStream(ins).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (e.name == "playlist.json") text = z.readBytes().toString(Charsets.UTF_8)
                    else if (e.name.startsWith("files/") && !e.isDirectory) {
                        val fn = File(e.name).name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                        dir.mkdirs()
                        FileOutputStream(File(dir, fn)).use { z.copyTo(it) }
                    }
                    z.closeEntry(); e = z.nextEntry
                }
            }
        } else {
            text = ins.use { it.readBytes().toString(Charsets.UTF_8) }
        }
        val root = try { JSONObject(text ?: throw IllegalStateException()) } catch (_: Exception) { null }
        if (root == null || root.optString("format") != FORMAT) { dir.deleteRecursively(); throw IllegalStateException("Ce fichier n'est pas une playlist exportée par l'appli.") }

        val src = root.getJSONArray("tracks")
        val tracks = JSONArray(); var files = 0
        for (i in 0 until src.length()) {
            val o = src.getJSONObject(i)
            val f = o.optString("f")
            if (f.isNotEmpty()) {
                val file = File(dir, File(f).name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                if (!file.exists()) continue
                o.remove("f"); o.put("u", Uri.fromFile(file).toString()); files++
            }
            if (o.optString("y").isNotEmpty() || o.optString("u").isNotEmpty()) tracks.put(o)
        }
        if (files == 0) dir.deleteRecursively()
        if (tracks.length() == 0) throw IllegalStateException("La playlist importée est vide.")
        val name = root.optString("name", "Playlist importée").ifBlank { "Playlist importée" }
        val id = lib.importPlaylist(name, tracks)
        return Imp(id, name, tracks.length(), files)
    }
}
