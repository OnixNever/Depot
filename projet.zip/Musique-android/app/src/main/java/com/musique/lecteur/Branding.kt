package com.musique.lecteur

import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build

/**
 * Nom de l'icône vocale (par défaut « Onyx »), modifiable dans l'appli.
 * Android ne permet pas de renommer l'icône du lanceur après l'installation : le nom choisi sert donc à créer
 * un raccourci sur l'écran d'accueil (qui peut porter n'importe quel nom). Le nom est aussi gardé dans l'appli.
 */
object Branding {
    const val DEFAULT = "Onyx"
    private const val PIN_ID = "voice_pin"

    private fun prefs(c: Context) = c.getSharedPreferences("engine", Context.MODE_PRIVATE)

    fun voiceName(c: Context): String = prefs(c).getString("voiceName", DEFAULT)?.takeIf { it.isNotBlank() } ?: DEFAULT

    /** Enregistre le nom et crée (ou renomme) le raccourci d'écran d'accueil. Renvoie "created", "updated" ou "unsupported". */
    fun applyVoiceName(c: Context, name: String): String {
        val n = name.trim().take(24).ifEmpty { DEFAULT }
        prefs(c).edit().putString("voiceName", n).apply()
        if (Build.VERSION.SDK_INT < 26) return "unsupported"
        val sm = c.getSystemService(ShortcutManager::class.java) ?: return "unsupported"
        val sc = ShortcutInfo.Builder(c, PIN_ID)
            .setShortLabel(n).setLongLabel(n)
            .setIcon(Icon.createWithResource(c, R.mipmap.ic_launcher_voice))
            .setIntent(Intent(c, VoiceLauncherActivity::class.java).setAction(Intent.ACTION_VIEW))
            .build()
        return try {
            if (sm.pinnedShortcuts.any { it.id == PIN_ID }) { sm.updateShortcuts(listOf(sc)); "updated" }
            else if (sm.isRequestPinShortcutSupported) { sm.requestPinShortcut(sc, null); "created" }
            else "unsupported"
        } catch (_: Exception) { "unsupported" }
    }
}
