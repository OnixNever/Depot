package com.musique.lecteur

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/**
 * Lecteur unique de l'appli (vit tant que le processus vit, indépendamment de l'écran).
 *
 *  - file d'attente + ordre de lecture (aléatoire = simple permutation de l'ordre)
 *  - source d'une piste : fichier du téléphone (u) > fichier téléchargé > flux YouTube direct
 *  - répétition : "off" | "one" (le titre, rcount fois, 0 = indéfiniment) | "all" (la file, rcount fois, 0 = indéfiniment)
 *  - tout ce qui modifie l'état passe par le thread principal
 */
object Engine {

    class T(val y: String, val u: String, val n: String, val a: String, val d: Long) {
        fun json(): JSONObject = JSONObject().put("y", y).put("u", u).put("n", n).put("a", a).put("d", d)
        companion object {
            fun from(o: JSONObject) = T(o.optString("y"), o.optString("u"), o.optString("n", "Sans titre"), o.optString("a"), o.optLong("d"))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()
    /** Appelés sur le thread principal à chaque changement d'état (interface, notification, session média). */
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    lateinit var ctx: Context
    lateinit var lib: Library
    private lateinit var prefs: SharedPreferences

    private val queue = ArrayList<T>()
    private var order = ArrayList<Int>()
    private var pos = -1

    private var mp: MediaPlayer? = null
    private var ready = false
    private var loading = false
    private var wantPlay = false
    private var gen = 0
    private var fails = 0
    private var canRetry = true
    private var startPosMs = 0
    private var trackPlays = 0
    private var queueLoops = 0
    private var repeat = "off"
    private var rcount = 0
    private var shuffle = false
    private var qv = 0
    private var err = ""
    private var errN = 0
    private val urlCache = ConcurrentHashMap<String, Pair<String, Long>>()
    private var wifi: WifiManager.WifiLock? = null

    // ------------------------------------------------------------------ init
    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        lib = Library(ctx)
        prefs = ctx.getSharedPreferences("engine", Context.MODE_PRIVATE)
        try {
            ctx.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) { main.post { if (wantPlay) pauseNow() } }   // casque débranché
            }, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        } catch (_: Exception) {}
        restore()
    }

    fun cur(): T? = if (pos in order.indices) queue[order[pos]] else null
    fun isPlaying() = wantPlay
    private fun fire() { for (l in listeners) try { l() } catch (_: Exception) {} }

    // ------------------------------------------------------------------ lecture d'une file
    fun playList(tracks: List<T>, start: Int) { main.post {
        if (tracks.isEmpty()) return@post
        queue.clear(); queue.addAll(tracks)
        shuffleKeeping(start.coerceIn(0, tracks.size - 1))
        trackPlays = 0; queueLoops = 0; fails = 0; startPosMs = 0; canRetry = true; qv++
        startCurrent(true); persist()
    } }

    /** Reconstruit l'ordre : identité, ou (aléatoire) piste [first] d'abord puis le reste mélangé. */
    private fun shuffleKeeping(first: Int) {
        val idx = queue.indices.toMutableList()
        if (shuffle && queue.size > 1) { idx.remove(first); idx.shuffle(); idx.add(0, first); pos = 0 } else pos = first
        order = ArrayList(idx)
    }

    private fun reshuffleAll() {
        val idx = queue.indices.toMutableList(); idx.shuffle()
        order = ArrayList(idx); pos = 0
    }

    private fun jump(p: Int) {
        pos = p; trackPlays = 0; startPosMs = 0; canRetry = true; fails = 0
        startCurrent(true); persist()
    }

    // ------------------------------------------------------------------ source + préparation
    private fun urlFor(y: String): String {
        val c = urlCache[y]
        if (c != null && System.currentTimeMillis() - c.second < 25 * 60_000L) return c.first
        val u = Yt.streamUrl(y)
        urlCache[y] = Pair(u, System.currentTimeMillis())
        return u
    }

    private fun startCurrent(autoplay: Boolean) {
        val t = cur() ?: return
        wantPlay = autoplay
        gen++
        val g = gen
        releaseMp()
        ready = false; loading = true; err = ""
        fire()
        if (autoplay) PlayService.ensure(ctx)
        io.execute {
            try {
                val streamed: Boolean
                val file: File?
                val uri: String?
                when {
                    t.u.isNotEmpty() -> { file = null; uri = t.u; streamed = false }
                    lib.isOffline(t.y) -> { file = lib.dl(t.y); uri = null; streamed = false }
                    else -> { file = null; uri = urlFor(t.y); streamed = true }
                }
                main.post { if (g == gen) prepare(file, uri, streamed, t, g) }
            } catch (e: Throwable) {
                val msg = Yt.explain(e)
                main.post { if (g == gen) failed(msg, true, t.y) }
            }
        }
    }

    private fun prepare(file: File?, uri: String?, streamed: Boolean, t: T, g: Int) {
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            when {
                file != null -> p.setDataSource(file.absolutePath)
                uri != null && uri.startsWith("http") -> p.setDataSource(ctx, Uri.parse(uri), mapOf("User-Agent" to Yt.UA))
                uri != null -> p.setDataSource(ctx, Uri.parse(uri))
            }
            p.setOnPreparedListener { m ->
                if (g == gen && mp === m) {
                    ready = true; loading = false; fails = 0; canRetry = true
                    if (startPosMs > 0) { try { m.seekTo(startPosMs) } catch (_: Exception) {}; startPosMs = 0 }
                    if (wantPlay) begin(m) else fire()
                }
            }
            p.setOnCompletionListener { m -> if (g == gen && mp === m) main.post { trackDone() } }
            p.setOnErrorListener { m, _, _ ->
                if (g == gen && mp === m) main.post { if (g == gen) { startPosMs = position(); failed("Lecture interrompue.", streamed, t.y) } }
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            failed("Impossible de lire ce titre.", streamed, t.y)
        }
    }

    private fun begin(m: MediaPlayer) {
        requestFocus()
        try { m.setVolume(1f, 1f); m.start() } catch (_: Exception) {}
        wifiLock(true)
        prefetchNext()
        fire()
    }

    /** Résout à l'avance l'URL du titre suivant : pas de blanc entre deux titres en streaming. */
    private fun prefetchNext() {
        val q = order.getOrNull(pos + 1) ?: return
        val t = queue.getOrNull(q) ?: return
        if (t.y.isNotEmpty() && t.u.isEmpty() && !lib.isOffline(t.y)) io.execute { try { urlFor(t.y) } catch (_: Throwable) {} }
    }

    private fun failed(msg: String, streamed: Boolean, y: String) {
        if (streamed && canRetry) {   // l'adresse du flux a peut-être expiré : une seule nouvelle tentative
            canRetry = false
            urlCache.remove(y)
            startCurrent(wantPlay)
            return
        }
        err = msg; errN++
        loading = false; ready = false; releaseMp()
        fails++
        if (queue.size <= 1 || fails >= queue.size) { wantPlay = false; fails = 0; wifiLock(false); fire(); return }
        canRetry = true
        advance()
    }

    // ------------------------------------------------------------------ enchaînement + répétitions
    private fun trackDone() {
        trackPlays++
        if (repeat == "one" && (rcount == 0 || trackPlays < rcount)) {
            try { mp?.seekTo(0); mp?.start() } catch (_: Exception) {}
            prefetchNext(); fire(); return
        }
        trackPlays = 0
        advance()
    }

    private fun advance() {
        startPosMs = 0
        if (pos + 1 < order.size) { pos++; trackPlays = 0; canRetry = true; startCurrent(true); persist(); return }
        queueLoops++
        if (repeat == "all" && (rcount == 0 || queueLoops < rcount)) {
            if (shuffle) reshuffleAll() else pos = 0
            trackPlays = 0; canRetry = true; startCurrent(true); persist(); return
        }
        // fin de la file : on s'arrête sur le premier titre, prêt à être relancé
        queueLoops = 0; trackPlays = 0
        gen++; releaseMp(); ready = false; loading = false; wantPlay = false
        pos = if (order.isEmpty()) -1 else 0
        wifiLock(false); fire(); persist()
    }

    // ------------------------------------------------------------------ commandes
    fun toggle() { main.post { toggleNow() } }
    fun play() { main.post { if (!wantPlay) toggleNow() } }
    fun pause() { main.post { if (wantPlay) toggleNow() } }

    private fun toggleNow() {
        val m = mp
        when {
            m != null && ready -> if (wantPlay) pauseNow() else { wantPlay = true; begin(m) }
            loading -> { wantPlay = !wantPlay; fire() }
            cur() != null -> { canRetry = true; fails = 0; startCurrent(true) }
        }
    }

    private fun pauseNow() {
        try { mp?.pause() } catch (_: Exception) {}
        wantPlay = false; wifiLock(false); persist(); fire()
    }

    fun next() { main.post {
        if (order.isEmpty()) return@post
        if (pos + 1 < order.size) jump(pos + 1)
        else if (repeat == "all") { if (shuffle) reshuffleAll() else pos = 0; jump(pos) }
    } }

    fun prev() { main.post {
        if (order.isEmpty()) return@post
        if (position() > 3000 || pos <= 0) { try { mp?.seekTo(0) } catch (_: Exception) {}; fire() } else jump(pos - 1)
    } }

    fun seek(ms: Int) { main.post { if (ready) { try { mp?.seekTo(ms) } catch (_: Exception) {} }; fire() } }

    fun setRepeat(mode: String, count: Int) { main.post {
        repeat = if (mode == "one" || mode == "all") mode else "off"
        rcount = count.coerceAtLeast(0)
        trackPlays = 0; queueLoops = 0
        persist(); fire()
    } }

    fun setShuffle(on: Boolean) { main.post {
        if (on == shuffle) return@post
        shuffle = on
        if (order.isNotEmpty()) { shuffleKeeping(order[pos.coerceIn(0, order.size - 1)]); qv++ }
        persist(); fire()
    } }

    /** « Lire ensuite » (next = true) ou « Ajouter à la file ». */
    fun enqueue(t: T, next: Boolean) { main.post {
        if (queue.isEmpty()) { playList(listOf(t), 0); return@post }
        queue.add(t)
        val idx = queue.size - 1
        if (next) order.add((pos + 1).coerceAtMost(order.size), idx) else order.add(idx)
        qv++; persist(); fire()
    } }

    fun jumpTo(orderPos: Int) { main.post { if (orderPos in order.indices) jump(orderPos) } }

    fun removeAt(op: Int) { main.post {
        if (op !in order.indices) return@post
        val q = order[op]
        queue.removeAt(q)
        order.removeAt(op)
        order = ArrayList(order.map { if (it > q) it - 1 else it })
        qv++
        if (queue.isEmpty()) { stopNow(); return@post }
        if (op < pos) pos-- else if (op == pos) { if (pos >= order.size) pos = 0; startPosMs = 0; startCurrent(wantPlay) }
        persist(); fire()
    } }

    fun clear() { main.post { stopNow() } }

    private fun stopNow() {
        gen++; releaseMp()
        queue.clear(); order.clear(); pos = -1
        ready = false; loading = false; wantPlay = false; startPosMs = 0; qv++
        wifiLock(false); persist(); fire()
    }

    // ------------------------------------------------------------------ MediaPlayer, focus audio, wifi
    private fun releaseMp() {
        val p = mp
        mp = null; ready = false
        if (p != null) {
            try { p.setOnPreparedListener(null); p.setOnCompletionListener(null); p.setOnErrorListener(null) } catch (_: Exception) {}
            try { p.release() } catch (_: Exception) {}
        }
    }

    private var focusReq: AudioFocusRequest? = null
    private var lostByFocus = false

    private fun requestFocus() {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (focusReq == null) {
                focusReq = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener { c -> main.post { onFocus(c) } }
                    .build()
            }
            am.requestAudioFocus(focusReq!!)
        } catch (_: Exception) {}
    }

    private fun onFocus(c: Int) {
        when (c) {
            AudioManager.AUDIOFOCUS_LOSS -> { lostByFocus = false; if (wantPlay) pauseNow() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> if (wantPlay) { lostByFocus = true; pauseNow() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> try { mp?.setVolume(0.25f, 0.25f) } catch (_: Exception) {}
            AudioManager.AUDIOFOCUS_GAIN -> {
                try { mp?.setVolume(1f, 1f) } catch (_: Exception) {}
                if (lostByFocus) { lostByFocus = false; val m = mp; if (m != null && ready) { wantPlay = true; begin(m) } }
            }
        }
    }

    private fun wifiLock(on: Boolean) {
        try {
            if (on) {
                if (wifi == null) {
                    wifi = (ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                        .createWifiLock(WifiManager.WIFI_MODE_FULL, "musique:stream").apply { setReferenceCounted(false) }
                }
                if (wifi?.isHeld == false) wifi?.acquire()
            } else if (wifi?.isHeld == true) wifi?.release()
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ état pour l'interface
    fun position(): Int = try { if (ready) (mp?.currentPosition ?: startPosMs) else startPosMs } catch (_: Exception) { 0 }
    private fun duration(): Int = try { if (ready) (mp?.duration ?: 0) else ((cur()?.d ?: 0L) * 1000L).toInt() } catch (_: Exception) { 0 }

    fun stateJson(): JSONObject {
        val t = cur()
        val o = JSONObject().put("has", t != null).put("playing", wantPlay).put("loading", loading)
            .put("pos", position()).put("dur", duration())
            .put("repeat", repeat).put("rc", rcount).put("shuffle", shuffle)
            .put("qv", qv).put("qi", pos).put("qn", order.size).put("err", err).put("errN", errN)
        if (t != null) o.put("t", t.json().put("off", t.y.isNotEmpty() && lib.isOffline(t.y)))
        return o
    }

    /** File dans l'ordre de lecture : [{t:{…}}] ; l'indice courant = qi de l'état. */
    fun queueJson(): JSONArray {
        val a = JSONArray()
        for (q in order) a.put(queue[q].json())
        return a
    }

    // ------------------------------------------------------------------ persistance (on retrouve sa file après fermeture)
    private fun persist() {
        try {
            val q = JSONArray(); for (t in queue) q.put(t.json())
            prefs.edit().putString("q", q.toString()).putString("o", JSONArray(order).toString()).putInt("pos", pos)
                .putInt("ppos", position()).putString("rep", repeat).putInt("rc", rcount).putBoolean("sh", shuffle).apply()
        } catch (_: Exception) {}
    }

    private fun restore() {
        try {
            repeat = prefs.getString("rep", "off") ?: "off"
            rcount = prefs.getInt("rc", 0)
            shuffle = prefs.getBoolean("sh", false)
            val q = JSONArray(prefs.getString("q", "[]"))
            for (i in 0 until q.length()) queue.add(T.from(q.getJSONObject(i)))
            val o = JSONArray(prefs.getString("o", "[]"))
            for (i in 0 until o.length()) order.add(o.getInt(i))
            pos = prefs.getInt("pos", -1)
            startPosMs = prefs.getInt("ppos", 0)
            if (order.size != queue.size || pos !in order.indices) { queue.clear(); order.clear(); pos = -1; startPosMs = 0 }
        } catch (_: Exception) { queue.clear(); order.clear(); pos = -1; startPosMs = 0 }
    }
}
