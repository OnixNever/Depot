package com.musique.lecteur

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

/**
 * Lecteur unique de l'appli (vit tant que le processus vit, indépendamment de l'écran).
 *
 *  - ExoPlayer fait tout le travail audio : tampon de ~2 min, reprise automatique, focus audio (appels, autres
 *    applis), casque débranché, verrous réseau + veille pendant la lecture.
 *  - source d'une piste : fichier du téléphone > fichier téléchargé > flux YouTube lu par tranches (ChunkedSource).
 *  - file d'attente + ordre de lecture (aléatoire = simple permutation de l'ordre).
 *  - répétition : "off" | "one" (le titre) | "all" (la file), rcount fois (0 = indéfiniment).
 *  - ExoPlayer n'est utilisable que sur le thread principal : tout passe par main.
 */
@androidx.annotation.OptIn(UnstableApi::class)
object Engine {

    class T(val y: String, val u: String, val n: String, val a: String, val d: Long) {
        fun json(): JSONObject = JSONObject().put("y", y).put("u", u).put("n", n).put("a", a).put("d", d)
        companion object {
            fun from(o: JSONObject) = T(o.optString("y"), o.optString("u"), o.optString("n", "Sans titre"), o.optString("a"), o.optLong("d"))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()
    /** Appelés sur le thread principal à chaque changement d'état (interface, notification, session média). */
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    lateinit var ctx: Context
    lateinit var lib: Library
    private lateinit var prefs: SharedPreferences
    private lateinit var player: ExoPlayer

    private val queue = ArrayList<T>()
    private var order = ArrayList<Int>()
    private var pos = -1

    private var ready = false
    private var loading = false
    private var wantPlay = false
    private var fails = 0
    private var canRetry = true
    private var startPosMs = 0
    private var trackPlays = 0
    private var queueLoops = 0
    private var repeat = "off"
    private var rcount = 0
    private var shuffle = false
    private var qv = 0
    private var err = ""
    private var errN = 0
    private var curY = ""
    private var curStreamed = false
    private val urlCache = ConcurrentHashMap<String, Pair<String, Long>>()

    // ------------------------------------------------------------------ init
    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        lib = Library(ctx)
        prefs = ctx.getSharedPreferences("engine", Context.MODE_PRIVATE)

        val attrs = AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
        val load = DefaultLoadControl.Builder().setBufferDurationsMs(30_000, 150_000, 2_000, 5_000).build()
        player = ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory()))
            .setLoadControl(load)
            .setAudioAttributes(attrs, true)          // focus audio géré (appels, autres applis)
            .setHandleAudioBecomingNoisy(true)        // pause si le casque est débranché
            .setWakeMode(C.WAKE_MODE_NETWORK)         // CPU + wifi gardés éveillés pendant la lecture, écran éteint
            .build()
        player.addListener(listener)
        restore()
    }

    /** « yt:ID » est résolu en URL de flux au moment de l'ouverture, puis lu par tranches. */
    private fun dataSourceFactory(): DataSource.Factory {
        val resolving = ResolvingDataSource.Factory(
            DataSource.Factory { ChunkedSource() },
            ResolvingDataSource.Resolver { spec ->
                if (spec.uri.scheme == "yt") {
                    val id = spec.uri.schemeSpecificPart
                    val u = try { urlFor(id) } catch (e: Throwable) { throw IOException(Yt.explain(e)) }
                    spec.withUri(Uri.parse(u))
                } else spec
            }
        )
        return DefaultDataSource.Factory(ctx, resolving)
    }

    private fun urlFor(y: String): String {
        val c = urlCache[y]
        if (c != null && System.currentTimeMillis() - c.second < 25 * 60_000L) return c.first
        val u = Yt.streamUrl(y)
        urlCache[y] = Pair(u, System.currentTimeMillis())
        return u
    }

    fun cur(): T? = if (pos in order.indices) queue[order[pos]] else null
    fun isPlaying() = wantPlay
    private fun fire() { for (l in listeners) try { l() } catch (_: Exception) {} }

    // ------------------------------------------------------------------ événements ExoPlayer
    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> { loading = true; fire() }
                Player.STATE_READY -> {
                    val first = !ready
                    ready = true; loading = false; fails = 0; canRetry = true
                    if (first) {
                        if (startPosMs > 0) { player.seekTo(startPosMs.toLong()); startPosMs = 0 }
                        prefetchNext()
                    }
                    fire()
                }
                Player.STATE_ENDED -> main.post { trackDone() }
                else -> {}
            }
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            wantPlay = playWhenReady
            if (!playWhenReady) persist()
            fire()
        }

        override fun onPlayerError(error: PlaybackException) {
            var msg = "Ce titre n'a pas pu être lu."
            var c: Throwable? = error
            while (c != null) { if (c is IOException && !c.message.isNullOrBlank()) { msg = c.message!!; break }; c = c.cause }
            startPosMs = try { player.currentPosition.toInt() } catch (_: Exception) { 0 }   // on reprend là où ça a cassé
            failed(msg)
        }
    }

    // ------------------------------------------------------------------ lecture d'une file
    fun playList(tracks: List<T>, start: Int) { main.post {
        if (tracks.isEmpty()) return@post
        queue.clear(); queue.addAll(tracks)
        shuffleKeeping(start.coerceIn(0, tracks.size - 1))
        trackPlays = 0; queueLoops = 0; fails = 0; startPosMs = 0; canRetry = true; qv++
        startCurrent(true); persist()
    } }

    /** Reconstruit l'ordre : identité, ou (aléatoire) piste [first] d'abord puis le reste mélangé. */
    private fun shuffleKeeping(first: Int) {
        val idx = queue.indices.toMutableList()
        if (shuffle && queue.size > 1) { idx.remove(first); idx.shuffle(); idx.add(0, first); pos = 0 } else pos = first
        order = ArrayList(idx)
    }

    private fun reshuffleAll() {
        val idx = queue.indices.toMutableList(); idx.shuffle()
        order = ArrayList(idx); pos = 0
    }

    private fun jump(p: Int) {
        pos = p; trackPlays = 0; startPosMs = 0; canRetry = true; fails = 0
        startCurrent(true); persist()
    }

    private fun startCurrent(autoplay: Boolean) {
        val t = cur() ?: return
        ready = false; loading = true; err = ""
        curY = t.y
        val uri: Uri = when {
            t.u.isNotEmpty() -> { curStreamed = false; Uri.parse(t.u) }
            lib.isOffline(t.y) -> { curStreamed = false; Uri.fromFile(lib.dl(t.y)) }
            else -> { curStreamed = true; Uri.parse("yt:" + t.y) }
        }
        player.setMediaItem(MediaItem.fromUri(uri))
        player.repeatMode = if (repeat == "one" && rcount == 0) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.prepare()
        player.playWhenReady = autoplay
        wantPlay = autoplay
        fire()
        if (autoplay) PlayService.ensure(ctx)
    }

    /** Résout à l'avance l'URL du titre suivant : pas de blanc entre deux titres en streaming. */
    private fun prefetchNext() {
        val q = order.getOrNull(pos + 1) ?: return
        val t = queue.getOrNull(q) ?: return
        if (t.y.isNotEmpty() && t.u.isEmpty() && !lib.isOffline(t.y)) io.execute { try { urlFor(t.y) } catch (_: Throwable) {} }
    }

    private fun failed(msg: String) {
        if (curStreamed && canRetry) {        // l'adresse du flux a peut-être expiré : une seule nouvelle tentative
            canRetry = false
            urlCache.remove(curY)
            startCurrent(wantPlay)
            return
        }
        err = msg; errN++
        loading = false; ready = false
        try { player.stop() } catch (_: Exception) {}
        fails++
        if (queue.size <= 1 || fails >= queue.size) { wantPlay = false; fails = 0; fire(); return }
        canRetry = true
        advance()
    }

    // ------------------------------------------------------------------ enchaînement + répétitions
    private fun trackDone() {
        if (!ready && !loading) return
        trackPlays++
        if (repeat == "one" && rcount > 0 && trackPlays < rcount) {
            player.seekTo(0); player.play(); prefetchNext(); fire(); return
        }
        trackPlays = 0
        advance()
    }

    private fun advance() {
        startPosMs = 0
        if (pos + 1 < order.size) { pos++; trackPlays = 0; canRetry = true; startCurrent(true); persist(); return }
        queueLoops++
        if (repeat == "all" && (rcount == 0 || queueLoops < rcount)) {
            if (shuffle) reshuffleAll() else pos = 0
            trackPlays = 0; canRetry = true; startCurrent(true); persist(); return
        }
        // fin de la file : on s'arrête sur le premier titre, prêt à être relancé
        queueLoops = 0; trackPlays = 0
        player.playWhenReady = false
        try { player.stop() } catch (_: Exception) {}
        ready = false; loading = false; wantPlay = false
        pos = if (order.isEmpty()) -1 else 0
        fire(); persist()
    }

    // ------------------------------------------------------------------ commandes
    fun toggle() { main.post { toggleNow() } }
    fun play() { main.post { if (!wantPlay) toggleNow() } }
    fun pause() { main.post { if (wantPlay) toggleNow() } }

    private fun toggleNow() {
        val st = player.playbackState
        when {
            cur() == null -> {}
            st == Player.STATE_IDLE || st == Player.STATE_ENDED -> { canRetry = true; fails = 0; startCurrent(true) }
            else -> player.playWhenReady = !player.playWhenReady
        }
    }

    fun next() { main.post {
        if (order.isEmpty()) return@post
        if (pos + 1 < order.size) jump(pos + 1)
        else if (repeat == "all") { if (shuffle) reshuffleAll() else pos = 0; jump(pos) }
    } }

    fun prev() { main.post {
        if (order.isEmpty()) return@post
        if (position() > 3000 || pos <= 0) { if (ready) player.seekTo(0); fire() } else jump(pos - 1)
    } }

    fun seek(ms: Int) { main.post {
        if (ready) player.seekTo(ms.toLong()) else startPosMs = ms
        fire()
    } }

    fun setRepeat(mode: String, count: Int) { main.post {
        repeat = if (mode == "one" || mode == "all") mode else "off"
        rcount = count.coerceAtLeast(0)
        trackPlays = 0; queueLoops = 0
        player.repeatMode = if (repeat == "one" && rcount == 0) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        persist(); fire()
    } }

    fun setShuffle(on: Boolean) { main.post {
        if (on == shuffle) return@post
        shuffle = on
        if (order.isNotEmpty()) { shuffleKeeping(order[pos.coerceIn(0, order.size - 1)]); qv++ }
        persist(); fire()
    } }

    /** « Lire ensuite » (next = true) ou « Ajouter à la file ». */
    fun enqueue(t: T, next: Boolean) { main.post {
        if (queue.isEmpty()) { playList(listOf(t), 0); return@post }
        queue.add(t)
        val idx = queue.size - 1
        if (next) order.add((pos + 1).coerceAtMost(order.size), idx) else order.add(idx)
        qv++; persist(); fire()
    } }

    fun jumpTo(orderPos: Int) { main.post { if (orderPos in order.indices) jump(orderPos) } }

    fun removeAt(op: Int) { main.post {
        if (op !in order.indices) return@post
        val q = order[op]
        queue.removeAt(q)
        order.removeAt(op)
        order = ArrayList(order.map { if (it > q) it - 1 else it })
        qv++
        if (queue.isEmpty()) { stopNow(); return@post }
        if (op < pos) pos-- else if (op == pos) { if (pos >= order.size) pos = 0; startPosMs = 0; startCurrent(wantPlay) }
        persist(); fire()
    } }

    /** Arrêt complet : la lecture s'arrête, la file est vidée, le service et la notification disparaissent. */
    fun clear() { main.post { stopNow() } }

    private fun stopNow() {
        player.playWhenReady = false
        try { player.stop(); player.clearMediaItems() } catch (_: Exception) {}
        queue.clear(); order.clear(); pos = -1
        ready = false; loading = false; wantPlay = false; startPosMs = 0; qv++
        persist(); fire()
    }

    // ------------------------------------------------------------------ état pour l'interface
    /** Exécute sur le thread principal (ExoPlayer l'exige) et attend le résultat : appelable depuis le pont JS. */
    private fun <R> onMain(block: () -> R): R? {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val f = FutureTask { block() }
        main.post(f)
        return try { f.get(1500, TimeUnit.MILLISECONDS) } catch (_: Exception) { null }
    }

    fun position(): Int = try {
        if (ready || player.playbackState == Player.STATE_BUFFERING) player.currentPosition.toInt().coerceAtLeast(0) else startPosMs
    } catch (_: Exception) { 0 }

    private fun duration(): Int = try {
        val d = player.duration
        if (ready && d != C.TIME_UNSET && d > 0) d.toInt() else ((cur()?.d ?: 0L) * 1000L).toInt()
    } catch (_: Exception) { 0 }

    fun stateJson(): JSONObject = onMain {
        val t = cur()
        val o = JSONObject().put("has", t != null).put("playing", wantPlay).put("loading", loading)
            .put("pos", position()).put("dur", duration())
            .put("repeat", repeat).put("rc", rcount).put("shuffle", shuffle)
            .put("qv", qv).put("qi", pos).put("qn", order.size).put("err", err).put("errN", errN)
        if (t != null) o.put("t", t.json().put("off", t.y.isNotEmpty() && lib.isOffline(t.y)))
        o
    } ?: JSONObject().put("has", false)

    /** File dans l'ordre de lecture ; l'indice courant = qi de l'état. */
    fun queueJson(): JSONArray = onMain {
        val a = JSONArray()
        for (q in order) a.put(queue[q].json())
        a
    } ?: JSONArray()

    // ------------------------------------------------------------------ persistance (on retrouve sa file après fermeture)
    private fun persist() {
        try {
            val q = JSONArray(); for (t in queue) q.put(t.json())
            prefs.edit().putString("q", q.toString()).putString("o", JSONArray(order).toString()).putInt("pos", pos)
                .putInt("ppos", position()).putString("rep", repeat).putInt("rc", rcount).putBoolean("sh", shuffle).apply()
        } catch (_: Exception) {}
    }

    private fun restore() {
        try {
            repeat = prefs.getString("rep", "off") ?: "off"
            rcount = prefs.getInt("rc", 0)
            shuffle = prefs.getBoolean("sh", false)
            val q = JSONArray(prefs.getString("q", "[]"))
            for (i in 0 until q.length()) queue.add(T.from(q.getJSONObject(i)))
            val o = JSONArray(prefs.getString("o", "[]"))
            for (i in 0 until o.length()) order.add(o.getInt(i))
            pos = prefs.getInt("pos", -1)
            startPosMs = prefs.getInt("ppos", 0)
            if (order.size != queue.size || pos !in order.indices) { queue.clear(); order.clear(); pos = -1; startPosMs = 0 }
        } catch (_: Exception) { queue.clear(); order.clear(); pos = -1; startPosMs = 0 }
    }
}
