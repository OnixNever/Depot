package com.musique.lecteur

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

/**
 * Lecteur unique de l'appli (vit tant que le processus vit, indépendamment de l'écran).
 *
 *  - ExoPlayer fait tout le travail audio : tampon de ~2 min, reprise automatique, focus audio (appels, autres
 *    applis), casque débranché, verrous réseau + veille pendant la lecture.
 *  - source d'une piste : fichier du téléphone > fichier téléchargé > flux YouTube lu par tranches (ChunkedSource).
 *  - file d'attente + ordre de lecture (aléatoire = simple permutation de l'ordre).
 *  - répétition : "off" | "one" (le titre) | "all" (la file), rcount fois (0 = indéfiniment).
 *  - ExoPlayer n'est utilisable que sur le thread principal : tout passe par main.
 */
@androidx.annotation.OptIn(UnstableApi::class)
object Engine {

    class T(val y: String, val u: String, val n: String, val a: String, val d: Long) {
        fun json(): JSONObject = JSONObject().put("y", y).put("u", u).put("n", n).put("a", a).put("d", d)
        companion object {
            fun from(o: JSONObject) = T(o.optString("y"), o.optString("u"), o.optString("n", "Sans titre"), o.optString("a"), o.optLong("d"))
        }
    }

    /** Titres « longs » (documentaires, émissions…) : seuls à avoir une mémoire de position et une vitesse réglable. */
    private const val LONG_MS = 600_000L
    private const val TICK_MS = 20_000L

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()
    /** Appelés sur le thread principal à chaque changement d'état (interface, notification, session média). */
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    lateinit var ctx: Context
    lateinit var lib: Library
    private lateinit var prefs: SharedPreferences
    private lateinit var player: ExoPlayer

    private val queue = ArrayList<T>()
    private var order = ArrayList<Int>()
    private var pos = -1

    private var ready = false
    private var loading = false
    private var wantPlay = false
    private var fails = 0
    private var canRetry = true
    private var startPosMs = 0
    private var trackPlays = 0
    private var queueLoops = 0
    private var repeat = "off"
    private var rcount = 0
    private var shuffle = false
    private var qv = 0
    private var err = ""
    private var errN = 0
    private var curY = ""
    private var curKey = ""            // clé du titre actuellement chargé dans le lecteur (y:… ou u:…)
    private var speed = 1f             // vitesse choisie, appliquée aux titres longs seulement
    private var resumeCache: JSONObject? = null
    private var curStreamed = false
    private val urlCache = ConcurrentHashMap<String, Pair<String, Long>>()

    // sortie audio : "" = automatique (le système choisit), sinon clé du périphérique choisi à la main
    class Out(val key: String, val name: String, val kind: String)
    @Volatile private var outKey = ""
    private lateinit var am: AudioManager
    private var knownOut = HashSet<String>()

    // ------------------------------------------------------------------ init
    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        lib = Library(ctx)
        prefs = ctx.getSharedPreferences("engine", Context.MODE_PRIVATE)
        speed = prefs.getFloat("speed", 1f).coerceIn(0.5f, 3f)

        val attrs = AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
        val load = DefaultLoadControl.Builder().setBufferDurationsMs(30_000, 150_000, 2_000, 5_000).build()
        player = ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory()))
            .setLoadControl(load)
            .setAudioAttributes(attrs, true)          // focus audio géré (appels, autres applis)
            .setHandleAudioBecomingNoisy(true)        // pause si le casque est débranché
            .setWakeMode(C.WAKE_MODE_NETWORK)         // CPU + wifi gardés éveillés pendant la lecture, écran éteint
            .build()
        player.addListener(listener)
        am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        knownOut = devices().map { devKey(it) }.toHashSet()
        try { am.registerAudioDeviceCallback(devCb, main) } catch (_: Exception) {}
        restore()
    }

    // ------------------------------------------------------------------ sortie audio (voiture, casque Bluetooth, haut-parleur…)
    private val devCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) = devicesChanged()
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) = devicesChanged()
    }

    /** Sorties de musique utilisables (le Bluetooth « téléphone / SCO » est exclu : il ne sert qu'aux appels). */
    private fun relevant(d: AudioDeviceInfo): Boolean = d.isSink && when (d.type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_HDMI, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY,
        AudioDeviceInfo.TYPE_DOCK, AudioDeviceInfo.TYPE_USB_HEADSET,
        23, 26, 27 -> true            // appareil auditif, Bluetooth LE casque / enceinte
        else -> false
    }

    private fun devKey(d: AudioDeviceInfo): String {
        val id = if (Build.VERSION.SDK_INT >= 28 && d.address.isNotBlank()) d.address else d.productName.toString()
        return d.type.toString() + ":" + id
    }

    private fun kindOf(d: AudioDeviceInfo): String = when (d.type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "phone"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, 26, 27 -> "bt"
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET -> "wired"
        else -> "other"
    }

    private fun nameOf(d: AudioDeviceInfo): String {
        if (d.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) return "Haut-parleur du téléphone"
        val n = d.productName?.toString()?.trim().orEmpty()
        if (n.isNotEmpty()) return n
        return when (kindOf(d)) { "wired" -> "Casque filaire"; "bt" -> "Appareil Bluetooth"; else -> "Périphérique audio" }
    }

    private fun devices(): List<AudioDeviceInfo> = try {
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { relevant(it) }.distinctBy { devKey(it) }
    } catch (_: Exception) { emptyList() }

    /** Automatique + toutes les sorties actuellement branchées / connectées. */
    fun outputsList(): List<Out> =
        listOf(Out("", "Automatique (système)", "auto")) + devices().map { Out(devKey(it), nameOf(it), kindOf(it)) }

    fun outKeyNow(): String = outKey

    /** Nom de la sortie choisie à la main ; vide en mode automatique. */
    fun outLabel(): String = if (outKey.isEmpty()) "" else outputsList().firstOrNull { it.key == outKey }?.name ?: ""

    fun outputsJson(): JSONArray {
        val a = JSONArray()
        for (o in outputsList()) a.put(JSONObject().put("k", o.key).put("n", o.name).put("t", o.kind).put("on", o.key == outKey))
        return a
    }

    /** Applique le choix à ExoPlayer (thread principal). Si la sortie choisie a disparu, retour en automatique. */
    private fun applyOutput() {
        var dev: AudioDeviceInfo? = null
        if (outKey.isNotEmpty()) {
            dev = devices().firstOrNull { devKey(it) == outKey }
            if (dev == null) outKey = ""
        }
        try { player.setPreferredAudioDevice(dev) } catch (_: Throwable) {}
    }

    /** Un appareil arrive ou part : si c'est un nouvel appareil, on repasse en automatique (ex. la voiture se connecte). */
    private fun devicesChanged() {
        val now = devices().map { devKey(it) }.toHashSet()
        val arrived = now.any { it !in knownOut }
        knownOut = now
        if (arrived && outKey.isNotEmpty()) outKey = ""
        applyOutput(); fire()
    }

    fun setOutput(key: String) { main.post { outKey = key; applyOutput(); fire() } }

    /** Passe à la sortie suivante de la liste (automatique → 1re sortie → … → automatique) et renvoie son nom. */
    fun cycleOutput(): String = onMain {
        val l = outputsList()
        val i = l.indexOfFirst { it.key == outKey }.coerceAtLeast(0)
        val n = l[(i + 1) % l.size]
        outKey = n.key; applyOutput(); fire()
        n.name
    } ?: ""

    /** « yt:ID » est résolu en URL de flux au moment de l'ouverture, puis lu par tranches. */
    private fun dataSourceFactory(): DataSource.Factory {
        val resolving = ResolvingDataSource.Factory(
            DataSource.Factory { ChunkedSource() },
            ResolvingDataSource.Resolver { spec ->
                if (spec.uri.scheme == "yt") {
                    val id = spec.uri.schemeSpecificPart
                    val u = try { urlFor(id) } catch (e: Throwable) { throw IOException(Yt.explain(e)) }
                    spec.withUri(Uri.parse(u))
                } else spec
            }
        )
        return DefaultDataSource.Factory(ctx, resolving)
    }

    private fun urlFor(y: String): String {
        val c = urlCache[y]
        if (c != null && System.currentTimeMillis() - c.second < 25 * 60_000L) return c.first
        val u = Yt.streamUrl(y)
        urlCache[y] = Pair(u, System.currentTimeMillis())
        return u
    }

    fun cur(): T? = if (pos in order.indices) queue[order[pos]] else null

    /** Titre en cours, lisible depuis n'importe quel thread (commandes vocales). */
    fun current(): T? = onMain { cur() }

    /** Position de lecture en ms, lisible depuis n'importe quel thread. */
    fun posNow(): Int = onMain { position() } ?: 0

    /** Baisse le volume du lecteur pendant que le micro écoute (sinon la musique couvre la voix). */
    fun duck(on: Boolean) { main.post { try { player.volume = if (on) 0.2f else 1f } catch (_: Exception) {} } }
    fun isPlaying() = wantPlay
    private fun fire() { for (l in listeners) try { l() } catch (_: Exception) {} }

    // ------------------------------------------------------------------ événements ExoPlayer
    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> { loading = true; fire() }
                Player.STATE_READY -> {
                    val first = !ready
                    ready = true; loading = false; fails = 0; canRetry = true
                    if (first) {
                        if (startPosMs > 0) { player.seekTo(startPosMs.toLong()); startPosMs = 0 }
                        applySpeed()
                        scheduleTick()
                        prefetchNext()
                    }
                    fire()
                }
                Player.STATE_ENDED -> main.post { trackDone() }
                else -> {}
            }
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            wantPlay = playWhenReady
            if (playWhenReady) scheduleTick()
            else { main.removeCallbacks(ticker); saveResume(); persist() }
            fire()
        }

        override fun onPlayerError(error: PlaybackException) {
            var msg = "Ce titre n'a pas pu être lu."
            var c: Throwable? = error
            while (c != null) { if (c is IOException && !c.message.isNullOrBlank()) { msg = c.message!!; break }; c = c.cause }
            startPosMs = try { player.currentPosition.toInt() } catch (_: Exception) { 0 }   // on reprend là où ça a cassé
            failed(msg)
        }
    }

    // ------------------------------------------------------------------ lecture d'une file
    fun playList(tracks: List<T>, start: Int) { main.post {
        if (tracks.isEmpty()) return@post
        queue.clear(); queue.addAll(tracks)
        shuffleKeeping(start.coerceIn(0, tracks.size - 1))
        trackPlays = 0; queueLoops = 0; fails = 0; startPosMs = 0; canRetry = true; qv++
        startCurrent(true); persist()
    } }

    /** Reconstruit l'ordre : identité, ou (aléatoire) piste [first] d'abord puis le reste mélangé. */
    private fun shuffleKeeping(first: Int) {
        val idx = queue.indices.toMutableList()
        if (shuffle && queue.size > 1) { idx.remove(first); idx.shuffle(); idx.add(0, first); pos = 0 } else pos = first
        order = ArrayList(idx)
    }

    private fun reshuffleAll() {
        val idx = queue.indices.toMutableList(); idx.shuffle()
        order = ArrayList(idx); pos = 0
    }

    private fun jump(p: Int) {
        pos = p; trackPlays = 0; startPosMs = 0; canRetry = true; fails = 0
        startCurrent(true); persist()
    }

    private fun startCurrent(autoplay: Boolean) {
        val t = cur() ?: return
        saveResume()                                  // position du titre qu'on quitte (si c'est un titre long)
        ready = false; loading = true; err = ""
        curY = t.y
        curKey = keyOf(t)
        if (startPosMs == 0) startPosMs = resumeFor(t) // reprise là où on s'était arrêté
        val uri: Uri = when {
            t.u.isNotEmpty() -> { curStreamed = false; Uri.parse(t.u) }
            lib.isOffline(t.y) -> { curStreamed = false; Uri.fromFile(lib.dl(t.y)) }
            else -> { curStreamed = true; Uri.parse("yt:" + t.y) }
        }
        player.setMediaItem(MediaItem.fromUri(uri))
        player.repeatMode = if (repeat == "one" && rcount == 0) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.prepare()
        player.playWhenReady = autoplay
        wantPlay = autoplay
        applySpeed()
        scheduleTick()
        fire()
        if (autoplay) PlayService.ensure(ctx)
    }

    /** Résout à l'avance l'URL du titre suivant : pas de blanc entre deux titres en streaming. */
    private fun prefetchNext() {
        val q = order.getOrNull(pos + 1) ?: return
        val t = queue.getOrNull(q) ?: return
        if (t.y.isNotEmpty() && t.u.isEmpty() && !lib.isOffline(t.y)) io.execute { try { urlFor(t.y) } catch (_: Throwable) {} }
    }

    private fun failed(msg: String) {
        if (curStreamed && canRetry) {        // l'adresse du flux a peut-être expiré : une seule nouvelle tentative
            canRetry = false
            urlCache.remove(curY)
            startCurrent(wantPlay)
            return
        }
        err = msg; errN++
        loading = false; ready = false
        try { player.stop() } catch (_: Exception) {}
        fails++
        if (queue.size <= 1 || fails >= queue.size) { wantPlay = false; fails = 0; fire(); return }
        canRetry = true
        advance()
    }

    // ------------------------------------------------------------------ enchaînement + répétitions
    private fun trackDone() {
        if (!ready && !loading) return
        trackPlays++
        if (repeat == "one" && rcount > 0 && trackPlays < rcount) {
            player.seekTo(0); player.play(); prefetchNext(); fire(); return
        }
        trackPlays = 0
        advance()
    }

    private fun advance() {
        saveResume()      // fin naturelle d'un titre long : sa mémoire est effacée
        startPosMs = 0
        if (pos + 1 < order.size) { pos++; trackPlays = 0; canRetry = true; startCurrent(true); persist(); return }
        queueLoops++
        if (repeat == "all" && (rcount == 0 || queueLoops < rcount)) {
            if (shuffle) reshuffleAll() else pos = 0
            trackPlays = 0; canRetry = true; startCurrent(true); persist(); return
        }
        // fin de la file : on s'arrête sur le premier titre, prêt à être relancé
        queueLoops = 0; trackPlays = 0
        player.playWhenReady = false
        try { player.stop() } catch (_: Exception) {}
        ready = false; loading = false; wantPlay = false
        pos = if (order.isEmpty()) -1 else 0
        fire(); persist()
    }

    // ------------------------------------------------------------------ commandes
    fun toggle() { main.post { toggleNow() } }
    fun play() { main.post { if (!wantPlay) toggleNow() } }
    fun pause() { main.post { if (wantPlay) toggleNow() } }

    private fun toggleNow() {
        val st = player.playbackState
        when {
            cur() == null -> {}
            st == Player.STATE_IDLE || st == Player.STATE_ENDED -> { canRetry = true; fails = 0; startCurrent(true) }
            else -> player.playWhenReady = !player.playWhenReady
        }
    }

    fun next() { main.post {
        if (order.isEmpty()) return@post
        if (pos + 1 < order.size) jump(pos + 1)
        else if (repeat == "all") { if (shuffle) reshuffleAll() else pos = 0; jump(pos) }
    } }

    fun prev() { main.post {
        if (order.isEmpty()) return@post
        if (position() > 3000 || pos <= 0) { if (ready) player.seekTo(0); fire() } else jump(pos - 1)
    } }

    fun seek(ms: Int) { main.post {
        if (ready) player.seekTo(ms.toLong()) else startPosMs = ms
        fire()
    } }

    fun setRepeat(mode: String, count: Int) { main.post {
        repeat = if (mode == "one" || mode == "all") mode else "off"
        rcount = count.coerceAtLeast(0)
        trackPlays = 0; queueLoops = 0
        player.repeatMode = if (repeat == "one" && rcount == 0) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        persist(); fire()
    } }

    fun setShuffle(on: Boolean) { main.post {
        if (on == shuffle) return@post
        shuffle = on
        if (order.isNotEmpty()) { shuffleKeeping(order[pos.coerceIn(0, order.size - 1)]); qv++ }
        persist(); fire()
    } }

    /** « Lire ensuite » (next = true) ou « Ajouter à la file ». */
    fun enqueue(t: T, next: Boolean) { main.post {
        if (queue.isEmpty()) { playList(listOf(t), 0); return@post }
        queue.add(t)
        val idx = queue.size - 1
        if (next) order.add((pos + 1).coerceAtMost(order.size), idx) else order.add(idx)
        qv++; persist(); fire()
    } }

    fun jumpTo(orderPos: Int) { main.post { if (orderPos in order.indices) jump(orderPos) } }

    fun removeAt(op: Int) { main.post {
        if (op !in order.indices) return@post
        val q = order[op]
        queue.removeAt(q)
        order.removeAt(op)
        order = ArrayList(order.map { if (it > q) it - 1 else it })
        qv++
        if (queue.isEmpty()) { stopNow(); return@post }
        if (op < pos) pos-- else if (op == pos) { if (pos >= order.size) pos = 0; startPosMs = 0; startCurrent(wantPlay) }
        persist(); fire()
    } }

    /** Arrêt complet : la lecture s'arrête, la file est vidée, le service et la notification disparaissent. */
    fun clear() { main.post { stopNow() } }

    private fun stopNow() {
        main.removeCallbacks(ticker)
        saveResume()
        player.playWhenReady = false
        try { player.stop(); player.clearMediaItems() } catch (_: Exception) {}
        queue.clear(); order.clear(); pos = -1
        ready = false; loading = false; wantPlay = false; startPosMs = 0; qv++
        persist(); fire()
    }

    // ------------------------------------------------------------------ état pour l'interface
    /** Exécute sur le thread principal (ExoPlayer l'exige) et attend le résultat : appelable depuis le pont JS. */
    private fun <R> onMain(block: () -> R): R? {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val f = FutureTask { block() }
        main.post(f)
        return try { f.get(1500, TimeUnit.MILLISECONDS) } catch (_: Exception) { null }
    }

    fun position(): Int = try {
        if (ready || player.playbackState == Player.STATE_BUFFERING) player.currentPosition.toInt().coerceAtLeast(0) else startPosMs
    } catch (_: Exception) { 0 }

    private fun duration(): Int = try {
        val d = player.duration
        if (ready && d != C.TIME_UNSET && d > 0) d.toInt() else ((cur()?.d ?: 0L) * 1000L).toInt()
    } catch (_: Exception) { 0 }

    fun stateJson(): JSONObject = onMain {
        val t = cur()
        val o = JSONObject().put("has", t != null).put("playing", wantPlay).put("loading", loading)
            .put("pos", position()).put("dur", duration())
            .put("repeat", repeat).put("rc", rcount).put("shuffle", shuffle)
            .put("qv", qv).put("qi", pos).put("qn", order.size).put("err", err).put("errN", errN)
            .put("out", outLabel()).put("outKey", outKey)
            .put("speed", speed.toDouble()).put("long", isLongNow())
        if (t != null) o.put("t", t.json().put("off", t.y.isNotEmpty() && lib.isOffline(t.y)))
        o
    } ?: JSONObject().put("has", false)

    /** File dans l'ordre de lecture ; l'indice courant = qi de l'état. */
    fun queueJson(): JSONArray = onMain {
        val a = JSONArray()
        for (q in order) a.put(queue[q].json())
        a
    } ?: JSONArray()

    // ------------------------------------------------------------------ mémoire de position + vitesse (titres longs)
    private fun keyOf(t: T) = if (t.y.isNotEmpty()) "y:" + t.y else "u:" + t.u

    private fun resume(): JSONObject = resumeCache ?: (try { JSONObject(prefs.getString("resume", "{}")) } catch (_: Exception) { JSONObject() }).also { resumeCache = it }

    /** Position à reprendre (ms, 3 s avant l'arrêt pour se remettre dans le fil), 0 s'il n'y a rien. */
    private fun resumeFor(t: T): Int {
        val p = resume().optJSONArray(keyOf(t))?.optLong(0) ?: return 0
        return if (p > 10_000) (p - 3_000).toInt() else 0
    }

    /**
     * Enregistre la position du titre chargé, seulement s'il est long (≥ 10 min). Arrivé à moins de 15 s de la fin :
     * la mémoire est effacée. Écriture légère (une seule clé, apply() asynchrone) ; jamais pour une chanson.
     */
    private fun saveResume() {
        if (!ready || curKey.isEmpty()) return
        try {
            val d = player.duration
            if (d == C.TIME_UNSET || d < LONG_MS) return
            val p = player.currentPosition
            val o = resume()
            if (p >= d - 15_000) o.remove(curKey)
            else if (p > 10_000) o.put(curKey, JSONArray().put(p).put(System.currentTimeMillis()))
            else return
            if (o.length() > 200) {           // on garde les 150 plus récents
                val keys = o.keys().asSequence().toList().sortedBy { o.optJSONArray(it)?.optLong(1) ?: 0L }
                for (k in keys.take(o.length() - 150)) o.remove(k)
            }
            prefs.edit().putString("resume", o.toString()).putInt("ppos", p.toInt()).apply()
        } catch (_: Exception) {}
    }

    /** Sauvegarde périodique : seulement pendant la lecture d'un titre long, toutes les 20 s. Rien en pause, rien pour la musique. */
    private val ticker = object : Runnable {
        override fun run() {
            if (!wantPlay) return
            if (ready) {
                val d = try { player.duration } catch (_: Exception) { C.TIME_UNSET }
                if (d != C.TIME_UNSET && d < LONG_MS) return   // titre court : on arrête de se réveiller
                saveResume()
            }
            main.postDelayed(this, TICK_MS)
        }
    }
    private fun scheduleTick() {
        main.removeCallbacks(ticker)
        if (wantPlay) main.postDelayed(ticker, TICK_MS)
    }

    /** À appeler quand l'appli passe en arrière-plan / se ferme : écrit la position tout de suite. */
    fun saveNow() { main.post { saveResume(); persist() } }

    private fun isLongNow(): Boolean = try {
        val d = player.duration
        (if (d != C.TIME_UNSET) d else 0L) >= LONG_MS || ((cur()?.d ?: 0L) * 1000L) >= LONG_MS
    } catch (_: Exception) { false }

    /** La vitesse choisie ne s'applique qu'aux titres longs ; la musique reste à vitesse normale. Hauteur de la voix inchangée. */
    private fun applySpeed() {
        try { player.playbackParameters = PlaybackParameters(if (isLongNow()) speed else 1f, 1f) } catch (_: Exception) {}
    }

    fun setSpeed(v: Float) { main.post {
        speed = v.coerceIn(0.5f, 3f)
        prefs.edit().putFloat("speed", speed).apply()
        applySpeed(); fire()
    } }

    /** Saut relatif en ms (négatif = reculer) : −15 s / +30 s dans l'interface. */
    fun seekBy(deltaMs: Int) { main.post {
        if (!ready) return@post
        val d = player.duration
        val max = if (d == C.TIME_UNSET) Long.MAX_VALUE else (d - 1000).coerceAtLeast(0L)
        player.seekTo((player.currentPosition + deltaMs).coerceIn(0L, max))
        fire()
    } }

    // ------------------------------------------------------------------ persistance (on retrouve sa file après fermeture)
    private fun persist() {
        try {
            val q = JSONArray(); for (t in queue) q.put(t.json())
            prefs.edit().putString("q", q.toString()).putString("o", JSONArray(order).toString()).putInt("pos", pos)
                .putInt("ppos", position()).putString("rep", repeat).putInt("rc", rcount).putBoolean("sh", shuffle).apply()
        } catch (_: Exception) {}
    }

    private fun restore() {
        try {
            repeat = prefs.getString("rep", "off") ?: "off"
            rcount = prefs.getInt("rc", 0)
            shuffle = prefs.getBoolean("sh", false)
            val q = JSONArray(prefs.getString("q", "[]"))
            for (i in 0 until q.length()) queue.add(T.from(q.getJSONObject(i)))
            val o = JSONArray(prefs.getString("o", "[]"))
            for (i in 0 until o.length()) order.add(o.getInt(i))
            pos = prefs.getInt("pos", -1)
            startPosMs = prefs.getInt("ppos", 0)
            if (order.size != queue.size || pos !in order.indices) { queue.clear(); order.clear(); pos = -1; startPosMs = 0 }
        } catch (_: Exception) { queue.clear(); order.clear(); pos = -1; startPosMs = 0 }
    }
}
