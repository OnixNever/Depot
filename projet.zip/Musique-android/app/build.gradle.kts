plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.musique.lecteur"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.musique.lecteur"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // signé avec la clé de debug : l'APK "release" reste installable directement
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.9.0")
    // Lecteur audio robuste (tampon, reprise, focus audio, veille) : le même moteur que YouTube Music et Spotify-like
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    // Recherche + extraction audio YouTube, sans clé d'API (la bibliothèque de NewPipe)
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
