# Musique (Musique-android_05)

Appli Android de musique : streaming par défaut, téléchargement hors ligne à la demande.
Construite sur le moteur YouTube de EntrainementTactique-android_06 (NewPipeExtractor, sans clé d'API).

## Build
`./gradlew assembleRelease` (ou Android Studio / ton workflow GitHub). APK : `app/build/outputs/apk/release/`.
Package : `com.musique.lecteur` (s'installe à côté de l'appli d'entraînement).

## Nouveautés de la 07
- **Bouton des sorties dans le panneau déroulant** : nouvelle méthode. Android bloque l'ouverture d'une fenêtre depuis l'arrière-plan ; le bouton affiche donc une notification en haut de l'écran (« Touche ici pour choisir le périphérique ») dont le tap ouvre le menu. Avec l'autorisation « Afficher par-dessus les autres applis » (Réglages → ⚙), le menu s'ouvre directement.
- **Icônes du menu des sorties** : vraies icônes dessinées (haut-parleur, téléphone, Bluetooth, casque, auto, ✓) à la place des émojis.
- **Icône vocale renommée « Onyx »**, avec un champ dans l'appli (⚙ en haut de « Ta musique ») pour choisir un autre nom : crée un raccourci d'écran d'accueil à ce nom (Android ne permet pas de renommer l'icône du lanceur après installation).

## Nouveautés de la 06
- **Menu des sorties audio partout** : même feuille de choix (`OutputActivity.kt`, refaite : sombre, violet, icônes, ✓ sur la sortie active) depuis le lecteur, la notification, les contrôles média du panneau déroulant et l'écran verrouillé (affichée par-dessus, sans taper le schéma).
- Si le bouton des contrôles média ne l'ouvre pas depuis l'extérieur : Réglages → Applis → Musique → « Afficher par-dessus les autres applis » → activer.

## Nouveautés de la 05 : commandes vocales (gratuit, 100 % Android)
- **« Ok Google, ouvre Musique Voix »** (ou bouton « Voix » en bas de l'appli, ou appui long sur l'icône → Commande vocale) :
  l'appli écoute en boucle, exécute, confirme à voix haute, réécoute. « Merci » / « c'est bon » pour finir.
- Commandes : lance la playlist X (en aléatoire) · joue X (playlist > titre > YouTube) · joue X de la playlist Y · cherche X ·
  ajoute-la / ajoute le deuxième / ajoute X à la playlist Y · enlève-la · retire X de la playlist Y · monte-la / descends-la (de 3 places) ·
  mets-la en premier / en dernier / en position 4 · déplace-la vers la playlist Y · copie-la dans Y · crée / renomme / supprime une playlist ·
  ouvre la playlist X · va dans la recherche / la bibliothèque / le lecteur / la file · pause, reprends, suivant, précédent, aléatoire,
  répète (n fois), volume, avance de 30 secondes, c'est quoi cette musique…
- « la » = le dernier titre dont on a parlé (résultat de recherche, titre ajouté), sinon le titre qui joue.
- Directement depuis Gemini / Assistant : pause, suivant, précédent (session média) ; « joue X sur Musique » (MEDIA_PLAY_FROM_SEARCH) ;
  « cherche X sur Musique » (SEARCH_ACTION). Selon la version de Gemini, ces deux dernières peuvent ne pas être transmises à une appli installée à la main.
- Fichiers : `VoiceParser.kt` (comprend le français, pur Kotlin), `Voice.kt` (exécute), `VoiceUi.kt` (micro + voix + panneau),
  `Ui.kt` (lien avec la page), `AssistantActivity.kt`, `VoiceLauncherActivity.kt`.

## Nouveautés de la 03
- **Choix de la sortie audio** : automatique (le système choisit, comme avant) ou à la main (haut-parleur du téléphone,
  casque / écouteurs Bluetooth, voiture, casque filaire, USB…). Deux endroits : bouton « Sortie » dans le lecteur plein écran
  et bouton « Sortie » dans la notification (liste des périphériques). Sur Android 13+, le bouton des contrôles média
  ouvre aussi la liste des périphériques (plus de passage au suivant en boucle). Si l'appareil choisi disparaît, ou si un nouvel appareil se connecte, retour en automatique.
- `OutputActivity.kt` : petite fenêtre de choix ouverte depuis la notification.

## Nouveautés de la 02
- Lecteur refait avec ExoPlayer (androidx.media3) : tampon de ~2 min, reprise automatique, focus audio (appels),
  pause si le casque est débranché, CPU + wifi gardés éveillés écran éteint.
- Streaming YouTube lu par tranches de 1 Mo via le paramètre « range » (ChunkedSource.kt), comme le téléchargement :
  fini les coupures « ça joue, silence, ça repart ». Si un flux casse, reprise au même endroit.
- Notification : pause / suivant / ARRÊTER dans la version réduite (+ précédent en étendu), aussi sur l'écran verrouillé.
  La lecture continue écran éteint ou appli en arrière-plan ; elle s'arrête avec le bouton Arrêter
  ou quand l'appli est fermée depuis les applis récentes.
- Répétition simplifiée : un bouton qui tourne (off → file → titre) + une pastille du nombre de fois (∞ → ×2 → ×3 → ×5).
- Ajout rapide : choisir une fois la playlist d'ajout (bandeau en haut de la recherche), puis ＋ ajoute en un tap (✓ si déjà dedans).
- Interface refaite : violet/rose, icônes, mosaïques de pochettes, lecteur avec fond flou, file d'attente.

## Fichiers
- `Engine.kt` : lecteur (file, ordre, répétitions, sources) — un seul pour toute l'appli.
- `ChunkedSource.kt` : lecture YouTube par tranches pour ExoPlayer.
- `PlayService.kt` : service de premier plan, notification + MediaSession.
- `OutputActivity.kt` : fenêtre de choix de la sortie audio (depuis la notification).
- `Library.kt` : playlists (library.json) et fichiers hors ligne (files/dl/<idYouTube>.m4a, partagés entre playlists).
- `Yt.kt` : recherche, téléchargement, `streamUrl()`.
- `Bridge.kt` / `MainActivity.kt` : pont avec l'interface `assets/www/index.html`.

## Si YouTube arrête de répondre
Mettre à jour la version de NewPipeExtractor dans `app/build.gradle.kts`.
