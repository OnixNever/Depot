# Onyx Music (Musique-android_10)

Appli Android de musique : streaming par défaut, téléchargement hors ligne à la demande.
Construite sur le moteur YouTube de EntrainementTactique-android_06 (NewPipeExtractor, sans clé d'API).

## Build
`./gradlew assembleRelease` (ou Android Studio / ton workflow GitHub). APK : `app/build/outputs/apk/release/`.
Package : `com.musique.lecteur` (s'installe à côté de l'appli d'entraînement).

## Nouveautés de la 10 : écouter des documentaires
- **Reprise automatique** des titres longs (≥ 10 min) : la position de chaque titre est mémorisée et la lecture reprend là où tu t'étais arrêté (3 s avant), même des jours plus tard, même après fermeture de l'appli ou arrêt de la lecture. Effacée quand tu arrives à la fin. Les chansons ne sont pas concernées. (`Engine.kt` : `saveResume`, `resumeFor`)
- **Vitesse de lecture** 0,75× → 2× (bouton « 1× » dans le lecteur), voix naturelle (hauteur inchangée). S'applique aux titres de plus de 10 min ; la musique reste à vitesse normale. Le réglage est gardé.
- **Boutons −15 s / +30 s** dans le lecteur plein écran.
- **Économie de batterie** : la position n'est écrite que toutes les 20 s pendant la lecture d'un titre long (une seule petite clé, écriture asynchrone), plus à chaque pause, changement de titre, arrêt et sortie de l'appli. Rien n'est écrit en pause ni pour la musique ; le minuteur s'arrête de lui-même sur un titre court. Mémoire limitée à 150 titres (les plus récents).

## Nouveautés de la 09
- **L'appli s'appelle « Onyx Music »** (avec un Y, comme Gemini l'entend). Plus d'icône séparée « Onix Voix » : Gemini ne l'indexait pas.
- **« Ok Google, ouvre Onyx Music »** ouvre l'appli ET lance l'écoute vocale (détection de l'appelant : appli Google / Gemini / Assistant,
  `launchedByGoogleAssistant()` dans `MainActivity.kt`). Un appui sur l'icône ouvre normalement, sans écoute.
  Le raccourci d'appui long « Commande vocale » reste. Si Gemini n'envoie pas son identité, l'appli s'ouvre sans écouter (bouton « Voix » en bas).
- Après installation : réinstaller si besoin et attendre quelques minutes que Gemini réindexe le nouveau nom.

## Nouveautés de la 08
- **Noms fixes** (plus de champ de renommage, plus de raccourci d'accueil) : l'appli s'appelait **« Musique Onix »**, l'icône vocale **« Onix Voix »** (remplacés dans la 09).
   Gemini garde un index des applis : après la mise à jour, si le nom n'est pas reconnu,
  réinstalle l'appli (ou ouvre-la une fois puis attends un peu) pour qu'il réindexe.
- **Bouton « Hors ligne »** (écran d'une playlist, et menu ⋮) : télécharge tous les titres YouTube puis **fige** la playlist (badge « hors ligne · figée »,
  lecture sans retourner sur YouTube). Les titres ajoutés ensuite à une playlist figée se téléchargent automatiquement. Re-toucher le bouton : télécharger
  les manquants, quitter le mode (en gardant ou en supprimant les fichiers).
- **Export / partage de playlist** (menu ⋮ d'une playlist → « Exporter / partager… », ouvre le partage Android : WhatsApp, Bluetooth, Fichiers…) :
  - playlist 100 % YouTube : petit fichier `.musique.json` (liens uniquement) ;
  - playlist avec des fichiers du téléphone : choix entre « seulement les titres YouTube (léger) » et « tout exporter » (`.musique.zip` : liens +
    fichiers audio sans source YouTube ; les titres YouTube restent de simples liens).
- **Import** : ⚙ Réglages → « Importer une playlist (fichier reçu) » → choisir le .json ou le .zip. Une nouvelle playlist est créée ; les fichiers audio du zip
  sont copiés dans l'appli et supprimés avec la playlist. Fichiers : `Transfer.kt` (export/import), `Library.kt` (frozen, imports/).

## Nouveautés de la 07
- **Bouton des sorties dans le panneau déroulant** : nouvelle méthode. Android bloque l'ouverture d'une fenêtre depuis l'arrière-plan ; le bouton affiche donc une notification en haut de l'écran (« Touche ici pour choisir le périphérique ») dont le tap ouvre le menu. Avec l'autorisation « Afficher par-dessus les autres applis » (Réglages → ⚙), le menu s'ouvre directement.
- **Icônes du menu des sorties** : vraies icônes dessinées (haut-parleur, téléphone, Bluetooth, casque, auto, ✓) à la place des émojis.
- ~~Icône vocale « Onyx » renommable par raccourci~~ : remplacée dans la 08 par deux noms fixes.

## Nouveautés de la 06
- **Menu des sorties audio partout** : même feuille de choix (`OutputActivity.kt`, refaite : sombre, violet, icônes, ✓ sur la sortie active) depuis le lecteur, la notification, les contrôles média du panneau déroulant et l'écran verrouillé (affichée par-dessus, sans taper le schéma).
- Si le bouton des contrôles média ne l'ouvre pas depuis l'extérieur : Réglages → Applis → Musique → « Afficher par-dessus les autres applis » → activer.

## Nouveautés de la 05 : commandes vocales (gratuit, 100 % Android)
- **« Ok Google, ouvre Onyx Music »** (ou bouton « Voix » en bas de l'appli, ou appui long sur l'icône → Commande vocale) :
  l'appli écoute en boucle, exécute, confirme à voix haute, réécoute. « Merci » / « c'est bon » pour finir.
- Commandes : lance la playlist X (en aléatoire) · joue X (playlist > titre > YouTube) · joue X de la playlist Y · cherche X ·
  ajoute-la / ajoute le deuxième / ajoute X à la playlist Y · enlève-la · retire X de la playlist Y · monte-la / descends-la (de 3 places) ·
  mets-la en premier / en dernier / en position 4 · déplace-la vers la playlist Y · copie-la dans Y · crée / renomme / supprime une playlist ·
  ouvre la playlist X · va dans la recherche / la bibliothèque / le lecteur / la file · pause, reprends, suivant, précédent, aléatoire,
  répète (n fois), volume, avance de 30 secondes, c'est quoi cette musique…
- « la » = le dernier titre dont on a parlé (résultat de recherche, titre ajouté), sinon le titre qui joue.
- Directement depuis Gemini / Assistant : pause, suivant, précédent (session média) ; « joue X sur Musique » (MEDIA_PLAY_FROM_SEARCH) ;
  « cherche X sur Musique » (SEARCH_ACTION). Selon la version de Gemini, ces deux dernières peuvent ne pas être transmises à une appli installée à la main.
- Fichiers : `VoiceParser.kt` (comprend le français, pur Kotlin), `Voice.kt` (exécute), `VoiceUi.kt` (micro + voix + panneau),
  `Ui.kt` (lien avec la page), `AssistantActivity.kt`, `VoiceLauncherActivity.kt`.

## Nouveautés de la 03
- **Choix de la sortie audio** : automatique (le système choisit, comme avant) ou à la main (haut-parleur du téléphone,
  casque / écouteurs Bluetooth, voiture, casque filaire, USB…). Deux endroits : bouton « Sortie » dans le lecteur plein écran
  et bouton « Sortie » dans la notification (liste des périphériques). Sur Android 13+, le bouton des contrôles média
  ouvre aussi la liste des périphériques (plus de passage au suivant en boucle). Si l'appareil choisi disparaît, ou si un nouvel appareil se connecte, retour en automatique.
- `OutputActivity.kt` : petite fenêtre de choix ouverte depuis la notification.

## Nouveautés de la 02
- Lecteur refait avec ExoPlayer (androidx.media3) : tampon de ~2 min, reprise automatique, focus audio (appels),
  pause si le casque est débranché, CPU + wifi gardés éveillés écran éteint.
- Streaming YouTube lu par tranches de 1 Mo via le paramètre « range » (ChunkedSource.kt), comme le téléchargement :
  fini les coupures « ça joue, silence, ça repart ». Si un flux casse, reprise au même endroit.
- Notification : pause / suivant / ARRÊTER dans la version réduite (+ précédent en étendu), aussi sur l'écran verrouillé.
  La lecture continue écran éteint ou appli en arrière-plan ; elle s'arrête avec le bouton Arrêter
  ou quand l'appli est fermée depuis les applis récentes.
- Répétition simplifiée : un bouton qui tourne (off → file → titre) + une pastille du nombre de fois (∞ → ×2 → ×3 → ×5).
- Ajout rapide : choisir une fois la playlist d'ajout (bandeau en haut de la recherche), puis ＋ ajoute en un tap (✓ si déjà dedans).
- Interface refaite : violet/rose, icônes, mosaïques de pochettes, lecteur avec fond flou, file d'attente.

## Fichiers
- `Engine.kt` : lecteur (file, ordre, répétitions, sources) — un seul pour toute l'appli.
- `ChunkedSource.kt` : lecture YouTube par tranches pour ExoPlayer.
- `PlayService.kt` : service de premier plan, notification + MediaSession.
- `OutputActivity.kt` : fenêtre de choix de la sortie audio (depuis la notification).
- `Library.kt` : playlists (library.json) et fichiers hors ligne (files/dl/<idYouTube>.m4a, partagés entre playlists).
- `Yt.kt` : recherche, téléchargement, `streamUrl()`.
- `Bridge.kt` / `MainActivity.kt` : pont avec l'interface `assets/www/index.html`.

## Si YouTube arrête de répondre
Mettre à jour la version de NewPipeExtractor dans `app/build.gradle.kts`.
