# Musique (Musique-android_02)

Appli Android de musique : streaming par défaut, téléchargement hors ligne à la demande.
Construite sur le moteur YouTube de EntrainementTactique-android_06 (NewPipeExtractor, sans clé d'API).

## Build
`./gradlew assembleRelease` (ou Android Studio / ton workflow GitHub). APK : `app/build/outputs/apk/release/`.
Package : `com.musique.lecteur` (s'installe à côté de l'appli d'entraînement).

## Nouveautés de la 02
- Lecteur refait avec ExoPlayer (androidx.media3) : tampon de ~2 min, reprise automatique, focus audio (appels),
  pause si le casque est débranché, CPU + wifi gardés éveillés écran éteint.
- Streaming YouTube lu par tranches de 1 Mo via le paramètre « range » (ChunkedSource.kt), comme le téléchargement :
  fini les coupures « ça joue, silence, ça repart ». Si un flux casse, reprise au même endroit.
- Notification : pause / suivant / ARRÊTER dans la version réduite (+ précédent en étendu), aussi sur l'écran verrouillé.
  La lecture continue écran éteint ou appli en arrière-plan ; elle s'arrête avec le bouton Arrêter
  ou quand l'appli est fermée depuis les applis récentes.
- Répétition simplifiée : un bouton qui tourne (off → file → titre) + une pastille du nombre de fois (∞ → ×2 → ×3 → ×5).
- Ajout rapide : choisir une fois la playlist d'ajout (bandeau en haut de la recherche), puis ＋ ajoute en un tap (✓ si déjà dedans).
- Interface refaite : violet/rose, icônes, mosaïques de pochettes, lecteur avec fond flou, file d'attente.

## Fichiers
- `Engine.kt` : lecteur (file, ordre, répétitions, sources) — un seul pour toute l'appli.
- `ChunkedSource.kt` : lecture YouTube par tranches pour ExoPlayer.
- `PlayService.kt` : service de premier plan, notification + MediaSession.
- `Library.kt` : playlists (library.json) et fichiers hors ligne (files/dl/<idYouTube>.m4a, partagés entre playlists).
- `Yt.kt` : recherche, téléchargement, `streamUrl()`.
- `Bridge.kt` / `MainActivity.kt` : pont avec l'interface `assets/www/index.html`.

## Si YouTube arrête de répondre
Mettre à jour la version de NewPipeExtractor dans `app/build.gradle.kts`.
