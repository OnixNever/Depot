# Musique (Musique-android_01)

Appli Android de musique : streaming par défaut, téléchargement hors ligne à la demande.
Construite sur le moteur YouTube de EntrainementTactique-android_06 (NewPipeExtractor, sans clé d'API).

## Build
Même procédure que les autres projets : `./gradlew assembleRelease` (ou Android Studio / ton workflow GitHub).
APK : `app/build/outputs/apk/release/`. Package : `com.musique.lecteur` (s'installe à côté de l'appli d'entraînement).

## Fonctions
- Recherche (mots-clés, lien de vidéo, lien de playlist YouTube) avec vignettes ; ajout direct à une playlist.
- Playlists : réordonner les titres et les playlists par glisser-déposer (poignée ⠿), renommer en un geste
  (✎ ou titre éditable), déplacer / copier un titre vers une autre playlist, retirer, supprimer.
- Streaming par défaut ; ⬇ télécharge un titre ou une playlist entière pour l'écoute hors ligne
  (le lecteur choisit tout seul : fichier du téléphone > fichier téléchargé > flux YouTube).
- Fichiers du téléphone : pointés (jamais copiés).
- Lecteur : file d'attente (lire ensuite / ajouter à la file / sauter / retirer), aléatoire,
  répétition de la file ou du titre : 1 fois, N fois ou indéfiniment.
- Lecture en arrière-plan, notification avec pochette et contrôles, écran verrouillé, boutons du casque.
- La file, la position, le mode aléatoire et la répétition sont retrouvés après fermeture de l'appli.

## Fichiers
- `Engine.kt` : lecteur (file, ordre, répétitions, sources, focus audio) — un seul pour toute l'appli.
- `PlayService.kt` : service de premier plan, notification + MediaSession.
- `Library.kt` : playlists (library.json) et fichiers hors ligne (files/dl/<idYouTube>.m4a, partagés entre playlists).
- `Yt.kt` : recherche, téléchargement, `streamUrl()` pour le streaming.
- `Bridge.kt` / `MainActivity.kt` : pont avec l'interface `assets/www/index.html`.

## Si YouTube arrête de répondre
Mettre à jour la version de NewPipeExtractor dans `app/build.gradle.kts`.
