package com.scanner.app

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Une ligne de texte reconnue, avec sa position (en pixels de l'image d'origine)
data class OcrLine(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

object Ocr {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    fun cacheFile(page: File): File =
        File(page.parentFile, page.nameWithoutExtension.replace("page_", "ocr_") + ".json")

    // Résultat mis en cache à côté de la page : l'analyse n'est faite qu'une fois
    suspend fun lines(ctx: Context, page: File): List<OcrLine> = withContext(Dispatchers.IO) {
        val cache = cacheFile(page)
        if (cache.exists()) {
            try {
                return@withContext parse(cache.readText())
            } catch (e: Exception) {
                // cache illisible : on refait l'analyse
            }
        }
        val image = InputImage.fromFilePath(ctx, Uri.fromFile(page))
        val result = recognizer.process(image).await()
        val out = result.textBlocks
            .flatMap { it.lines }
            .mapNotNull { line ->
                val b = line.boundingBox ?: return@mapNotNull null
                OcrLine(line.text, b.left, b.top, b.right, b.bottom)
            }
        cache.writeText(toJson(out))
        out
    }

    private fun toJson(lines: List<OcrLine>): String {
        val arr = JSONArray()
        lines.forEach {
            arr.put(
                JSONObject()
                    .put("t", it.text)
                    .put("l", it.left)
                    .put("tp", it.top)
                    .put("r", it.right)
                    .put("b", it.bottom)
            )
        }
        return arr.toString()
    }

    private fun parse(json: String): List<OcrLine> {
        val arr = JSONArray(json)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            OcrLine(o.getString("t"), o.getInt("l"), o.getInt("tp"), o.getInt("r"), o.getInt("b"))
        }
    }
}
