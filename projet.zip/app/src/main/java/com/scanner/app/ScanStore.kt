package com.scanner.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

data class Scan(val id: String, val dir: File) {
    private val orderFile: File get() = File(dir, "order.txt")

    // Pages dans l'ordre choisi par l'utilisateur (fichier order.txt)
    val pages: List<File>
        get() {
            val all = dir.listFiles()
                ?.filter { it.name.startsWith("page_") && it.name.endsWith(".jpg") }
                ?: emptyList()
            if (!orderFile.exists()) return all.sortedBy { it.name }
            val byName = all.associateBy { it.name }
            val ordered = orderFile.readLines().mapNotNull { byName[it.trim()] }
            val rest = all.filter { it !in ordered }.sortedBy { it.name }
            return ordered + rest
        }

    fun writeOrder(files: List<File>) {
        orderFile.writeText(files.joinToString("\n") { it.name })
    }

    val pdf: File get() = File(dir, "document.pdf")

    private val nameFile: File get() = File(dir, "name.txt")

    val title: String
        get() {
            val custom = if (nameFile.exists()) nameFile.readText().trim() else ""
            if (custom.isNotEmpty()) return custom
            val date = SimpleDateFormat("yyyy-MM-dd HH'h'mm", Locale.getDefault())
                .format(Date(id.toLongOrNull() ?: 0L))
            return "Scan $date"
        }

    fun rename(newName: String) {
        nameFile.writeText(newName.trim())
    }
}

object ScanStore {
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun root(ctx: Context): File = File(ctx.filesDir, "scans").apply { mkdirs() }

    fun list(ctx: Context): List<Scan> =
        root(ctx).listFiles()
            ?.filter { it.isDirectory }
            ?.sortedByDescending { it.name }
            ?.map { Scan(it.name, it) }
            ?: emptyList()

    // Page traitée, stockée dans le dossier temporaire de la session (nom unique)
    fun saveSessionPage(ctx: Context, bmp: Bitmap): File {
        val dir = File(ctx.cacheDir, "session").apply { mkdirs() }
        val f = File(dir, "p_${System.nanoTime()}.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        return f
    }

    fun saveFiles(ctx: Context, files: List<File>): Scan {
        val id = System.currentTimeMillis().toString()
        val dir = File(root(ctx), id).apply { mkdirs() }
        files.forEachIndexed { i, f ->
            f.copyTo(File(dir, "page_%03d.jpg".format(i + 1)), overwrite = true)
        }
        val scan = Scan(id, dir)
        scan.writeOrder(scan.pages)
        buildPdf(scan)
        return scan
    }

    // Ajoute des pages à la fin d'un document existant
    @Synchronized
    fun appendFiles(scan: Scan, files: List<File>) {
        val before = scan.pages
        val base = System.currentTimeMillis()
        val added = files.mapIndexed { i, f ->
            File(scan.dir, "page_${base}_$i.jpg").also { f.copyTo(it, overwrite = true) }
        }
        scan.writeOrder(before + added)
        buildPdf(scan)
    }

    // Applique l'ordre et les suppressions tout de suite, puis refait le PDF en arrière-plan
    fun applyPagesFast(scan: Scan, ordered: List<File>) {
        scan.pages.filter { it !in ordered }.forEach {
            it.delete()
            Ocr.cacheFile(it).delete()
        }
        scan.writeOrder(ordered)
        io.launch { syncPdf(scan) }
    }

    // Refait le PDF seulement s'il est plus ancien que l'ordre des pages
    @Synchronized
    fun syncPdf(scan: Scan) {
        val order = File(scan.dir, "order.txt")
        if (!scan.pdf.exists() || scan.pdf.lastModified() < order.lastModified()) buildPdf(scan)
    }

    fun delete(scan: Scan) {
        scan.dir.deleteRecursively()
    }

    private fun buildPdf(scan: Scan) {
        val doc = PdfDocument()
        scan.pages.forEachIndexed { i, f ->
            var bmp = BitmapFactory.decodeFile(f.path) ?: return@forEachIndexed
            val longSide = max(bmp.width, bmp.height)
            if (longSide > 3000) {
                val k = 3000f / longSide
                bmp = Bitmap.createScaledBitmap(
                    bmp, (bmp.width * k).roundToInt(), (bmp.height * k).roundToInt(), true
                )
            }
            val pw = 595
            val ph = (pw.toFloat() * bmp.height / bmp.width).roundToInt()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
            page.canvas.drawBitmap(bmp, null, Rect(0, 0, pw, ph), Paint(Paint.FILTER_BITMAP_FLAG))
            doc.finishPage(page)
        }
        scan.pdf.outputStream().use { doc.writeTo(it) }
        doc.close()
    }
}
