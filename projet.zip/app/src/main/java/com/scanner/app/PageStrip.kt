package com.scanner.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import java.io.File

// Maintiens une page puis glisse-la pour la déplacer ; le ✕ la supprime
@Composable
fun PageStrip(
    files: List<File>,
    onMove: (Int, Int) -> Unit,
    onDelete: (Int) -> Unit,
    modifier: Modifier = Modifier,
    onDragEnd: () -> Unit = {}
) {
    val density = LocalDensity.current
    val itemW = 72.dp
    val gap = 8.dp
    val stepPx = with(density) { (itemW + gap).toPx() }
    val filesNow by rememberUpdatedState(files)
    val moveNow by rememberUpdatedState(onMove)
    val endNow by rememberUpdatedState(onDragEnd)
    var dragPath by remember { mutableStateOf<String?>(null) }
    var dragDx by remember { mutableStateOf(0f) }

    Row(
        modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(gap)
    ) {
        files.forEachIndexed { i, f ->
            key(f.path) {
                val dragging = dragPath == f.path
                Box(
                    Modifier
                        .width(itemW)
                        .height(96.dp)
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer {
                            translationX = if (dragging) dragDx else 0f
                            scaleX = if (dragging) 1.08f else 1f
                            scaleY = if (dragging) 1.08f else 1f
                        }
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.DarkGray)
                        .pointerInput(f.path) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = {
                                    dragPath = f.path
                                    dragDx = 0f
                                },
                                onDrag = { change, amount ->
                                    change.consume()
                                    dragDx += amount.x
                                    val idx = filesNow.indexOfFirst { it.path == f.path }
                                    if (idx >= 0) {
                                        if (dragDx > stepPx / 2 && idx < filesNow.size - 1) {
                                            moveNow(idx, idx + 1)
                                            dragDx -= stepPx
                                        } else if (dragDx < -stepPx / 2 && idx > 0) {
                                            moveNow(idx, idx - 1)
                                            dragDx += stepPx
                                        }
                                    }
                                },
                                onDragEnd = {
                                    dragPath = null
                                    dragDx = 0f
                                    endNow()
                                },
                                onDragCancel = {
                                    dragPath = null
                                    dragDx = 0f
                                    endNow()
                                }
                            )
                        }
                ) {
                    Thumb(f, Modifier.fillMaxSize(), 8, ContentScale.Crop)
                    Text(
                        "${i + 1}",
                        color = Color.White,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .background(Color(0xAA000000))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(3.dp)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(0xCC000000))
                            .clickable { onDelete(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✕", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
