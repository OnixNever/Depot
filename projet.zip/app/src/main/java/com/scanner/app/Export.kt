package com.scanner.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.io.IOException

object Export {
    // PDF -> Téléchargements/Scanner ; images -> Images/Scanner (visibles dans la galerie)
    fun saveToDevice(ctx: Context, scan: Scan, asPdf: Boolean): String {
        val resolver = ctx.contentResolver
        val name = safeName(scan.title)
        if (asPdf) {
            insert(
                ctx, MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                "$name.pdf", "application/pdf", "Download/Scanner", scan.pdf
            )
            return "PDF enregistré dans Téléchargements/Scanner"
        }
        val pages = scan.pages
        pages.forEachIndexed { i, f ->
            val fileName = if (pages.size == 1) "$name.jpg" else "${name}_${i + 1}.jpg"
            insert(
                ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                fileName, "image/jpeg", "Pictures/Scanner", f
            )
        }
        return "${pages.size} image(s) enregistrée(s) dans Images/Scanner"
    }

    private fun insert(
        ctx: Context, collection: Uri, name: String, mime: String, relPath: String, src: File
    ) {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("Création impossible")
        resolver.openOutputStream(uri)?.use { out ->
            src.inputStream().use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }
}
