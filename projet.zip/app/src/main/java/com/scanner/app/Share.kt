package com.scanner.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

// Retire les caractères interdits dans un nom de fichier
fun safeName(name: String): String =
    name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "scan" }

private fun shareDir(ctx: Context): File =
    File(ctx.cacheDir, "share").apply {
        deleteRecursively()
        mkdirs()
    }

private fun uriFor(ctx: Context, file: File): Uri =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)

// Partage le PDF sous le nom choisi par l'utilisateur
fun sharePdf(ctx: Context, scan: Scan) {
    if (!scan.pdf.exists()) {
        Toast.makeText(ctx, "PDF introuvable", Toast.LENGTH_SHORT).show()
        return
    }
    val out = File(shareDir(ctx), safeName(scan.title) + ".pdf")
    scan.pdf.copyTo(out, overwrite = true)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uriFor(ctx, out))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(intent, "Partager le PDF"))
}

// Partage toutes les pages en images JPEG (nom_1.jpg, nom_2.jpg, ...)
fun shareImages(ctx: Context, scan: Scan) {
    val pages = scan.pages
    if (pages.isEmpty()) {
        Toast.makeText(ctx, "Aucune image", Toast.LENGTH_SHORT).show()
        return
    }
    val dir = shareDir(ctx)
    val base = safeName(scan.title)
    val uris = ArrayList<Uri>()
    pages.forEachIndexed { i, page ->
        val name = if (pages.size == 1) "$base.jpg" else "${base}_${i + 1}.jpg"
        val out = File(dir, name)
        page.copyTo(out, overwrite = true)
        uris.add(uriFor(ctx, out))
    }
    val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
        type = "image/jpeg"
        putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(intent, "Partager les images"))
}
