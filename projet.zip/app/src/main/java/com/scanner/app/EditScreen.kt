package com.scanner.app

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min

@Composable
fun EditScreen(
    source: Bitmap,
    pageNo: Int,
    onAdd: (Bitmap) -> Unit,
    onFinish: (Bitmap) -> Unit,
    onRetake: () -> Unit
) {
    var quad by remember(source) { mutableStateOf<List<Offset>?>(null) }
    var showResult by remember(source) { mutableStateOf(false) }
    var filter by remember(source) { mutableStateOf(Filter.AUTO) }
    var rotation by remember(source) { mutableStateOf(0) }

    // Détection automatique des bords sur la photo en pleine résolution
    LaunchedEffect(source) {
        quad = withContext(Dispatchers.Default) { DocScanner.detect(source) }
            ?: DocScanner.defaultQuad(source.width, source.height)
    }

    val result by produceState<Bitmap?>(null, quad, filter, rotation, showResult) {
        val q = quad
        value = if (!showResult || q == null) {
            null
        } else {
            withContext(Dispatchers.Default) { DocScanner.render(source, q, filter, rotation) }
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(
            if (showResult) "Page $pageNo : choisis le rendu"
            else "Page $pageNo : glisse les coins pour ajuster le cadrage",
            style = MaterialTheme.typography.titleSmall
        )
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
            if (!showResult) {
                CropArea(source, quad) { quad = it }
            } else {
                val r = result
                if (r == null) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                } else {
                    val img = remember(r) { r.asImageBitmap() }
                    Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
            }
        }

        if (!showResult) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRetake, modifier = Modifier.weight(1f)) { Text("Ignorer") }
                Button(
                    onClick = { showResult = true },
                    enabled = quad != null,
                    modifier = Modifier.weight(1f)
                ) { Text("Valider le cadrage") }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Filter.values().forEach { f ->
                    if (f == filter) {
                        Button(onClick = { filter = f }) { Text(f.label) }
                    } else {
                        OutlinedButton(onClick = { filter = f }) { Text(f.label) }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { rotation = (rotation + 90) % 360 },
                    modifier = Modifier.weight(1f)
                ) { Text("Pivoter") }
                OutlinedButton(
                    onClick = { showResult = false },
                    modifier = Modifier.weight(1f)
                ) { Text("Recadrer") }
                OutlinedButton(onClick = onRetake, modifier = Modifier.weight(1f)) { Text("Ignorer") }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { result?.let(onAdd) },
                    enabled = result != null,
                    modifier = Modifier.weight(1f)
                ) { Text("Ajouter une page") }
                Button(
                    onClick = { result?.let(onFinish) },
                    enabled = result != null,
                    modifier = Modifier.weight(1f)
                ) { Text("Terminer") }
            }
        }
    }
}

// Photo avec cadre à 4 coins déplaçables
@Composable
fun CropArea(source: Bitmap, quad: List<Offset>?, onQuad: (List<Offset>) -> Unit) {
    val img = remember(source) { source.asImageBitmap() }
    val currentQuad by rememberUpdatedState(quad)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth.toFloat()
        val hPx = constraints.maxHeight.toFloat()
        val scale = min(wPx / source.width, hPx / source.height)
        val offX = (wPx - source.width * scale) / 2f
        val offY = (hPx - source.height * scale) / 2f

        Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        Canvas(
            Modifier.fillMaxSize().pointerInput(source, scale) {
                var active = -1
                detectDragGestures(
                    onDragStart = { p ->
                        active = -1
                        val q = currentQuad
                        if (q != null) {
                            var best = 110f
                            q.forEachIndexed { i, o ->
                                val d = (Offset(o.x * scale + offX, o.y * scale + offY) - p).getDistance()
                                if (d < best) {
                                    best = d
                                    active = i
                                }
                            }
                        }
                    },
                    onDrag = { change, drag ->
                        val q = currentQuad
                        if (active >= 0 && q != null) {
                            change.consume()
                            val nq = q.toMutableList()
                            val o = nq[active]
                            nq[active] = Offset(
                                (o.x + drag.x / scale).coerceIn(0f, source.width.toFloat()),
                                (o.y + drag.y / scale).coerceIn(0f, source.height.toFloat())
                            )
                            onQuad(nq)
                        }
                    },
                    onDragEnd = { active = -1 },
                    onDragCancel = { active = -1 }
                )
            }
        ) {
            currentQuad?.let { q ->
                val pts = q.map { Offset(it.x * scale + offX, it.y * scale + offY) }
                val path = Path().apply {
                    moveTo(pts[0].x, pts[0].y)
                    lineTo(pts[1].x, pts[1].y)
                    lineTo(pts[2].x, pts[2].y)
                    lineTo(pts[3].x, pts[3].y)
                    close()
                }
                drawPath(path, Color(0x2200E676))
                drawPath(path, Color(0xFF00E676), style = Stroke(width = 5f))
                pts.forEach {
                    drawCircle(Color.White, 24f, it)
                    drawCircle(Color(0xFF00E676), 17f, it)
                }
            }
        }
    }
}
