package com.scanner.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.opencv.android.OpenCVLoader
import java.io.File
import kotlin.math.hypot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!OpenCVLoader.initLocal()) {
            Toast.makeText(this, "Moteur d image indisponible", Toast.LENGTH_LONG).show()
        }
        setContent {
            val colors = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = colors) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun Home(scans: List<Scan>, onScan: () -> Unit, onImport: () -> Unit, onOpen: (Scan) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Scanner", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onScan, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("Scanner un document")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
            Text("Importer depuis la galerie")
        }
        Spacer(Modifier.height(16.dp))
        if (scans.isEmpty()) {
            Text("Aucun scan pour l'instant.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(scans, key = { it.id }) { s ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(s) }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            s.pages.firstOrNull()?.let {
                                Thumb(it, Modifier.size(64.dp), 8, ContentScale.Crop)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(s.title)
                                Text("${s.pages.size} page(s)", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RenameDialog(current: String, onDone: (String?) -> Unit) {
    var draft by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text("Nom du document") },
        text = {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, singleLine = true)
        },
        confirmButton = { TextButton(onClick = { onDone(draft) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("Annuler") } }
    )
}

// Choix du format pour Enregistrer / Partager
@Composable
fun FormatDialog(title: String, onPick: (Boolean) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onPick(true) }, modifier = Modifier.fillMaxWidth()) { Text("PDF") }
                Button(onClick = { onPick(false) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Images (JPEG)")
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun Detail(
    scan: Scan,
    askName: Boolean,
    onBack: () -> Unit,
    onDelete: () -> Unit,
    onAddPages: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var pages by remember(scan.id) { mutableStateOf(scan.pages) }
    var title by remember(scan.id) { mutableStateOf(scan.title) }
    var renaming by remember(scan.id) { mutableStateOf(askName) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    // Lignes sélectionnées : clé = numéro de page * 10000 + numéro de ligne
    var selected by remember(scan.id) { mutableStateOf<Set<Int>>(emptySet()) }
    val ocr = remember(scan.id) { mutableStateMapOf<String, List<OcrLine>>() }

    LaunchedEffect(pages) {
        pages.forEach { f ->
            if (!ocr.containsKey(f.path)) {
                ocr[f.path] = try {
                    Ocr.lines(ctx, f)
                } catch (e: Exception) {
                    emptyList()
                }
            }
        }
    }
    val ready = pages.all { ocr.containsKey(it.path) }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    fun pageText(f: File): String = ocr[f.path].orEmpty().joinToString("\n") { it.text }

    fun selectedText(): String = selected.sorted().mapNotNull { key ->
        val page = pages.getOrNull(key / 10000) ?: return@mapNotNull null
        ocr[page.path]?.getOrNull(key % 10000)?.text
    }.joinToString("\n")

    if (renaming) {
        RenameDialog(title) { newName ->
            if (!newName.isNullOrBlank()) {
                scan.rename(newName)
                title = scan.title
            }
            renaming = false
        }
    }

    dialog?.let { kind ->
        FormatDialog(
            title = if (kind == "save") "Enregistrer en…" else "Partager en…",
            onPick = { asPdf ->
                dialog = null
                scope.launch {
                    withContext(Dispatchers.IO) { ScanStore.syncPdf(scan) }
                    if (kind == "save") {
                        val msg = withContext(Dispatchers.IO) {
                            try {
                                Export.saveToDevice(ctx, scan, asPdf)
                            } catch (e: Exception) {
                                "Erreur : ${e.message}"
                            }
                        }
                        toast(msg)
                    } else if (asPdf) {
                        sharePdf(ctx, scan)
                    } else {
                        shareImages(ctx, scan)
                    }
                }
            },
            onDismiss = { dialog = null }
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Retour") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDelete) { Text("Supprimer le document") }
            }

            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.clickable { renaming = true }
            )
            TextButton(onClick = { renaming = true }) { Text("Renommer") }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { dialog = "save" }, modifier = Modifier.weight(1f)) {
                    Text("Enregistrer")
                }
                Button(onClick = { dialog = "share" }, modifier = Modifier.weight(1f)) {
                    Text("Partager")
                }
            }

            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onAddPages, modifier = Modifier.fillMaxWidth()) {
                Text("Ajouter des pages")
            }
            Text(
                "Maintiens une page et glisse pour la déplacer, ✕ pour la supprimer.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp)
            )
            PageStrip(
                files = pages,
                onMove = { from, to ->
                    val list = pages.toMutableList()
                    list.add(to, list.removeAt(from))
                    pages = list
                    selected = emptySet()
                },
                onDelete = { i ->
                    val list = pages.toMutableList()
                    list.removeAt(i)
                    if (list.isEmpty()) {
                        onDelete()
                    } else {
                        pages = list
                        selected = emptySet()
                        ScanStore.applyPagesFast(scan, list)
                    }
                },
                onDragEnd = { ScanStore.applyPagesFast(scan, pages) }
            )

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (tab == 0) {
                    Button(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("Document") }
                    OutlinedButton(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("Texte") }
                } else {
                    OutlinedButton(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("Document") }
                    Button(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("Texte") }
                }
            }
            Spacer(Modifier.height(8.dp))

            if (tab == 0) {
                Text(
                    if (!ready) "Analyse du texte en cours…"
                    else "Touche une ligne pour la sélectionner. Maintiens puis glisse pour en sélectionner plusieurs.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    pages.forEachIndexed { pi, f ->
                        val onThisPage = selected.filter { it / 10000 == pi }.map { it % 10000 }.toSet()
                        PageView(
                            file = f,
                            lines = ocr[f.path],
                            selected = onThisPage,
                            onTapLine = { li ->
                                val key = pi * 10000 + li
                                selected = if (key in selected) selected - key else selected + key
                            },
                            onRange = { a, b ->
                                selected = (minOf(a, b)..maxOf(a, b)).map { pi * 10000 + it }.toSet()
                            }
                        )
                    }
                }
            } else {
                // Vue texte : sélection native au doigt (maintenir sur un mot, glisser les poignées)
                pages.forEachIndexed { pi, f ->
                    Text("Page ${pi + 1}", style = MaterialTheme.typography.titleSmall)
                    val t = if (ocr.containsKey(f.path)) pageText(f) else null
                    when {
                        t == null -> Text("Analyse en cours…")
                        t.isBlank() -> Text("Aucun texte détecté.")
                        else -> {
                            SelectionContainer { Text(t) }
                            TextButton(onClick = {
                                clipboard.setText(AnnotatedString(t))
                                toast("Page ${pi + 1} copiée")
                            }) { Text("Copier cette page") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedButton(
                    onClick = {
                        if (!ready) {
                            toast("Analyse du texte en cours…")
                        } else {
                            clipboard.setText(AnnotatedString(pages.joinToString("\n\n") { pageText(it) }.trim()))
                            toast("Tout le texte est copié")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Copier tout le texte") }
            }
            Spacer(Modifier.height(90.dp))
        }

        if (tab == 0 && selected.isNotEmpty()) {
            Surface(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            clipboard.setText(AnnotatedString(selectedText()))
                            toast("Texte copié")
                            selected = emptySet()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Copier (${selected.size})") }
                    OutlinedButton(
                        onClick = {
                            selected = pages.flatMapIndexed { pi, f ->
                                ocr[f.path].orEmpty().indices.map { pi * 10000 + it }
                            }.toSet()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Tout") }
                    TextButton(onClick = { selected = emptySet() }) { Text("✕") }
                }
            }
        }
    }
}

// Trouve la ligne de texte sous le doigt (coordonnées en pixels de l'image d'origine)
fun hitLine(lines: List<OcrLine>, x: Float, y: Float, pad: Float): Int {
    var best = -1
    var bestD = Float.MAX_VALUE
    lines.forEachIndexed { i, l ->
        if (x >= l.left - pad && x <= l.right + pad && y >= l.top - pad && y <= l.bottom + pad) {
            val d = hypot(x - (l.left + l.right) / 2f, y - (l.top + l.bottom) / 2f)
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
    }
    return best
}

@Composable
fun PageView(
    file: File,
    lines: List<OcrLine>?,
    selected: Set<Int>,
    onTapLine: (Int) -> Unit,
    onRange: (Int, Int) -> Unit
) {
    val dims = remember(file) { imageSize(file) }
    val bmp by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(
                file.path,
                BitmapFactory.Options().apply { inSampleSize = 2 }
            )
        }
    }
    val density = LocalDensity.current
    val tap by rememberUpdatedState(onTapLine)
    val range by rememberUpdatedState(onRange)
    val sel by rememberUpdatedState(selected)
    val ls = lines.orEmpty()

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthPx = with(density) { maxWidth.toPx() }
        val scale = widthPx / dims.first
        val heightDp = with(density) { (dims.second * scale).toDp() }
        val pad = 14f / scale
        Box(Modifier.fillMaxWidth().height(heightDp)) {
            bmp?.let {
                Image(
                    it.asImageBitmap(), null,
                    Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
            }
            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(ls, scale) {
                        detectTapGestures(onTap = { p ->
                            val i = hitLine(ls, p.x / scale, p.y / scale, pad)
                            if (i >= 0) tap(i)
                        })
                    }
                    .pointerInput(ls, scale) {
                        var anchor = -1
                        detectDragGesturesAfterLongPress(
                            onDragStart = { p ->
                                anchor = hitLine(ls, p.x / scale, p.y / scale, pad)
                                if (anchor >= 0) range(anchor, anchor)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                if (anchor >= 0) {
                                    val i = hitLine(
                                        ls, change.position.x / scale, change.position.y / scale, pad
                                    )
                                    if (i >= 0) range(anchor, i)
                                }
                            },
                            onDragEnd = { anchor = -1 },
                            onDragCancel = { anchor = -1 }
                        )
                    }
            ) {
                sel.forEach { i ->
                    ls.getOrNull(i)?.let { l ->
                        drawRect(
                            Color(0x663D8BFF),
                            topLeft = Offset(l.left * scale, l.top * scale),
                            size = Size((l.right - l.left) * scale, (l.bottom - l.top) * scale)
                        )
                    }
                }
            }
        }
    }
}

fun imageSize(file: File): Pair<Int, Int> {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, o)
    return Pair(maxOf(o.outWidth, 1), maxOf(o.outHeight, 1))
}

@Composable
fun Thumb(file: File, modifier: Modifier, sample: Int, scale: ContentScale) {
    val bmp by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(
                file.path,
                BitmapFactory.Options().apply { inSampleSize = sample }
            )
        }
    }
    bmp?.let { Image(it.asImageBitmap(), null, modifier, contentScale = scale) }
}
