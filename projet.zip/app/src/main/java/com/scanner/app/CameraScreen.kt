package com.scanner.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.hypot

// Nombre de photos prises à chaque déclenchement : l'appli garde la plus nette.
// Mets 1 pour désactiver la rafale, 4 ou 5 si ta main tremble beaucoup.
private const val BURST = 3

@Composable
fun CameraScreen(
    session: List<File>,
    onMovePage: (Int, Int) -> Unit,
    onDeletePage: (Int) -> Unit,
    onCaptured: (Bitmap) -> Unit,
    onFinish: () -> Unit,
    onGallery: () -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted = it }
    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("L'accès à la caméra est nécessaire pour scanner.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) {
                Text("Autoriser la caméra")
            }
            TextButton(onClick = onClose) { Text("Retour") }
        }
    } else {
        CameraContent(session, onMovePage, onDeletePage, onCaptured, onFinish, onGallery, onClose)
    }
}

@Composable
fun CameraContent(
    session: List<File>,
    onMovePage: (Int, Int) -> Unit,
    onDeletePage: (Int) -> Unit,
    onCaptured: (Bitmap) -> Unit,
    onFinish: () -> Unit,
    onGallery: () -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner
    val scope = rememberCoroutineScope()
    val previewView = remember {
        PreviewView(ctx).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
    }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var quad by remember { mutableStateOf<List<Offset>?>(null) }
    var capturing by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(true) }
    var flash by remember { mutableStateOf(false) }
    var sharpOk by remember { mutableStateOf(true) }
    var shotText by remember { mutableStateOf("Capture…") }

    DisposableEffect(Unit) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                        .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                        .build()
                )
                .build()
            provider.unbindAll()
            camera = provider.bindToLifecycle(
                owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture
            )
            imageCapture = capture
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { if (future.isDone) future.get().unbindAll() }
    }

    LaunchedEffect(flash, camera) { camera?.cameraControl?.enableTorch(flash) }

    // Mise au point + exposition sur un point de l'écran (centre du document)
    fun focusAt(x: Float, y: Float, onDone: (() -> Unit)? = null) {
        val cam = camera
        if (cam == null || previewView.width == 0) {
            onDone?.invoke()
            return
        }
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            val action = FocusMeteringAction.Builder(
                pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            ).setAutoCancelDuration(2, TimeUnit.SECONDS).build()
            val fut = cam.cameraControl.startFocusAndMetering(action)
            if (onDone != null) fut.addListener({ onDone() }, ContextCompat.getMainExecutor(ctx))
        } catch (e: Exception) {
            onDone?.invoke()
        }
    }

    // Rafale : BURST photos d'affilée, on mesure la netteté de chacune et on garde la meilleure
    fun shoot() {
        val ic = imageCapture
        if (ic == null) {
            capturing = false
            return
        }
        var best: Bitmap? = null
        var bestScore = -1.0

        fun finish() {
            capturing = false
            val b = best
            if (b != null) onCaptured(b)
        }

        fun next(i: Int) {
            if (i >= BURST) {
                finish()
                return
            }
            shotText = if (BURST > 1) "Capture ${i + 1}/$BURST…" else "Capture…"
            val file = File(ctx.cacheDir, "cap_${System.currentTimeMillis()}_$i.jpg")
            ic.takePicture(
                ImageCapture.OutputFileOptions.Builder(file).build(),
                ContextCompat.getMainExecutor(ctx),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                        scope.launch {
                            val bmp = withContext(Dispatchers.IO) {
                                DocScanner.loadBitmap(ctx, Uri.fromFile(file))
                            }
                            file.delete()
                            if (bmp != null) {
                                val score = withContext(Dispatchers.Default) {
                                    DocScanner.sharpness(bmp, null)
                                }
                                if (score > bestScore) {
                                    best?.recycle()
                                    best = bmp
                                    bestScore = score
                                } else {
                                    bmp.recycle()
                                }
                            }
                            next(i + 1)
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        file.delete()
                        if (best != null) {
                            finish()
                        } else {
                            capturing = false
                            Toast.makeText(
                                ctx, "Erreur photo : ${exception.message}", Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            )
        }

        next(0)
    }

    // refocus = true pour le bouton manuel : on refait le point sur le document, puis on déclenche
    fun capture(refocus: Boolean) {
        if (imageCapture == null || capturing) return
        capturing = true
        if (!refocus) {
            shoot()
            return
        }
        val q = quad
        val cx = q?.map { it.x }?.average()?.toFloat() ?: (previewView.width / 2f)
        val cy = q?.map { it.y }?.average()?.toFloat() ?: (previewView.height / 2f)
        var fired = false
        val go = {
            if (!fired) {
                fired = true
                shoot()
            }
        }
        focusAt(cx, cy, go)
        scope.launch {
            delay(900)
            go()
        }
    }

    // Détection en direct + capture auto : cadre stable ET image nette (pic de netteté atteint)
    LaunchedEffect(imageCapture) {
        if (imageCapture == null) return@LaunchedEffect
        var last: List<Offset>? = null
        var stable = 0
        var focusedAt: Offset? = null
        val recent = ArrayDeque<Double>()
        while (true) {
            delay(120)
            if (capturing) continue
            val bmp = previewView.bitmap ?: continue
            val res = withContext(Dispatchers.Default) {
                val q = DocScanner.detect(bmp)
                Pair(q, if (q != null) DocScanner.sharpness(bmp, q) else 0.0)
            }
            val q = res.first
            val sharp = res.second
            quad = q
            val diag = hypot(bmp.width.toFloat(), bmp.height.toFloat())
            val prev = last
            if (q != null && prev != null) {
                val move = q.indices.maxOf { (q[it] - prev[it]).getDistance() }
                stable = if (move < diag * 0.02f) stable + 1 else 0
            } else {
                stable = 0
            }
            last = q

            if (q != null) {
                val c = Offset(q.map { it.x }.average().toFloat(), q.map { it.y }.average().toFloat())
                val f = focusedAt
                if (f == null || (c - f).getDistance() > diag * 0.08f) {
                    focusAt(c.x, c.y)
                    focusedAt = c
                    recent.clear()
                }
                recent.addLast(sharp)
                if (recent.size > 12) recent.removeFirst()
            } else {
                focusedAt = null
                recent.clear()
            }
            val peak = recent.maxOrNull() ?: 0.0
            sharpOk = q == null || (sharp > 12.0 && sharp >= peak * 0.75)

            if (auto && q != null && stable >= 2 && sharpOk) {
                stable = 0
                recent.clear()
                capture(false)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        Canvas(Modifier.fillMaxSize()) {
            quad?.let { q ->
                val path = Path().apply {
                    moveTo(q[0].x, q[0].y)
                    lineTo(q[1].x, q[1].y)
                    lineTo(q[2].x, q[2].y)
                    lineTo(q[3].x, q[3].y)
                    close()
                }
                drawPath(path, Color(0x3300E676))
                drawPath(path, Color(0xFF00E676), style = Stroke(width = 6f))
            }
        }

        Column(Modifier.align(Alignment.TopCenter).padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(onClick = onClose) { Text("✕") }
                Button(onClick = { flash = !flash }) { Text(if (flash) "Flash : oui" else "Flash : non") }
                Button(onClick = { auto = !auto }) { Text(if (auto) "Auto : oui" else "Auto : non") }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                when {
                    capturing -> shotText
                    quad != null && !sharpOk -> "Mise au point…"
                    quad != null && auto -> "Document détecté, ne bouge plus"
                    quad != null -> "Document détecté"
                    else -> "Place le document dans le cadre"
                },
                color = Color.White,
                modifier = Modifier.background(Color(0x99000000)).padding(8.dp)
            )
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
            if (session.isNotEmpty()) {
                Text(
                    "Maintiens une page et glisse pour la déplacer",
                    color = Color.White,
                    modifier = Modifier.padding(start = 16.dp).background(Color(0x99000000)).padding(4.dp)
                )
                PageStrip(
                    files = session,
                    onMove = onMovePage,
                    onDelete = onDeletePage,
                    modifier = Modifier.fillMaxWidth().background(Color(0x88000000))
                )
            }
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = onGallery) { Text("Galerie") }
                Button(onClick = { capture(true) }, enabled = !capturing) { Text("Photo") }
                Button(onClick = onFinish, enabled = session.isNotEmpty()) {
                    Text("Terminer (${session.size})")
                }
            }
        }
    }
}
