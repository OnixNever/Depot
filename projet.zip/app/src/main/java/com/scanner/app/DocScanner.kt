package com.scanner.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.ui.geometry.Offset
import androidx.exifinterface.media.ExifInterface
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.MatOfDouble
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

enum class Filter(val label: String) {
    AUTO("Auto"),
    DOCUMENT("Document"),
    PHOTO("Photo"),
    BW("Noir & blanc"),
    GRAY("Gris"),
    SCREEN("Écran"),
    ORIGINAL("Original")
}

object DocScanner {

    // ------------------------------------------------------------------
    // 1. Détection du document : renvoie 4 coins (haut-gauche, haut-droit,
    //    bas-droit, bas-gauche) en pixels du bitmap, ou null si rien trouvé.
    //    Deux méthodes combinées : contours (Canny) et zone claire (Otsu).
    // ------------------------------------------------------------------
    fun detect(src: Bitmap): List<Offset>? {
        val s = min(1.0, 500.0 / max(src.width, src.height))
        val small = if (s < 1.0) {
            Bitmap.createScaledBitmap(
                src, (src.width * s).roundToInt(), (src.height * s).roundToInt(), true
            )
        } else src

        val rgba = Mat()
        Utils.bitmapToMat(small, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 0.0)
        val total = gray.width().toDouble() * gray.height()

        val edges = Mat()
        Imgproc.Canny(gray, edges, 40.0, 120.0)
        val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(5.0, 5.0))
        Imgproc.dilate(edges, edges, k)
        Imgproc.morphologyEx(edges, edges, Imgproc.MORPH_CLOSE, k)

        val otsu = Mat()
        Imgproc.threshold(gray, otsu, 0.0, 255.0, Imgproc.THRESH_BINARY + Imgproc.THRESH_OTSU)
        val k2 = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(9.0, 9.0))
        Imgproc.morphologyEx(otsu, otsu, Imgproc.MORPH_CLOSE, k2)
        Imgproc.morphologyEx(otsu, otsu, Imgproc.MORPH_OPEN, k2)

        val a = bestQuad(edges, total)
        val b = bestQuad(otsu, total)
        val best = listOfNotNull(a, b).maxByOrNull { it.second }

        rgba.release()
        gray.release()
        edges.release()
        otsu.release()
        if (small !== src) small.recycle()

        return best?.first?.map { Offset((it.x / s).toFloat(), (it.y / s).toFloat()) }
    }

    private fun bestQuad(mask: Mat, total: Double): Pair<List<Point>, Double>? {
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask.clone(), contours, Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
        val sorted = contours.sortedByDescending { Imgproc.contourArea(it) }
        for (c in sorted.take(10)) {
            val area = Imgproc.contourArea(c)
            if (area < total * 0.15) break
            if (area > total * 0.97) continue
            val c2 = MatOfPoint2f(*c.toArray())
            val peri = Imgproc.arcLength(c2, true)
            val approx = MatOfPoint2f()
            Imgproc.approxPolyDP(c2, approx, 0.02 * peri, true)
            if (approx.total() == 4L && Imgproc.isContourConvex(MatOfPoint(*approx.toArray()))) {
                return Pair(order(approx.toArray()), area)
            }
        }
        return null
    }

    private fun order(p: Array<Point>): List<Point> {
        val tl = p.minByOrNull { it.x + it.y }!!
        val br = p.maxByOrNull { it.x + it.y }!!
        val tr = p.minByOrNull { it.y - it.x }!!
        val bl = p.maxByOrNull { it.y - it.x }!!
        return listOf(tl, tr, br, bl)
    }

    fun defaultQuad(w: Int, h: Int): List<Offset> {
        val mx = w * 0.06f
        val my = h * 0.06f
        return listOf(
            Offset(mx, my), Offset(w - mx, my),
            Offset(w - mx, h - my), Offset(mx, h - my)
        )
    }

    // ------------------------------------------------------------------
    // 2. Rendu complet : redressement + filtre + rotation
    // ------------------------------------------------------------------
    fun render(src: Bitmap, quad: List<Offset>, filter: Filter, rotation: Int): Bitmap {
        val warped = warp(src, quad)
        val processed = process(warped, filter)
        warped.recycle()
        if (rotation % 360 == 0) return processed
        val m = Matrix().apply { postRotate(rotation.toFloat()) }
        return Bitmap.createBitmap(processed, 0, 0, processed.width, processed.height, m, true)
    }

    private fun warp(src: Bitmap, q: List<Offset>): Bitmap {
        fun d(a: Offset, b: Offset) = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble())
        var w = max(d(q[0], q[1]), d(q[3], q[2]))
        var h = max(d(q[0], q[3]), d(q[1], q[2]))
        val f = min(1.0, 3000.0 / max(w, h))
        w = max(50.0, w * f)
        h = max(50.0, h * f)

        val srcMat = Mat()
        Utils.bitmapToMat(src, srcMat)
        val from = MatOfPoint2f(*q.map { Point(it.x.toDouble(), it.y.toDouble()) }.toTypedArray())
        val dst = MatOfPoint2f(
            Point(0.0, 0.0), Point(w - 1, 0.0), Point(w - 1, h - 1), Point(0.0, h - 1)
        )
        val m = Imgproc.getPerspectiveTransform(from, dst)
        val out = Mat()
        Imgproc.warpPerspective(srcMat, out, m, Size(w, h), Imgproc.INTER_CUBIC)
        val bmp = Bitmap.createBitmap(out.cols(), out.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        srcMat.release()
        out.release()
        return bmp
    }

    // ------------------------------------------------------------------
    // 3. Filtres
    // ------------------------------------------------------------------
    private fun process(bmp: Bitmap, filter: Filter): Bitmap {
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()

        val chosen = if (filter == Filter.AUTO) {
            if (looksLikePhoto(rgb)) Filter.PHOTO else Filter.DOCUMENT
        } else filter

        val out: Mat = when (chosen) {
            Filter.ORIGINAL, Filter.AUTO -> rgb
            Filter.DOCUMENT -> {
                // Niveaux calculés sur CETTE image (plus de valeurs fixes) : pas d'effet flash
                // en lumière forte, pas de bruit gonflé en lumière faible.
                val k = lightFactor(rgb)
                val base = adaptiveLevels(flatten(rgb), 1.15)
                // Netteté à deux échelles : détails fins du texte + contraste local
                sharpen(sharpen(base, 0.9 * k, 1.0), 0.35 * k, 2.5)
            }
            Filter.PHOTO -> photo(rgb)
            Filter.GRAY -> {
                val g = Mat()
                Imgproc.cvtColor(flatten(rgb), g, Imgproc.COLOR_RGB2GRAY)
                sharpen(adaptiveLevels(g, 1.25), 1.0 * lightFactor(rgb), 1.2)
            }
            Filter.BW -> blackWhite(rgb)
            Filter.SCREEN -> descreen(rgb)
        }
        return toBitmap(out)
    }

    // Page très colorée ou très sombre (couverture, photo) : le filtre Document
    // la détruirait, on prend le filtre Photo à la place.
    private fun looksLikePhoto(rgb: Mat): Boolean {
        val side = max(rgb.width(), rgb.height())
        val f = min(1.0, 300.0 / side)
        val small = Mat()
        Imgproc.resize(
            rgb, small, Size(rgb.width() * f, rgb.height() * f), 0.0, 0.0, Imgproc.INTER_AREA
        )
        val hsv = Mat()
        Imgproc.cvtColor(small, hsv, Imgproc.COLOR_RGB2HSV)
        val ch = ArrayList<Mat>()
        Core.split(hsv, ch)
        // Seuil de "sombre" relatif : 27 % de la luminosité du papier (95e centile),
        // pour qu'un document pris dans une pièce sombre ne soit pas pris pour une photo.
        val v95 = percentile(ch[2], 0.95)
        val darkThr = max(25.0, v95 * 0.27)
        val sat = Mat()
        Imgproc.threshold(ch[1], sat, 70.0, 1.0, Imgproc.THRESH_BINARY)
        val lit = Mat()
        Imgproc.threshold(ch[2], lit, darkThr, 1.0, Imgproc.THRESH_BINARY)
        Core.bitwise_and(sat, lit, sat) // la saturation n'est fiable que si c'est assez éclairé
        lit.release()
        val dark = Mat()
        Imgproc.threshold(ch[2], dark, darkThr, 1.0, Imgproc.THRESH_BINARY_INV)
        val total = small.width().toDouble() * small.height()
        val satRatio = Core.sumElems(sat).`val`[0] / total
        val darkRatio = Core.sumElems(dark).`val`[0] / total
        small.release()
        hsv.release()
        sat.release()
        dark.release()
        ch.forEach { it.release() }
        return satRatio > 0.30 || darkRatio > 0.30
    }

    // Filtre Photo : garde les vraies couleurs, redresse juste la lumière (canal L) + netteté douce
    private fun photo(rgb: Mat): Mat {
        val lab = Mat()
        Imgproc.cvtColor(rgb, lab, Imgproc.COLOR_RGB2Lab)
        val ch = ArrayList<Mat>()
        Core.split(lab, ch)
        val clahe = Imgproc.createCLAHE(1.6, Size(8.0, 8.0))
        val l2 = Mat()
        clahe.apply(ch[0], l2)
        ch[0] = l2
        val merged = Mat()
        Core.merge(ch, merged)
        val back = Mat()
        Imgproc.cvtColor(merged, back, Imgproc.COLOR_Lab2RGB)
        lab.release()
        merged.release()
        return sharpen(back, 0.55, 1.4)
    }

    // Mesure de netteté (variance du Laplacien) sur la zone du document.
    // Valeur normalisée (zone ramenée à 400 px de large) : plus c'est haut, plus c'est net.
    fun sharpness(src: Bitmap, quad: List<Offset>?): Double {
        val rgba = Mat()
        Utils.bitmapToMat(src, rgba)
        val w = rgba.width()
        val h = rgba.height()
        var x0 = (w * 0.2).toInt()
        var y0 = (h * 0.2).toInt()
        var x1 = (w * 0.8).toInt()
        var y1 = (h * 0.8).toInt()
        if (quad != null && quad.size == 4) {
            val minX = quad.minOf { it.x }
            val maxX = quad.maxOf { it.x }
            val minY = quad.minOf { it.y }
            val maxY = quad.maxOf { it.y }
            val mx = (maxX - minX) * 0.15f
            val my = (maxY - minY) * 0.15f
            x0 = (minX + mx).toInt()
            x1 = (maxX - mx).toInt()
            y0 = (minY + my).toInt()
            y1 = (maxY - my).toInt()
        }
        x0 = x0.coerceIn(0, w - 2)
        y0 = y0.coerceIn(0, h - 2)
        x1 = x1.coerceIn(x0 + 1, w)
        y1 = y1.coerceIn(y0 + 1, h)
        val roi = Mat(rgba, Rect(x0, y0, x1 - x0, y1 - y0))
        val gray = Mat()
        Imgproc.cvtColor(roi, gray, Imgproc.COLOR_RGBA2GRAY)
        val k = 400.0 / gray.width()
        if (k < 1.0) {
            Imgproc.resize(
                gray, gray, Size(gray.width() * k, gray.height() * k), 0.0, 0.0, Imgproc.INTER_AREA
            )
        }
        val lap = Mat()
        Imgproc.Laplacian(gray, lap, CvType.CV_64F)
        val mean = MatOfDouble()
        val std = MatOfDouble()
        Core.meanStdDev(lap, mean, std)
        val sd = std.toArray().firstOrNull() ?: 0.0
        roi.release()
        gray.release()
        lap.release()
        rgba.release()
        return sd * sd
    }

    // Estime le fond (papier + ombres) en effaçant le texte, pour pouvoir le "diviser" ensuite
    private fun background(gray: Mat): Mat {
        val side = max(gray.width(), gray.height())
        val f = min(1.0, 600.0 / side)
        val small = Mat()
        Imgproc.resize(
            gray, small, Size(gray.width() * f, gray.height() * f), 0.0, 0.0, Imgproc.INTER_AREA
        )
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(21.0, 21.0))
        Imgproc.morphologyEx(small, small, Imgproc.MORPH_CLOSE, kernel)
        Imgproc.GaussianBlur(small, small, Size(0.0, 0.0), 8.0)
        val bg = Mat()
        Imgproc.resize(
            small, bg, Size(gray.width().toDouble(), gray.height().toDouble()),
            0.0, 0.0, Imgproc.INTER_LINEAR
        )
        Core.add(bg, Scalar(1.0), bg)
        // Gain maximal limité (~5,7x) : en lumière très faible, on évite de gonfler le bruit
        Core.max(bg, Scalar(45.0), bg)
        return bg
    }

    // Supprime les ombres et l'éclairage inégal : fond blanc uniforme, couleurs conservées
    private fun flatten(rgb: Mat): Mat {
        val gray = Mat()
        Imgproc.cvtColor(rgb, gray, Imgproc.COLOR_RGB2GRAY)
        val bg = background(gray)
        val chans = ArrayList<Mat>()
        Core.split(rgb, chans)
        for (c in chans) Core.divide(c, bg, c, 255.0)
        val out = Mat()
        Core.merge(chans, out)
        gray.release()
        bg.release()
        return out
    }

    // Centile (0.0..1.0) de la luminosité d'une image 8 bits à 1 canal
    private fun percentile(gray: Mat, p: Double): Int {
        val side = max(gray.width(), gray.height())
        val f = min(1.0, 300.0 / side)
        val small = Mat()
        Imgproc.resize(
            gray, small, Size(gray.width() * f, gray.height() * f), 0.0, 0.0, Imgproc.INTER_AREA
        )
        val n = small.total().toInt()
        val data = ByteArray(n)
        small.get(0, 0, data)
        small.release()
        val hist = IntArray(256)
        for (b in data) hist[b.toInt() and 0xFF]++
        val target = n * p
        var acc = 0
        for (i in 0..255) {
            acc += hist[i]
            if (acc >= target) return i
        }
        return 255
    }

    // Luminosité du papier -> facteur 0.45..1.0 : plus il fait sombre, moins on affûte (le bruit ressortirait)
    private fun lightFactor(rgb: Mat): Double {
        val g = Mat()
        Imgproc.cvtColor(rgb, g, Imgproc.COLOR_RGB2GRAY)
        val paper = percentile(g, 0.9)
        g.release()
        return (paper / 170.0).coerceIn(0.45, 1.0)
    }

    // Niveaux adaptatifs : le point blanc suit le papier réel, le point noir suit l'encre réelle
    private fun adaptiveLevels(src: Mat, gamma: Double): Mat {
        val gray = if (src.channels() == 1) src else Mat().also {
            Imgproc.cvtColor(src, it, Imgproc.COLOR_RGB2GRAY)
        }
        val paper = percentile(gray, 0.75)
        val ink = percentile(gray, 0.01)
        if (gray !== src) gray.release()
        val hi = (paper * 0.92).toInt().coerceIn(140, 235)
        val lo = (ink * 0.7).toInt().coerceIn(5, 60).coerceAtMost(hi - 90)
        return levels(src, lo, hi, gamma)
    }

    // Niveaux : point noir, point blanc et gamma (noirs plus profonds, blancs purs)
    private fun levels(src: Mat, lo: Int, hi: Int, gamma: Double): Mat {
        val lut = Mat(1, 256, CvType.CV_8UC1)
        val data = ByteArray(256)
        for (i in 0..255) {
            val v = ((i - lo).toDouble() / (hi - lo)).coerceIn(0.0, 1.0).pow(gamma)
            data[i] = (v * 255).roundToInt().toByte()
        }
        lut.put(0, 0, data)
        val out = Mat()
        Core.LUT(src, lut, out)
        return out
    }

    // Masque flou : accentue la netteté du texte
    private fun sharpen(src: Mat, amount: Double, sigma: Double): Mat {
        val blur = Mat()
        Imgproc.GaussianBlur(src, blur, Size(0.0, 0.0), sigma)
        val out = Mat()
        Core.addWeighted(src, 1.0 + amount, blur, -amount, 0.0, out)
        blur.release()
        return out
    }

    private fun blackWhite(rgb: Mat): Mat {
        val g = Mat()
        Imgproc.cvtColor(flatten(rgb), g, Imgproc.COLOR_RGB2GRAY)
        val side = max(g.width(), g.height())
        var block = (side / 55).coerceIn(25, 75)
        if (block % 2 == 0) block++
        val bw = Mat()
        Imgproc.adaptiveThreshold(
            g, bw, 255.0, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY, block, 12.0
        )
        g.release()
        return bw
    }

    // Mode écran : floute fortement les couleurs (franges arc-en-ciel du moiré)
    // et lisse la luminosité par réduction/agrandissement, puis réaffûte
    private fun descreen(rgb: Mat): Mat {
        val ycc = Mat()
        Imgproc.cvtColor(rgb, ycc, Imgproc.COLOR_RGB2YCrCb)
        val ch = ArrayList<Mat>()
        Core.split(ycc, ch)
        Imgproc.GaussianBlur(ch[1], ch[1], Size(0.0, 0.0), 7.0)
        Imgproc.GaussianBlur(ch[2], ch[2], Size(0.0, 0.0), 7.0)
        val y = ch[0]
        val small = Mat()
        Imgproc.resize(
            y, small, Size(y.width() * 0.5, y.height() * 0.5), 0.0, 0.0, Imgproc.INTER_AREA
        )
        Imgproc.medianBlur(small, small, 3)
        val y2 = Mat()
        Imgproc.resize(
            small, y2, Size(y.width().toDouble(), y.height().toDouble()),
            0.0, 0.0, Imgproc.INTER_CUBIC
        )
        ch[0] = y2
        val merged = Mat()
        Core.merge(ch, merged)
        val back = Mat()
        Imgproc.cvtColor(merged, back, Imgproc.COLOR_YCrCb2RGB)
        return sharpen(back, 0.7, 1.5)
    }

    private fun toBitmap(m: Mat): Bitmap {
        val rgba = Mat()
        Imgproc.cvtColor(
            m, rgba,
            if (m.channels() == 1) Imgproc.COLOR_GRAY2RGBA else Imgproc.COLOR_RGB2RGBA
        )
        val bmp = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, bmp)
        rgba.release()
        return bmp
    }

    // ------------------------------------------------------------------
    // 4. Chargement d'une image (photo ou galerie) avec la bonne orientation
    // ------------------------------------------------------------------
    fun loadBitmap(ctx: Context, uri: Uri, maxSide: Int = 3200): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null
        val rot = try {
            ctx.contentResolver.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        } catch (e: Exception) {
            0
        }
        if (rot == 0) return bmp
        val m = Matrix().apply { postRotate(rot.toFloat()) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
}
