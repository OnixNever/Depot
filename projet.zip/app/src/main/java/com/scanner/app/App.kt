package com.scanner.app

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var scans by remember { mutableStateOf(ScanStore.list(ctx)) }
    var openId by remember { mutableStateOf<String?>(null) }
    var justScanned by remember { mutableStateOf<String?>(null) }
    var appendId by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableStateOf("home") }
    var editBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val session = remember { mutableStateListOf<File>() }
    val queue = remember { mutableStateListOf<Uri>() }
    val open = scans.firstOrNull { it.id == openId }

    fun resetSession() {
        session.clear()
        queue.clear()
        File(ctx.cacheDir, "session").deleteRecursively()
    }

    fun loadInto(uri: Uri) {
        scope.launch {
            val b = withContext(Dispatchers.IO) { DocScanner.loadBitmap(ctx, uri) }
            if (b != null) {
                editBitmap = b
                mode = "edit"
            } else {
                Toast.makeText(ctx, "Image illisible", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            queue.clear()
            queue.addAll(uris.drop(1))
            loadInto(uris.first())
        }
    }

    fun finishSession() {
        scope.launch {
            val files = session.toList()
            val target = appendId
            val scan: Scan = withContext(Dispatchers.IO) {
                if (target != null) {
                    val existing = ScanStore.list(ctx).first { it.id == target }
                    ScanStore.appendFiles(existing, files)
                    existing
                } else {
                    ScanStore.saveFiles(ctx, files)
                }
            }
            resetSession()
            scans = ScanStore.list(ctx)
            justScanned = if (target == null) scan.id else null
            openId = scan.id
            appendId = null
            editBitmap = null
            mode = "home"
        }
    }

    fun addPage(result: Bitmap, finish: Boolean) {
        scope.launch {
            val f = withContext(Dispatchers.IO) { ScanStore.saveSessionPage(ctx, result) }
            session.add(f)
            editBitmap = null
            if (finish) {
                queue.clear()
                finishSession()
            } else if (queue.isNotEmpty()) {
                loadInto(queue.removeAt(0))
            } else {
                mode = "camera"
            }
        }
    }

    BackHandler(enabled = mode != "home" || open != null) {
        if (mode == "edit") {
            editBitmap = null
            queue.clear()
            mode = "camera"
        } else if (mode == "camera") {
            resetSession()
            appendId = null
            mode = "home"
        } else {
            openId = null
            justScanned = null
        }
    }

    when (mode) {
        "camera" -> CameraScreen(
            session = session,
            onMovePage = { from, to ->
                val f = session.removeAt(from)
                session.add(to, f)
            },
            onDeletePage = { i -> session.removeAt(i).delete() },
            onCaptured = {
                editBitmap = it
                mode = "edit"
            },
            onFinish = { finishSession() },
            onGallery = { picker.launch("image/*") },
            onClose = {
                resetSession()
                appendId = null
                mode = "home"
            }
        )
        "edit" -> editBitmap?.let { bmp ->
            EditScreen(
                source = bmp,
                pageNo = session.size + 1,
                onAdd = { addPage(it, false) },
                onFinish = { addPage(it, true) },
                onRetake = {
                    editBitmap = null
                    if (queue.isNotEmpty()) loadInto(queue.removeAt(0)) else mode = "camera"
                }
            )
        }
        else -> {
            if (open == null) {
                Home(
                    scans,
                    onScan = {
                        resetSession()
                        appendId = null
                        mode = "camera"
                    },
                    onImport = {
                        resetSession()
                        appendId = null
                        picker.launch("image/*")
                    },
                    onOpen = { openId = it.id }
                )
            } else {
                Detail(
                    scan = open,
                    askName = open.id == justScanned,
                    onBack = {
                        openId = null
                        justScanned = null
                    },
                    onDelete = {
                        ScanStore.delete(open)
                        scans = ScanStore.list(ctx)
                        openId = null
                        justScanned = null
                    },
                    onAddPages = {
                        resetSession()
                        appendId = open.id
                        mode = "camera"
                    }
                )
            }
        }
    }
}
