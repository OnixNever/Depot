package com.onixnever.hub;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Cadrage d'icône : on déplace / zoome l'image dans un cadre carré. */
public class CropView extends View {
    private Bitmap bmp;
    private final Matrix m = new Matrix();
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF frame = new RectF();
    private final Path framePath = new Path();
    private final ScaleGestureDetector sgd;
    private float coverScale = 1f;
    private float lastX, lastY;

    public CropView(Context c) {
        super(c);
        border.setStyle(Paint.Style.STROKE);
        border.setColor(0xFFFFFFFF);
        border.setStrokeWidth(Ui.dp(c, 2));
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                zoomBy(d.getScaleFactor(), d.getFocusX(), d.getFocusY());
                return true;
            }
        });
    }

    public void setBitmap(Bitmap b) {
        bmp = b;
        fit(true);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float side = Math.min(w, h) * 0.86f;
        frame.set(w / 2f - side / 2f, h / 2f - side / 2f, w / 2f + side / 2f, h / 2f + side / 2f);
        framePath.reset();
        float r = side * 0.2f;
        framePath.addRoundRect(frame, r, r, Path.Direction.CW);
        fit(true);
    }

    /** cover = l'image remplit le cadre ; sinon elle y tient en entier. */
    public void fit(boolean cover) {
        if (bmp == null || frame.isEmpty()) return;
        float sx = frame.width() / bmp.getWidth();
        float sy = frame.height() / bmp.getHeight();
        coverScale = Math.max(sx, sy);
        float s = cover ? coverScale : Math.min(sx, sy);
        m.reset();
        m.postScale(s, s);
        m.postTranslate(frame.centerX() - bmp.getWidth() * s / 2f,
                frame.centerY() - bmp.getHeight() * s / 2f);
        invalidate();
    }

    private float currentScale() {
        float[] v = new float[9];
        m.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    public void zoomBy(float f, float px, float py) {
        float s = currentScale();
        float target = Math.max(coverScale * 0.1f, Math.min(coverScale * 10f, s * f));
        float real = target / s;
        m.postScale(real, real, px, py);
        invalidate();
    }

    public void zoomCenter(float f) {
        zoomBy(f, frame.centerX(), frame.centerY());
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF000000);
        if (bmp == null) return;
        c.drawBitmap(bmp, m, paint);
        c.save();
        c.clipOutPath(framePath);
        c.drawColor(0xCC000000);
        c.restore();
        c.drawPath(framePath, border);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        sgd.onTouchEvent(e);
        int action = e.getActionMasked();
        int skip = (action == MotionEvent.ACTION_POINTER_UP) ? e.getActionIndex() : -1;
        float sx = 0, sy = 0;
        int n = 0;
        for (int i = 0; i < e.getPointerCount(); i++) {
            if (i == skip) continue;
            sx += e.getX(i);
            sy += e.getY(i);
            n++;
        }
        if (n == 0) return true;
        float cx = sx / n, cy = sy / n;
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_POINTER_UP:
                lastX = cx;
                lastY = cy;
                break;
            case MotionEvent.ACTION_MOVE:
                m.postTranslate(cx - lastX, cy - lastY);
                lastX = cx;
                lastY = cy;
                invalidate();
                break;
            default:
                break;
        }
        return true;
    }

    /** Rend le contenu du cadre en PNG carré. */
    public Bitmap export(int size) {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Matrix mm = new Matrix(m);
        mm.postTranslate(-frame.left, -frame.top);
        float k = size / frame.width();
        mm.postScale(k, k);
        c.drawBitmap(bmp, mm, paint);
        return out;
    }
}
