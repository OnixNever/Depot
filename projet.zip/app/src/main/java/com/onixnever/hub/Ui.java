package com.onixnever.hub;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/** Petits utilitaires d'interface (tout est construit en code, thème sombre). */
final class Ui {
    static final int BG = 0xFF0F1115;
    static final int CARD = 0xFF1A1D24;
    static final int CARD2 = 0xFF262B36;
    static final int TEXT = 0xFFE8EAF0;
    static final int MUTED = 0xFF9AA0AE;
    static final int ACCENT = 0xFF4C8DFF;
    static final int DANGER = 0xFFE5484D;

    private Ui() {
    }

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    static GradientDrawable rect(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    static Button button(Context c, String t, int bg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(15);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(c, 44));
        b.setMinimumHeight(dp(c, 44));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), rect(c, bg, 12), null));
        b.setPadding(dp(c, 16), 0, dp(c, 16), 0);
        b.setOnClickListener(l);
        return b;
    }

    static EditText input(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setBackground(rect(c, CARD, 12));
        e.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        return e;
    }

    static void style(Activity a) {
        a.getWindow().setStatusBarColor(BG);
        a.getWindow().setNavigationBarColor(BG);
    }

    /** Icône de remplacement : lettre initiale sur fond coloré. */
    static Bitmap letterIcon(String name, int size) {
        int[] pal = {0xFF4C8DFF, 0xFF7C5CFF, 0xFF2BB673, 0xFFE5853D, 0xFFD6457F, 0xFF1FA2B8, 0xFFB5A21E};
        String n = name == null ? "" : name.trim();
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(pal[(n.hashCode() & 0x7fffffff) % pal.length]);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(size * 0.5f);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        String letter = n.isEmpty() ? "?" : n.substring(0, n.offsetByCodePoints(0, 1)).toUpperCase();
        c.drawText(letter, size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p);
        return b;
    }
}
