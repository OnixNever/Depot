package com.onixnever.hub;

import android.content.Context;

import org.json.JSONArray;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Stockage : liste des projets (JSON), icônes (PNG) et code des projets HTML. */
public class Store {
    private final Context ctx;

    public Store(Context c) {
        ctx = c.getApplicationContext();
    }

    private File root() {
        File f = new File(ctx.getFilesDir(), "hub");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    public File codeDir(String id) {
        return new File(root(), "p_" + id);
    }

    public File iconFile(String id) {
        return new File(root(), "icon_" + id + ".png");
    }

    private File db() {
        return new File(root(), "projects.json");
    }

    // ---------- liste des projets ----------

    public synchronized List<Project> load() {
        List<Project> out = new ArrayList<>();
        File f = db();
        if (!f.exists()) return out;
        try {
            JSONArray a = new JSONArray(new String(readAll(new FileInputStream(f)), "UTF-8"));
            for (int i = 0; i < a.length(); i++) out.add(Project.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {
        }
        return out;
    }

    public synchronized void save(List<Project> list) throws IOException {
        JSONArray a = new JSONArray();
        for (Project p : list) a.put(p.toJson());
        File tmp = new File(root(), "projects.json.tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(a.toString().getBytes("UTF-8"));
        }
        Files.move(tmp.toPath(), db().toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    public Project get(String id) {
        if (id == null) return null;
        for (Project p : load()) if (id.equals(p.id)) return p;
        return null;
    }

    public synchronized void upsert(Project p) throws IOException {
        List<Project> l = load();
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id.equals(p.id)) {
                l.set(i, p);
                found = true;
                break;
            }
        }
        if (!found) l.add(p);
        save(l);
    }

    public synchronized void delete(String id) throws IOException {
        List<Project> l = load();
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id.equals(id)) l.remove(i);
        save(l);
        deleteFiles(id);
    }

    /** Supprime le code et l'icône d'un projet (sans toucher à la liste). */
    public void deleteFiles(String id) {
        deleteRec(codeDir(id));
        iconFile(id).delete();
    }

    public boolean hasCode(String id) {
        return new File(codeDir(id), "index.html").exists();
    }

    // ---------- import de code (HTML seul ou zip) ----------

    /** Importe un fichier .html OU un .zip (détecté automatiquement) comme code du projet. */
    public void importFromStream(InputStream raw, String id) throws IOException {
        BufferedInputStream in = new BufferedInputStream(raw);
        in.mark(4);
        int b0 = in.read();
        int b1 = in.read();
        in.reset();
        boolean zip = (b0 == 'P' && b1 == 'K');

        File tmp = new File(root(), "tmp_" + id);
        deleteRec(tmp);
        tmp.mkdirs();
        try {
            if (zip) {
                unzip(in, tmp);
            } else {
                try (FileOutputStream o = new FileOutputStream(new File(tmp, "index.html"))) {
                    copy(in, o);
                }
            }
            File base = tmp;
            File[] ch = tmp.listFiles();
            if (zip && ch != null && ch.length == 1 && ch[0].isDirectory()) base = ch[0];

            File idx = new File(base, "index.html");
            if (!idx.exists()) {
                File first = firstHtml(base);
                if (first == null) throw new IOException("Aucun fichier HTML trouvé");
                Files.copy(first.toPath(), idx.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
            File dest = codeDir(id);
            deleteRec(dest);
            if (!base.renameTo(dest)) throw new IOException("Impossible d'installer le code");
        } finally {
            deleteRec(tmp);
        }
    }

    private static void unzip(InputStream in, File dir) throws IOException {
        String canon = dir.getCanonicalPath() + File.separator;
        ZipInputStream zis = new ZipInputStream(in);
        ZipEntry e;
        while ((e = zis.getNextEntry()) != null) {
            String n = e.getName();
            if (n.startsWith("__MACOSX") || n.endsWith(".DS_Store")) continue;
            File out = new File(dir, n);
            if (!out.getCanonicalPath().startsWith(canon)) throw new IOException("Zip invalide");
            if (e.isDirectory()) {
                out.mkdirs();
            } else {
                out.getParentFile().mkdirs();
                try (FileOutputStream o = new FileOutputStream(out)) {
                    copy(zis, o);
                }
            }
        }
    }

    private static File firstHtml(File dir) {
        File[] l = dir.listFiles();
        if (l == null) return null;
        for (File f : l) {
            String n = f.getName().toLowerCase();
            if (f.isFile() && (n.endsWith(".html") || n.endsWith(".htm"))) return f;
        }
        for (File f : l) {
            if (f.isDirectory()) {
                File r = firstHtml(f);
                if (r != null) return r;
            }
        }
        return null;
    }

    // ---------- utilitaires ----------

    public static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    public static byte[] readAll(InputStream in) throws IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            copy(i, b);
            return b.toByteArray();
        }
    }

    public static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] l = f.listFiles();
        if (l != null) for (File c : l) deleteRec(c);
        f.delete();
    }
}
