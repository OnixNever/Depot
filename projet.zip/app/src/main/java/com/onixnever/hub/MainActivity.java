package com.onixnever.hub;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Écran d'accueil : la grille des projets (un bouton par projet). */
public class MainActivity extends Activity {
    private static final int RC_PERMS = 1, RC_EDIT = 2;
    private static final int THEME = AlertDialog.THEME_DEVICE_DEFAULT_DARK;

    private Store store;
    private final List<Project> items = new ArrayList<>();
    private final Map<String, Bitmap> iconCache = new HashMap<>();
    private GridView grid;
    private TextView empty;
    private TileAdapter adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.style(this);
        store = new Store(this);

        LinearLayout rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setBackgroundColor(Ui.BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this, 20), Ui.dp(this, 18), Ui.dp(this, 14), Ui.dp(this, 10));
        TextView title = Ui.text(this, "Mes projets", 26, Ui.TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button menu = Ui.button(this, "⋮", Ui.CARD2, v -> showMenu());
        menu.setTextSize(20);
        header.addView(menu, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
        Button add = Ui.button(this, "+", Ui.ACCENT, v -> startEdit(null, false));
        add.setTextSize(22);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46));
        alp.leftMargin = Ui.dp(this, 8);
        header.addView(add, alp);
        rootView.addView(header, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout body = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 96));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(Ui.dp(this, 14));
        grid.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 24));
        grid.setClipToPadding(false);
        grid.setSelector(android.R.color.transparent);
        adapter = new TileAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, id) -> open(items.get(pos)));
        grid.setOnItemLongClickListener((AdapterView<?> p, View v, int pos, long id) -> {
            showItemMenu(items.get(pos));
            return true;
        });
        body.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        empty = Ui.text(this, "Aucun projet pour l'instant.\nAppuie sur + pour en ajouter un.", 16, Ui.MUTED, false);
        empty.setGravity(Gravity.CENTER);
        body.addView(empty, new FrameLayout.LayoutParams(-1, -1));
        rootView.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(rootView);

        SharedPreferences sp = getSharedPreferences("hub", MODE_PRIVATE);
        if (!sp.getBoolean("welcomed", false)) {
            sp.edit().putBoolean("welcomed", true).apply();
            new AlertDialog.Builder(this, THEME)
                    .setTitle("Autorisations")
                    .setMessage("Pour que tes projets web fonctionnent sans limite (micro, caméra, "
                            + "localisation, notifications, fichiers), l'appli va te demander les "
                            + "autorisations d'un coup. Tu pourras les redemander plus tard avec le menu ⋮.")
                    .setPositiveButton("Continuer", (d, w) -> {
                        if (!Perms.requestAll(this, RC_PERMS)) Perms.batteryExemption(this);
                    })
                    .setCancelable(false).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        items.clear();
        items.addAll(store.load());
        iconCache.clear();
        adapter.notifyDataSetChanged();
        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == RC_PERMS) Perms.batteryExemption(this);
    }

    private void open(Project p) {
        if (p.type == Project.HTML && !store.hasCode(p.id)) {
            Toast.makeText(this, "Aucun code importé pour ce projet", Toast.LENGTH_SHORT).show();
            startEdit(p, true);
            return;
        }
        Intent i = new Intent(this, ProjectActivity.class);
        i.setData(Uri.parse("hub://project/" + p.id));
        i.putExtra("id", p.id);
        startActivity(i);
    }

    private void startEdit(Project p, boolean autoSource) {
        Intent i = new Intent(this, EditActivity.class);
        if (p != null) i.putExtra("id", p.id);
        i.putExtra("autoSource", autoSource);
        startActivityForResult(i, RC_EDIT);
    }

    private void showItemMenu(final Project p) {
        final List<String> labels = new ArrayList<>();
        labels.add("Ouvrir");
        labels.add("Modifier");
        if (p.type == Project.HTML) labels.add("Remplacer le code");
        labels.add("Supprimer");
        new AlertDialog.Builder(this, THEME).setTitle(p.name)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    String l = labels.get(which);
                    if (l.equals("Ouvrir")) open(p);
                    else if (l.equals("Modifier")) startEdit(p, false);
                    else if (l.equals("Remplacer le code")) startEdit(p, true);
                    else confirmDelete(p);
                }).show();
    }

    private void confirmDelete(final Project p) {
        new AlertDialog.Builder(this, THEME).setTitle("Supprimer « " + p.name + " » ?")
                .setMessage("Le bouton, son icône et le code stocké dans l'appli seront effacés.")
                .setPositiveButton("Supprimer", (d, w) -> {
                    try {
                        store.delete(p.id);
                    } catch (IOException e) {
                        Toast.makeText(this, "Suppression impossible", Toast.LENGTH_SHORT).show();
                    }
                    reload();
                })
                .setNegativeButton("Annuler", null).show();
    }

    private void showMenu() {
        String[] l = {"Accorder toutes les autorisations", "Autoriser l'activité en arrière-plan (batterie)",
                "Réglages Android de l'appli", "À propos"};
        new AlertDialog.Builder(this, THEME).setItems(l, (d, which) -> {
            if (which == 0) {
                if (!Perms.requestAll(this, 3)) {
                    Toast.makeText(this, "Tout est déjà accordé", Toast.LENGTH_SHORT).show();
                }
            } else if (which == 1) {
                Perms.batteryExemption(this);
            } else if (which == 2) {
                Perms.appSettings(this);
            } else {
                new AlertDialog.Builder(this, THEME).setTitle("Hub Projets 0.1")
                        .setMessage("Un bouton par projet web : fichier HTML / zip stocké dans l'appli, "
                                + "lien web, ou serveur (adresse + port). Appui long sur un bouton pour "
                                + "le modifier ou remplacer son code.")
                        .setPositiveButton("OK", null).show();
            }
        }).show();
    }

    private Bitmap iconFor(Project p) {
        Bitmap b = iconCache.get(p.id);
        if (b != null) return b;
        if (p.hasIcon) {
            File f = store.iconFile(p.id);
            if (f.exists()) b = BitmapFactory.decodeFile(f.getAbsolutePath());
        }
        if (b == null) b = Ui.letterIcon(p.name, 256);
        iconCache.put(p.id, b);
        return b;
    }

    private class TileAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int i) {
            return items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Project p = items.get(pos);
            LinearLayout tile = new LinearLayout(MainActivity.this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER_HORIZONTAL);
            tile.setPadding(Ui.dp(MainActivity.this, 4), Ui.dp(MainActivity.this, 4),
                    Ui.dp(MainActivity.this, 4), Ui.dp(MainActivity.this, 4));

            ImageView iv = new ImageView(MainActivity.this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(iconFor(p));
            iv.setBackgroundColor(Ui.CARD);
            final int radius = Ui.dp(MainActivity.this, 18);
            iv.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
                }
            });
            iv.setClipToOutline(true);
            int size = Ui.dp(MainActivity.this, 72);
            tile.addView(iv, new LinearLayout.LayoutParams(size, size));

            TextView name = Ui.text(MainActivity.this, p.name, 12, Ui.TEXT, false);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
            nlp.topMargin = Ui.dp(MainActivity.this, 6);
            tile.addView(name, nlp);
            return tile;
        }
    }
}
