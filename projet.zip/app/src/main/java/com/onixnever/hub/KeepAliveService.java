package com.onixnever.hub;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.util.LinkedHashMap;

/**
 * Service au premier plan : garde l'appli (et donc les pages web ouvertes) en vie
 * quand l'écran s'éteint ou qu'on change d'appli. Une seule notification pour tous les projets actifs.
 */
public class KeepAliveService extends Service {
    private static final String CHANNEL = "keepalive";
    private static final int NOTIF_ID = 4242;
    private static final String ACT_ADD = "com.onixnever.hub.ADD";
    private static final String ACT_STOP = "com.onixnever.hub.STOP";

    private static KeepAliveService inst;
    private final LinkedHashMap<String, String> active = new LinkedHashMap<>();
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    /** À appeler depuis une activité au premier plan. */
    public static void add(Context c, String id, String name) {
        Intent i = new Intent(c, KeepAliveService.class).setAction(ACT_ADD)
                .putExtra("id", id).putExtra("name", name);
        c.startForegroundService(i);
    }

    public static void remove(String id) {
        if (inst != null) inst.drop(id);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACT_STOP.equals(action)) {
            sendBroadcast(new Intent(ProjectActivity.ACTION_STOP_ALL).setPackage(getPackageName()));
            active.clear();
            shutdown();
            return START_NOT_STICKY;
        }
        if (ACT_ADD.equals(action)) {
            active.put(intent.getStringExtra("id"), intent.getStringExtra("name"));
        }
        goForeground();
        return START_NOT_STICKY;
    }

    private void goForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Projets actifs",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification n = build();
        if (Build.VERSION.SDK_INT >= 29) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
            if (Perms.has(this, android.Manifest.permission.RECORD_AUDIO)) {
                type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
            try {
                startForeground(NOTIF_ID, n, type);
            } catch (SecurityException e) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            }
        } else {
            startForeground(NOTIF_ID, n);
        }
        acquireLocks();
    }

    private Notification build() {
        StringBuilder names = new StringBuilder();
        for (String s : active.values()) {
            if (names.length() > 0) names.append(", ");
            names.append(s);
        }
        Intent open;
        if (active.size() == 1) {
            String id = active.keySet().iterator().next();
            open = new Intent(this, ProjectActivity.class)
                    .setData(Uri.parse("hub://project/" + id)).putExtra("id", id);
        } else {
            open = new Intent(this, MainActivity.class);
        }
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        int imm = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open, imm);
        PendingIntent stopPi = PendingIntent.getService(this, 1,
                new Intent(this, KeepAliveService.class).setAction(ACT_STOP), imm);

        Notification.Action stop = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat), "Arrêter", stopPi).build();
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(active.size() > 1 ? active.size() + " projets actifs" : "Projet actif")
                .setContentText(names.toString())
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(stop)
                .build();
    }

    private void acquireLocks() {
        if (wakeLock == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "hub:keepalive");
            wakeLock.setReferenceCounted(false);
        }
        if (!wakeLock.isHeld()) wakeLock.acquire();
        if (wifiLock == null) {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                int mode = Build.VERSION.SDK_INT >= 29
                        ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                wifiLock = wm.createWifiLock(mode, "hub:wifi");
                wifiLock.setReferenceCounted(false);
            }
        }
        if (wifiLock != null && !wifiLock.isHeld()) wifiLock.acquire();
    }

    private void drop(String id) {
        active.remove(id);
        if (active.isEmpty()) {
            shutdown();
        } else {
            getSystemService(NotificationManager.class).notify(NOTIF_ID, build());
        }
    }

    private void shutdown() {
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
