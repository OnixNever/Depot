package com.onixnever.hub;

import org.json.JSONException;
import org.json.JSONObject;

/** Un projet = un bouton du hub. */
public class Project {
    public static final int HTML = 0;   // code HTML (ou zip) stocké dans l'appli
    public static final int LINK = 1;   // lien web complet
    public static final int SERVER = 2; // serveur : protocole + adresse + port + chemin

    public String id = "";
    public String name = "";
    public int type = HTML;
    public String url = "";
    public String scheme = "http";
    public String host = "";
    public String port = "";
    public String path = "";
    public boolean hasIcon = false;
    public boolean keepAlive = true;
    public boolean keepScreenOn = false;

    public static String newId() {
        return Long.toString(System.currentTimeMillis(), 36)
                + Integer.toString((int) (Math.random() * 1296), 36);
    }

    /** Hôte virtuel d'un projet HTML : une origine https isolée par projet. */
    public static String hostFor(String id) {
        return id + ".hub.invalid";
    }

    public String startUrl() {
        if (type == HTML) {
            return "https://" + hostFor(id) + "/index.html";
        }
        if (type == SERVER) {
            String h = host.trim().replaceFirst("^[a-zA-Z]+://", "");
            String p = path == null ? "" : path.trim();
            int slash = h.indexOf('/');
            if (slash >= 0) {
                if (p.isEmpty()) p = h.substring(slash);
                h = h.substring(0, slash);
            }
            if (!p.isEmpty() && !p.startsWith("/")) p = "/" + p;
            String pr = port == null ? "" : port.trim();
            return scheme + "://" + h + (pr.isEmpty() ? "" : ":" + pr) + p;
        }
        String u = url.trim();
        if (!u.contains("://")) u = "http://" + u;
        return u;
    }

    public JSONObject toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("name", name);
            o.put("type", type);
            o.put("url", url);
            o.put("scheme", scheme);
            o.put("host", host);
            o.put("port", port);
            o.put("path", path);
            o.put("hasIcon", hasIcon);
            o.put("keepAlive", keepAlive);
            o.put("keepScreenOn", keepScreenOn);
            return o;
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    public static Project fromJson(JSONObject o) {
        Project p = new Project();
        p.id = o.optString("id");
        p.name = o.optString("name");
        p.type = o.optInt("type", HTML);
        p.url = o.optString("url");
        p.scheme = o.optString("scheme", "http");
        p.host = o.optString("host");
        p.port = o.optString("port");
        p.path = o.optString("path");
        p.hasIcon = o.optBoolean("hasIcon", false);
        p.keepAlive = o.optBoolean("keepAlive", true);
        p.keepScreenOn = o.optBoolean("keepScreenOn", false);
        return p;
    }
}
