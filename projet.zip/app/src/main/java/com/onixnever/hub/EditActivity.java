package com.onixnever.hub;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Création / modification d'un projet : nom, icône (avec cadrage), type et source du code. */
public class EditActivity extends Activity {
    private static final int RC_ICON = 11, RC_CODE = 12;
    private static final int THEME = AlertDialog.THEME_DEVICE_DEFAULT_DARK;

    private interface Job {
        void run() throws Exception;
    }

    private Store store;
    private Project p;
    private boolean isNew, committed, autoSource;
    private int type = Project.HTML;
    private String scheme = "http";
    private Bitmap pendingIcon;
    private boolean removeIcon;

    private EditText fName, fUrl, fHost, fPort, fPath;
    private ImageView iconView;
    private TextView codeStatus;
    private final TextView[] tabs = new TextView[3];
    private final TextView[] schemeBtns = new TextView[2];
    private LinearLayout secHtml, secLink, secServer;
    private Switch swKeep, swScreen;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.style(this);
        store = new Store(this);
        autoSource = getIntent().getBooleanExtra("autoSource", false);
        p = store.get(getIntent().getStringExtra("id"));
        if (p == null) {
            p = new Project();
            p.id = Project.newId();
            isNew = true;
        }
        type = p.type;
        scheme = "https".equals(p.scheme) ? "https" : "http";
        buildUi();
        selectType(type);
        refreshCodeStatus();
        refreshIcon();
        if (autoSource && !isNew && type == Project.HTML) showSourceDialog();
    }

    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
        l.topMargin = Ui.dp(this, top);
        return l;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));

        col.addView(Ui.text(this, isNew ? "Nouveau projet" : "Modifier le projet", 24, Ui.TEXT, true));

        // Icône
        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setOrientation(LinearLayout.HORIZONTAL);
        iconRow.setGravity(Gravity.CENTER_VERTICAL);
        iconView = new ImageView(this);
        iconView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final int r = Ui.dp(this, 22);
        iconView.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r);
            }
        });
        iconView.setClipToOutline(true);
        int sz = Ui.dp(this, 88);
        iconRow.addView(iconView, new LinearLayout.LayoutParams(sz, sz));
        LinearLayout iconBtns = new LinearLayout(this);
        iconBtns.setOrientation(LinearLayout.VERTICAL);
        iconBtns.setPadding(Ui.dp(this, 14), 0, 0, 0);
        iconBtns.addView(Ui.button(this, "Choisir une icône", Ui.CARD2, v -> pickIcon()));
        iconBtns.addView(Ui.button(this, "Retirer l'icône", Ui.CARD, v -> {
            pendingIcon = null;
            removeIcon = true;
            refreshIcon();
        }), lp(8));
        iconRow.addView(iconBtns, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(iconRow, lp(18));

        // Nom
        col.addView(Ui.text(this, "Nom", 13, Ui.MUTED, false), lp(18));
        fName = Ui.input(this, "Ex. Entraînement tactique");
        fName.setText(p.name);
        fName.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        col.addView(fName, lp(6));

        // Type
        col.addView(Ui.text(this, "Type de projet", 13, Ui.MUTED, false), lp(18));
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] tn = {"Fichier HTML", "Lien web", "Serveur + port"};
        for (int i = 0; i < 3; i++) {
            final int t = i;
            tabs[i] = Ui.text(this, tn[i], 14, Ui.TEXT, true);
            tabs[i].setGravity(Gravity.CENTER);
            tabs[i].setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
            tabs[i].setOnClickListener(v -> selectType(t));
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) l.leftMargin = Ui.dp(this, 6);
            tabRow.addView(tabs[i], l);
        }
        col.addView(tabRow, lp(6));

        // Section HTML
        secHtml = new LinearLayout(this);
        secHtml.setOrientation(LinearLayout.VERTICAL);
        codeStatus = Ui.text(this, "", 14, Ui.MUTED, false);
        secHtml.addView(codeStatus, lp(0));
        secHtml.addView(Ui.button(this, "Choisir un fichier HTML ou un zip", Ui.ACCENT, v -> pickCodeFile()), lp(10));
        secHtml.addView(Ui.button(this, "Coller du code", Ui.CARD2, v -> pasteCode()), lp(8));
        secHtml.addView(Ui.button(this, "Télécharger depuis une URL (GitHub raw…)", Ui.CARD2, v -> urlCode()), lp(8));
        col.addView(secHtml, lp(14));

        // Section lien
        secLink = new LinearLayout(this);
        secLink.setOrientation(LinearLayout.VERTICAL);
        secLink.addView(Ui.text(this, "Adresse (http ou https)", 13, Ui.MUTED, false), lp(0));
        fUrl = Ui.input(this, "https://exemple.com/page");
        fUrl.setText(p.url);
        fUrl.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        secLink.addView(fUrl, lp(6));
        col.addView(secLink, lp(14));

        // Section serveur
        secServer = new LinearLayout(this);
        secServer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout sRow = new LinearLayout(this);
        sRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] sn = {"http", "https"};
        for (int i = 0; i < 2; i++) {
            final String s = sn[i];
            schemeBtns[i] = Ui.text(this, s.toUpperCase(), 14, Ui.TEXT, true);
            schemeBtns[i].setGravity(Gravity.CENTER);
            schemeBtns[i].setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
            schemeBtns[i].setOnClickListener(v -> {
                scheme = s;
                refreshScheme();
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) l.leftMargin = Ui.dp(this, 6);
            sRow.addView(schemeBtns[i], l);
        }
        secServer.addView(Ui.text(this, "Protocole", 13, Ui.MUTED, false), lp(0));
        secServer.addView(sRow, lp(6));
        secServer.addView(Ui.text(this, "Adresse (IP, nom ou tunnel)", 13, Ui.MUTED, false), lp(12));
        fHost = Ui.input(this, "192.168.1.20 ou monpc.trycloudflare.com");
        fHost.setText(p.host);
        fHost.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        secServer.addView(fHost, lp(6));
        secServer.addView(Ui.text(this, "Port (facultatif)", 13, Ui.MUTED, false), lp(12));
        fPort = Ui.input(this, "8000");
        fPort.setText(p.port);
        fPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        secServer.addView(fPort, lp(6));
        secServer.addView(Ui.text(this, "Chemin (facultatif)", 13, Ui.MUTED, false), lp(12));
        fPath = Ui.input(this, "/index.html");
        fPath.setText(p.path);
        secServer.addView(fPath, lp(6));
        col.addView(secServer, lp(14));

        // Options
        col.addView(Ui.text(this, "Options", 13, Ui.MUTED, false), lp(22));
        swKeep = new Switch(this);
        swKeep.setText("Rester actif en arrière-plan (écran éteint)");
        swKeep.setTextColor(Ui.TEXT);
        swKeep.setChecked(p.keepAlive);
        col.addView(swKeep, lp(8));
        swScreen = new Switch(this);
        swScreen.setText("Garder l'écran allumé");
        swScreen.setTextColor(Ui.TEXT);
        swScreen.setChecked(p.keepScreenOn);
        col.addView(swScreen, lp(14));

        // Boutons
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button cancel = Ui.button(this, "Annuler", Ui.CARD2, v -> finish());
        row.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1f));
        Button save = Ui.button(this, "Enregistrer", Ui.ACCENT, v -> save());
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, -2, 1f);
        sl.leftMargin = Ui.dp(this, 10);
        row.addView(save, sl);
        col.addView(row, lp(26));

        setContentView(sv);
    }

    private void selectType(int t) {
        type = t;
        for (int i = 0; i < 3; i++) {
            tabs[i].setBackground(Ui.rect(this, i == t ? Ui.ACCENT : Ui.CARD, 12));
        }
        secHtml.setVisibility(t == Project.HTML ? View.VISIBLE : View.GONE);
        secLink.setVisibility(t == Project.LINK ? View.VISIBLE : View.GONE);
        secServer.setVisibility(t == Project.SERVER ? View.VISIBLE : View.GONE);
        refreshScheme();
    }

    private void refreshScheme() {
        for (int i = 0; i < 2; i++) {
            boolean on = (i == 0) == "http".equals(scheme);
            schemeBtns[i].setBackground(Ui.rect(this, on ? Ui.ACCENT : Ui.CARD, 12));
        }
    }

    private void refreshIcon() {
        Bitmap b = null;
        if (pendingIcon != null) {
            b = pendingIcon;
        } else if (p.hasIcon && !removeIcon) {
            File f = store.iconFile(p.id);
            if (f.exists()) b = BitmapFactory.decodeFile(f.getAbsolutePath());
        }
        if (b == null) {
            String n = fName == null ? p.name : fName.getText().toString();
            b = Ui.letterIcon(n, 256);
        }
        iconView.setImageBitmap(b);
    }

    private void refreshCodeStatus() {
        File f = new File(store.codeDir(p.id), "index.html");
        if (f.exists()) {
            String d = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                    .format(new Date(f.lastModified()));
            codeStatus.setText("Code présent · " + human(f.length()) + " · importé le " + d);
        } else {
            codeStatus.setText("Aucun code importé pour l'instant.");
        }
    }

    private static String human(long n) {
        if (n < 1024) return n + " o";
        if (n < 1024 * 1024) return (n / 1024) + " Ko";
        return String.format("%.1f Mo", n / 1048576.0);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ code

    private void showSourceDialog() {
        String[] l = {"Choisir un fichier HTML ou un zip", "Coller du code", "Télécharger depuis une URL"};
        new AlertDialog.Builder(this, THEME).setTitle("Remplacer le code")
                .setItems(l, (d, w) -> {
                    if (w == 0) pickCodeFile();
                    else if (w == 1) pasteCode();
                    else urlCode();
                }).show();
    }

    private void pickCodeFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, RC_CODE);
    }

    private void pasteCode() {
        final EditText e = new EditText(this);
        e.setHint("Colle ici le code HTML complet");
        e.setHintTextColor(Ui.MUTED);
        e.setTextColor(Ui.TEXT);
        e.setMinLines(6);
        e.setGravity(Gravity.TOP);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        new AlertDialog.Builder(this, THEME).setTitle("Coller du code").setView(e)
                .setPositiveButton("Importer", (d, w) -> {
                    final String code = e.getText().toString();
                    if (code.trim().isEmpty()) return;
                    runImport(() -> store.importFromStream(
                            new ByteArrayInputStream(code.getBytes("UTF-8")), p.id));
                })
                .setNegativeButton("Annuler", null).show();
    }

    private void urlCode() {
        final EditText e = new EditText(this);
        e.setHint("https://raw.githubusercontent.com/…");
        e.setHintTextColor(Ui.MUTED);
        e.setTextColor(Ui.TEXT);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this, THEME).setTitle("Télécharger le code")
                .setMessage("Lien direct vers un fichier .html ou .zip. Les liens github.com/…/blob/… sont convertis automatiquement (dépôts publics).")
                .setView(e)
                .setPositiveButton("Télécharger", (d, w) -> {
                    final String u = fixGithub(e.getText().toString().trim());
                    if (u.isEmpty()) return;
                    runImport(() -> {
                        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(30000);
                        c.setInstanceFollowRedirects(true);
                        if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
                        try (InputStream in = c.getInputStream()) {
                            store.importFromStream(in, p.id);
                        } finally {
                            c.disconnect();
                        }
                    });
                })
                .setNegativeButton("Annuler", null).show();
    }

    private static String fixGithub(String u) {
        Matcher m = Pattern.compile("^https://github\\.com/([^/]+)/([^/]+)/blob/(.+)$").matcher(u);
        return m.matches() ? "https://raw.githubusercontent.com/" + m.group(1) + "/" + m.group(2) + "/" + m.group(3) : u;
    }

    private void runImport(final Job job) {
        toast("Import en cours…");
        new Thread(() -> {
            try {
                job.run();
                runOnUiThread(() -> {
                    toast("Code importé");
                    refreshCodeStatus();
                    if (autoSource && !isNew) finish();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> toast("Échec de l'import : " + e.getMessage()));
            }
        }).start();
    }

    // ------------------------------------------------------------------ icône

    private void pickIcon() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, RC_ICON);
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (code == RC_ICON) {
            try {
                openCrop(decode(uri));
            } catch (Exception e) {
                toast("Image illisible");
            }
        } else if (code == RC_CODE) {
            runImport(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    store.importFromStream(in, p.id);
                }
            });
        }
    }

    private Bitmap decode(Uri uri) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        int max = Math.max(o.outWidth, o.outHeight);
        int ss = 1;
        while (max / ss > 1600) ss *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = ss;
        Bitmap b;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            b = BitmapFactory.decodeStream(in, null, o);
        }
        if (b == null) throw new IOException("Image illisible");
        int rot = 0;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
            if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
        } catch (Exception ignored) {
        }
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
        }
        return b;
    }

    private void openCrop(Bitmap src) {
        final Dialog d = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(Ui.BG);
        TextView hint = Ui.text(this, "Glisse pour déplacer · pince pour zoomer", 14, Ui.MUTED, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 8));
        l.addView(hint, new LinearLayout.LayoutParams(-1, -2));
        final CropView cv = new CropView(this);
        cv.setBitmap(src);
        l.addView(cv, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), 0);
        r1.addView(Ui.button(this, "−", Ui.CARD2, v -> cv.zoomCenter(1f / 1.15f)), new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(Ui.button(this, "+", Ui.CARD2, v -> cv.zoomCenter(1.15f)), wl(6));
        r1.addView(Ui.button(this, "Remplir", Ui.CARD2, v -> cv.fit(true)), wl(6));
        r1.addView(Ui.button(this, "Ajuster", Ui.CARD2, v -> cv.fit(false)), wl(6));
        l.addView(r1, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 16));
        r2.addView(Ui.button(this, "Annuler", Ui.CARD2, v -> d.dismiss()), new LinearLayout.LayoutParams(0, -2, 1f));
        r2.addView(Ui.button(this, "Valider", Ui.ACCENT, v -> {
            pendingIcon = cv.export(256);
            removeIcon = false;
            refreshIcon();
            d.dismiss();
        }), wl(10));
        l.addView(r2, new LinearLayout.LayoutParams(-1, -2));

        d.setContentView(l);
        d.show();
    }

    private LinearLayout.LayoutParams wl(int left) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, -2, 1f);
        l.leftMargin = Ui.dp(this, left);
        return l;
    }

    // ------------------------------------------------------------------ enregistrement

    private void save() {
        String name = fName.getText().toString().trim();
        if (name.isEmpty()) name = "Projet";
        p.name = name;
        p.type = type;
        if (type == Project.LINK) {
            p.url = fUrl.getText().toString().trim();
            if (p.url.isEmpty()) {
                toast("Entre une adresse");
                return;
            }
        } else if (type == Project.SERVER) {
            p.host = fHost.getText().toString().trim();
            p.port = fPort.getText().toString().trim();
            p.path = fPath.getText().toString().trim();
            p.scheme = scheme;
            if (p.host.isEmpty()) {
                toast("Entre une adresse de serveur");
                return;
            }
        } else if (!store.hasCode(p.id)) {
            toast("Importe d'abord du code (fichier, zip, collage ou URL)");
            return;
        }
        p.keepAlive = swKeep.isChecked();
        p.keepScreenOn = swScreen.isChecked();
        try {
            if (pendingIcon != null) {
                try (FileOutputStream o = new FileOutputStream(store.iconFile(p.id))) {
                    pendingIcon.compress(Bitmap.CompressFormat.PNG, 100, o);
                }
                p.hasIcon = true;
            } else if (removeIcon) {
                store.iconFile(p.id).delete();
                p.hasIcon = false;
            }
            store.upsert(p);
        } catch (IOException e) {
            toast("Enregistrement impossible : " + e.getMessage());
            return;
        }
        committed = true;
        setResult(RESULT_OK);
        finish();
    }

    @Override
    protected void onDestroy() {
        // Nouveau projet abandonné : on nettoie le code déjà importé.
        if (isNew && !committed) store.deleteFiles(p.id);
        super.onDestroy();
    }
}
