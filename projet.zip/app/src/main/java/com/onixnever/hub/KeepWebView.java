package com.onixnever.hub;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;

/** WebView qui reste « visible » pour Chromium même écran éteint / appli en arrière-plan. */
public class KeepWebView extends WebView {
    public boolean keepAlive = false;

    public KeepWebView(Context c) {
        super(c);
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        if (keepAlive && visibility != View.GONE) {
            super.onWindowVisibilityChanged(View.VISIBLE);
        } else {
            super.onWindowVisibilityChanged(visibility);
        }
    }
}
