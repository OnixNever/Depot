package com.onixnever.hub;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Ouvre un projet dans une WebView avec toutes les autorisations accordées. */
public class ProjectActivity extends Activity {
    static final String ACTION_STOP_ALL = "com.onixnever.hub.STOP_ALL";
    private static final int RC_WEB = 21, RC_GEO = 22, RC_FILE = 23;
    private static final int THEME = AlertDialog.THEME_DEVICE_DEFAULT_DARK;

    private Project project;
    private Store store;
    private KeepWebView web;
    private FrameLayout root;
    private ProgressBar bar;
    private HubChrome chrome;
    private boolean keepAlive;
    private boolean registered;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private PermissionRequest pendingWebPerm;
    private GeolocationPermissions.Callback pendingGeoCb;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> fileCb;

    private final BroadcastReceiver stopReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        project = store.get(getIntent().getStringExtra("id"));
        if (project == null) {
            Toast.makeText(this, "Projet introuvable", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        setTitle(project.name);
        keepAlive = project.keepAlive;
        if (project.keepScreenOn) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        web = new KeepWebView(this);
        web.keepAlive = keepAlive;
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        root.addView(bar, new FrameLayout.LayoutParams(-1, Ui.dp(this, 3)));
        setContentView(root);

        setupWebView();

        IntentFilter f = new IntentFilter(ACTION_STOP_ALL);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stopReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stopReceiver, f);
        }
        registered = true;

        if (keepAlive) KeepAliveService.add(this, project.id, project.name);
        web.loadUrl(project.startUrl());
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setGeolocationEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);
        WebView.setWebContentsDebuggingEnabled(true);

        if (project.type != Project.LINK) web.addJavascriptInterface(new Bridge(), "HubBridge");

        chrome = new HubChrome();
        web.setWebViewClient(new HubClient());
        web.setWebChromeClient(chrome);
        web.setDownloadListener((url, ua, cd, mime, len) -> handleDownload(url, ua, cd, mime));
    }

    // ------------------------------------------------------------------ client

    private class HubClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (project.type == Project.HTML && "https".equals(u.getScheme())
                    && Project.hostFor(project.id).equals(u.getHost())) {
                return serveLocal(u);
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String sc = u.getScheme();
            if (sc == null) return false;
            if (sc.equals("http") || sc.equals("https") || sc.equals("about") || sc.equals("data")
                    || sc.equals("blob") || sc.equals("javascript") || sc.equals("file")) {
                return false;
            }
            try {
                Intent i = sc.equals("intent")
                        ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                        : new Intent(Intent.ACTION_VIEW, u);
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(ProjectActivity.this, "Aucune appli pour ouvrir ce lien", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        @Override
        public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
            h.proceed(); // certificats auto-signés de tes serveurs locaux
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (!r.isForMainFrame()) return;
            String url = r.getUrl().toString();
            String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                    + "<body style='background:#0f1115;color:#e8eaf0;font-family:sans-serif;padding:32px'>"
                    + "<h2>Impossible d'ouvrir la page</h2>"
                    + "<p style='color:#9aa0ae'>" + TextUtils.htmlEncode(String.valueOf(e.getDescription())) + "</p>"
                    + "<p style='word-break:break-all'>" + TextUtils.htmlEncode(url) + "</p>"
                    + "<p><a href='" + TextUtils.htmlEncode(url) + "' style='color:#4c8dff;font-size:20px'>Réessayer</a></p>"
                    + "</body></html>";
            v.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
        }
    }

    private WebResourceResponse serveLocal(Uri u) {
        try {
            String p = u.getPath();
            if (p == null || p.isEmpty() || p.equals("/")) p = "/index.html";
            File base = store.codeDir(project.id);
            File f = new File(base, p);
            if (!f.getCanonicalPath().startsWith(base.getCanonicalPath() + File.separator)
                    || !f.isFile()) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                        new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
            }
            String ext = MimeTypeMap.getFileExtensionFromUrl(f.getName());
            String mime = mimeFor(f.getName(), ext);
            String enc = (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json")
                    || mime.contains("xml") || mime.contains("svg")) ? "utf-8" : null;
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-cache");
            return new WebResourceResponse(mime, enc, 200, "OK", h, new FileInputStream(f));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 500, "Error",
                    new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mimeFor(String name, String ext) {
        String n = name.toLowerCase();
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        if (n.endsWith(".js") || n.endsWith(".mjs")) return "text/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json") || n.endsWith(".webmanifest")) return "application/json";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".wasm")) return "application/wasm";
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m != null ? m : "application/octet-stream";
    }

    // ------------------------------------------------------------------ chrome

    private class HubChrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            bar.setProgress(p);
            bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> {
                List<String> need = new ArrayList<>();
                for (String r : req.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                            && !Perms.has(ProjectActivity.this, android.Manifest.permission.CAMERA)) {
                        need.add(android.Manifest.permission.CAMERA);
                    } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                            && !Perms.has(ProjectActivity.this, android.Manifest.permission.RECORD_AUDIO)) {
                        need.add(android.Manifest.permission.RECORD_AUDIO);
                    }
                }
                if (need.isEmpty()) {
                    req.grant(req.getResources());
                } else {
                    pendingWebPerm = req;
                    requestPermissions(need.toArray(new String[0]), RC_WEB);
                }
            });
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest req) {
            if (pendingWebPerm == req) pendingWebPerm = null;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (Perms.has(ProjectActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                    || Perms.has(ProjectActivity.this, android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
                cb.invoke(origin, true, true);
            } else {
                pendingGeoOrigin = origin;
                pendingGeoCb = cb;
                requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION}, RC_GEO);
            }
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(params.createIntent(), RC_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            web.setVisibility(View.GONE);
            root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            root.removeView(customView);
            customView = null;
            web.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(0);
            if (customCb != null) customCb.onCustomViewHidden();
            customCb = null;
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
            new AlertDialog.Builder(ProjectActivity.this, THEME).setMessage(msg)
                    .setPositiveButton("OK", (d, w) -> r.confirm())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
            new AlertDialog.Builder(ProjectActivity.this, THEME).setMessage(msg)
                    .setPositiveButton("OK", (d, w) -> r.confirm())
                    .setNegativeButton("Annuler", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
            final EditText e = new EditText(ProjectActivity.this);
            e.setText(def);
            new AlertDialog.Builder(ProjectActivity.this, THEME).setMessage(msg).setView(e)
                    .setPositiveButton("OK", (d, w) -> r.confirm(e.getText().toString()))
                    .setNegativeButton("Annuler", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }
    }

    // --------------------------------------------------------------- téléchargements

    private void handleDownload(String url, String ua, String cd, String mime) {
        String name = URLUtil.guessFileName(url, cd, mime);
        if (url.startsWith("data:")) {
            saveDataUrl(url, null);
        } else if (url.startsWith("blob:")) {
            if (project.type == Project.LINK) {
                Toast.makeText(this, "Téléchargement non supporté pour ce lien", Toast.LENGTH_SHORT).show();
                return;
            }
            String js = "(function(){var x=new XMLHttpRequest();x.open('GET','" + jsEsc(url)
                    + "',true);x.responseType='blob';x.onload=function(){var r=new FileReader();"
                    + "r.onloadend=function(){HubBridge.saveDataUrl(r.result,'" + jsEsc(name)
                    + "');};r.readAsDataURL(x.response);};x.send();})();";
            web.evaluateJavascript(js, null);
        } else {
            try {
                DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
                rq.setMimeType(mime);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) rq.addRequestHeader("Cookie", ck);
                rq.addRequestHeader("User-Agent", ua);
                rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(rq);
                Toast.makeText(this, "Téléchargement : " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Téléchargement impossible", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private static String jsEsc(String s) {
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "");
    }

    private void saveDataUrl(String dataUrl, String fallbackName) {
        try {
            int comma = dataUrl.indexOf(',');
            String meta = dataUrl.substring(dataUrl.startsWith("data:") ? 5 : 0, comma);
            String payload = dataUrl.substring(comma + 1);
            boolean b64 = meta.endsWith(";base64");
            String mime = meta.replace(";base64", "").split(";")[0];
            if (mime.isEmpty()) mime = "application/octet-stream";
            byte[] data = b64 ? Base64.decode(payload, Base64.DEFAULT) : Uri.decode(payload).getBytes("UTF-8");
            String name = (fallbackName != null && !fallbackName.isEmpty())
                    ? fallbackName : URLUtil.guessFileName("download", null, mime);
            saveToDownloads(name, mime, data);
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Enregistrement impossible", Toast.LENGTH_SHORT).show());
        }
    }

    private void saveToDownloads(String name, String mime, byte[] data) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            try (OutputStream o = getContentResolver().openOutputStream(u)) {
                o.write(data);
            }
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            dir.mkdirs();
            try (FileOutputStream o = new FileOutputStream(new File(dir, name))) {
                o.write(data);
            }
        }
        final String shown = name;
        runOnUiThread(() -> Toast.makeText(this, "Enregistré dans Téléchargements : " + shown,
                Toast.LENGTH_LONG).show());
    }

    /** Pont JavaScript (projets HTML et serveurs uniquement) pour enregistrer les blob:/data:. */
    private class Bridge {
        @JavascriptInterface
        public void saveDataUrl(String dataUrl, String name) {
            ProjectActivity.this.saveDataUrl(dataUrl, name);
        }
    }

    // ----------------------------------------------------------------- résultats

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == RC_WEB && pendingWebPerm != null) {
            List<String> ok = new ArrayList<>();
            for (String r : pendingWebPerm.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                    if (Perms.has(this, android.Manifest.permission.CAMERA)) ok.add(r);
                } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                    if (Perms.has(this, android.Manifest.permission.RECORD_AUDIO)) ok.add(r);
                } else {
                    ok.add(r);
                }
            }
            if (ok.isEmpty()) pendingWebPerm.deny(); else pendingWebPerm.grant(ok.toArray(new String[0]));
            pendingWebPerm = null;
        } else if (code == RC_GEO && pendingGeoCb != null) {
            boolean granted = Perms.has(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                    || Perms.has(this, android.Manifest.permission.ACCESS_COARSE_LOCATION);
            pendingGeoCb.invoke(pendingGeoOrigin, granted, granted);
            pendingGeoCb = null;
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == RC_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCb = null;
        }
    }

    // ------------------------------------------------------------------ cycle de vie

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        // Projet « actif en arrière-plan » : on ne met JAMAIS la WebView en pause.
        if (web != null && !keepAlive) web.onPause();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            chrome.onHideCustomView();
        } else if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (registered) unregisterReceiver(stopReceiver);
        if (project != null) KeepAliveService.remove(project.id);
        if (web != null) {
            root.removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
