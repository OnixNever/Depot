package com.onixnever.hub;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Toutes les autorisations dont les projets web peuvent avoir besoin. */
final class Perms {
    private Perms() {
    }

    static List<String> wanted() {
        List<String> l = new ArrayList<>();
        l.add(Manifest.permission.CAMERA);
        l.add(Manifest.permission.RECORD_AUDIO);
        l.add(Manifest.permission.ACCESS_FINE_LOCATION);
        l.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.POST_NOTIFICATIONS);
            l.add(Manifest.permission.READ_MEDIA_IMAGES);
            l.add(Manifest.permission.READ_MEDIA_VIDEO);
            l.add(Manifest.permission.READ_MEDIA_AUDIO);
        } else {
            l.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (Build.VERSION.SDK_INT >= 31) l.add(Manifest.permission.BLUETOOTH_CONNECT);
        if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return l;
    }

    static boolean has(Context c, String perm) {
        return c.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    static List<String> missing(Context c) {
        List<String> m = new ArrayList<>();
        for (String p : wanted()) if (!has(c, p)) m.add(p);
        return m;
    }

    /** Demande tout ce qui manque. Retourne false s'il ne manquait rien. */
    static boolean requestAll(Activity a, int code) {
        List<String> m = missing(a);
        if (m.isEmpty()) return false;
        a.requestPermissions(m.toArray(new String[0]), code);
        return true;
    }

    static void batteryExemption(Activity a) {
        PowerManager pm = a.getSystemService(PowerManager.class);
        if (pm != null && pm.isIgnoringBatteryOptimizations(a.getPackageName())) {
            Toast.makeText(a, "Déjà autorisé en arrière-plan", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            a.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + a.getPackageName())));
        } catch (Exception e) {
            try {
                a.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    static void appSettings(Activity a) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + a.getPackageName()));
        a.startActivity(i);
    }
}
