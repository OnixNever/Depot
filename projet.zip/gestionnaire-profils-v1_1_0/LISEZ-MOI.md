# Gestionnaire de Profils — v1.0.0

Application Android : plusieurs profils de navigation isolés (cookies, connexions, stockage),
avec micro et caméra autorisés ou non profil par profil. Interface sombre.

## Fonctions
- Créer, renommer, recolorer, supprimer un profil (appui long ou ⋮ sur la liste, ⚙ dans le navigateur)
- Liste des profils sauvegardée (SharedPreferences), dernière page rétablie à la réouverture
- Changement rapide de profil : toucher la pastille colorée en haut
- Permissions micro / caméra réglées par profil ; tout le reste est refusé
- Barre d'adresse (URL ou recherche Google), barre de progression, bouton retour
- Suppression : efface cookies et données du profil puis supprime le profil WebView

## Compiler (sans Android Studio)
1. Poussez ce dossier dans un dépôt GitHub privé
2. Onglet Actions → « Build APK » → Run workflow
3. Téléchargez l'artefact `gestionnaire-profils-apk`, installez l'APK

## À vérifier sur le téléphone
- Un bandeau orange sur l'écran des profils signale que l'isolation n'est pas supportée
- Cookie posé dans un profil (ex. connexion) absent des autres
- Deux comptes Google / Claude différents dans deux profils
- Micro : accordé dans un profil avec l'option, refusé dans les autres
- Supprimer un profil puis en recréer un : aucune session restante

## Limites connues
- Les connexions (cookies) ne peuvent pas être copiées d'un profil à l'autre : un profil dupliqué repart déconnecté
- La connexion Google dépend du masquage de la WebView (User-Agent) : peut casser si Google durcit ses règles

## Nouveautés v0.3
- Palette de couleurs libre (carré saturation/luminosité + teinte) avec quelques couleurs rapides
- Pop-ups gérées dans le même profil (connexion Google « Se connecter avec Google » sur Claude) ; bouton retour pour fermer la pop-up

## Nouveautés v0.4
- Onglets multiples par profil (barre d'onglets, ＋ pour ouvrir, ✕ pour fermer) ; les onglets sont restaurés à la réouverture
- ⚙ dans le navigateur : nouvel onglet, actualiser, moteur de recherche du profil, mode clair/sombre, fermer l'onglet
- Les autorisations (micro, caméra), la création et la suppression de profils se gèrent depuis la liste, protégées par un code maître (créé à la première utilisation ; ⚙ de la liste pour le modifier)
- Mode clair / sombre (⚙ de la liste ou du navigateur)
- Moteur de recherche par défaut : DuckDuckGo, modifiable par profil (Google, Bing, Brave, Qwant)

Code maître oublié : désinstaller puis réinstaller l'appli (efface tous les profils).

## Nouveautés v0.5
- **Ouverture de liens** : l'appli apparaît dans « Ouvrir avec » pour les liens http/https (et peut être choisie comme navigateur par défaut). Une feuille de choix affiche chaque profil avec son « logo » (initiale sur dégradé de sa couleur) ; le lien s'ouvre dans un nouvel onglet du profil choisi.
- **Mode strict / libre par profil** (⚙ du navigateur). Strict par défaut : cookies tiers refusés, Safe Browsing actif, accès aux fichiers fermé. Libre : cookies tiers acceptés, Safe Browsing coupé, accès aux fichiers ouvert. Le passage en libre demande le code maître ; 🔓 s'affiche sur la pastille du profil. Les autorisations micro/caméra restent réglées par profil, indépendamment du mode.
- Les profils existants démarrent en mode strict.

## À vérifier (v0.5)
- Connexion Google / Claude / YouTube dans un profil en mode strict (les cookies tiers sont refusés : si une connexion échoue, passer ce profil en libre et le signaler)
- Lien reçu depuis une autre appli (message, mail) : la feuille de choix apparaît, le lien s'ouvre dans le bon profil
- Lien reçu alors que l'appli est déjà ouverte

## Nouveautés v0.6
- **Ouverture de fichiers locaux** : l'appli apparaît aussi dans « Ouvrir avec » pour les fichiers HTML, PDF, images, textes (txt, md, json, xml, csv), vidéos et audios. Même feuille de choix de profil que pour les liens ; le fichier s'ouvre dans un nouvel onglet du profil choisi.
- **Lecteur PDF intégré** (PdfRenderer d'Android) : pages chargées à la demande, zoom par pincement. Pas de sélection de texte ni de recherche pour l'instant ; PDF protégés par mot de passe non pris en charge.
- Les fichiers sont copiés dans le cache de l'appli et servis via une adresse interne `https://fichier.local/…` (aucun accès aux fichiers du téléphone n'est ouvert : le mode strict reste strict). Une page HTML ouverte ainsi doit être autonome (les liens relatifs vers d'autres fichiers du dossier ne fonctionnent pas).
- Après fermeture de l'appli, un onglet de fichier local rouvre l'accueil du profil (le fichier est purgé du cache à la fermeture).
- Zoom par pincement activé dans tous les onglets.

## À vérifier (v0.6)
- Fichier .html ouvert depuis « Mes fichiers » (Samsung) : l'appli est proposée, le profil se choisit, la page s'affiche et ses scripts tournent
- PDF : pages affichées, zoom au pincement, défilement fluide sur un PDF de plusieurs dizaines de pages
- Image, texte, vidéo : affichage correct (vidéo : lecture et avance rapide)
- Si l'appli n'apparaît toujours pas dans « Ouvrir avec » : désinstaller puis réinstaller l'APK, puis réessayer

## Nouveautés v0.7
- **Vrai mode libre** : micro, caméra et localisation sont accordés automatiquement aux pages (les cases micro / caméra du profil ne comptent plus tant que le profil est en libre) ; contenu mixte http/https autorisé ; en plus de cookies tiers, Safe Browsing coupé et accès fichiers déjà présents.
- Les pop-ups (connexion Google, etc.) reçoivent les mêmes autorisations que la page principale.
- Passage en libre : Android demande tout de suite l'accès au micro ; la caméra et la localisation sont demandées au moment où une page s'en sert.
- Demandes d'autorisation qui se chevauchent (appel qui demande plusieurs accès) : chacune est maintenant traitée séparément (avant, la première pouvait rester sans réponse).
- Messages à l'écran quand un accès est refusé (case décochée en strict, ou refus côté Android).
- Nouvelles icônes : 🛡️ strict, ⚡ libre (à changer en haut de MainActivity.kt : ICO_STRICT / ICO_LIBRE).

## À vérifier (v0.7)
- Profil en libre → appel vocal Network : le micro marche sans toucher aux cases
- Profil en strict avec case micro décochée : l'appel est refusé avec un message
- Pop-up de connexion Google en libre

## Nouveautés v0.8
- **PowerPoint** : l'appli apparaît dans « Ouvrir avec » pour les fichiers .pptx, .ppsx, .ppt et .pps.
- Les .pptx / .ppsx s'affichent en lecture simple : texte et images de chaque diapositive, l'une sous l'autre. Pas de mise en page d'origine, pas de formes, graphiques, tableaux ni animations ; l'ordre suit la numérotation interne des diapositives.
- L'ancien format .ppt (binaire) n'est pas lisible : un message invite à l'enregistrer en .pptx ou à l'ouvrir avec une autre appli.

## À vérifier (v0.8)
- Un .pptx ouvert depuis « Mes fichiers » : l'appli est proposée, le profil se choisit, les diapositives s'affichent
- Un .ppt : l'appli est proposée, puis le message d'explication s'affiche

## Nouveautés v0.9
- **Icône simplifiée** : un seul fichier à remplacer pour changer l'icône de l'appli, `app/src/main/res/drawable/icone_app.png`. Remplacez l'image (carrée, PNG, 512x512 ou plus), recompilez : plus besoin de toucher aux fichiers fond/premier plan séparés. Le fond de l'icône est blanc et l'image est réduite pour ne pas être rognée ; pour la mettre en plein cadre, mettre `inset="0%"` dans `drawable/icone_app_cadree.xml`.

## Correctif v0.9.1
- **Connexions conservées** : les cookies de chaque profil sont maintenant écrits sur le disque à chaque page chargée et quand l'appli passe en arrière-plan ou se ferme. Avant, ils restaient en mémoire et pouvaient être perdus à la fermeture (déconnexion à la réouverture).

## À vérifier (v0.9.1)
- Se connecter à Claude (Google) dans un profil, fermer complètement l'appli (la retirer des applis récentes), la rouvrir : toujours connecté
- Même test avec deux profils : chacun garde sa propre connexion

## Nouveautés v1.0
- **Téléchargements** : un fichier proposé par une page (lien, bouton « Télécharger », PDF, image, blob, data:) est enregistré dans le dossier Téléchargements du téléphone, avec notification d'Android et les cookies du profil (les téléchargements derrière une connexion marchent). ⚙ → « ⬇ Téléchargements » : liste par profil avec progression, toucher pour ouvrir, appui long pour retirer de la liste ou supprimer le fichier. Les contenus blob: / data: sont limités à 50 Mo. Android 8 et 9 demandent l'accès au stockage au premier téléchargement.
- **Envoi de fichiers** : les champs « parcourir » des pages (pièces jointes sur Claude, formulaires…) ouvrent maintenant le sélecteur de fichiers d'Android.
- **Photo de profil** : dans la fiche d'un profil, « Choisir une photo » (galerie) ; elle remplace l'initiale partout (liste, feuille « Ouvrir avec », etc.). « Retirer » rend la pastille colorée.
- **Verrou de profil** : dans la fiche d'un profil, bouton « Verrou » → aucun, code, ou schéma (grille de 9 points, 4 minimum). Le profil demande son code ou son schéma à chaque ouverture (liste, lien reçu, changement de profil) et se reverrouille quand on quitte l'appli ou revient à la liste. **Le code maître ouvre toujours** un profil verrouillé (bouton « Code maître » sous le schéma, ou saisi à la place du code).
- **Historique par profil** : ⚙ → « 🕘 Historique » (500 pages max, groupées par jour). « Vider l'historique » n'efface que la liste ; « Effacer cookies et données de site » déconnecte le profil sans toucher à l'historique ni aux favoris. Toucher une page l'ouvre dans l'onglet en cours.
- **Favoris par profil** : ☆ dans la barre d'adresse (★ si la page est déjà en favori), appui long sur l'étoile ou ⚙ → « ★ Favoris » pour la liste.
- **Dupliquer un profil** : dans la fiche d'un profil, « Dupliquer ce profil » : copie le nom (+ « (copie) »), la couleur, la photo, les autorisations, le moteur, le mode, le verrou et les favoris. Pas les connexions ni l'historique.
- **PDF : recherche et sélection de texte** : le lecteur PDF est remplacé par pdf.js (Mozilla, licence Apache 2.0, embarqué dans l'appli, aucun accès réseau). 🔍 dans la barre du lecteur : recherche avec surlignage, résultat suivant / précédent, compteur ; sélection et copie du texte par appui long ; boutons − et + pour le zoom (en plus du pincement) ; les PDF protégés par mot de passe sont maintenant pris en charge. Un PDF scanné (images sans texte) reste non cherchable. Si pdf.js ne démarre pas, un lien « Ouvrir en lecture simple » renvoie à l'ancien lecteur.
- L'APK grossit d'environ 5 Mo (pdf.js).

## À vérifier (v1.0)
- Télécharger un fichier depuis un site (pièce jointe, PDF) : notification, fichier dans Téléchargements, entrée dans ⚙ → Téléchargements, ouverture au toucher
- Télécharger un fichier généré par une page (export, « Enregistrer sous ») : cas blob:
- Joindre un fichier à un message (bouton trombone / parcourir)
- Photo de profil : choisie, visible partout, retirée ; photo prise en portrait bien orientée
- Verrou par code puis par schéma : bon code ouvre, mauvais refuse, code maître ouvre ; quitter l'appli puis revenir demande de nouveau le verrou
- Historique : pages ajoutées avec leur titre ; « Vider » garde la connexion ; « Effacer cookies » déconnecte
- Favori ajouté / retiré (★/☆), propre à chaque profil
- Dupliquer un profil : copie avec photo, favoris et verrou, sans connexion
- PDF : recherche d'un mot (résultats surlignés, ▲ ▼), sélection de texte, zoom, PDF à mot de passe

## Correctif v1.0.1
- **Synthèse vocale** : `speechSynthesis` (voix off des ordres, etc.) restait muet car, depuis Android 11, la WebView ne voyait pas le moteur de synthèse vocale du téléphone. Déclaration `<queries>` ajoutée au manifeste : ça marche dans les deux modes, strict comme libre.
- **Mode libre renforcé** : contenu http autorisé (cleartext), accès fichiers `file://` entre pages, débogage distant (chrome://inspect sur le PC), plein écran des vidéos et pages (`requestFullscreen`), permissions réseau / vibration / veille / Bluetooth déclarées.
- **Mode strict** : en plus du reste, DRM (médias protégés) autorisé ; micro et caméra restent gérés par les cases du profil.
- **Nouvelle icône** : logo engrenages « G » (`drawable/icone_app.png`, 1024x1024), fond d'icône noir.
- Limites de la WebView Android (valables pour toute appli, pas contournables) : pas de Web Bluetooth, Web USB, Web Serial, ni de `webkitSpeechRecognition` (reconnaissance vocale intégrée au navigateur) ni de notifications web.

## À vérifier (v1.0.1)
- Entraînement Tactique : les ordres sont prononcés à voix haute (strict ET libre)
- Vidéo : bouton plein écran fonctionne, bouton retour en sort
- Nouvelle icône visible sur l'écran d'accueil du téléphone

## Correctif v1.0.2 : la WebView rattrapée par des ponts natifs
Android System WebView n'a pas plusieurs API que Chrome possède (limite de Google, pas un réglage). Au lieu de les débloquer une par une, un script (`assets/ponts.js`) est injecté **au tout début de chaque page**, dans **tous les profils et les deux modes**, et recrée les API web standards par-dessus le vrai Android (`PontsWeb.kt`). Les projets n'ont rien à modifier.
- **Synthèse vocale** : `speechSynthesis`, `SpeechSynthesisUtterance` (texte, lang, rate, pitch, volume, onstart/onend/onerror, getVoices, cancel). Pause/reprise : non supportées par Android.
- **Reconnaissance vocale** : `SpeechRecognition` / `webkitSpeechRecognition` (lang, continuous, interimResults, onresult/onerror/onend). Respecte la case micro du profil en strict. En mode continu, Android peut faire un petit « bip » entre deux phrases.
- **Notifications** : `new Notification(titre, {body})` + `requestPermission()`.
- **Partage** : `navigator.share()` ouvre la feuille de partage d'Android.
- Déjà en place depuis la 1.0.1 : http autorisé, plein écran, débogage `chrome://inspect`, fichiers `file://`, géolocalisation, DRM.
- **Impossible dans une WebView, même en libre** : Web Bluetooth, Web USB, Web Serial, Web NFC (il faudrait des ponts natifs dédiés, à ajouter au besoin).
- Fichier `test-api.html` fourni à part : ouvrez-le dans l'appli (« Ouvrir avec ») pour voir ✓/✗ pour chaque fonction.

## À vérifier (v1.0.2)
- `test-api.html` : tout en ✓ (voix prononcée, reconnaissance, notification, partage…)
- Entraînement Tactique : les ordres sont prononcés en strict ET en libre
- Si rien ne parle : Réglages Android → Gestion globale → Synthèse vocale (un moteur et la voix française doivent être installés)

## Correctif v1.0.3 : suite du diagnostic `test-api.html`
Le diagnostic complet (Samsung SM-A556B, Android 16) a montré 8 ✗ et 8 partiels ; la plupart n'étaient pas de vrais défauts. Corrigé :
- **Liens `mailto:`, `tel:`, `sms:`, `geo:`, `intent:`, `market:`…** : ils sont maintenant ouverts par l'appli Android adaptée (courrier, téléphone…) au lieu de faire quitter la page ou d'afficher une erreur. Vaut pour les onglets et les pop-ups. Message « Aucune appli pour ouvrir ce lien » si rien ne convient.
- **Presse-papiers (lecture)** : `navigator.clipboard.readText()` et `read()` marchent (pont natif). L'écriture marchait déjà. Sous Android 12 et plus, le système peut afficher un petit message « Gestionnaire de Profils a collé depuis votre presse-papiers ».
- **Permissions** : `navigator.permissions.query()` répondait « refusée » pour les notifications, la lecture du presse-papiers et la veille d'écran, alors que ces fonctions marchent. La réponse est maintenant « accordée » pour ces quatre-là ; géolocalisation, micro et caméra gardent l'état réel d'Android.
- **Stockage persistant** : `storage.persist()` et `persisted()` répondent `true`. C'est une déclaration : les données restent dans le dossier privé de l'appli, mais Android peut toujours les retirer si l'on efface les données de l'appli.
- Déjà en place, rien à changer : téléchargements (`DownloadListener`), écriture des cookies sur le disque à chaque pause.
- **Impossible dans une WebView** : partage d'écran (`getDisplayMedia`), passkeys (WebAuthn), Picture-in-Picture, Push, WebGPU. Le WASM multi-thread demande en plus des en-têtes COOP/COEP que seule une page servie avec ces en-têtes peut avoir.

## À vérifier (v1.0.3)
- Relancer `test-api.html` : notifications, presse-papiers et veille d'écran ne sont plus en ✗ dans « Permissions » ; la lecture du presse-papiers est en ✓
- Toucher un lien `mailto:` puis `tel:` : l'appli courrier / téléphone s'ouvre et la page reste en place
- Télécharger le fichier `diag.txt` : une notification apparaît et il est dans Téléchargements


## Nouveautés v1.0.4 — sécurité et intraçabilité
- **Plus aucun historique** : les pages visitées ne sont plus enregistrées, l'écran « Historique » est supprimé, et l'historique laissé par les versions précédentes est effacé au démarrage. Il ne reste que les favoris et les cookies.
- **Cookies et connexions inchangés** : les sessions (Google, Claude…) ne sont pas touchées. « 🧹 Effacer cookies et données de site » est maintenant dans le menu ⚙ du navigateur.
- **Blocage des traceurs tiers** (mode strict) : les requêtes secondaires vers des régies publicitaires et d'analyse connues sont bloquées ; la page principale n'est jamais bloquée. Liste modifiable dans Protection.kt.
- **Anti-empreinte** (mode strict) : nombre de cœurs, mémoire, batterie et réseau masqués, signal « Ne pas me suivre » envoyé, léger bruit sur les petits canevas. Retiré en mode libre.
- **DNS privé** : un entrée du menu ⚙ explique comment l'activer dans Android (une appli ne peut pas l'imposer).
- Sauvegarde automatique Android désactivée (allowBackup=false) : favoris, réglages et code ne partent plus dans une sauvegarde cloud.

## À vérifier (v1.0.4)
- Connexion Google / Claude toujours conservée après fermeture et réouverture de l'appli
- Un site qui se comporte mal en strict : passer le profil en libre pour comparer (la protection y est coupée)
- Les profils existants ne montrent plus d'historique dans le menu ⚙


## Nouveautés v1.0.5 — onglets
- **Réorganiser les onglets** : appui long sur un onglet (vibration), puis glisser à gauche ou à droite ; les autres onglets s'écartent, la barre défile près des bords, et l'ordre est sauvegardé. Un simple toucher affiche toujours l'onglet.
- **Plus d'onglet en double** : un lien reçu d'une autre appli bascule sur l'onglet déjà ouvert s'il a la même adresse ; si le profil n'a qu'un onglet resté sur la page d'accueil, il est réutilisé au lieu d'en ouvrir un second. Les onglets déjà ouverts d'un profil sont toujours conservés.
- Le bouton ＋ ouvre toujours un nouvel onglet volontairement.

## À vérifier (v1.0.5)
- Appui long + glisser sur un onglet : il change de place, l'onglet affiché reste le même, l'ordre est conservé après avoir quitté puis rouvert le profil
- Réouvrir un profil depuis la liste : aucun onglet supplémentaire n'apparaît
- Ouvrir deux fois le même lien dans le même profil : un seul onglet

## v1.0.9 — Clé de signature intégrée au projet

- La clé de signature est maintenant dans le projet : `app/cle-signature.jks` (mots de passe écrits dans `app/build.gradle.kts`). Plus aucun secret GitHub n'est nécessaire.
- Compilée depuis n'importe où (GitHub Actions, builder PC, builder mobile, local), l'appli est toujours signée avec la même clé : la mise à jour s'installe par-dessus l'ancienne, sans désinstaller, et les profils et connexions sont conservés.
- **Ne jamais supprimer ni régénérer `cle-signature.jks`**, et la garder dans chaque zip. Sans elle, Android refuse la mise à jour.
- **Première installation de la v1.0.9 uniquement** : cette clé est nouvelle, donc Android refusera de l'installer par-dessus une version signée avec l'ancienne clé. Il faut désinstaller une fois (les profils de la version actuelle seront perdus). À partir de la v1.0.9, toutes les mises à jour se feront par-dessus.
- Le dépôt GitHub doit rester privé : la clé et ses mots de passe sont dans le code.


## Nouveautés v1.1.0 — Word et Excel (en plus du PDF et de PowerPoint)
- **« Ouvrir avec »** : l'appli est maintenant proposée pour les fichiers Word (.docx, .doc), Excel (.xlsx, .xlsm, .xlsb, .xltx, .xls, .ods) en plus des PDF et PowerPoint (.pptx, .ppsx, .ppt, .pps) déjà pris en charge. Même feuille de choix du profil que pour les autres fichiers.
- **Word (.docx)** : lecteur intégré (bibliothèque mammoth, licence BSD, embarquée, aucun accès réseau). Affiche le texte, les titres, les listes, les tableaux, les images, les notes de bas de page et les liens (seules les adresses http, https, mailto et tel restent cliquables). Boutons A− / A+ pour la taille du texte, sélection et copie par appui long. Pas de mise en page d'origine : pas de marges, en-têtes / pieds de page, colonnes, couleurs, polices, zones de texte ni formes.
- **Excel** : lecteur intégré (bibliothèque SheetJS 0.18.5, licence Apache 2.0, embarquée, aucun accès réseau). Une barre d'onglets pour passer d'une feuille à l'autre (les feuilles masquées sont cachées), en-têtes de colonnes (A, B, C…) et numéros de lignes figés pendant le défilement, cellules fusionnées, dates et nombres comme dans Excel. Les feuilles de plus de 1000 lignes s'affichent par tranches (bouton « Afficher plus »). Les formules montrent la dernière valeur calculée par Excel (rien n'est recalculé) ; pas de graphiques, images, mise en forme conditionnelle ni couleurs de cellules.
- **PowerPoint** : inchangé (v0.8) : texte et images des diapositives, lecture simple.
- **Anciens formats** : .doc et .ppt (binaires) ne sont pas lisibles : un message invite à enregistrer en .docx / .pptx. En revanche .xls (ancien Excel) est lu.
- Fichiers de plus de 40 Mo (Word, Excel) : message invitant à utiliser une autre appli.
- Le type du fichier est reconnu par son extension d'abord (certaines applis annoncent un type générique), puis par le type annoncé.
- L'APK grossit d'environ 1,5 Mo (mammoth + SheetJS, dossier `app/src/main/assets/docs`).
- La clé de signature `app/cle-signature.jks` est conservée : la mise à jour s'installe par-dessus la v1.0.9, profils et connexions gardés.

## À vérifier (v1.1.0)
- Un .docx ouvert depuis « Mes fichiers » : l'appli est proposée, le profil se choisit, le texte, les tableaux et les images s'affichent ; A− / A+ fonctionnent
- Un .xlsx : onglets des feuilles, colonnes A B C…, numéros de lignes, dates correctes ; sur une grande feuille, « Afficher plus » charge la suite
- Un .xls (ancien Excel) s'ouvre ; un .doc ou un .ppt affiche le message d'explication
- Un .pptx et un PDF s'ouvrent toujours comme avant
- Si l'appli n'apparaît pas dans « Ouvrir avec » pour un type : le système a mémorisé l'ancienne liste, désinstaller puis réinstaller l'APK (ou installer par-dessus : la liste se met à jour dans la plupart des cas)
