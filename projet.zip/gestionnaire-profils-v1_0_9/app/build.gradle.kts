plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.profils"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.profils"
        minSdk = 26
        targetSdk = 34
        // Le workflow GitHub fournit VERSION_CODE (minutes écoulées depuis 1970) : il augmente à chaque build,
        // même si le dépôt est recréé. En local, on garde la valeur de secours.
        versionCode = System.getenv("VERSION_CODE")?.toIntOrNull() ?: 19
        versionName = "1.0.9"
    }

    // Cle de signature FIXE, integree au projet (app/cle-signature.jks).
    // Tous les builds (GitHub Actions, builder PC, builder mobile, local) signent avec la MEME cle :
    // l'APK s'installe par-dessus l'ancien sans desinstaller, donc profils et comptes sont conserves.
    // Ne jamais supprimer ni regenerer ce fichier, sinon Android refusera la mise a jour.
    signingConfigs {
        create("release") {
            storeFile = file("cle-signature.jks")
            storePassword = "profils-cle-fixe-2026"
            keyAlias = "profils"
            keyPassword = "profils-cle-fixe-2026"
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        // Le debug utilise aussi la meme cle : un APK debug peut s'installer par-dessus un release.
        getByName("debug") {
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
