package com.example.profils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/** Grille 3×3 de points à relier du doigt (schéma de verrouillage). Les points sont numérotés de 0 à 8. */
class SchemaVue(context: Context, private val couleurTrait: Int, private val couleurPoint: Int) : View(context) {

    /** Appelé quand le doigt se lève, avec la suite de points touchés (jamais vide). */
    var auFini: ((List<Int>) -> Unit)? = null

    private val points = mutableListOf<Int>()
    private var doigtX = 0f
    private var doigtY = 0f
    private var enCours = false

    private val peintureTrait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = couleurTrait; strokeWidth = 10f * resources.displayMetrics.density / 2f
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val peinturePoint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = couleurPoint; style = Paint.Style.FILL }
    private val peintureActif = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = couleurTrait; style = Paint.Style.FILL }

    override fun onMeasure(largeurSpec: Int, hauteurSpec: Int) {
        val t = resolveSize(MeasureSpec.getSize(largeurSpec).coerceAtLeast(1), largeurSpec)
        setMeasuredDimension(t, t)
    }

    private fun centreX(i: Int) = ((i % 3) + 0.5f) * width / 3f
    private fun centreY(i: Int) = ((i / 3) + 0.5f) * height / 3f

    private fun pointSous(x: Float, y: Float): Int {
        val rayon = width / 7f
        for (i in 0 until 9) {
            val dx = x - centreX(i)
            val dy = y - centreY(i)
            if (dx * dx + dy * dy <= rayon * rayon) return i
        }
        return -1
    }

    /** Efface le tracé (par exemple après une erreur). */
    fun effacer() {
        points.clear(); enCours = false; invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                points.clear(); enCours = true
                doigtX = e.x; doigtY = e.y
                val p = pointSous(e.x, e.y)
                if (p >= 0) points.add(p)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!enCours) return true
                doigtX = e.x; doigtY = e.y
                val p = pointSous(e.x, e.y)
                if (p >= 0 && p !in points) points.add(p)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                enCours = false
                doigtX = e.x; doigtY = e.y
                invalidate()
                if (points.isNotEmpty()) auFini?.invoke(points.toList())
            }
            MotionEvent.ACTION_CANCEL -> { enCours = false; points.clear(); invalidate() }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val r = width / 22f
        for (i in 0 until 9) {
            c.drawCircle(centreX(i), centreY(i), if (i in points) r * 1.5f else r, if (i in points) peintureActif else peinturePoint)
        }
        for (k in 1 until points.size) {
            c.drawLine(centreX(points[k - 1]), centreY(points[k - 1]), centreX(points[k]), centreY(points[k]), peintureTrait)
        }
        if (enCours && points.isNotEmpty()) {
            val d = points.last()
            c.drawLine(centreX(d), centreY(d), doigtX, doigtY, peintureTrait)
        }
    }
}
