package com.example.profils

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.URLUtil
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * Un téléchargement noté dans la liste d'un profil.
 * id >= 0 : confié au gestionnaire de téléchargements d'Android ; id = -1 : fichier déjà écrit (blob, data:), `uri` renseignée.
 */
class Telechargement(val id: Long, val nom: String, val url: String, val date: Long, val mime: String, val uri: String)

/** État d'un téléchargement confié à Android (codes DownloadManager.STATUS_*). */
class EtatTelechargement(val code: Int, val octets: Long, val total: Long)

/** Liste des téléchargements, profil par profil (SharedPreferences, JSON). */
class DepotTelechargements(context: Context) {
    private val prefs = context.getSharedPreferences("telechargements", Context.MODE_PRIVATE)

    fun liste(profilId: String): MutableList<Telechargement> {
        val res = mutableListOf<Telechargement>()
        try {
            val arr = JSONArray(prefs.getString("dl_$profilId", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                res.add(Telechargement(
                    o.optLong("id", -1L), o.optString("nom", "fichier"), o.optString("url", ""),
                    o.optLong("date", 0L), o.optString("mime", "application/octet-stream"), o.optString("uri", "")
                ))
            }
        } catch (e: Exception) { }
        return res
    }

    fun sauver(profilId: String, liste: List<Telechargement>) {
        val arr = JSONArray()
        liste.forEach {
            arr.put(JSONObject().put("id", it.id).put("nom", it.nom).put("url", it.url)
                .put("date", it.date).put("mime", it.mime).put("uri", it.uri))
        }
        prefs.edit().putString("dl_$profilId", arr.toString()).apply()
    }

    fun oublier(profilId: String) {
        prefs.edit().remove("dl_$profilId").apply()
    }
}

object Telechargeur {
    const val LISTE_MAX = 100

    fun nomFichier(url: String, contentDisposition: String?, mime: String?): String {
        val brut = try { URLUtil.guessFileName(url, contentDisposition, mime) } catch (e: Exception) { "fichier" }
        return brut.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "fichier" }
    }

    private fun gestionnaire(ctx: Context) = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    /** Adresse http(s) : confiée à Android (notification, reprise), avec les cookies du profil pour rester connecté. */
    fun demarrer(
        ctx: Context, url: String, agent: String?, contentDisposition: String?, mime: String?,
        cookie: String?, referent: String?
    ): Telechargement {
        val nom = nomFichier(url, contentDisposition, mime)
        val type = if (mime.isNullOrBlank()) "application/octet-stream" else mime
        val req = DownloadManager.Request(Uri.parse(url))
        if (!cookie.isNullOrEmpty()) req.addRequestHeader("Cookie", cookie)
        if (!agent.isNullOrEmpty()) req.addRequestHeader("User-Agent", agent)
        if (!referent.isNullOrEmpty()) req.addRequestHeader("Referer", referent)
        req.setMimeType(type)
        req.setTitle(nom)
        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, nom)
        val id = gestionnaire(ctx).enqueue(req)
        return Telechargement(id, nom, url, System.currentTimeMillis(), type, "")
    }

    /** Contenu déjà en mémoire (blob:, data:) : écrit directement dans le dossier Téléchargements. */
    fun enregistrer(ctx: Context, octets: ByteArray, nom: String, mime: String): Telechargement {
        val uri: String
        if (Build.VERSION.SDK_INT >= 29) {
            val res = ctx.contentResolver
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, nom)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val u = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("création du fichier impossible")
            val sortie = res.openOutputStream(u) ?: throw IOException("écriture impossible")
            sortie.use { it.write(octets) }
            res.update(u, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            uri = u.toString()
        } else {
            @Suppress("DEPRECATION")
            val dossier = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dossier.mkdirs()
            var f = File(dossier, nom)
            var n = 1
            while (f.exists()) {
                val base = nom.substringBeforeLast('.', nom)
                val ext = if (nom.contains('.')) "." + nom.substringAfterLast('.') else ""
                f = File(dossier, "$base-$n$ext"); n++
            }
            f.writeBytes(octets)
            MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(mime), null)
            uri = Uri.fromFile(f).toString()
        }
        return Telechargement(-1, nom, "", System.currentTimeMillis(), mime, uri)
    }

    /** « data:type;base64,… » → (type, octets). */
    fun decoderDataUrl(s: String): Pair<String, ByteArray>? {
        if (!s.startsWith("data:")) return null
        val virgule = s.indexOf(',')
        if (virgule < 0) return null
        val entete = s.substring(5, virgule)
        val corps = s.substring(virgule + 1)
        val mime = entete.substringBefore(';').ifEmpty { "text/plain" }
        val octets = if (entete.endsWith(";base64")) Base64.decode(corps, Base64.DEFAULT)
                     else Uri.decode(corps).toByteArray(Charsets.UTF_8)
        return Pair(mime, octets)
    }

    fun etat(ctx: Context, id: Long): EtatTelechargement? {
        if (id < 0) return null
        try {
            gestionnaire(ctx).query(DownloadManager.Query().setFilterById(id))?.use { c ->
                if (c.moveToFirst()) {
                    return EtatTelechargement(
                        c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                        c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                        c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    )
                }
            }
        } catch (e: Exception) { }
        return null
    }

    /** Ouvre le fichier avec une appli du téléphone. Renvoie false si ce n'est pas possible. */
    fun ouvrir(ctx: Context, t: Telechargement): Boolean {
        try {
            val dm = gestionnaire(ctx)
            val uri: Uri?
            val mime: String
            if (t.id >= 0) {
                uri = dm.getUriForDownloadedFile(t.id)
                mime = dm.getMimeTypeForDownloadedFile(t.id) ?: t.mime
            } else if (t.uri.startsWith("file:")) {
                // Android 8 et 9 : pas d'adresse partageable, on ouvre le dossier Téléchargements
                ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } else {
                uri = Uri.parse(t.uri); mime = t.mime
            }
            if (uri == null) return false
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun ouvrirDossier(ctx: Context) {
        try {
            ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    /** Supprime aussi le fichier du téléphone. */
    fun supprimerFichier(ctx: Context, t: Telechargement) {
        try {
            if (t.id >= 0) gestionnaire(ctx).remove(t.id)
            else if (t.uri.startsWith("content:")) ctx.contentResolver.delete(Uri.parse(t.uri), null, null)
            else if (t.uri.startsWith("file:")) File(Uri.parse(t.uri).path ?: return).delete()
        } catch (e: Exception) { }
    }
}

/**
 * Passerelle appelée par la page pour remettre le contenu d'un blob: (voir MainActivity.telechargerBlob).
 * Classe publique : WebView ne peut appeler par réflexion que les méthodes publiques d'une classe publique.
 * Chaque appel doit porter un jeton à usage unique que seule l'appli connaît.
 */
class PontTelechargement(
    private val surRecu: (String, String) -> Unit,
    private val surEchec: (String, String) -> Unit
) {
    @android.webkit.JavascriptInterface
    fun recevoir(jeton: String, donnees: String) { surRecu(jeton, donnees) }

    @android.webkit.JavascriptInterface
    fun echec(jeton: String, raison: String) { surEchec(jeton, raison) }
}
