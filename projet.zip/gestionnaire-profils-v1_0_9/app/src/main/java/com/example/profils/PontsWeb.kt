package com.example.profils

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale

/**
 * Ponts natifs : comblent ce que la WebView Android n'a pas (contrairement à Chrome).
 * Côté page, assets/ponts.js recrée les API standards par-dessus ces ponts :
 *   speechSynthesis / SpeechSynthesisUtterance, (webkit)SpeechRecognition, Notification, navigator.share,
 *   navigator.clipboard.readText / read.
 * Les pages n'ont rien à changer : elles utilisent l'API web habituelle.
 */
class PontsWeb(
    private val act: Activity,
    private val executerJs: (String) -> Unit,                      // exécute du JS dans toutes les pages ouvertes
    private val demander: (List<String>, () -> Unit) -> Unit       // demande d'autorisations Android
) {
    private val ui = Handler(Looper.getMainLooper())

    val script: String by lazy { act.assets.open("ponts.js").bufferedReader().use { it.readText() } }

    fun pontPour(microOk: () -> Boolean) = Pont(microOk)

    fun liberer() {
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        try { reco?.destroy() } catch (e: Exception) { }
        tts = null; reco = null
    }

    /** Appli quittée : on coupe la voix et le micro (la reconnaissance « continue » se relance sinon toute seule, indéfiniment). */
    fun arreterEnArrierePlan() {
        try { tts?.stop() } catch (e: Exception) { }
        if (recoActive) recoFin()
    }

    // ───────────────────────── Synthèse vocale ─────────────────────────

    private var tts: TextToSpeech? = null
    private var ttsPret = false
    private val enAttente = ArrayList<() -> Unit>()

    private fun demarrerTts() {
        tts = TextToSpeech(act) { statut ->
            ttsPret = statut == TextToSpeech.SUCCESS
            if (ttsPret) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { evtVoix("start", utteranceId) }
                    override fun onDone(utteranceId: String?) { evtVoix("end", utteranceId) }
                    @Suppress("OVERRIDE_DEPRECATION")
                    override fun onError(utteranceId: String?) { evtVoix("error", utteranceId) }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { evtVoix("error", utteranceId) }
                })
                val liste = enAttente.toList(); enAttente.clear()
                liste.forEach { it() }
            } else {
                enAttente.clear()
                Toast.makeText(act, "Synthèse vocale indisponible : Réglages Android → Synthèse vocale", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun evtVoix(type: String, id: String?) {
        if (id == null) return
        executerJs("window.speechSynthesis&&window.speechSynthesis.__evt&&window.speechSynthesis.__evt('$type','$id');")
    }

    private fun dire(id: String, texte: String, lang: String, taux: Float, hauteur: Float, volume: Float) {
        val action = {
            val t = tts
            if (t != null) {
                try { t.language = Locale.forLanguageTag(if (lang.isEmpty()) "fr-FR" else lang) } catch (e: Exception) { }
                t.setSpeechRate(if (taux > 0f) taux else 1f)
                t.setPitch(if (hauteur > 0f) hauteur else 1f)
                val params = Bundle()
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, if (volume in 0f..1f) volume else 1f)
                t.speak(texte, TextToSpeech.QUEUE_ADD, params, id)
            }
        }
        if (ttsPret) action()
        else {
            enAttente.add(action)
            if (tts == null) demarrerTts()
        }
    }

    // ───────────────────────── Reconnaissance vocale ─────────────────────────

    private var reco: SpeechRecognizer? = null
    private var recoActive = false
    private var recoContinu = false
    private var recoInterim = false
    private var recoLang = "fr-FR"
    private var recoDebutEnvoye = false

    private fun evtReco(type: String, data: String, fin: Boolean = false) {
        executerJs("window.__appReco&&window.__appReco.__evt('$type',${JSONObject.quote(data)},$fin);")
    }

    private fun recoLancer(lang: String, continu: Boolean, interim: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(act)) {
            evtReco("error", "service-not-allowed"); evtReco("end", "")
            return
        }
        demander(listOf(Manifest.permission.RECORD_AUDIO)) {
            if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                recoActive = true
                recoContinu = continu
                recoInterim = interim
                recoLang = if (lang.isEmpty()) "fr-FR" else lang
                recoDebutEnvoye = false
                recoSession()
            } else {
                evtReco("error", "not-allowed"); evtReco("end", "")
            }
        }
    }

    private fun recoSession() {
        try { reco?.destroy() } catch (e: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(act)
        reco = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (!recoDebutEnvoye) { recoDebutEnvoye = true; evtReco("start", "") }
            }
            override fun onBeginningOfSpeech() { }
            override fun onRmsChanged(rmsdB: Float) { }
            override fun onBufferReceived(buffer: ByteArray?) { }
            override fun onEndOfSpeech() { }
            override fun onEvent(eventType: Int, params: Bundle?) { }
            override fun onPartialResults(partialResults: Bundle?) {
                if (!recoInterim) return
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                evtReco("result", t, false)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) evtReco("result", t, true)
                if (recoContinu && recoActive) recoRelancer() else recoFin()
            }
            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        if (recoContinu && recoActive) recoRelancer()
                        else {
                            if (recoActive) evtReco("error", "no-speech")
                            recoFin()
                        }
                    }
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { evtReco("error", "not-allowed"); recoFin() }
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> { evtReco("error", "network"); recoFin() }
                    SpeechRecognizer.ERROR_AUDIO -> { evtReco("error", "audio-capture"); recoFin() }
                    else -> { evtReco("error", "aborted"); recoFin() }
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, recoInterim)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, recoLang)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        r.startListening(i)
    }

    /** Android s'arrête après chaque phrase : en mode « continuous », on relance. */
    private fun recoRelancer() {
        ui.postDelayed({ if (recoActive) recoSession() }, 150)
    }

    private fun recoFin() {
        recoActive = false
        recoDebutEnvoye = false
        try { reco?.destroy() } catch (e: Exception) { }
        reco = null
        evtReco("end", "")
    }

    // ───────────────────────── Notifications ─────────────────────────

    private fun montrerNotif(titre: String, corps: String) {
        val nm = act.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val canal = "pages_web"
        nm.createNotificationChannel(NotificationChannel(canal, "Notifications des pages", NotificationManager.IMPORTANCE_DEFAULT))
        val n = Notification.Builder(act, canal)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(titre)
            .setContentText(corps)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }

    // ───────────────────────── Interface exposée aux pages (window.AppNatif) ─────────────────────────

    inner class Pont(private val microOk: () -> Boolean) {
        @JavascriptInterface
        fun parler(id: String, texte: String, lang: String, taux: Double, hauteur: Double, volume: Double) {
            ui.post { dire(id, texte, lang, taux.toFloat(), hauteur.toFloat(), volume.toFloat()) }
        }
        @JavascriptInterface
        fun arreter() { ui.post { tts?.stop() } }

        @JavascriptInterface
        fun recoDemarrer(lang: String, continu: Boolean, interim: Boolean) {
            ui.post {
                if (microOk()) recoLancer(lang, continu, interim)
                else { evtReco("error", "not-allowed"); evtReco("end", "") }
            }
        }
        @JavascriptInterface
        fun recoArreter() { ui.post { recoActive = false; reco?.stopListening() } }
        @JavascriptInterface
        fun recoAnnuler() { ui.post { if (reco != null || recoActive) { try { reco?.cancel() } catch (e: Exception) { }; recoFin() } } }

        @JavascriptInterface
        fun notifier(titre: String, corps: String) { ui.post { montrerNotif(titre, corps) } }
        @JavascriptInterface
        fun notifPermission() {
            ui.post { if (Build.VERSION.SDK_INT >= 33) demander(listOf(Manifest.permission.POST_NOTIFICATIONS)) { } }
        }

        /** Texte du presse-papiers (la WebView refuse clipboard.readText : pas de fenêtre d'autorisation). */
        @JavascriptInterface
        fun presspapierLire(): String {
            return try {
                val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip == null || clip.itemCount == 0) "" else clip.getItemAt(0).coerceToText(act)?.toString() ?: ""
            } catch (e: Exception) { "" }
        }

        @JavascriptInterface
        fun presspapierEcrire(texte: String) {
            ui.post {
                try {
                    val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("texte", texte))
                } catch (e: Exception) { }
            }
        }

        @JavascriptInterface
        fun partager(titre: String, texte: String, url: String) {
            ui.post {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_SUBJECT, titre)
                i.putExtra(Intent.EXTRA_TEXT, listOf(texte, url).filter { it.isNotEmpty() }.joinToString("\n"))
                act.startActivity(Intent.createChooser(i, if (titre.isEmpty()) "Partager" else titre))
            }
        }
    }
}
