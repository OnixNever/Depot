package com.example.profils

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class Moteur(val id: String, val nom: String, val recherche: String, val accueil: String)

/** Page mise en favori dans un profil. */
data class Favori(val titre: String, val url: String)

data class Profil(
    val id: String,
    var nom: String,
    var couleur: Int,
    var micro: Boolean,
    var camera: Boolean,
    var moteur: String = "ddg",
    val onglets: MutableList<String> = mutableListOf(),
    var actif: Int = 0,
    /** false = mode strict (par défaut) ; true = mode libre (réglages plus permissifs). */
    var libre: Boolean = false,
    /** Verrou du profil : "" (aucun), "code" ou "schema". Le code maître débloque toujours. */
    var verrou: String = "",
    var verrouSel: String = "",
    var verrouHash: String = "",
    val favoris: MutableList<Favori> = mutableListOf()
) {
    /** Nom du profil WebView (caractères autorisés : lettres, chiffres, _ et -). */
    val nomInterne: String get() = "p_$id"

    val verrouille: Boolean get() = verrou.isNotEmpty() && verrouHash.isNotEmpty()

    companion object {
        val COULEURS = intArrayOf(
            0xFF4F8CFF.toInt(), 0xFF3DDC97.toInt(), 0xFFFFB84D.toInt(),
            0xFFFF6B6B.toInt(), 0xFFB28DFF.toInt(), 0xFF4DD0E1.toInt()
        )
        val MOTEURS = listOf(
            Moteur("ddg", "DuckDuckGo", "https://duckduckgo.com/?q=", "https://duckduckgo.com/"),
            Moteur("google", "Google", "https://www.google.com/search?q=", "https://www.google.com/"),
            Moteur("bing", "Bing", "https://www.bing.com/search?q=", "https://www.bing.com/"),
            Moteur("brave", "Brave Search", "https://search.brave.com/search?q=", "https://search.brave.com/"),
            Moteur("qwant", "Qwant", "https://www.qwant.com/?q=", "https://www.qwant.com/")
        )
        fun moteur(id: String): Moteur = MOTEURS.firstOrNull { it.id == id } ?: MOTEURS[0]

        fun nouveauId() = UUID.randomUUID().toString().replace("-", "").take(12)

        fun nouveau(nom: String, couleur: Int, micro: Boolean, camera: Boolean) =
            Profil(nouveauId(), nom, couleur, micro, camera)
    }
}

/** Sauvegarde de la liste des profils (SharedPreferences, JSON). Les favoris sont rangés à part, profil par profil. Aucun historique de navigation n'est conservé. */
class DepotProfils(context: Context) {
    private val prefs = context.getSharedPreferences("profils", Context.MODE_PRIVATE)

    fun charger(): MutableList<Profil> {
        val liste = mutableListOf<Profil>()
        try {
            val arr = JSONArray(prefs.getString("liste", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val onglets = mutableListOf<String>()
                val ao = o.optJSONArray("onglets")
                if (ao != null) {
                    for (j in 0 until ao.length()) onglets.add(ao.getString(j))
                } else if (o.optString("url", "").isNotEmpty()) {
                    onglets.add(o.getString("url")) // ancienne version : une seule page
                }
                val p = Profil(
                    o.getString("id"), o.getString("nom"), o.getInt("couleur"),
                    o.optBoolean("micro", false), o.optBoolean("camera", false),
                    o.optString("moteur", "ddg"), onglets, o.optInt("actif", 0),
                    o.optBoolean("libre", false),
                    o.optString("verrou", ""), o.optString("verrouSel", ""), o.optString("verrouHash", "")
                )
                p.favoris.addAll(lireFavoris(p.id))
                // Nettoyage : efface tout historique laissé par les versions précédentes
                if (prefs.contains("hist_${p.id}")) prefs.edit().remove("hist_${p.id}").apply()
                liste.add(p)
            }
        } catch (e: Exception) { /* liste corrompue : on repart de zéro */ }
        return liste
    }

    fun sauver(liste: List<Profil>) {
        val arr = JSONArray()
        liste.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("nom", it.nom); put("couleur", it.couleur)
                put("micro", it.micro); put("camera", it.camera); put("moteur", it.moteur)
                put("onglets", JSONArray(it.onglets)); put("actif", it.actif); put("libre", it.libre)
                put("verrou", it.verrou); put("verrouSel", it.verrouSel); put("verrouHash", it.verrouHash)
            })
        }
        prefs.edit().putString("liste", arr.toString()).apply()
    }

    // ----- Favoris -----

    private fun lireFavoris(id: String): List<Favori> {
        val res = mutableListOf<Favori>()
        try {
            val arr = JSONArray(prefs.getString("fav_$id", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                res.add(Favori(o.optString("titre", ""), o.getString("url")))
            }
        } catch (e: Exception) { }
        return res
    }

    fun sauverFavoris(p: Profil) {
        val arr = JSONArray()
        p.favoris.forEach { arr.put(JSONObject().put("titre", it.titre).put("url", it.url)) }
        prefs.edit().putString("fav_${p.id}", arr.toString()).apply()
    }

    /** Efface tout ce que l'appli range pour ce profil en dehors de la liste (suppression du profil). */
    fun oublier(id: String) {
        prefs.edit().remove("fav_$id").remove("hist_$id").apply()
    }
}
