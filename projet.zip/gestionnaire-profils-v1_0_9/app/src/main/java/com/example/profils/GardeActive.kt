package com.example.profils

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder

/**
 * Tourne seulement tant qu'un profil en mode libre est ouvert : la notification permanente empêche Android de geler l'appli,
 * donc le micro, le son et les pages de ce profil continuent quand on passe sur une autre appli (ex. conversation vocale).
 * Se coupe quand le profil repasse en strict ou quand l'appli est fermée.
 */
class GardeActive : Service() {

    private companion object {
        const val CANAL = "garde_active"
        const val NOTIF_ID = 4301
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CANAL, "Mode libre actif", NotificationManager.IMPORTANCE_LOW))
        val ouvrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notif = Notification.Builder(this, CANAL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Gestionnaire de Profils")
            .setContentText("Mode libre actif en arrière-plan")
            .setOngoing(true)
            .setContentIntent(ouvrir)
            .build()
        val micro = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val type = if (micro) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                   else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        try { startForeground(NOTIF_ID, notif, type) } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    /** Appli retirée des applis récentes : tout s'arrête. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }
}
