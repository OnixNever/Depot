package com.example.profils

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * Protection anti-pistage (actives en mode strict uniquement) :
 *  1. blocage des requêtes tierces vers des régies publicitaires et des traceurs connus ;
 *  2. script injecté au début de chaque page qui réduit les informations servant à identifier l'appareil.
 * Ni les cookies ni les connexions ne sont touchés : les sessions Google, Claude, etc. restent en place.
 */
object Protection {

    /** Domaines (et sous-domaines) bloqués quand ils sont chargés comme ressource d'une autre page. */
    private val TRACEURS = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "googletagservices.com",
        "googletagmanager.com", "google-analytics.com", "adservice.google.com", "analytics.google.com",
        "scorecardresearch.com", "quantserve.com", "quantcount.com", "hotjar.com", "hotjar.io",
        "mixpanel.com", "amplitude.com", "fullstory.com", "mouseflow.com", "crazyegg.com",
        "bat.bing.com", "clarity.ms", "ads.linkedin.com", "px.ads.linkedin.com", "snap.licdn.com",
        "analytics.tiktok.com", "ads-twitter.com", "analytics.twitter.com",
        "criteo.com", "criteo.net", "taboola.com", "outbrain.com", "adnxs.com", "rubiconproject.com",
        "pubmatic.com", "openx.net", "casalemedia.com", "adsrvr.org", "bidswitch.net",
        "smartadserver.com", "amazon-adsystem.com", "moatads.com", "doubleverify.com",
        "adsafeprotected.com", "demdex.net", "omtrdc.net", "everesttech.net", "bluekai.com",
        "krxd.net", "agkn.com", "rlcdn.com", "tapad.com", "id5-sync.com", "liadm.com",
        "mc.yandex.ru", "stats.wp.com", "pixel.facebook.com"
    )

    /** Jamais bloqués, même s'ils ressemblaient à un traceur (connexion et services de l'utilisateur). */
    private val JAMAIS = setOf("accounts.google.com", "claude.ai", "anthropic.com", "gstatic.com")

    private fun correspond(hote: String, liste: Set<String>): Boolean =
        liste.any { hote == it || hote.endsWith(".$it") }

    fun doitBloquer(rq: WebResourceRequest): Boolean {
        if (rq.isForMainFrame) return false
        val hote = rq.url.host?.lowercase() ?: return false
        if (correspond(hote, JAMAIS)) return false
        return correspond(hote, TRACEURS)
    }

    fun reponseVide(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 204, "Bloqué", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    /** Script injecté au début de chaque page (mode strict). Prudent : chaque réglage est isolé dans un try/catch. */
    val SCRIPT_ANTI_EMPREINTE = """
(function () {
  if (window.__protegee) return;
  window.__protegee = true;
  function figer(obj, nom, val) {
    try { Object.defineProperty(obj, nom, { get: function () { return val; }, configurable: true }); } catch (e) {}
  }
  var nav = Navigator.prototype;
  figer(nav, 'hardwareConcurrency', 4);
  figer(nav, 'deviceMemory', 8);
  figer(nav, 'doNotTrack', '1');
  figer(nav, 'globalPrivacyControl', true);
  figer(nav, 'connection', undefined);
  figer(nav, 'getBattery', undefined);
  try { figer(nav, 'maxTouchPoints', 5); } catch (e) {}

  /* Empreinte canvas : léger bruit sur les petits canevas (ceux servant à identifier l'appareil) uniquement */
  try {
    var petit = function (c) { return c.width * c.height <= 60000; };
    var bruiter = function (d) {
      for (var i = 0; i < d.length; i += 4) {
        if ((i / 4) % 97 === 0) d[i] = d[i] ^ 1;
      }
    };
    var gid = CanvasRenderingContext2D.prototype.getImageData;
    CanvasRenderingContext2D.prototype.getImageData = function () {
      var r = gid.apply(this, arguments);
      try { if (petit(this.canvas)) bruiter(r.data); } catch (e) {}
      return r;
    };
    var tdu = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function () {
      try {
        if (petit(this)) {
          var c2 = document.createElement('canvas'); c2.width = this.width; c2.height = this.height;
          var x = c2.getContext('2d'); x.drawImage(this, 0, 0);
          var im = gid.call(x, 0, 0, c2.width, c2.height); bruiter(im.data); x.putImageData(im, 0, 0);
          return tdu.apply(c2, arguments);
        }
      } catch (e) {}
      return tdu.apply(this, arguments);
    };
  } catch (e) {}
})();
""".trimIndent()
}
