(function () {
  if (window.__appNatifPret) return;
  var N = window.AppNatif;
  if (!N) return;
  window.__appNatifPret = true;

  function def(nom, val) {
    try { Object.defineProperty(window, nom, { value: val, configurable: true, writable: true }); }
    catch (e) { try { window[nom] = val; } catch (e2) {} }
  }
  function ecouteurs(o) {
    o._ec = {};
    o.addEventListener = function (t, f) { (o._ec[t] = o._ec[t] || []).push(f); };
    o.removeEventListener = function (t, f) {
      var l = o._ec[t]; if (!l) return; var i = l.indexOf(f); if (i >= 0) l.splice(i, 1);
    };
    o._emit = function (t, ev) {
      var h = o['on' + t];
      if (typeof h === 'function') { try { h.call(o, ev); } catch (e) { console.error(e); } }
      (o._ec[t] || []).slice().forEach(function (f) { try { f.call(o, ev); } catch (e) { console.error(e); } });
    };
  }

  /* ───── Synthèse vocale : speechSynthesis / SpeechSynthesisUtterance ───── */
  var voixAndroid = { name: 'Voix Android', lang: 'fr-FR', voiceURI: 'android-tts', localService: true, default: true };
  var file = {}, actives = 0, nb = 0, prefixe = Math.random().toString(36).slice(2, 7);

  function Utterance(texte) {
    ecouteurs(this);
    this.text = texte === undefined ? '' : String(texte);
    this.lang = ''; this.rate = 1; this.pitch = 1; this.volume = 1; this.voice = null;
    this.onstart = this.onend = this.onerror = this.onpause = this.onresume = this.onboundary = this.onmark = null;
  }
  var synth = {
    __appVoix: true, speaking: false, pending: false, paused: false, onvoiceschanged: null,
    speak: function (u) {
      var id = 'u' + prefixe + (++nb);
      file[id] = u; actives++;
      synth.speaking = true; synth.pending = actives > 1;
      var lang = u.lang || (u.voice && u.voice.lang) || '';
      try { N.parler(id, String(u.text), lang, Number(u.rate) || 1, Number(u.pitch) || 1, u.volume === undefined ? 1 : Number(u.volume)); }
      catch (e) { synth.__evt('error', id); }
    },
    cancel: function () {
      try { N.arreter(); } catch (e) {}
      file = {}; actives = 0; synth.speaking = false; synth.pending = false;
    },
    pause: function () {}, resume: function () {},
    getVoices: function () { return [voixAndroid]; },
    __evt: function (type, id) {
      var u = file[id]; if (!u) return;
      if (type === 'start') { u._emit('start', { type: 'start', utterance: u }); return; }
      delete file[id]; actives = Math.max(0, actives - 1);
      synth.speaking = actives > 0; synth.pending = actives > 1;
      if (type === 'end') u._emit('end', { type: 'end', utterance: u });
      else u._emit('error', { type: 'error', error: 'canceled', utterance: u });
    }
  };
  ecouteurs(synth);
  def('SpeechSynthesisUtterance', Utterance);
  def('speechSynthesis', synth);
  function voixChangees() { synth._emit('voiceschanged', { type: 'voiceschanged' }); }
  setTimeout(voixChangees, 0);
  window.addEventListener('load', voixChangees);

  /* ───── Reconnaissance vocale : (webkit)SpeechRecognition ───── */
  var recoActif = null;
  function Reco() {
    ecouteurs(this);
    this.lang = ''; this.continuous = false; this.interimResults = false; this.maxAlternatives = 1; this.grammars = null;
    this.onstart = this.onend = this.onresult = this.onerror = this.onnomatch = null;
    this.onaudiostart = this.onaudioend = this.onspeechstart = this.onspeechend = this.onsoundstart = this.onsoundend = null;
    this._res = [];
  }
  Reco.prototype.start = function () {
    if (recoActif) throw new DOMException('recognition has already started.', 'InvalidStateError');
    recoActif = this; this._res = [];
    N.recoDemarrer(this.lang || document.documentElement.lang || 'fr-FR', !!this.continuous, !!this.interimResults);
  };
  Reco.prototype.stop = function () { N.recoArreter(); };
  Reco.prototype.abort = function () { N.recoAnnuler(); };
  window.__appReco = {
    __evt: function (type, data, fin) {
      var r = recoActif; if (!r) return;
      if (type === 'start') {
        r._emit('start', { type: 'start' }); r._emit('audiostart', { type: 'audiostart' });
      } else if (type === 'result') {
        var alt = [{ transcript: data, confidence: fin ? 0.9 : 0.5 }];
        alt.isFinal = !!fin; alt.item = function (i) { return this[i]; };
        var idx = r._res.length, liste;
        if (fin) { r._res.push(alt); liste = r._res.slice(); } else { liste = r._res.concat([alt]); }
        liste.item = function (i) { return this[i]; };
        r._emit('result', { type: 'result', resultIndex: idx, results: liste });
      } else if (type === 'error') {
        r._emit('error', { type: 'error', error: data, message: data });
      } else if (type === 'end') {
        recoActif = null;
        r._emit('audioend', { type: 'audioend' }); r._emit('end', { type: 'end' });
      }
    }
  };
  def('SpeechRecognition', Reco);
  def('webkitSpeechRecognition', Reco);

  /* ───── Notifications ───── */
  function Notif(titre, opts) {
    ecouteurs(this);
    this.title = titre; this.body = (opts && opts.body) || '';
    try { N.notifier(String(titre), String(this.body)); } catch (e) {}
  }
  Notif.permission = 'granted';
  Notif.requestPermission = function (cb) {
    try { N.notifPermission(); } catch (e) {}
    var p = Promise.resolve('granted'); if (typeof cb === 'function') p.then(cb); return p;
  };
  Notif.prototype.close = function () {};
  def('Notification', Notif);

  /* ───── Partage ───── */
  try {
    navigator.share = function (d) { d = d || {}; N.partager(d.title || '', d.text || '', d.url || ''); return Promise.resolve(); };
    navigator.canShare = function () { return true; };
  } catch (e) {}

  /* ───── Presse-papiers : lecture (readText / read) ───── */
  try {
    var cb = navigator.clipboard;
    if (cb) {
      var poser = function (nom, f) {
        try { Object.defineProperty(cb, nom, { value: f, configurable: true, writable: true }); }
        catch (e) { try { cb[nom] = f; } catch (e2) {} }
      };
      poser('readText', function () {
        try { return Promise.resolve(String(N.presspapierLire())); }
        catch (e) { return Promise.reject(new DOMException('Read permission denied.', 'NotAllowedError')); }
      });
      if (typeof ClipboardItem === 'function') {
        poser('read', function () {
          try {
            var t = String(N.presspapierLire());
            return Promise.resolve([new ClipboardItem({ 'text/plain': new Blob([t], { type: 'text/plain' }) })]);
          } catch (e) { return Promise.reject(new DOMException('Read permission denied.', 'NotAllowedError')); }
        });
      }
    }
  } catch (e) {}

  /* ───── Permissions : états cohérents avec ce que les ponts font réellement ─────
     permissions.query() de la WebView répond « refusée » à des API qui marchent (notifications, presse-papiers,
     veille d'écran). On aligne la réponse ; les autres (géolocalisation, micro, caméra…) restent celles d'Android. */
  try {
    if (navigator.permissions && navigator.permissions.query) {
      var vraiQuery = navigator.permissions.query.bind(navigator.permissions);
      var accordees = { 'notifications': 1, 'clipboard-read': 1, 'clipboard-write': 1, 'screen-wake-lock': 1 };
      navigator.permissions.query = function (desc) {
        var nom = desc && desc.name;
        if (accordees[nom]) {
          var st = { name: nom, state: 'granted', onchange: null,
                     addEventListener: function () {}, removeEventListener: function () {}, dispatchEvent: function () { return true; } };
          return Promise.resolve(st);
        }
        return vraiQuery(desc);
      };
    }
  } catch (e) {}

  /* ───── Stockage persistant : déclaré acquis ─────
     Les données d'un profil restent dans le dossier privé de l'appli (jamais purgées par un navigateur) ;
     seul « Effacer les données » d'Android ou la suppression du profil les retire. */
  try {
    if (navigator.storage) {
      navigator.storage.persist = function () { return Promise.resolve(true); };
      navigator.storage.persisted = function () { return Promise.resolve(true); };
    }
  } catch (e) {}
})();
