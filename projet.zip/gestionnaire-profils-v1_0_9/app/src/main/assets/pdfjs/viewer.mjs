// Lecteur PDF de l'appli : pdf.js (Mozilla, licence Apache 2.0) + recherche et sélection de texte.
import * as pdfjsLib from "./pdf.min.mjs";

const $ = (id) => document.getElementById(id);
const base = new URL("./", import.meta.url).href;
const id = document.body.dataset.id;

function message(texte) {
  const m = $("message");
  m.textContent = texte;
  m.classList.add("on");
}

async function demarrer() {
  globalThis.pdfjsLib = pdfjsLib;
  const { EventBus, PDFViewer, PDFLinkService, PDFFindController } = await import("./pdf_viewer.mjs");
  pdfjsLib.GlobalWorkerOptions.workerSrc = base + "pdf.worker.min.mjs";

  const conteneur = $("conteneur");
  const eventBus = new EventBus();
  const linkService = new PDFLinkService({ eventBus });
  const findController = new PDFFindController({ linkService, eventBus });
  const viewer = new PDFViewer({
    container: conteneur,
    viewer: $("viewer"),
    eventBus,
    linkService,
    findController,
    textLayerMode: 1,
    removePageBorders: true,
  });
  linkService.setViewer(viewer);

  eventBus.on("pagesinit", () => { viewer.currentScaleValue = "page-width"; });

  // ----- Zoom (en plus du pincement) -----
  $("bPlus").onclick = () => { viewer.currentScale = Math.min(viewer.currentScale * 1.25, 6); };
  $("bMoins").onclick = () => { viewer.currentScale = Math.max(viewer.currentScale / 1.25, 0.25); };

  // ----- Recherche -----
  const barreRech = $("recherche");
  const champ = $("q");
  let derniere = "";
  function lancer(again, retour) {
    const texte = champ.value;
    if (!texte) { eventBus.dispatch("findbarclose", { source: null }); $("compte").textContent = ""; derniere = ""; return; }
    const type = again && texte === derniere ? "again" : "";
    derniere = texte;
    eventBus.dispatch("find", {
      source: null, type, query: texte, caseSensitive: false, entireWord: false,
      highlightAll: true, findPrevious: !!retour, matchDiacritics: false,
    });
  }
  function ouvrirRecherche() {
    barreRech.classList.add("on");
    conteneur.classList.add("avecRecherche");
    champ.focus();
  }
  function fermerRecherche() {
    barreRech.classList.remove("on");
    conteneur.classList.remove("avecRecherche");
    champ.blur();
    eventBus.dispatch("findbarclose", { source: null });
    $("compte").textContent = "";
    derniere = "";
  }
  $("bRech").onclick = () => (barreRech.classList.contains("on") ? fermerRecherche() : ouvrirRecherche());
  $("bFermer").onclick = fermerRecherche;
  $("bSuiv").onclick = () => lancer(true, false);
  $("bPrec").onclick = () => lancer(true, true);
  champ.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); lancer(true, e.shiftKey); } });
  champ.addEventListener("input", () => { derniere = ""; lancer(false, false); });
  eventBus.on("updatefindmatchescount", ({ matchesCount }) => {
    $("compte").textContent = matchesCount.total ? matchesCount.current + " / " + matchesCount.total : "0";
  });
  eventBus.on("updatefindcontrolstate", ({ state, matchesCount }) => {
    if (state === 1 /* NOT_FOUND */) $("compte").textContent = "0";
    else if (matchesCount && matchesCount.total) $("compte").textContent = matchesCount.current + " / " + matchesCount.total;
  });

  // ----- Chargement (avec mot de passe éventuel) -----
  const tache = pdfjsLib.getDocument({
    url: "/" + id + "/~brut",
    cMapUrl: base + "cmaps/",
    cMapPacked: true,
    standardFontDataUrl: base + "standard_fonts/",
    disableRange: true,
    disableStream: true,
    isEvalSupported: false,
  });
  tache.onPassword = (maj, raison) => {
    $("mdp").classList.add("on");
    $("mdpErreur").textContent = raison === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD ? "Mot de passe incorrect" : "";
    const valider = () => {
      const v = $("mdpChamp").value;
      $("mdp").classList.remove("on");
      maj(v);
    };
    $("mdpOk").onclick = valider;
    $("mdpChamp").onkeydown = (e) => { if (e.key === "Enter") valider(); };
    $("mdpChamp").value = "";
    $("mdpChamp").focus();
  };
  const pdf = await tache.promise;
  viewer.setDocument(pdf);
  linkService.setDocument(pdf, null);
  $("titre").textContent = document.body.dataset.nom + " · " + pdf.numPages + " page" + (pdf.numPages > 1 ? "s" : "");
}

demarrer().catch((e) => {
  const lien = "/" + id + "/~simple";
  const m = $("message");
  m.innerHTML = "";
  const p = document.createElement("div");
  p.textContent = "Impossible d'afficher ce PDF (" + (e && e.message ? e.message : "erreur") + ").";
  const a = document.createElement("a");
  a.href = lien; a.textContent = "Ouvrir en lecture simple"; a.style.cssText = "display:block;margin-top:14px;color:#4F8CFF";
  m.appendChild(p); m.appendChild(a); m.classList.add("on");
});
