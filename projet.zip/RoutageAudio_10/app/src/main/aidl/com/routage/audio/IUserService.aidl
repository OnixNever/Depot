package com.routage.audio;

interface IUserService {
    void destroy() = 16777114;
    String exec(String cmd) = 1;
    String route(int type, String address) = 2;
    String reset() = 3;
    String routeApps(String spec) = 4;
    String clearApps() = 5;
    String setMic(int type, String address) = 6;
    String clearMic() = 7;
}
