package com.exemple.pressepapiers

import android.app.Activity
import android.app.NotificationManager
import android.content.ContentUris
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/**
 * S'ouvre juste après une capture d'écran : tu rognes avec le cadre,
 * tu valides, et l'image part directement vers le PC.
 */
class CropActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ctx = this
        val id = intent.getLongExtra("id", 0L)
        getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("notif", 0))
        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

        val apercu = try { Envoi.decoder(ctx, uri, 1600) } catch (e: Exception) { null }
        if (apercu == null) {
            Toast.makeText(ctx, "Capture introuvable", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val dp = resources.displayMetrics.density
        val racine = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt())
        }
        // garde le bouton au-dessus de la barre de navigation / des gestes
        val marge = (12 * dp).toInt()
        racine.setOnApplyWindowInsetsListener { v, ins ->
            @Suppress("DEPRECATION")
            v.setPadding(
                marge + ins.systemWindowInsetLeft, marge + ins.systemWindowInsetTop,
                marge + ins.systemWindowInsetRight, marge + ins.systemWindowInsetBottom
            )
            ins
        }
        val rognage = CropView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            definir(apercu)
        }
        // un seul bouton, large, tout en bas
        val envoyer = Button(ctx).apply {
            text = "Envoyer"
            textSize = 18f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (64 * dp).toInt()
            ).apply { topMargin = (12 * dp).toInt() }
        }

        envoyer.setOnClickListener {
            envoyer.isEnabled = false
            val p = 100
            val f = rognage.fractions()
            Thread {
                val code = try {
                    val complete = Envoi.decoder(ctx, uri, Int.MAX_VALUE)
                    if (complete == null) {
                        -1
                    } else {
                        val x = (f.left * complete.width).toInt().coerceIn(0, complete.width - 1)
                        val y = (f.top * complete.height).toInt().coerceIn(0, complete.height - 1)
                        val w = ((f.right - f.left) * complete.width).toInt().coerceIn(1, complete.width - x)
                        val h = ((f.bottom - f.top) * complete.height).toInt().coerceIn(1, complete.height - y)
                        val rogne: Bitmap = Bitmap.createBitmap(complete, x, y, w, h)
                        val r = Envoi.envoyer(ctx, rogne, p)
                        if (rogne !== complete) rogne.recycle()
                        complete.recycle()
                        r
                    }
                } catch (e: Exception) {
                    -1
                }
                runOnUiThread {
                    Toast.makeText(ctx, Envoi.message(code), Toast.LENGTH_LONG).show()
                    if (code == 200) finish() else envoyer.isEnabled = true
                }
            }.start()
        }

        racine.addView(rognage)
        racine.addView(envoyer)
        setContentView(racine)
    }
}
