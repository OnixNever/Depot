package com.exemple.pressepapiers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Affiche l'image entière, centrée. Quand [dessin] est vrai, le doigt trace des traits :
 * à chaque trait terminé, [surTrait] reçoit les points (en fractions de l'image) et
 * l'épaisseur (en fraction de la largeur de l'image).
 */
class DessinView(c: Context) : View(c) {
    private var bitmap: Bitmap? = null
    private var ox = 0f
    private var oy = 0f
    private var dw = 0f
    private var dh = 0f

    var dessin = false
    var couleur = Color.RED
    var surligneur = false

    /** Épaisseur du stylo à l'écran, en pixels (x3 pour le surligneur). */
    var epaisseur = 10f
    var surTrait: ((List<PointF>, Float) -> Unit)? = null

    private val pts = ArrayList<PointF>()
    private val peinture = Paint(Paint.FILTER_BITMAP_FLAG)
    private val live = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        setBackgroundColor(Color.BLACK)
    }

    fun definir(b: Bitmap) {
        bitmap = b
        calculer()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        calculer()
    }

    private fun calculer() {
        val b = bitmap ?: return
        if (width == 0 || height == 0) return
        val s = minOf((width - 48f) / b.width, (height - 48f) / b.height)
        dw = b.width * s
        dh = b.height * s
        ox = (width - dw) / 2f
        oy = (height - dh) / 2f
    }

    private fun largeurEcran() = epaisseur * (if (surligneur) 3f else 1f)

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        if (b.isRecycled) return
        canvas.drawBitmap(b, null, RectF(ox, oy, ox + dw, oy + dh), peinture)
        if (pts.isNotEmpty()) {
            live.color = couleur
            live.strokeWidth = largeurEcran()
            if (surligneur) live.alpha = 110
            canvas.save()
            canvas.clipRect(ox, oy, ox + dw, oy + dh)
            canvas.drawPath(Editeur.chemin(pts, ox, oy, dw, dh), live)
            canvas.restore()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!dessin || bitmap == null || dw <= 0f || dh <= 0f) return false
        val nx = ((e.x - ox) / dw).coerceIn(0f, 1f)
        val ny = ((e.y - oy) / dh).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                pts.clear()
                pts.add(PointF(nx, ny))
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                pts.add(PointF(nx, ny))
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                pts.add(PointF(nx, ny))
                val liste = ArrayList(pts)
                pts.clear()
                surTrait?.invoke(liste, largeurEcran() / dw)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                pts.clear()
                invalidate()
            }
        }
        return true
    }
}
