package com.exemple.pressepapiers

import android.app.Activity
import android.app.NotificationManager
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/**
 * Éditeur de capture, ouvert juste après une capture d'écran :
 * rogner, dessiner, régler netteté / luminosité / contraste, pivoter.
 * Le bouton « Envoyer » (en haut à droite) applique tout sur l'image d'origine et l'envoie au PC.
 */
class CropActivity : Activity() {

    private enum class Outil { ROGNER, DESSINER, AJUSTER }

    private val ACTIF = Color.parseColor("#64B5F6")

    private lateinit var uri: Uri
    private lateinit var original: Bitmap   // aperçu de départ, jamais modifié
    private lateinit var courant: Bitmap    // aperçu avec les modifications déjà validées
    private val ops = ArrayList<Op>()
    private var outil = Outil.ROGNER
    private var envoiEnCours = false

    private lateinit var rognage: CropView
    private lateinit var dessin: DessinView
    private lateinit var optionsDessin: LinearLayout
    private lateinit var optionsAjuster: LinearLayout
    private lateinit var envoyer: Button
    private lateinit var annuler: TextView
    private lateinit var sNet: SeekBar
    private lateinit var sLum: SeekBar
    private lateinit var sCon: SeekBar
    private val boutonsOutils = HashMap<Outil, TextView>()
    private val pastilles = ArrayList<Pair<View, Int>>()

    private var apercuAjuste: Bitmap? = null
    private var ajustement = Op.Ajuster(0, 0, 0)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ctx = this
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val id = intent.getLongExtra("id", 0L)
        getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("notif", 0))
        uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

        val apercu = try { Envoi.decoder(ctx, uri, 1600) } catch (e: Exception) { null }
        val copie = apercu?.copy(Bitmap.Config.ARGB_8888, true)
        if (apercu == null || copie == null) {
            Toast.makeText(ctx, "Capture introuvable", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        original = apercu
        courant = copie

        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val racine = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        racine.setOnApplyWindowInsetsListener { v, ins ->
            @Suppress("DEPRECATION")
            v.setPadding(
                ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom
            )
            ins
        }

        // ---------- barre du haut : fermer, annuler, ... Envoyer (en haut à droite) ----------
        fun icone(t: String) = TextView(ctx).apply {
            text = t
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(px(48), px(48))
        }
        val fermer = icone("✕")
        annuler = icone("↩")
        val espace = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }
        envoyer = Button(ctx).apply {
            text = "Envoyer"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E88E5"))
                cornerRadius = px(22).toFloat()
            }
            setPadding(px(22), 0, px(22), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, px(44))
        }
        val barre = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(8), px(6), px(12), px(6))
            addView(fermer)
            addView(annuler)
            addView(espace)
            addView(envoyer)
        }

        // ---------- zone centrale ----------
        rognage = CropView(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            definir(courant)
        }
        dessin = DessinView(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            visibility = View.GONE
            epaisseur = 10f * dp
        }
        val zone = FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(rognage)
            addView(dessin)
        }

        // ---------- options du dessin ----------
        val couleurs = listOf("#E53935", "#FDD835", "#43A047", "#1E88E5", "#FFFFFF", "#000000")
        val ligneCouleurs = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for (cs in couleurs) {
            val c = Color.parseColor(cs)
            val v = View(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(px(34), px(34)).apply {
                    setMargins(px(6), px(4), px(6), px(4))
                }
                setOnClickListener {
                    dessin.couleur = c
                    majPastilles()
                }
            }
            pastilles.add(Pair(v, c))
            ligneCouleurs.addView(v)
        }
        val epaisseurBarre = SeekBar(ctx).apply {
            max = 30
            progress = 7
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    dessin.epaisseur = (v + 3) * dp
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val texteEpaisseur = TextView(ctx).apply {
            text = "Épaisseur"
            textSize = 14f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(px(84), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val interrupteurSurligneur = Switch(ctx).apply {
            text = "Surligneur"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, coche -> dessin.surligneur = coche }
        }
        val ligneEpaisseur = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(texteEpaisseur)
            addView(epaisseurBarre)
        }
        optionsDessin = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(4), px(16), px(4))
            visibility = View.GONE
            addView(ligneCouleurs)
            addView(ligneEpaisseur)
            addView(interrupteurSurligneur)
        }

        // ---------- options netteté / luminosité / contraste ----------
        val ecoute = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                majAjustement()
            }
        }
        fun ligne(nom: String, maxi: Int, depart: Int): Pair<LinearLayout, SeekBar> {
            val sb = SeekBar(ctx).apply {
                this.max = maxi
                progress = depart
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(ecoute)
            }
            val t = TextView(ctx).apply {
                text = nom
                textSize = 14f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(px(84), ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val l = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(t)
                addView(sb)
            }
            return Pair(l, sb)
        }
        val (ln, sn) = ligne("Netteté", 100, 0)
        val (ll, sl) = ligne("Luminosité", 200, 100)
        val (lc, sc) = ligne("Contraste", 200, 100)
        sNet = sn
        sLum = sl
        sCon = sc
        optionsAjuster = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(4), px(16), px(4))
            visibility = View.GONE
            addView(ln)
            addView(ll)
            addView(lc)
        }

        // ---------- barre d'outils du bas ----------
        fun boutonOutil(symbole: String, nom: String) = TextView(ctx).apply {
            text = "$symbole\n$nom"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, px(8), 0, px(8))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val bRogner = boutonOutil("✂", "Rogner")
        val bDessiner = boutonOutil("✏", "Dessiner")
        val bAjuster = boutonOutil("◐", "Ajuster")
        val bPivoter = boutonOutil("↻", "Pivoter")
        boutonsOutils[Outil.ROGNER] = bRogner
        boutonsOutils[Outil.DESSINER] = bDessiner
        boutonsOutils[Outil.AJUSTER] = bAjuster
        val outils = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1A1A1A"))
            addView(bRogner)
            addView(bDessiner)
            addView(bAjuster)
            addView(bPivoter)
        }

        // ---------- actions ----------
        fermer.setOnClickListener { finish() }
        annuler.setOnClickListener { annulerDerniere() }
        bRogner.setOnClickListener { choisir(Outil.ROGNER) }
        bDessiner.setOnClickListener { choisir(Outil.DESSINER) }
        bAjuster.setOnClickListener { choisir(Outil.AJUSTER) }
        bPivoter.setOnClickListener {
            if (envoiEnCours) return@setOnClickListener
            valider()
            ajouter(Op.Pivoter(1))
            afficherOutil()
        }
        dessin.surTrait = { pts, largeur ->
            ajouter(Op.Trait(pts, dessin.couleur, largeur, dessin.surligneur))
            dessin.definir(courant)
        }
        envoyer.setOnClickListener { lancerEnvoi() }

        racine.addView(barre)
        racine.addView(zone)
        racine.addView(optionsDessin)
        racine.addView(optionsAjuster)
        racine.addView(outils)
        setContentView(racine)

        majPastilles()
        afficherOutil()
    }

    // ---------------- état de l'éditeur ----------------

    private fun majPastilles() {
        val dp = resources.displayMetrics.density
        for ((v, c) in pastilles) {
            val choisie = c == dessin.couleur
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke((if (choisie) 3 else 1) * dp.toInt(), if (choisie) ACTIF else Color.GRAY)
            }
        }
    }

    private fun majAnnuler() {
        val quelqueChose = ops.isNotEmpty() || (outil == Outil.AJUSTER && apercuAjuste != null)
        annuler.alpha = if (quelqueChose) 1f else 0.35f
    }

    /** Montre dans la vue visible l'image à jour. */
    private fun montrer() {
        if (outil == Outil.ROGNER) rognage.definir(courant) else dessin.definir(apercuAjuste ?: courant)
    }

    private fun choisir(nouveau: Outil) {
        if (envoiEnCours || nouveau == outil) return
        valider()
        outil = nouveau
        afficherOutil()
    }

    private fun afficherOutil() {
        rognage.visibility = if (outil == Outil.ROGNER) View.VISIBLE else View.GONE
        dessin.visibility = if (outil == Outil.ROGNER) View.GONE else View.VISIBLE
        dessin.dessin = outil == Outil.DESSINER
        optionsDessin.visibility = if (outil == Outil.DESSINER) View.VISIBLE else View.GONE
        optionsAjuster.visibility = if (outil == Outil.AJUSTER) View.VISIBLE else View.GONE
        if (outil == Outil.AJUSTER) {
            sNet.progress = 0
            sLum.progress = 100
            sCon.progress = 100
            ajustement = Op.Ajuster(0, 0, 0)
            apercuAjuste = null
        }
        montrer()
        for ((o, t) in boutonsOutils) t.setTextColor(if (o == outil) ACTIF else Color.LTGRAY)
        majAnnuler()
    }

    /** Ajoute une modification à l'aperçu (l'ancienne image est consommée). */
    private fun ajouter(op: Op) {
        courant = Editeur.appliquer(courant, op)
        ops.add(op)
        majAnnuler()
    }

    /** Valide ce qui est en cours dans l'outil actif (cadre de rognage, réglages). */
    private fun valider() {
        when (outil) {
            Outil.ROGNER -> {
                val f = rognage.fractions()
                if (f.left > 0.003f || f.top > 0.003f || f.right < 0.997f || f.bottom < 0.997f) {
                    ajouter(Op.Rogner(f.left, f.top, f.right, f.bottom))
                }
            }
            Outil.AJUSTER -> {
                val a = ajustement
                val ap = apercuAjuste
                if (ap != null && (a.nettete != 0 || a.lumiere != 0 || a.contraste != 0)) {
                    val ancien = courant
                    courant = ap
                    apercuAjuste = null
                    ancien.recycle()
                    ops.add(a)
                    majAnnuler()
                }
                apercuAjuste = null
                ajustement = Op.Ajuster(0, 0, 0)
            }
            Outil.DESSINER -> {}
        }
    }

    private fun majAjustement() {
        ajustement = Op.Ajuster(sNet.progress, sLum.progress - 100, sCon.progress - 100)
        val ancien = apercuAjuste
        if (ajustement.nettete == 0 && ajustement.lumiere == 0 && ajustement.contraste == 0) {
            apercuAjuste = null
            dessin.definir(courant)
        } else {
            val copie = courant.copy(Bitmap.Config.ARGB_8888, true) ?: return
            val nouveau = Editeur.appliquer(copie, ajustement)
            apercuAjuste = nouveau
            dessin.definir(nouveau)
        }
        ancien?.recycle()
        majAnnuler()
    }

    private fun annulerDerniere() {
        if (envoiEnCours) return
        // un réglage en cours (curseurs) s'annule d'abord
        if (outil == Outil.AJUSTER && apercuAjuste != null) {
            sNet.progress = 0
            sLum.progress = 100
            sCon.progress = 100
            majAjustement()
            return
        }
        if (ops.isEmpty()) return
        ops.removeAt(ops.size - 1)
        val ancien = courant
        val base = original.copy(Bitmap.Config.ARGB_8888, true) ?: return
        courant = Editeur.rejouer(base, ops)
        montrer()
        if (ancien !== courant) ancien.recycle()
        majAnnuler()
    }

    // ---------------- envoi ----------------

    private fun lancerEnvoi() {
        if (envoiEnCours) return
        valider()
        montrer()
        envoiEnCours = true
        envoyer.isEnabled = false
        envoyer.text = "Envoi…"
        val liste = ArrayList(ops)
        val ctx = this
        Thread {
            val code = try {
                val complete = Envoi.decoder(ctx, uri, Int.MAX_VALUE)
                if (complete == null) {
                    -1
                } else {
                    // les modifications sont rejouées sur l'image d'origine, en pleine résolution
                    val finale = Editeur.rejouer(complete, liste)
                    val r = Envoi.envoyer(ctx, finale, 100)
                    finale.recycle()
                    r
                }
            } catch (e: OutOfMemoryError) {
                -2
            } catch (e: Exception) {
                -1
            }
            runOnUiThread {
                Toast.makeText(ctx, Envoi.message(code), Toast.LENGTH_LONG).show()
                if (code == 200) {
                    finish()
                } else {
                    envoiEnCours = false
                    envoyer.isEnabled = true
                    envoyer.text = "Envoyer"
                }
            }
        }.start()
    }
}
