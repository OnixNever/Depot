package com.exemple.pressepapiers

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF

/**
 * Une modification faite dans l'éditeur. Toutes les positions sont en fractions (0 à 1)
 * de l'image au moment de la modification : on peut donc les rejouer à l'identique
 * sur l'image en pleine résolution au moment de l'envoi.
 */
sealed class Op {
    /** Rotation de [quarts] x 90° dans le sens horaire. */
    data class Pivoter(val quarts: Int) : Op()

    /** Rognage : gauche, haut, droite, bas (fractions de l'image). */
    data class Rogner(val g: Float, val h: Float, val d: Float, val b: Float) : Op()

    /** Trait de dessin. [largeur] = épaisseur finale en fraction de la largeur de l'image. */
    class Trait(val pts: List<PointF>, val couleur: Int, val largeur: Float, val surligneur: Boolean) : Op()

    /** Netteté (0 à 100), luminosité et contraste (-100 à 100). */
    data class Ajuster(val nettete: Int, val lumiere: Int, val contraste: Int) : Op()
}

object Editeur {

    /**
     * Applique une modification. L'image [src] est « consommée » : elle peut être modifiée sur place
     * ou libérée, il faut donc utiliser uniquement l'image renvoyée.
     */
    fun appliquer(src: Bitmap, op: Op): Bitmap = when (op) {
        is Op.Pivoter -> {
            val m = Matrix().apply { postRotate(90f * (((op.quarts % 4) + 4) % 4)) }
            val r = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            if (r !== src) src.recycle()
            r
        }
        is Op.Rogner -> {
            val x = (op.g * src.width).toInt().coerceIn(0, src.width - 1)
            val y = (op.h * src.height).toInt().coerceIn(0, src.height - 1)
            val w = ((op.d - op.g) * src.width).toInt().coerceIn(1, src.width - x)
            val h = ((op.b - op.h) * src.height).toInt().coerceIn(1, src.height - y)
            val r = Bitmap.createBitmap(src, x, y, w, h)
            if (r !== src) src.recycle()
            r
        }
        is Op.Trait -> trait(src, op)
        is Op.Ajuster -> ajuster(src, op)
    }

    /** Rejoue une liste de modifications sur [base] (consommée). */
    fun rejouer(base: Bitmap, ops: List<Op>): Bitmap {
        var b = base
        for (op in ops) b = appliquer(b, op)
        return b
    }

    /** Chemin lissé à partir de points en fractions, placé dans le rectangle (ox, oy, lw x lh). */
    fun chemin(pts: List<PointF>, ox: Float, oy: Float, lw: Float, lh: Float): Path {
        val p = Path()
        if (pts.isEmpty()) return p
        val premier = pts[0]
        p.moveTo(ox + premier.x * lw, oy + premier.y * lh)
        if (pts.size == 1) {
            p.lineTo(ox + premier.x * lw + 0.1f, oy + premier.y * lh + 0.1f)
            return p
        }
        for (i in 1 until pts.size) {
            val a = pts[i - 1]
            val b = pts[i]
            val mx = (a.x + b.x) / 2f
            val my = (a.y + b.y) / 2f
            p.quadTo(ox + a.x * lw, oy + a.y * lh, ox + mx * lw, oy + my * lh)
        }
        val dernier = pts.last()
        p.lineTo(ox + dernier.x * lw, oy + dernier.y * lh)
        return p
    }

    private fun trait(src: Bitmap, op: Op.Trait): Bitmap {
        val b: Bitmap = if (src.isMutable && src.config == Bitmap.Config.ARGB_8888) {
            src
        } else {
            val copie = src.copy(Bitmap.Config.ARGB_8888, true) ?: return src
            src.recycle()
            copie
        }
        val peinture = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            color = op.couleur
            strokeWidth = maxOf(1f, op.largeur * b.width)
            if (op.surligneur) alpha = 110
        }
        Canvas(b).drawPath(chemin(op.pts, 0f, 0f, b.width.toFloat(), b.height.toFloat()), peinture)
        return b
    }

    private fun ajuster(src: Bitmap, op: Op.Ajuster): Bitmap {
        var b = src
        if (op.nettete > 0) {
            val r = nettete(b, op.nettete / 100f * 1.2f)
            b.recycle()
            b = r
        }
        if (op.lumiere != 0 || op.contraste != 0) {
            val c = if (op.contraste >= 0) 1f + op.contraste / 50f else 1f + op.contraste / 200f
            val t = 128f * (1f - c) + op.lumiere * 1.5f
            val cm = ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, t,
                    0f, c, 0f, 0f, t,
                    0f, 0f, c, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            val sortie = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
            val p = Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
            Canvas(sortie).drawBitmap(b, 0f, 0f, p)
            b.recycle()
            b = sortie
        }
        return b
    }

    private fun borne(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else v.toInt()

    /** Netteté par masque 3x3 : pixel * (1 + 4a) - a * (haut + bas + gauche + droite). */
    private fun nettete(src: Bitmap, a: Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val out = px.copyOf()
        val k = 1f + 4f * a
        for (y in 1 until h - 1) {
            var i = y * w + 1
            for (x in 1 until w - 1) {
                val c = px[i]
                val u = px[i - w]
                val d = px[i + w]
                val l = px[i - 1]
                val r = px[i + 1]
                val rr = ((c shr 16) and 255) * k -
                    a * (((u shr 16) and 255) + ((d shr 16) and 255) + ((l shr 16) and 255) + ((r shr 16) and 255))
                val gg = ((c shr 8) and 255) * k -
                    a * (((u shr 8) and 255) + ((d shr 8) and 255) + ((l shr 8) and 255) + ((r shr 8) and 255))
                val bb = (c and 255) * k -
                    a * ((u and 255) + (d and 255) + (l and 255) + (r and 255))
                out[i] = (c and -16777216) or (borne(rr) shl 16) or (borne(gg) shl 8) or borne(bb)
                i++
            }
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }
}
