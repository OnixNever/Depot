package com.exemple.pressepapiers

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class SyncService : Service() {
    companion object {
        const val ACTION_ENVOYER = "com.exemple.pressepapiers.ENVOYER"
        const val ACTION_REAFFICHER = "com.exemple.pressepapiers.REAFFICHER"
    }

    private val images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private var dernierId = 0L
    private var depuis = System.currentTimeMillis() / 1000

    // anti-doublons pour ce qui vient du PC
    private val dejaVus = LinkedHashSet<String>()
    private var derniereCle = ""
    private var derniereHeure = 0L

    @Volatile
    private var actif = true
    private lateinit var observateur: ContentObserver

    override fun onBind(i: Intent?): IBinder? = null

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun notifService(): Notification {
        val reafficher = PendingIntent.getService(
            this, 0,
            Intent(this, SyncService::class.java).setAction(ACTION_REAFFICHER),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, "sync")
            .setContentTitle("Presse-papiers partagé actif")
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .setDeleteIntent(reafficher) // si tu la balaies, elle revient
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        val nm = nm()
        nm.createNotificationChannel(NotificationChannel("sync", "Synchronisation", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("recu", "Reçu du PC", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("capture", "Capture prête", NotificationManager.IMPORTANCE_HIGH))
        val n = notifService()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }

        dernierId = lireDernierId()
        observateur = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                Thread { verifierCaptures() }.start()
            }
        }
        contentResolver.registerContentObserver(images, true, observateur)
        Thread { ecouterPc() }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val i = intent ?: return START_STICKY
        when (i.action) {
            ACTION_REAFFICHER -> nm().notify(1, notifService())
            ACTION_ENVOYER -> {
                val id = i.getLongExtra("id", 0L)
                nm().cancel(i.getIntExtra("notif", 0))
                Thread { envoyerCapture(id, 100) }.start()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        actif = false
        contentResolver.unregisterContentObserver(observateur)
        super.onDestroy()
    }

    private fun toast(message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
        }
    }

    // ---------------- Téléphone -> PC ----------------

    private fun lireDernierId(): Long {
        try {
            contentResolver.query(
                images,
                arrayOf(MediaStore.Images.Media._ID),
                null,
                null,
                MediaStore.Images.Media._ID + " DESC"
            )?.use {
                if (it.moveToFirst()) return it.getLong(0)
            }
        } catch (e: Exception) {
        }
        return 0L
    }

    @Synchronized
    private fun verifierCaptures() {
        try {
            Thread.sleep(700)
            val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH)
            contentResolver.query(
                images,
                proj,
                MediaStore.Images.Media._ID + " > ?",
                arrayOf(dernierId.toString()),
                MediaStore.Images.Media._ID + " ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    dernierId = maxOf(dernierId, id)
                    val chemin = c.getString(1) ?: ""
                    if (chemin.contains("screenshot", ignoreCase = true)) {
                        if (Config.demander(this)) {
                            proposerCapture(id)
                        } else {
                            envoyerCapture(id, Config.pourcent(this))
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    /** Notification « Capture prête » : toucher = ajuster la taille, ou bouton = envoyer tel quel. */
    private fun proposerCapture(id: Long) {
        val nid = (System.currentTimeMillis() % 100000).toInt() + 10
        val uri = ContentUris.withAppendedId(images, id)

        val ouvrir = Intent(this, ResizeActivity::class.java)
            .putExtra("id", id)
            .putExtra("notif", nid)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val piOuvrir = PendingIntent.getActivity(
            this, nid, ouvrir,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val direct = Intent(this, SyncService::class.java)
            .setAction(ACTION_ENVOYER)
            .putExtra("id", id)
            .putExtra("notif", nid)
        val piDirect = PendingIntent.getService(
            this, nid, direct,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val b = Notification.Builder(this, "capture")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Capture prête")
            .setContentText("Touche pour ajuster la taille puis envoyer au PC")
            .setContentIntent(piOuvrir)
            .setAutoCancel(true)
            .addAction(0, "Envoyer tel quel", piDirect)
        val miniature = try { Envoi.decoder(this, uri, 700) } catch (e: Exception) { null }
        if (miniature != null) {
            b.setStyle(Notification.BigPictureStyle().bigPicture(miniature))
        }
        nm().notify(nid, b.build())
    }

    private fun envoyerCapture(id: Long, pourcent: Int) {
        val uri = ContentUris.withAppendedId(images, id)
        val code = try {
            val bmp = Envoi.decoder(this, uri, Int.MAX_VALUE)
            if (bmp == null) {
                -1
            } else {
                val r = Envoi.envoyer(this, bmp, pourcent)
                bmp.recycle()
                r
            }
        } catch (e: Exception) {
            -1
        }
        toast(Envoi.message(code))
    }

    // ---------------- PC -> Téléphone ----------------

    private fun ecouterPc() {
        while (actif) {
            try {
                val adresse = "https://ntfy.sh/" + Config.sujet(this) + "/json?since=" + depuis
                val cx = URL(adresse).openConnection() as HttpURLConnection
                cx.readTimeout = 90000
                cx.inputStream.bufferedReader().forEachLine { ligne ->
                    if (ligne.isNotBlank()) {
                        try {
                            traiter(JSONObject(ligne))
                        } catch (e: Exception) {
                        }
                    }
                }
            } catch (e: Exception) {
            }
            if (actif) Thread.sleep(5000)
        }
    }

    private fun empreinte(octets: ByteArray): String =
        MessageDigest.getInstance("MD5").digest(octets).joinToString("") { "%02x".format(it) }

    /** Vrai si ce contenu a déjà été notifié il y a moins de 8 secondes. */
    private fun estDoublon(cle: String): Boolean {
        val maintenant = System.currentTimeMillis()
        if (cle == derniereCle && maintenant - derniereHeure < 8000) return true
        derniereCle = cle
        derniereHeure = maintenant
        return false
    }

    @Synchronized
    private fun traiter(j: JSONObject) {
        if (j.optString("event") != "message") return
        depuis = j.optLong("time") + 1

        // même message ntfy reçu deux fois (reconnexion) : on l'ignore
        val idMessage = j.optString("id")
        if (idMessage.isNotEmpty()) {
            if (!dejaVus.add(idMessage)) return
            if (dejaVus.size > 200) dejaVus.remove(dejaVus.first())
        }

        val att = j.optJSONObject("attachment")
        if (att == null) {
            val texte = j.optString("message")
            if (texte.isBlank()) return // message vide : pas de notification
            if (estDoublon("txt" + empreinte(texte.toByteArray(Charsets.UTF_8)))) return
            notifier(texte, null)
            return
        }
        val octets = telecharger(att.getString("url"))
        if (att.optString("type").startsWith("image")) {
            if (estDoublon("img" + empreinte(octets))) return
            val dossier = File(cacheDir, "partage").apply { mkdirs() }
            val f = File(dossier, "pc_" + j.optLong("time") + ".jpg")
            f.writeBytes(octets)
            notifier(null, f)
        } else {
            val texte = String(octets, Charsets.UTF_8)
            if (texte.isBlank()) return
            if (estDoublon("txt" + empreinte(octets))) return
            notifier(texte, null)
        }
    }

    private fun telecharger(adresse: String): ByteArray {
        val cx = URL(adresse).openConnection() as HttpURLConnection
        cx.connectTimeout = 10000
        cx.readTimeout = 30000
        return cx.inputStream.use { it.readBytes() }
    }

    private fun notifier(texte: String?, fichier: File?) {
        val id = (System.currentTimeMillis() % 100000).toInt()
        val copier = Intent(this, CopyReceiver::class.java)
        if (texte != null) copier.putExtra("texte", texte)
        if (fichier != null) copier.putExtra("fichier", fichier.absolutePath)
        val pi = PendingIntent.getBroadcast(
            this, id, copier,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, "recu")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(if (fichier != null) "Image du PC" else "Texte du PC")
            .setAutoCancel(true)
            .addAction(0, "Copier", pi)
        if (texte != null) {
            b.setContentText(texte).setStyle(Notification.BigTextStyle().bigText(texte))
        } else if (fichier != null) {
            b.setContentText("Touche Copier pour la mettre dans le presse-papiers")
            val apercu = Envoi.decoderFichier(fichier.absolutePath, 1024)
            if (apercu != null) b.setStyle(Notification.BigPictureStyle().bigPicture(apercu))
        }
        nm().notify(id, b.build())
    }
}
