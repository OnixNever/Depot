package com.exemple.pressepapiers

import android.app.Activity
import android.app.NotificationManager
import android.content.ContentUris
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Aperçu de la capture avec un curseur de taille, avant l'envoi vers le PC. */
class ResizeActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ctx = this
        val id = intent.getLongExtra("id", 0L)
        getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("notif", 0))
        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

        val apercu = try { Envoi.decoder(ctx, uri, 1600) } catch (e: Exception) { null }
        if (apercu == null) {
            Toast.makeText(ctx, "Capture introuvable", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        val largeur = if (o.outWidth > 0) o.outWidth else apercu.width
        val hauteur = if (o.outHeight > 0) o.outHeight else apercu.height

        val racine = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }
        val image = ImageView(ctx).apply {
            setImageBitmap(apercu)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val info = TextView(ctx).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 8)
        }
        val curseur = SeekBar(ctx).apply {
            max = 90 // 10 % à 100 %
            progress = Config.pourcent(ctx) - 10
        }
        fun maj() {
            val p = curseur.progress + 10
            info.text = "Origine $largeur × $hauteur px\nEnvoi ${largeur * p / 100} × ${hauteur * p / 100} px ($p %)"
        }
        maj()
        curseur.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) = maj()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val annuler = Button(ctx).apply {
            text = "Annuler"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val envoyer = Button(ctx).apply {
            text = "Envoyer au PC"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val boutons = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(annuler)
            addView(envoyer)
        }

        annuler.setOnClickListener { finish() }
        envoyer.setOnClickListener {
            envoyer.isEnabled = false
            val p = curseur.progress + 10
            Config.savePourcent(ctx, p)
            Thread {
                val code = try {
                    val complete = Envoi.decoder(ctx, uri, Int.MAX_VALUE)
                    if (complete == null) {
                        -1
                    } else {
                        val r = Envoi.envoyer(ctx, complete, p)
                        complete.recycle()
                        r
                    }
                } catch (e: Exception) {
                    -1
                }
                runOnUiThread {
                    Toast.makeText(ctx, Envoi.message(code), Toast.LENGTH_LONG).show()
                    if (code == 200) finish() else envoyer.isEnabled = true
                }
            }.start()
        }

        listOf(image, info, curseur, boutons).forEach { racine.addView(it) }
        setContentView(racine)
    }
}
