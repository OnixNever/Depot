package com.exemple.pressepapiers

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val cm = c.getSystemService(ClipboardManager::class.java)
        val texte = i.getStringExtra("texte")
        val fichier = i.getStringExtra("fichier")
        val clip = when {
            texte != null -> ClipData.newPlainText("pc", texte)
            fichier != null -> {
                val uri = FileProvider.getUriForFile(c, c.packageName + ".fp", File(fichier))
                ClipData.newUri(c.contentResolver, "image", uri)
            }
            else -> return
        }
        cm.setPrimaryClip(clip)
        Toast.makeText(c, "Copié", Toast.LENGTH_SHORT).show()
    }
}
