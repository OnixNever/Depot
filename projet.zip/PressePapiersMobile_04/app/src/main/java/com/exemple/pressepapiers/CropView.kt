package com.exemple.pressepapiers

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs

/**
 * Rognage façon galerie photo :
 * - tirer un coin ou un bord du cadre pour le redimensionner dans tous les sens ;
 * - pincer pour zoomer dans l'image, glisser pour la déplacer sous le cadre ;
 * - quand tu lâches le cadre, il se recentre et l'image zoome pour remplir l'écran.
 */
class CropView(c: Context) : View(c) {
    private var bitmap: Bitmap? = null
    private var bw = 1f
    private var bh = 1f

    // image : position écran = position bitmap * echelle + (tx, ty)
    private var echelle = 1f
    private var echelleDepart = 1f
    private var tx = 0f
    private var ty = 0f

    private val zone = RectF()   // espace disponible pour l'image et le cadre
    private val cadre = RectF()  // cadre de rognage, en coordonnées écran
    private val mat = Matrix()
    private var animation: ValueAnimator? = null

    private val peinture = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val voile = Paint().apply { color = Color.argb(170, 0, 0, 0) }
    private val bord = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val grille = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(100, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val equerre = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 9f
        strokeCap = Paint.Cap.SQUARE
    }

    private val marge = 56f
    private val minimum = 120f
    private val GAUCHE = 1
    private val HAUT = 2
    private val DROITE = 4
    private val BAS = 8
    private val PAN = 32
    private var mode = 0
    private var dernierX = 0f
    private var dernierY = 0f

    private val detecteur = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val mini = echelleMin()
            val maxi = maxOf(echelleDepart * 10f, mini)
            val nouvelle = (echelle * d.scaleFactor).coerceIn(mini, maxi)
            val k = nouvelle / echelle
            tx = d.focusX - (d.focusX - tx) * k
            ty = d.focusY - (d.focusY - ty) * k
            echelle = nouvelle
            caler()
            invalidate()
            return true
        }
    })

    init {
        setBackgroundColor(Color.BLACK)
    }

    fun definir(b: Bitmap) {
        bitmap = b
        bw = b.width.toFloat()
        bh = b.height.toFloat()
        if (width > 0) initialiser()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        initialiser()
    }

    /** Image entière, centrée, cadre sur toute l'image. */
    private fun initialiser() {
        if (bitmap == null || width == 0 || height == 0) return
        animation?.cancel()
        zone.set(24f, 24f, width - 24f, height - 24f)
        echelleDepart = minOf(zone.width() / bw, zone.height() / bh)
        echelle = echelleDepart
        tx = zone.centerX() - bw * echelle / 2
        ty = zone.centerY() - bh * echelle / 2
        cadre.set(tx, ty, tx + bw * echelle, ty + bh * echelle)
    }

    fun toutReinitialiser() {
        initialiser()
        invalidate()
    }

    private fun echelleMin() = maxOf(cadre.width() / bw, cadre.height() / bh)

    private fun borne(v: Float, bas: Float, haut: Float): Float = if (bas > haut) haut else v.coerceIn(bas, haut)

    /** L'image doit toujours couvrir entièrement le cadre. */
    private fun caler() {
        echelle = maxOf(echelle, echelleMin())
        tx = borne(tx, cadre.right - bw * echelle, cadre.left)
        ty = borne(ty, cadre.bottom - bh * echelle, cadre.top)
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        mat.reset()
        mat.postScale(echelle, echelle)
        mat.postTranslate(tx, ty)
        canvas.drawBitmap(b, mat, peinture)

        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, cadre.top, voile)
        canvas.drawRect(0f, cadre.bottom, w, h, voile)
        canvas.drawRect(0f, cadre.top, cadre.left, cadre.bottom, voile)
        canvas.drawRect(cadre.right, cadre.top, w, cadre.bottom, voile)

        val tiersX = cadre.width() / 3
        val tiersY = cadre.height() / 3
        for (i in 1..2) {
            canvas.drawLine(cadre.left + tiersX * i, cadre.top, cadre.left + tiersX * i, cadre.bottom, grille)
            canvas.drawLine(cadre.left, cadre.top + tiersY * i, cadre.right, cadre.top + tiersY * i, grille)
        }
        canvas.drawRect(cadre, bord)

        // équerres aux quatre coins
        val l = 46f
        val g = cadre.left
        val d = cadre.right
        val t = cadre.top
        val bas = cadre.bottom
        canvas.drawLine(g, t, g + l, t, equerre)
        canvas.drawLine(g, t, g, t + l, equerre)
        canvas.drawLine(d, t, d - l, t, equerre)
        canvas.drawLine(d, t, d, t + l, equerre)
        canvas.drawLine(g, bas, g + l, bas, equerre)
        canvas.drawLine(g, bas, g, bas - l, equerre)
        canvas.drawLine(d, bas, d - l, bas, equerre)
        canvas.drawLine(d, bas, d, bas - l, equerre)
        // petites barres au milieu des bords
        val cx = cadre.centerX()
        val cy = cadre.centerY()
        canvas.drawLine(cx - 20f, t, cx + 20f, t, equerre)
        canvas.drawLine(cx - 20f, bas, cx + 20f, bas, equerre)
        canvas.drawLine(g, cy - 20f, g, cy + 20f, equerre)
        canvas.drawLine(d, cy - 20f, d, cy + 20f, equerre)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (animation?.isRunning == true) return true
        detecteur.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                mode = trouverMode(e.x, e.y)
                if (mode == 0) mode = PAN
                dernierX = e.x
                dernierY = e.y
            }
            MotionEvent.ACTION_POINTER_DOWN -> mode = PAN
            MotionEvent.ACTION_POINTER_UP -> {
                val reste = if (e.actionIndex == 0) 1 else 0
                dernierX = e.getX(reste)
                dernierY = e.getY(reste)
                mode = PAN
            }
            MotionEvent.ACTION_MOVE -> {
                if (detecteur.isInProgress) {
                    dernierX = e.x
                    dernierY = e.y
                    return true
                }
                val dx = e.x - dernierX
                val dy = e.y - dernierY
                dernierX = e.x
                dernierY = e.y
                if (mode == PAN) {
                    tx += dx
                    ty += dy
                    caler()
                } else if (mode != 0) {
                    redimensionner(dx, dy)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val avaitRedimensionne = mode != 0 && mode != PAN
                mode = 0
                if (avaitRedimensionne) recadrer()
            }
        }
        return true
    }

    private fun trouverMode(x: Float, y: Float): Int {
        val r = cadre
        var f = 0
        if (y > r.top - marge && y < r.bottom + marge) {
            val g = abs(x - r.left)
            val d = abs(x - r.right)
            if (g < marge && g <= d) f = f or GAUCHE else if (d < marge) f = f or DROITE
        }
        if (x > r.left - marge && x < r.right + marge) {
            val h = abs(y - r.top)
            val b = abs(y - r.bottom)
            if (h < marge && h <= b) f = f or HAUT else if (b < marge) f = f or BAS
        }
        return f
    }

    /** Tire les bords du cadre, sans sortir de l'image visible. */
    private fun redimensionner(dx: Float, dy: Float) {
        val lim = RectF(tx, ty, tx + bw * echelle, ty + bh * echelle)
        lim.intersect(zone)
        if (mode and GAUCHE != 0) cadre.left = borne(cadre.left + dx, lim.left, cadre.right - minimum)
        if (mode and DROITE != 0) cadre.right = borne(cadre.right + dx, cadre.left + minimum, lim.right)
        if (mode and HAUT != 0) cadre.top = borne(cadre.top + dy, lim.top, cadre.bottom - minimum)
        if (mode and BAS != 0) cadre.bottom = borne(cadre.bottom + dy, cadre.top + minimum, lim.bottom)
    }

    /** Après avoir lâché le cadre : il se recentre et l'image zoome pour que la zone remplisse l'écran. */
    private fun recadrer() {
        val k = minOf(zone.width() / cadre.width(), zone.height() / cadre.height())
        if (k < 1.03f) return
        val nw = cadre.width() * k
        val nh = cadre.height() * k
        val cible = RectF(zone.centerX() - nw / 2, zone.centerY() - nh / 2, zone.centerX() + nw / 2, zone.centerY() + nh / 2)
        val e1 = echelle
        val x1 = tx
        val y1 = ty
        val c1 = RectF(cadre)
        val e2 = e1 * k
        val x2 = cible.left - (c1.left - x1) * k
        val y2 = cible.top - (c1.top - y1) * k
        animation = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            addUpdateListener { v ->
                val f = v.animatedValue as Float
                echelle = e1 + (e2 - e1) * f
                tx = x1 + (x2 - x1) * f
                ty = y1 + (y2 - y1) * f
                cadre.set(
                    c1.left + (cible.left - c1.left) * f,
                    c1.top + (cible.top - c1.top) * f,
                    c1.right + (cible.right - c1.right) * f,
                    c1.bottom + (cible.bottom - c1.bottom) * f
                )
                invalidate()
            }
            start()
        }
    }

    /** Cadre exprimé en fractions (0 à 1) de l'image : gauche, haut, droite, bas. */
    fun fractions(): RectF {
        val lw = bw * echelle
        val lh = bh * echelle
        return RectF(
            ((cadre.left - tx) / lw).coerceIn(0f, 1f),
            ((cadre.top - ty) / lh).coerceIn(0f, 1f),
            ((cadre.right - tx) / lw).coerceIn(0f, 1f),
            ((cadre.bottom - ty) / lh).coerceIn(0f, 1f)
        )
    }
}
