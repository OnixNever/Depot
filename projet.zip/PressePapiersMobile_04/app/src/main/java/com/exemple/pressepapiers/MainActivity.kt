package com.exemple.pressepapiers

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statut: TextView

    private fun majStatut() {
        statut.text = if (Settings.canDrawOverlays(this)) {
            "Ouverture automatique du rognage : autorisée"
        } else {
            "Ouverture automatique du rognage : NON autorisée\n(touche Démarrer pour l'autoriser)"
        }
    }

    override fun onResume() {
        super.onResume()
        majStatut()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ctx = this
        val l = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        val titre = TextView(ctx).apply {
            text = "Presse-papiers partagé"
            textSize = 22f
        }
        val url = EditText(ctx).apply {
            hint = "Adresse ngrok (https://xxx.ngrok-free.app)"
            setText(Config.url(ctx))
        }
        val jeton = EditText(ctx).apply {
            hint = "Jeton (copié depuis le PC)"
            setText(Config.jeton(ctx))
        }
        val sujet = EditText(ctx).apply {
            hint = "Sujet ntfy (copié depuis le PC)"
            setText(Config.sujet(ctx))
        }
        val demander = Switch(ctx).apply {
            text = "Rogner la capture avant d'envoyer"
            isChecked = Config.demander(ctx)
            setPadding(0, 32, 0, 8)
        }
        val tailleTexte = TextView(ctx)
        val taille = SeekBar(ctx).apply {
            max = 90
            progress = Config.pourcent(ctx) - 10
        }
        fun majTaille() {
            tailleTexte.text = "Taille en envoi automatique : ${taille.progress + 10} %"
        }
        majTaille()
        taille.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) = majTaille()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        statut = TextView(ctx).apply { setPadding(0, 16, 0, 16) }
        val marche = Button(ctx).apply { text = "Démarrer" }
        val arret = Button(ctx).apply { text = "Arrêter" }

        marche.setOnClickListener {
            Config.save(ctx, url.text.toString(), jeton.text.toString(), sujet.text.toString())
            Config.saveOptions(ctx, demander.isChecked, taille.progress + 10)
            val p = if (Build.VERSION.SDK_INT >= 33) {
                arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.POST_NOTIFICATIONS)
            } else {
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            requestPermissions(p, 1)
        }
        arret.setOnClickListener { stopService(Intent(ctx, SyncService::class.java)) }

        listOf(titre, url, jeton, sujet, demander, tailleTexte, taille, statut, marche, arret).forEach { l.addView(it) }
        setContentView(l)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        startForegroundService(Intent(this, SyncService::class.java))
        // sans cette autorisation, Android interdit d'ouvrir le rognage tout seul après une capture
        if (Config.demander(this) && !Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
    }
}
