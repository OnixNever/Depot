package com.exemple.pressepapiers

import android.app.Activity
import android.app.NotificationManager
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/**
 * S'ouvre juste après une capture d'écran : tu rognes avec le cadre,
 * tu valides, et l'image part directement vers le PC.
 */
class CropActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ctx = this
        val id = intent.getLongExtra("id", 0L)
        getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("notif", 0))
        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

        val apercu = try { Envoi.decoder(ctx, uri, 1600) } catch (e: Exception) { null }
        if (apercu == null) {
            Toast.makeText(ctx, "Capture introuvable", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        val largeur = if (o.outWidth > 0) o.outWidth else apercu.width
        val hauteur = if (o.outHeight > 0) o.outHeight else apercu.height

        val racine = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 24)
        }
        val rognage = CropView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            definir(apercu)
        }
        val info = TextView(ctx).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 4)
        }
        val curseur = SeekBar(ctx).apply {
            max = 90 // 10 % à 100 %
            progress = Config.pourcent(ctx) - 10
        }

        fun maj() {
            val f = rognage.fractions()
            val p = curseur.progress + 10
            val w = ((f.right - f.left) * largeur).toInt()
            val h = ((f.bottom - f.top) * hauteur).toInt()
            info.text = "Zone gardée : $w × $h px\nEnvoi à $p % : ${w * p / 100} × ${h * p / 100} px"
        }
        // met le texte à jour pendant que le doigt déplace le cadre
        rognage.setOnTouchListener { v, e ->
            val r = v.onTouchEvent(e)
            maj()
            r
        }
        curseur.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) = maj()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        rognage.post { maj() }

        val annuler = Button(ctx).apply {
            text = "Annuler"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tout = Button(ctx).apply {
            text = "Tout"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val envoyer = Button(ctx).apply {
            text = "Envoyer"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f)
        }
        val boutons = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(annuler)
            addView(tout)
            addView(envoyer)
        }

        annuler.setOnClickListener { finish() }
        tout.setOnClickListener {
            rognage.toutReinitialiser()
            maj()
        }
        envoyer.setOnClickListener {
            envoyer.isEnabled = false
            val p = curseur.progress + 10
            val f = rognage.fractions()
            Config.savePourcent(ctx, p)
            Thread {
                val code = try {
                    val complete = Envoi.decoder(ctx, uri, Int.MAX_VALUE)
                    if (complete == null) {
                        -1
                    } else {
                        val x = (f.left * complete.width).toInt().coerceIn(0, complete.width - 1)
                        val y = (f.top * complete.height).toInt().coerceIn(0, complete.height - 1)
                        val w = ((f.right - f.left) * complete.width).toInt().coerceIn(1, complete.width - x)
                        val h = ((f.bottom - f.top) * complete.height).toInt().coerceIn(1, complete.height - y)
                        val rogne: Bitmap = Bitmap.createBitmap(complete, x, y, w, h)
                        val r = Envoi.envoyer(ctx, rogne, p)
                        if (rogne !== complete) rogne.recycle()
                        complete.recycle()
                        r
                    }
                } catch (e: Exception) {
                    -1
                }
                runOnUiThread {
                    Toast.makeText(ctx, Envoi.message(code), Toast.LENGTH_LONG).show()
                    if (code == 200) finish() else envoyer.isEnabled = true
                }
            }.start()
        }

        listOf(rognage, info, curseur, boutons).forEach { racine.addView(it) }
        setContentView(racine)
    }
}
