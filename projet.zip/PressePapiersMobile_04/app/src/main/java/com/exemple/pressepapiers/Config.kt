package com.exemple.pressepapiers

import android.content.Context

object Config {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun url(c: Context) = p(c).getString("url", "") ?: ""
    fun jeton(c: Context) = p(c).getString("jeton", "") ?: ""
    fun sujet(c: Context) = p(c).getString("sujet", "") ?: ""

    /** true : une notification propose d'ajuster la taille avant l'envoi ; false : envoi automatique. */
    fun demander(c: Context) = p(c).getBoolean("demander", true)

    /** Taille d'envoi en % de la capture d'origine (10 à 100). */
    fun pourcent(c: Context) = p(c).getInt("pourcent", 100).coerceIn(10, 100)

    fun save(c: Context, url: String, jeton: String, sujet: String) {
        p(c).edit()
            .putString("url", url.trim().trimEnd('/'))
            .putString("jeton", jeton.trim())
            .putString("sujet", sujet.trim())
            .apply()
    }

    fun saveOptions(c: Context, demander: Boolean, pourcent: Int) {
        p(c).edit()
            .putBoolean("demander", demander)
            .putInt("pourcent", pourcent.coerceIn(10, 100))
            .apply()
    }

    fun savePourcent(c: Context, pourcent: Int) {
        p(c).edit().putInt("pourcent", pourcent.coerceIn(10, 100)).apply()
    }
}
