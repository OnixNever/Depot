package com.exemple.pressepapiers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Envoi d'une capture vers le PC et petits utilitaires d'images. */
object Envoi {

    /** Envoie la capture (réduite à [pourcent] %) et renvoie le code HTTP reçu. Lève une exception si le PC est injoignable. */
    fun envoyer(c: Context, bmp: Bitmap, pourcent: Int): Int {
        val p = pourcent.coerceIn(10, 100)
        val b = if (p < 100) {
            Bitmap.createScaledBitmap(bmp, maxOf(1, bmp.width * p / 100), maxOf(1, bmp.height * p / 100), true)
        } else {
            bmp
        }
        try {
            val sortie = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 85, sortie)
            val cx = URL(Config.url(c) + "/image").openConnection() as HttpURLConnection
            cx.requestMethod = "POST"
            cx.doOutput = true
            cx.connectTimeout = 10000
            cx.readTimeout = 20000
            cx.setRequestProperty("X-Jeton", Config.jeton(c))
            cx.setRequestProperty("Content-Type", "image/jpeg")
            cx.setRequestProperty("ngrok-skip-browser-warning", "1")
            cx.outputStream.use { it.write(sortie.toByteArray()) }
            val code = cx.responseCode
            cx.disconnect()
            return code
        } finally {
            if (b !== bmp) b.recycle()
        }
    }

    fun message(code: Int): String = when (code) {
        200 -> "Envoyé au PC"
        403 -> "Refusé (403) : le jeton ne correspond pas à celui du PC"
        404 -> "Introuvable (404) : vérifie l'adresse ngrok et le port"
        503 -> "Le PC est en pause"
        -1 -> "Pas de réponse : ngrok ou le programme PC est éteint"
        else -> "Erreur $code"
    }

    /** Lit une image du MediaStore, réduite pour que son plus grand côté ne dépasse pas [maxCote]. */
    fun decoder(c: Context, uri: Uri, maxCote: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > maxCote) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    fun decoderFichier(chemin: String, maxCote: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(chemin, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > maxCote) s *= 2
        return BitmapFactory.decodeFile(chemin, BitmapFactory.Options().apply { inSampleSize = s })
    }
}
