plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.entrainement.tactique"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.entrainement.tactique"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "1.6.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // signé avec la clé de debug : l'APK "release" reste installable directement
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.9.0")
    // Recherche + extraction audio YouTube, sans clé d'API (la bibliothèque de NewPipe)
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
