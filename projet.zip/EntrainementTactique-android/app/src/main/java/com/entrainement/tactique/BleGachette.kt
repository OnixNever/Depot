package com.entrainement.tactique

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import java.util.UUID

/**
 * Client Bluetooth Low Energy pour le capteur de gâchette (ESP32, voir test_tactile_G4.ino).
 *
 * - cherche l'ESP32 par son service (6e400001-…), se connecte, active les notifications ;
 * - se reconnecte tout seul si la liaison tombe (tant qu'on n'a pas appelé stop()) ;
 * - remonte à la page : emit("state", etat) et emit("msg", texte reçu, ex. "T,512").
 *
 * États : idle, off, scanning, connecting, ready, lost, error, badservice.
 * Les permissions (BLUETOOTH_SCAN / BLUETOOTH_CONNECT, ou localisation avant Android 12)
 * sont demandées par MainActivity avant d'appeler start().
 */
@SuppressLint("MissingPermission")
class BleGachette(
    private val ctx: Context,
    private val emit: (String, String) -> Unit
) {
    companion object {
        val SERVICE: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
        val CHAR: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        private const val CONNECT_TIMEOUT_MS = 15000L
    }

    private val main = Handler(Looper.getMainLooper())
    private val manager = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter: BluetoothAdapter? get() = manager?.adapter

    private var scanner: BluetoothLeScanner? = null
    private var scanning = false
    private var gatt: BluetoothGatt? = null
    private var ch: BluetoothGattCharacteristic? = null
    private var retries = 0

    @Volatile private var wanted = false
    @Volatile var state: String = "idle"
        private set

    private val retryRun = Runnable { begin() }
    private val timeoutRun = Runnable {
        // la connexion n'a pas abouti à temps : on repart de zéro
        dropGatt()
        if (wanted) { setState("lost"); retryLater() }
    }

    fun supported(): Boolean =
        adapter != null && ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)

    // ---------------------------------------------------------------- API publique

    /** À appeler sur le thread principal. */
    fun start() {
        if (wanted && (state == "ready" || state == "scanning" || state == "connecting")) return
        wanted = true
        retries = 0
        main.removeCallbacks(retryRun)
        begin()
    }

    /** À appeler sur le thread principal. */
    fun stop() {
        wanted = false
        main.removeCallbacks(retryRun)
        main.removeCallbacks(timeoutRun)
        stopScan()
        dropGatt()
        setState("idle")
    }

    /** Envoie une commande ("G", "R", "P", "I") à la carte. Sans réponse BLE, très rapide. */
    @Synchronized
    @Suppress("DEPRECATION")
    fun send(text: String): Boolean {
        val c = ch ?: return false
        val g = gatt ?: return false
        val bytes = text.toByteArray(Charsets.UTF_8)
        return try {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) ==
                    BluetoothStatusCodes.SUCCESS
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                c.value = bytes
                g.writeCharacteristic(c)
            }
        } catch (e: Exception) { false }
    }

    // ---------------------------------------------------------------- recherche / connexion

    private fun setState(s: String) {
        state = s
        emit("state", s)
    }

    private fun retryLater(ms: Long = 0) {
        val delay = if (ms > 0) ms else minOf(1000L + retries * 500L, 4000L)
        retries++
        main.removeCallbacks(retryRun)
        main.postDelayed(retryRun, delay)
    }

    private fun begin() {
        if (!wanted) return
        if (gatt != null || scanning) return
        val a = adapter
        if (a == null || !a.isEnabled) {
            setState("off")
            retryLater(2000)          // dès que le Bluetooth est rallumé, on reprend
            return
        }
        val sc = a.bluetoothLeScanner
        if (sc == null) {
            setState("off")
            retryLater(2000)
            return
        }
        scanner = sc
        val filters = listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build())
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        try {
            scanning = true
            sc.startScan(filters, settings, scanCb)
            setState("scanning")
        } catch (e: Exception) {
            scanning = false
            setState("error")
            retryLater()
        }
    }

    private fun stopScan() {
        if (!scanning) return
        scanning = false
        try { scanner?.stopScan(scanCb) } catch (_: Exception) {}
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            main.post {
                if (!wanted || !scanning) return@post
                stopScan()
                connectTo(result.device)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            main.post {
                scanning = false
                if (wanted) { setState("error"); retryLater() }
            }
        }
    }

    private fun connectTo(dev: BluetoothDevice) {
        setState("connecting")
        main.removeCallbacks(timeoutRun)
        main.postDelayed(timeoutRun, CONNECT_TIMEOUT_MS)
        gatt = if (Build.VERSION.SDK_INT >= 23)
            dev.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE)
        else
            dev.connectGatt(ctx, false, gattCb)
    }

    private fun dropGatt() {
        main.removeCallbacks(timeoutRun)
        val g = gatt
        gatt = null
        ch = null
        if (g != null) {
            try { g.disconnect() } catch (_: Exception) {}
            try { g.close() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------- GATT

    private val gattCb = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                try { g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH) } catch (_: Exception) {}
                try { g.discoverServices() } catch (_: Exception) {}
            } else {
                main.post {
                    if (gatt !== g) { try { g.close() } catch (_: Exception) {} ; return@post }
                    dropGatt()
                    if (wanted) { setState("lost"); retryLater() } else setState("idle")
                }
            }
        }

        @Suppress("DEPRECATION")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val c = g.getService(SERVICE)?.getCharacteristic(CHAR)
            if (status != BluetoothGatt.GATT_SUCCESS || c == null) {
                main.post {
                    if (gatt === g) {
                        setState("badservice")
                        dropGatt()
                        if (wanted) retryLater(4000)
                    }
                }
                return
            }
            ch = c
            try {
                g.setCharacteristicNotification(c, true)
                val d = c.getDescriptor(CCCD)
                if (Build.VERSION.SDK_INT >= 33) {
                    g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                } else {
                    d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(d)
                }
            } catch (e: Exception) {
                main.post { if (gatt === g) { dropGatt(); if (wanted) { setState("error"); retryLater() } } }
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            if (d.uuid != CCCD) return
            main.post {
                if (gatt !== g) return@post
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    main.removeCallbacks(timeoutRun)
                    retries = 0
                    setState("ready")
                } else {
                    dropGatt()
                    if (wanted) { setState("error"); retryLater() }
                }
            }
        }

        // Android 13+
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            handle(value)
        }

        // Android 12 et avant
        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            handle(c.value ?: return)
        }
    }

    private fun handle(bytes: ByteArray) {
        val s = String(bytes, Charsets.UTF_8).trim()
        if (s.isNotEmpty()) emit("msg", s)
    }
}
