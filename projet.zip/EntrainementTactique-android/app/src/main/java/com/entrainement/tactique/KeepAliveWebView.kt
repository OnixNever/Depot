package com.entrainement.tactique

import android.content.Context
import android.view.View
import android.webkit.WebView

/**
 * WebView qui ne se croit jamais "cachée" : quand l'écran passe en veille ou que l'appli part en
 * arrière-plan, Android envoie GONE à la fenêtre et Chromium gèle/ralentit les minuteurs JS et l'audio.
 * On ignore ce signal, la session continue donc de tourner normalement.
 */
class KeepAliveWebView(context: Context) : WebView(context) {
    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.GONE) super.onWindowVisibilityChanged(View.VISIBLE)
    }
}
