package com.entrainement.tactique

import android.webkit.WebView

/** État partagé entre l'activité (qui possède la WebView) et le service de premier plan. */
object SessionHost {
    @Volatile var webView: WebView? = null
    @Volatile var sessionActive: Boolean = false
}
