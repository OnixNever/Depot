package com.entrainement.tactique

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/** Pont JavaScript -> Android (exposé dans la page sous le nom "Android"). */
class AndroidBridge(private val activity: MainActivity) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ttsOk = false

    init {
        main.post {
            tts = TextToSpeech(activity.applicationContext) { status ->
                val engine = tts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    val r = engine.setLanguage(Locale.FRANCE)
                    ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    engine.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { notifyDone(utteranceId) }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { notifyDone(utteranceId) }
                        override fun onError(utteranceId: String?, errorCode: Int) { notifyDone(utteranceId) }
                    })
                }
            }
        }
    }

    private fun notifyDone(id: String?) {
        val n = id?.toIntOrNull() ?: return
        val wv = SessionHost.webView ?: return
        wv.post { wv.evaluateJavascript("window.__ttsDone&&window.__ttsDone($n)", null) }
    }

    @JavascriptInterface fun isNative(): Boolean = true

    @JavascriptInterface fun ttsReady(): Boolean = ttsOk

    @JavascriptInterface
    fun speak(id: Int, text: String, volume: Double) {
        main.post {
            val engine = tts
            if (engine != null && ttsOk) {
                val params = Bundle()
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.toFloat().coerceIn(0f, 1f))
                engine.speak(text, TextToSpeech.QUEUE_ADD, params, id.toString())
            }
        }
    }

    @JavascriptInterface
    fun stopSpeak() {
        main.post { tts?.stop() }
    }

    @JavascriptInterface
    fun sessionStarted() {
        main.post { activity.onSessionStarted() }
    }

    @JavascriptInterface
    fun sessionStopped() {
        main.post { activity.onSessionStopped() }
    }

    // ------------------------------------------------------------------
    // Persistance native : réglages (clé/valeur) et sons importés.
    // Écriture immédiate sur disque (commit) -> rien n'est perdu si l'appli est tuée.
    // ------------------------------------------------------------------
    private val appCtx: Context = activity.applicationContext
    private val kv by lazy { appCtx.getSharedPreferences("kv", Context.MODE_PRIVATE) }
    private val ambNames by lazy { appCtx.getSharedPreferences("amb_names", Context.MODE_PRIVATE) }
    private val ambDir by lazy { File(appCtx.filesDir, "amb").apply { mkdirs() } }

    private fun safe(key: String) = key.replace(Regex("[^A-Za-z0-9_-]"), "_")
    private fun ambFile(key: String) = File(ambDir, safe(key) + ".dat")
    private fun ambPart(key: String) = File(ambDir, safe(key) + ".part")

    @JavascriptInterface
    fun kvAll(): String {
        val o = JSONObject()
        for ((k, v) in kv.all) if (v is String) o.put(k, v)
        return o.toString()
    }

    @JavascriptInterface
    fun kvSet(key: String, value: String) { kv.edit().putString(key, value).commit() }

    @JavascriptInterface
    fun kvRemove(key: String) { kv.edit().remove(key).commit() }

    @JavascriptInterface
    fun kvClear() { kv.edit().clear().commit() }

    /** Liste des sons importés : [{"key":"perso:…","name":"…"}] */
    @JavascriptInterface
    fun ambList(): String {
        val arr = JSONArray()
        for ((k, v) in ambNames.all) {
            if (v is String && ambFile(k).exists()) arr.put(JSONObject().put("key", k).put("name", v))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun ambPutStart(key: String): Boolean = try {
        ambDir.mkdirs()
        val part = ambPart(key)
        part.delete()
        part.createNewFile()
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun ambPutChunk(key: String, b64: String): Boolean = try {
        FileOutputStream(ambPart(key), true).use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
        true
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun ambPutEnd(key: String, name: String): Boolean = try {
        val part = ambPart(key)
        val dest = ambFile(key)
        dest.delete()
        part.exists() && part.renameTo(dest) && ambNames.edit().putString(key, name).commit()
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun ambDelete(key: String) {
        try { ambFile(key).delete() } catch (_: Exception) {}
        try { ambPart(key).delete() } catch (_: Exception) {}
        ambNames.edit().remove(key).commit()
    }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
    }
}
