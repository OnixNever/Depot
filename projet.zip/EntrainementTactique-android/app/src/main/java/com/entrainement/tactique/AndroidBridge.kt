package com.entrainement.tactique

import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import java.util.Locale

/** Pont JavaScript -> Android (exposé dans la page sous le nom "Android"). */
class AndroidBridge(private val activity: MainActivity) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ttsOk = false

    init {
        main.post {
            tts = TextToSpeech(activity.applicationContext) { status ->
                val engine = tts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    val r = engine.setLanguage(Locale.FRANCE)
                    ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    engine.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { notifyDone(utteranceId) }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { notifyDone(utteranceId) }
                        override fun onError(utteranceId: String?, errorCode: Int) { notifyDone(utteranceId) }
                    })
                }
            }
        }
    }

    private fun notifyDone(id: String?) {
        val n = id?.toIntOrNull() ?: return
        val wv = SessionHost.webView ?: return
        wv.post { wv.evaluateJavascript("window.__ttsDone&&window.__ttsDone($n)", null) }
    }

    @JavascriptInterface fun isNative(): Boolean = true

    @JavascriptInterface fun ttsReady(): Boolean = ttsOk

    @JavascriptInterface
    fun speak(id: Int, text: String, volume: Double) {
        main.post {
            val engine = tts
            if (engine != null && ttsOk) {
                val params = Bundle()
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.toFloat().coerceIn(0f, 1f))
                engine.speak(text, TextToSpeech.QUEUE_ADD, params, id.toString())
            }
        }
    }

    @JavascriptInterface
    fun stopSpeak() {
        main.post { tts?.stop() }
    }

    @JavascriptInterface
    fun sessionStarted() {
        main.post { activity.onSessionStarted() }
    }

    @JavascriptInterface
    fun sessionStopped() {
        main.post { activity.onSessionStopped() }
    }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
    }
}
