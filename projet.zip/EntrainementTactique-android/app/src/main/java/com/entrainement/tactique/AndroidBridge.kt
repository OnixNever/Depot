package com.entrainement.tactique

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Pont JavaScript -> Android (exposé dans la page sous le nom "Android"). */
class AndroidBridge(private val activity: MainActivity) {

    private val main = Handler(Looper.getMainLooper())
    val lib = MusicLibrary(activity.applicationContext)
    val music = MusicPlayer(activity.applicationContext).also { SessionHost.music = it }
    private var tts: TextToSpeech? = null
    @Volatile private var ttsOk = false

    init {
        main.post {
            tts = TextToSpeech(activity.applicationContext) { status ->
                val engine = tts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    val r = engine.setLanguage(Locale.FRANCE)
                    ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    engine.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { notifyDone(utteranceId) }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { notifyDone(utteranceId) }
                        override fun onError(utteranceId: String?, errorCode: Int) { notifyDone(utteranceId) }
                    })
                }
            }
        }
    }

    private fun notifyDone(id: String?) {
        val n = id?.toIntOrNull() ?: return
        val wv = SessionHost.webView ?: return
        wv.post { wv.evaluateJavascript("window.__ttsDone&&window.__ttsDone($n)", null) }
    }

    @JavascriptInterface fun isNative(): Boolean = true

    @JavascriptInterface fun ttsReady(): Boolean = ttsOk

    @JavascriptInterface
    fun speak(id: Int, text: String, volume: Double) {
        main.post {
            val engine = tts
            if (engine != null && ttsOk) {
                val params = Bundle()
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.toFloat().coerceIn(0f, 1f))
                engine.speak(text, TextToSpeech.QUEUE_ADD, params, id.toString())
            }
        }
    }

    @JavascriptInterface
    fun stopSpeak() {
        main.post { tts?.stop() }
    }

    @JavascriptInterface
    fun sessionStarted() {
        main.post { activity.onSessionStarted() }
    }

    @JavascriptInterface
    fun sessionStopped() {
        main.post { activity.onSessionStopped() }
    }

    // ------------------------------------------------------------------
    // Persistance native : réglages (clé/valeur) et sons importés.
    // Écriture immédiate sur disque (commit) -> rien n'est perdu si l'appli est tuée.
    // ------------------------------------------------------------------
    private val appCtx: Context = activity.applicationContext
    private val kv by lazy { appCtx.getSharedPreferences("kv", Context.MODE_PRIVATE) }
    private val ambNames by lazy { appCtx.getSharedPreferences("amb_names", Context.MODE_PRIVATE) }
    private val ambDir by lazy { File(appCtx.filesDir, "amb").apply { mkdirs() } }

    private fun safe(key: String) = key.replace(Regex("[^A-Za-z0-9_-]"), "_")
    private fun ambFile(key: String) = File(ambDir, safe(key) + ".dat")
    private fun ambPart(key: String) = File(ambDir, safe(key) + ".part")

    @JavascriptInterface
    fun kvAll(): String {
        val o = JSONObject()
        for ((k, v) in kv.all) if (v is String) o.put(k, v)
        return o.toString()
    }

    @JavascriptInterface
    fun kvSet(key: String, value: String) { kv.edit().putString(key, value).commit() }

    @JavascriptInterface
    fun kvRemove(key: String) { kv.edit().remove(key).commit() }

    @JavascriptInterface
    fun kvClear() { kv.edit().clear().commit() }

    /** Liste des sons importés : [{"key":"perso:…","name":"…"}] */
    @JavascriptInterface
    fun ambList(): String {
        val arr = JSONArray()
        for ((k, v) in ambNames.all) {
            if (v is String && ambFile(k).exists()) arr.put(JSONObject().put("key", k).put("name", v))
        }
        for ((k, n) in lib.uriAll()) arr.put(JSONObject().put("key", k).put("name", n))
        return arr.toString()
    }

    @JavascriptInterface
    fun ambPutStart(key: String): Boolean = try {
        ambDir.mkdirs()
        val part = ambPart(key)
        part.delete()
        part.createNewFile()
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun ambPutChunk(key: String, b64: String): Boolean = try {
        FileOutputStream(ambPart(key), true).use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
        true
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun ambPutEnd(key: String, name: String): Boolean = try {
        val part = ambPart(key)
        val dest = ambFile(key)
        dest.delete()
        part.exists() && part.renameTo(dest) && ambNames.edit().putString(key, name).commit()
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun ambDelete(key: String) {
        try { ambFile(key).delete() } catch (_: Exception) {}
        try { ambPart(key).delete() } catch (_: Exception) {}
        ambNames.edit().remove(key).commit()
        lib.uriRemove(key)
    }

    // ------------------------------------------------------------------
    // Lecture native des musiques / playlists (flux, aucune mise en mémoire) — coupée à la fin de session
    // ------------------------------------------------------------------
    @JavascriptInterface
    fun musicStart(key: String, volume: Double) {
        val (sources, shuffle) = lib.sourcesFor(key)
        music.start(key, sources, shuffle, volume.toFloat())
    }

    @JavascriptInterface fun musicStop(key: String) { music.stop(key) }
    @JavascriptInterface fun musicStopAll() { music.stopAll() }
    @JavascriptInterface fun musicVolume(v: Double) { music.setVolume(v.toFloat()) }
    @JavascriptInterface fun musicPause() { music.pause() }
    @JavascriptInterface fun musicResume() { music.resume() }

    // ------------------------------------------------------------------
    // Playlists : lecture / édition
    // ------------------------------------------------------------------
    @JavascriptInterface fun plList(): String = lib.plAll().toString()
    @JavascriptInterface fun plRemoveTrack(key: String, idx: Int): Boolean = lib.plRemoveTrack(key, idx)
    @JavascriptInterface fun plRename(key: String, name: String) { lib.plRename(key, name) }
    @JavascriptInterface fun plShuffle(key: String, on: Boolean) { lib.plShuffle(key, on) }
    @JavascriptInterface fun plDelete(key: String) { lib.plDelete(key) }

    /** Choix de musiques du téléphone : pointées (pas copiées). plKey vide = sons seuls, sinon ajout à cette playlist. */
    @JavascriptInterface
    fun pickMusic(reqId: Int, plKey: String) {
        main.post { activity.pickMusic(reqId, plKey) }
    }

    /** Garde l'écran allumé pendant un gros téléchargement lancé par l'utilisateur. */
    @JavascriptInterface
    fun importBusy(on: Boolean) {
        main.post { activity.setKeepScreenOn(on) }
    }

    // ------------------------------------------------------------------
    // YouTube : recherche / lien / playlist, téléchargement audio (réponses renvoyées à la page par callback).
    // ------------------------------------------------------------------
    private val net = Executors.newCachedThreadPool()
    private val cancels = ConcurrentHashMap<Int, AtomicBoolean>()

    fun ytReply(reqId: Int, ok: Boolean, payload: String) {
        val wv = SessionHost.webView ?: return
        val js = "window.__ytCb&&window.__ytCb($reqId,$ok,${JSONObject.quote(payload)})"
        wv.post { wv.evaluateJavascript(js, null) }
    }

    private fun ytProgress(reqId: Int, pct: Int) {
        val wv = SessionHost.webView ?: return
        wv.post { wv.evaluateJavascript("window.__ytProg&&window.__ytProg($reqId,$pct)", null) }
    }

    private fun plProgress(reqId: Int, i: Int, n: Int, pct: Int, title: String) {
        val wv = SessionHost.webView ?: return
        wv.post { wv.evaluateJavascript("window.__plProg&&window.__plProg($reqId,$i,$n,$pct,${JSONObject.quote(title)})", null) }
    }

    @JavascriptInterface
    fun ytSearch(reqId: Int, query: String) {
        net.execute {
            try {
                ytReply(reqId, true, YouTube.lookup(query).toString())
            } catch (e: Throwable) {
                ytReply(reqId, false, YouTube.explain(e))
            }
        }
    }

    @JavascriptInterface
    fun ytCancel(reqId: Int) { cancels[reqId]?.set(true) }

    /** Une vidéo → un son seul (clé « perso:… » fournie par la page). */
    @JavascriptInterface
    fun ytImport(reqId: Int, key: String, url: String, name: String) {
        val flag = AtomicBoolean(false)
        cancels[reqId] = flag
        net.execute {
            val part = ambPart(key)
            try {
                ambDir.mkdirs()
                part.delete()
                var last = -2
                val title = YouTube.download(url, part, { flag.get() }) { p ->
                    if (p != last) { last = p; ytProgress(reqId, p) }
                }
                val finalName = name.ifBlank { title }
                if (!ambPutEnd(key, finalName)) throw IllegalStateException("Impossible d'enregistrer le fichier.")
                ytReply(reqId, true, finalName)
            } catch (e: Throwable) {
                try { part.delete() } catch (_: Exception) {}
                ytReply(reqId, false, YouTube.explain(e))
            } finally {
                cancels.remove(reqId)
            }
        }
    }

    /**
     * Plusieurs vidéos → pistes d'une playlist (créée si plKey n'existe pas encore, sinon on ajoute à la suite).
     * Chaque piste réussie est enregistrée tout de suite : si ça s'interrompt, ce qui est déjà là reste.
     */
    @JavascriptInterface
    fun ytImportTracks(reqId: Int, plKey: String, plName: String, itemsJson: String) {
        val flag = AtomicBoolean(false)
        cancels[reqId] = flag
        net.execute {
            var added = 0
            var failed = 0
            var lastErr = ""
            try {
                val items = JSONArray(itemsJson)
                val n = items.length()
                for (i in 0 until n) {
                    if (flag.get()) break
                    val o = items.getJSONObject(i)
                    val vid = o.getString("id")
                    val title = o.optString("title", "YouTube")
                    plProgress(reqId, i, n, 0, title)

                    val existing = lib.findYt(vid)
                    if (existing != null) {
                        lib.plAddTrack(plKey, plName, JSONObject().put("id", existing).put("yt", vid).put("n", title))
                        added++
                        continue
                    }
                    val tkey = lib.newKey("plt:")
                    val part = lib.part(tkey)
                    try {
                        ambDir.mkdirs()
                        part.delete()
                        var last = -2
                        YouTube.download("https://www.youtube.com/watch?v=$vid", part, { flag.get() }) { p ->
                            if (p != last) { last = p; plProgress(reqId, i, n, p, title) }
                        }
                        if (!lib.finishFile(tkey)) throw IllegalStateException("Impossible d'enregistrer le fichier.")
                        lib.plAddTrack(plKey, plName, JSONObject().put("id", tkey).put("yt", vid).put("n", title))
                        added++
                    } catch (e: Throwable) {
                        try { part.delete() } catch (_: Exception) {}
                        if (flag.get()) break
                        failed++
                        lastErr = YouTube.explain(e)
                    }
                }
                val res = JSONObject().put("added", added).put("failed", failed).put("total", n)
                    .put("cancelled", flag.get()).put("err", lastErr).put("key", plKey)
                ytReply(reqId, true, res.toString())
            } catch (e: Throwable) {
                ytReply(reqId, false, YouTube.explain(e))
            } finally {
                cancels.remove(reqId)
            }
        }
    }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        music.stopAll()
        SessionHost.music = null
        net.shutdown()
    }
}
