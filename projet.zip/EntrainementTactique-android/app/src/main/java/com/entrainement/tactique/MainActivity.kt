package com.entrainement.tactique

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : Activity() {

    companion object {
        private const val REQ_FILE = 11
        private const val REQ_NOTIF = 12
        private const val REQ_PICK = 13
        private const val REQ_BLE = 14
        private const val HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$HOST/assets/www/index.html"
    }

    private lateinit var web: KeepAliveWebView
    private var bridge: AndroidBridge? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pickReq = -1
    private var pickPl = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = KeepAliveWebView(this)
        setContentView(web)
        SessionHost.webView = web

        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.setSupportZoom(false)
        s.builtInZoomControls = false

        val loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            // sons importés par l'utilisateur (stockage interne de l'appli)
            .addPathHandler("/amb/", WebViewAssetLoader.InternalStoragePathHandler(this, File(filesDir, "amb").apply { mkdirs() }))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request == null) return null
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null || request.url.host == HOST) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (_: Exception) {}
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (result == null) return false
                if (isFinishing) { result.cancel(); return true }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (result == null) return false
                if (isFinishing) { result.cancel(); return true }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Annuler") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult?
            ): Boolean {
                if (result == null) return false
                if (isFinishing) { result.cancel(); return true }
                val input = EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setView(input)
                    .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Annuler") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        bridge = AndroidBridge(this)
        web.addJavascriptInterface(bridge!!, "Android")

        web.loadUrl(START_URL)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    /** Connexion à la gâchette : demande d'abord les autorisations Bluetooth si besoin. */
    fun bleConnectWithPermission() {
        val b = bridge ?: return
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)   // Android 11 et avant : le scan BLE exige la localisation
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) b.ble.start()
        else requestPermissions(missing.toTypedArray(), REQ_BLE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_BLE) {
            val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (ok) bridge?.ble?.start() else bridge?.bleEvt("state", "noperm")
        }
    }

    /** Sélecteur système (Audio) : plusieurs fichiers, pointés sans copie via une permission persistante. */
    fun pickMusic(reqId: Int, plKey: String) {
        pickReq = reqId
        pickPl = plKey
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            pickReq = -1
            bridge?.ytReply(reqId, false, "Impossible d'ouvrir le sélecteur de fichiers.")
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n.replace(Regex("\\.[^.]+$"), "")
                }
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "Son perso"
    }

    private fun handlePicked(data: Intent?) {
        val b = bridge
        val req = pickReq
        val pl = pickPl
        pickReq = -1
        if (b == null || req < 0) return
        val uris = ArrayList<Uri>()
        data?.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        data?.data?.let { if (uris.isEmpty()) uris.add(it) }
        var count = 0
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            val name = displayName(u)
            if (pl.isEmpty()) {
                b.lib.uriPut(b.lib.newKey("perso:"), u.toString(), name)
            } else {
                b.lib.plAddTrack(pl, name, org.json.JSONObject().put("uri", u.toString()).put("n", name))
            }
            count++
        }
        b.ytReply(req, true, count.toString())
    }

    fun setKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /** Appelé par la page (via le pont) quand une session démarre. */
    fun onSessionStarted() {
        SessionHost.sessionActive = true
        val i = Intent(this, SessionService::class.java).setAction(SessionService.ACTION_START)
        try { startForegroundService(i) } catch (_: Exception) {}
        askBatteryExemptionOnce()
    }

    /** Appelé par la page quand la session s'arrête (bouton Quitter, fin du chrono, ou action de la notification). */
    fun onSessionStopped() {
        SessionHost.sessionActive = false
        bridge?.music?.stopAll()   // plus aucune musique après l'arrêt
        stopService(Intent(this, SessionService::class.java))
    }

    private fun askBatteryExemptionOnce() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) return
            val prefs = getSharedPreferences("app", MODE_PRIVATE)
            if (prefs.getBoolean("battery_asked", false)) return
            prefs.edit().putBoolean("battery_asked", true).apply()
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {}
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_PICK) {
            handlePicked(if (resultCode == Activity.RESULT_OK) data else null)
            return
        }
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (SessionHost.sessionActive) {
            // session en cours : on met l'appli en arrière-plan, la session continue
            moveTaskToBack(true)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.resumeTimers()
    }

    /** Force la page à écrire ses réglages tout de suite (appelé dès qu'on quitte l'écran). */
    private fun saveWebState() {
        try { web.evaluateJavascript("window.__saveNow&&window.__saveNow()", null) } catch (_: Exception) {}
    }

    override fun onPause() {
        saveWebState()
        super.onPause()
        if (SessionHost.sessionActive) { web.onResume(); web.resumeTimers() } else web.onPause()
    }

    override fun onStop() {
        saveWebState()
        super.onStop()
        if (SessionHost.sessionActive) { web.onResume(); web.resumeTimers() }
    }

    override fun onDestroy() {
        if (isFinishing) {
            SessionHost.sessionActive = false
            stopService(Intent(this, SessionService::class.java))
        }
        bridge?.shutdown()
        SessionHost.webView = null
        (web.parent as? android.view.ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
