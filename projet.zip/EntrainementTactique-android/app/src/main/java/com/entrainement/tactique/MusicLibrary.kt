package com.entrainement.tactique

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.random.Random

/**
 * Bibliothèque musicale native :
 *  - sons pointés (liens vers des fichiers du téléphone, sans copie) : prefs « amb_uris »
 *  - playlists (clé « pl:… ») : prefs « playlists », pistes = fichier téléchargé (id « plt:… ») ou lien pointé
 * Les fichiers téléchargés vivent dans files/amb/ (comme les sons importés).
 */
class MusicLibrary(ctx: Context) {

    private val dir = File(ctx.filesDir, "amb").apply { mkdirs() }
    private val uris = ctx.getSharedPreferences("amb_uris", Context.MODE_PRIVATE)
    private val pls = ctx.getSharedPreferences("playlists", Context.MODE_PRIVATE)

    private fun safe(k: String) = k.replace(Regex("[^A-Za-z0-9_-]"), "_")
    fun file(key: String) = File(dir, safe(key) + ".dat")
    fun part(key: String) = File(dir, safe(key) + ".part")

    fun finishFile(key: String): Boolean {
        val p = part(key)
        val d = file(key)
        d.delete()
        return p.exists() && p.renameTo(d)
    }

    fun newKey(prefix: String) =
        prefix + System.currentTimeMillis().toString(36) + Random.nextInt(46656).toString(36)

    // ---------- sons pointés ----------
    fun uriPut(key: String, uri: String, name: String) {
        uris.edit().putString(key, JSONObject().put("uri", uri).put("name", name).toString()).commit()
    }

    fun uriAll(): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((k, v) in uris.all) {
            if (v is String) try { out[k] = JSONObject(v).optString("name", "Son perso") } catch (_: Exception) {}
        }
        return out
    }

    fun uriGet(key: String): String? =
        uris.getString(key, null)?.let { try { JSONObject(it).optString("uri") } catch (_: Exception) { null } }

    fun uriRemove(key: String) { uris.edit().remove(key).commit() }

    // ---------- playlists ----------
    private fun plRead(key: String): JSONObject? =
        pls.getString(key, null)?.let { try { JSONObject(it) } catch (_: Exception) { null } }

    private fun plWrite(key: String, o: JSONObject) { pls.edit().putString(key, o.toString()).commit() }

    @Synchronized
    fun plAddTrack(key: String, name: String, track: JSONObject) {
        val o = plRead(key) ?: JSONObject().put("name", name).put("shuffle", false).put("tracks", JSONArray())
        o.getJSONArray("tracks").put(track)
        plWrite(key, o)
    }

    /** [{key,name,shuffle,tracks:[{n}]}] trié par ordre de création */
    @Synchronized
    fun plAll(): JSONArray {
        val out = JSONArray()
        for (k in pls.all.keys.sorted()) {
            val o = plRead(k) ?: continue
            val tracks = JSONArray()
            val src = o.optJSONArray("tracks") ?: JSONArray()
            for (i in 0 until src.length()) tracks.put(JSONObject().put("n", src.getJSONObject(i).optString("n", "Piste")))
            out.put(
                JSONObject().put("key", k).put("name", o.optString("name", "Playlist"))
                    .put("shuffle", o.optBoolean("shuffle", false)).put("tracks", tracks)
            )
        }
        return out
    }

    private fun isReferenced(id: String): Boolean {
        for (k in pls.all.keys) {
            val t = plRead(k)?.optJSONArray("tracks") ?: continue
            for (i in 0 until t.length()) if (t.getJSONObject(i).optString("id") == id) return true
        }
        return false
    }

    private fun dropFileIfOrphan(track: JSONObject) {
        val id = track.optString("id")
        if (id.isNotEmpty() && !isReferenced(id)) { try { file(id).delete() } catch (_: Exception) {} }
    }

    @Synchronized
    fun plRemoveTrack(key: String, idx: Int): Boolean {
        val o = plRead(key) ?: return false
        val t = o.getJSONArray("tracks")
        if (idx < 0 || idx >= t.length()) return false
        val removed = t.getJSONObject(idx)
        t.remove(idx)
        plWrite(key, o)
        dropFileIfOrphan(removed)
        return true
    }

    @Synchronized
    fun plRename(key: String, name: String) {
        val o = plRead(key) ?: return
        plWrite(key, o.put("name", name))
    }

    @Synchronized
    fun plShuffle(key: String, on: Boolean) {
        val o = plRead(key) ?: return
        plWrite(key, o.put("shuffle", on))
    }

    @Synchronized
    fun plDelete(key: String) {
        val o = plRead(key)
        pls.edit().remove(key).commit()
        val t = o?.optJSONArray("tracks") ?: return
        for (i in 0 until t.length()) dropFileIfOrphan(t.getJSONObject(i))
    }

    /** Piste déjà téléchargée pour cette vidéo YouTube (évite de re-télécharger). */
    @Synchronized
    fun findYt(videoId: String): String? {
        for (k in pls.all.keys) {
            val t = plRead(k)?.optJSONArray("tracks") ?: continue
            for (i in 0 until t.length()) {
                val tr = t.getJSONObject(i)
                val id = tr.optString("id")
                if (tr.optString("yt") == videoId && id.isNotEmpty() && file(id).exists()) return id
            }
        }
        return null
    }

    // ---------- lecture ----------
    /** Sources à lire pour une clé d'ambiance (« pl:… » = playlist, « perso:… » = son seul) + option aléatoire. */
    fun sourcesFor(key: String): Pair<List<MusicPlayer.Source>, Boolean> {
        if (key.startsWith("pl:")) {
            val o = plRead(key) ?: return Pair(emptyList(), false)
            val t = o.optJSONArray("tracks") ?: JSONArray()
            val list = ArrayList<MusicPlayer.Source>()
            for (i in 0 until t.length()) {
                val tr = t.getJSONObject(i)
                val id = tr.optString("id")
                if (id.isNotEmpty()) {
                    if (file(id).exists()) list.add(MusicPlayer.Source(file = file(id)))
                } else {
                    val u = tr.optString("uri")
                    if (u.isNotEmpty()) list.add(MusicPlayer.Source(uri = u))
                }
            }
            return Pair(list, o.optBoolean("shuffle", false))
        }
        val u = uriGet(key)
        if (u != null && u.isNotEmpty()) return Pair(listOf(MusicPlayer.Source(uri = u)), false)
        val f = file(key)
        return if (f.exists()) Pair(listOf(MusicPlayer.Source(file = f)), false) else Pair(emptyList(), false)
    }
}
