package com.entrainement.tactique

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import org.json.JSONObject

/**
 * Service de premier plan : garde l'appli (et donc la session) en vie écran éteint,
 * tient un wake lock CPU et affiche une notification persistante qui reflète l'état de la session.
 * Toutes les secondes il interroge la page (window.__snapshot) — ce qui sert aussi de "coup de pouce"
 * pour que la WebView ne s'endorme jamais.
 */
class SessionService : Service() {

    companion object {
        const val ACTION_START = "com.entrainement.tactique.START"
        const val ACTION_TOGGLE_PAUSE = "com.entrainement.tactique.TOGGLE_PAUSE"
        const val ACTION_STOP = "com.entrainement.tactique.STOP"
        private const val CHANNEL_ID = "session"
        private const val NOTIF_ID = 42
    }

    private data class Snap(
        val running: Boolean = true,
        val paused: Boolean = false,
        val timer: String = "",
        val fatigue: String = "",
        val blocks: List<String> = emptyList(),
        val order: String = "",
        val weapon: String = "",
        val exercise: String = "",
        val last: String = "",
        val hex: String = "",
        val age: Int = -1
    )

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var active = false
    private var startedAt = 0L
    private var lastSig = ""
    private var snap = Snap()

    private val ticker = object : Runnable {
        override fun run() {
            if (!active) return
            poll()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin()
            ACTION_TOGGLE_PAUSE -> if (active) runJs("togglePause()") else stopSelf()
            ACTION_STOP -> {
                if (active) runJs("quitSession()")
                endNow()
            }
            else -> if (!active) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun begin() {
        createChannel()
        startedAt = System.currentTimeMillis()
        lastSig = ""
        snap = Snap()
        val n = buildNotification(snap)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "entrainementtactique:session").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
        }
        if (!active) {
            active = true
            handler.post(ticker)
        }
    }

    private fun endNow() {
        active = false
        handler.removeCallbacksAndMessages(null)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun runJs(js: String) {
        SessionHost.webView?.evaluateJavascript(js, null)
    }

    private fun poll() {
        val wv = SessionHost.webView
        if (wv == null) { endNow(); return }
        wv.evaluateJavascript(
            "(function(){try{return window.__snapshot?window.__snapshot():null}catch(e){return null}})()"
        ) { res ->
            if (active && res != null && res != "null") {
                try {
                    val s = parse(JSONObject(res))
                    if (!s.running) endNow() else update(s)
                } catch (_: Exception) {}
            }
        }
    }

    private fun parse(j: JSONObject): Snap {
        val arr = j.optJSONArray("blocks")
        val blocks = ArrayList<String>()
        if (arr != null) for (i in 0 until arr.length()) blocks.add(arr.optString(i))
        return Snap(
            running = j.optBoolean("running", true),
            paused = j.optBoolean("paused", false),
            timer = j.optString("timer", ""),
            fatigue = j.optString("fatigue", ""),
            blocks = blocks,
            order = j.optString("order", ""),
            weapon = j.optString("weapon", ""),
            exercise = j.optString("exercise", ""),
            last = j.optString("last", ""),
            hex = j.optString("hex", ""),
            age = j.optInt("age", -1)
        )
    }

    private fun update(s: Snap) {
        snap = s
        val sig = listOf(s.paused, s.timer, s.fatigue, s.blocks, s.order, s.weapon, s.exercise, s.last, s.hex, s.age).toString()
        if (sig == lastSig) return
        lastSig = sig
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(s))
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Session d'entraînement", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Notification persistante pendant une session"
            ch.setShowBadge(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(s: Snap): Notification {
        val timerTxt = if (s.timer.isNotBlank() && s.timer != "∞") s.timer else ""
        val ageTxt = if (s.age in 0..3600) "il y a ${s.age} s" else ""

        // Titre = ce qu'il faut voir d'un coup d'œil : l'ordre en cours, sinon la dernière couleur / annonce
        val headline = when {
            s.order.isNotBlank() -> s.order.uppercase()
            s.last.isNotBlank() -> s.last.uppercase()
            else -> "EN ATTENTE…"
        }
        val title = if (s.paused) "⏸ PAUSE · $headline" else headline

        val sub = ArrayList<String>()
        if (s.blocks.isNotEmpty()) sub.add(s.blocks.joinToString(" · "))
        if (ageTxt.isNotEmpty() && s.last.isNotBlank()) sub.add(ageTxt)
        if (timerTxt.isNotEmpty()) sub.add(timerTxt)
        val text = if (sub.isEmpty()) "Session en cours" else sub.joinToString(" · ")

        val lines = ArrayList<String>()
        if (s.order.isNotBlank()) lines.add("Ordre en cours : ${s.order}")
        if (s.blocks.isNotEmpty()) lines.add("En cours : " + s.blocks.joinToString(" · "))
        if (s.last.isNotBlank()) lines.add("Dernière annonce : ${s.last}" + (if (ageTxt.isNotEmpty()) " ($ageTxt)" else ""))
        if (s.weapon.isNotBlank()) lines.add("Arme : ${s.weapon}")
        if (s.exercise.isNotBlank()) lines.add(s.exercise)
        if (s.fatigue.isNotBlank() && !s.fatigue.endsWith("off")) lines.add(s.fatigue)
        if (timerTxt.isNotEmpty()) lines.add("Temps restant : $timerTxt")

        // fond de la notification = couleur annoncée (tant qu'aucun ordre n'est en cours)
        var tint = 0xFFC8A24A.toInt()
        var colorize = false
        if (s.order.isBlank() && s.hex.isNotBlank()) {
            try { tint = android.graphics.Color.parseColor(s.hex); colorize = true } catch (_: Exception) {}
        }

        val openIntent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val piOpen = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val piPause = PendingIntent.getService(
            this, 1, Intent(this, SessionService::class.java).setAction(ACTION_TOGGLE_PAUSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val piStop = PendingIntent.getService(
            this, 2, Intent(this, SessionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val b = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_session)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(lines.joinToString("\n").ifBlank { text }))
            .setLocalOnly(true)
            .setContentIntent(piOpen)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setColor(tint)
            .setColorized(colorize)

        if (s.timer == "∞" && !s.paused) {
            b.setShowWhen(true).setWhen(startedAt).setUsesChronometer(true)
        } else {
            b.setShowWhen(false)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }

        @Suppress("DEPRECATION")
        b.addAction(
            if (s.paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause,
            if (s.paused) "Reprendre" else "Pause",
            piPause
        )
        @Suppress("DEPRECATION")
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", piStop)

        return b.build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        endNow()
    }

    override fun onDestroy() {
        active = false
        handler.removeCallbacksAndMessages(null)
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }
}
