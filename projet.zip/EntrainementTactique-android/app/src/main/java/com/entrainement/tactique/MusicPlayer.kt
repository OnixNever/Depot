package com.entrainement.tactique

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.File

/**
 * Lecteur natif des musiques / playlists d'ambiance : lecture en flux depuis le fichier (ou le lien pointé),
 * aucun chargement en mémoire, démarrage immédiat, durée illimitée.
 * Une « chaîne » par ambiance cochée : un seul son = boucle ; plusieurs = playlist (piste après piste, en boucle,
 * option aléatoire). Tout s'arrête avec stopAll() (fin de session).
 */
class MusicPlayer(private val ctx: Context) {

    data class Source(val file: File? = null, val uri: String? = null)

    private val main = Handler(Looper.getMainLooper())
    private val channels = HashMap<String, Channel>()
    private var volume = 0.3f
    private var paused = false

    private inner class Channel(val key: String, val sources: List<Source>, val shuffle: Boolean) {
        var mp: MediaPlayer? = null
        var ready = false
        var alive = true
        var order: List<Int> = emptyList()
        var pos = -1
        var fails = 0

        fun begin() {
            if (sources.isEmpty()) { alive = false; return }
            newOrder()
            next()
        }

        private fun newOrder() {
            val idx = sources.indices.toList()
            order = if (shuffle && sources.size > 1) idx.shuffled() else idx
            pos = -1
        }

        fun next() {
            if (!alive) return
            if (fails >= sources.size) { alive = false; release(); return }   // tout est illisible : on abandonne
            pos++
            if (pos >= order.size) { newOrder(); pos = 0 }
            play(sources[order[pos]])
        }

        private fun play(src: Source) {
            release()
            val p = MediaPlayer()
            mp = p
            try {
                p.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                if (src.file != null) p.setDataSource(src.file.absolutePath)
                else p.setDataSource(ctx, Uri.parse(src.uri))
                p.isLooping = sources.size == 1
                p.setVolume(volume, volume)
                p.setOnPreparedListener { m ->
                    if (alive && mp === m) {
                        fails = 0
                        ready = true
                        if (!paused) { try { m.start() } catch (_: Exception) {} }
                    }
                }
                p.setOnCompletionListener { m -> if (alive && mp === m) next() }
                p.setOnErrorListener { m, _, _ ->
                    if (alive && mp === m) { fails++; main.post { next() } }
                    true
                }
                p.prepareAsync()
            } catch (_: Exception) {
                fails++
                release()
                main.post { next() }
            }
        }

        fun setVol(v: Float) { try { mp?.setVolume(v, v) } catch (_: Exception) {} }
        fun pause() { try { if (ready && mp?.isPlaying == true) mp?.pause() } catch (_: Exception) {} }
        fun resume() { try { if (ready) mp?.start() } catch (_: Exception) {} }

        fun release() {
            ready = false
            val p = mp
            mp = null
            if (p != null) {
                try { p.setOnPreparedListener(null); p.setOnCompletionListener(null); p.setOnErrorListener(null) } catch (_: Exception) {}
                try { p.release() } catch (_: Exception) {}
            }
        }

        fun kill() { alive = false; release() }
    }

    fun start(key: String, sources: List<Source>, shuffle: Boolean, vol: Float) {
        main.post {
            volume = vol.coerceIn(0f, 1f)
            channels.remove(key)?.kill()
            val ch = Channel(key, sources, shuffle)
            channels[key] = ch
            ch.begin()
        }
    }

    fun stop(key: String) { main.post { channels.remove(key)?.kill() } }

    fun stopAll() {
        main.post {
            channels.values.forEach { it.kill() }
            channels.clear()
            paused = false
        }
    }

    fun setVolume(v: Float) {
        main.post {
            volume = v.coerceIn(0f, 1f)
            channels.values.forEach { it.setVol(volume) }
        }
    }

    fun pause() { main.post { paused = true; channels.values.forEach { it.pause() } } }
    fun resume() { main.post { paused = false; channels.values.forEach { it.resume() } } }
}
