# Entraînement Tactique — version Android

Projet Android (Kotlin) qui embarque l'appli web `entrainement-tactique_08` dans une WebView,
avec un service de premier plan : la session continue écran éteint ou appli en arrière-plan.

- Notification persistante : minuteur, dernière annonce (couleur / ordre) avec son âge,
  événement en cours (couverture, repli, rechargement, blessure, changement d'arme), arme, exercice.
  Boutons Pause / Reprendre et Arrêter directement dans la notification.
- Voix : synthèse vocale native Android (repli automatique sur celle du navigateur).
- Wake lock CPU pendant la session ; demande d'exclusion d'optimisation batterie au 1er lancement de session.
- Bouton Retour pendant une session : met l'appli en arrière-plan sans arrêter la session.
- Le code de l appli web est dans `app/src/main/assets/www/index.html` (v08 + sauvegarde automatique de l état + pont Android)
  (la seule différence avec la v08 : un bloc JS ajouté à la fin, inactif hors Android).

Compilation : `./gradlew assembleDebug` (JDK 17) → `app/build/outputs/apk/debug/app-debug.apk`

## Persistance (v1.1.0)

Tout est gardé après fermeture complète de l'appli :
- réglages, cases cochées, curseurs, configurations nommées : doublés dans un stockage natif (`SharedPreferences`, écriture immédiate) ;
- sons d'ambiance importés : fichiers dans le stockage interne de l'appli (`files/amb/`), servis à la page via `/amb/…`.
Les données d'avant la mise à jour (localStorage / IndexedDB) sont recopiées automatiquement au premier lancement.
La page est aussi forcée de sauvegarder dès que l'appli quitte l'écran (`onPause` / `onStop`).

## Musiques, playlists, YouTube (v1.3.0)

Bloc « Ambiance sonore » :
- **Musiques du téléphone** : bouton « Choisir des musiques » (sélecteur système, plusieurs fichiers). Les fichiers sont *pointés*
  (permission persistante), pas copiés : aucune place en plus, aucun chargement.
- **YouTube** : barre « recherche, lien de vidéo ou de playlist ». Vidéo seule → un son ; playlist (jusqu'à 300 pistes) ou
  sélection de plusieurs résultats → playlist, avec cases à cocher, barre de progression globale (piste n / N + %), bouton Annuler.
  Aucune clé d'API : bibliothèque NewPipeExtractor (`YouTube.kt`). Pas de limite de durée.
- **Playlists** : puce « ♪ nom (n) » dans la liste des ambiances ; ✎ ouvre l'édition (retirer une piste, renommer, mode aléatoire,
  ajouter des pistes YouTube ou du téléphone, supprimer). Une piste déjà téléchargée n'est jamais re-téléchargée.
- **Lecture native en flux** (`MusicPlayer.kt`, MediaPlayer) : plus de décodage en mémoire. Un son = boucle ; playlist = piste après
  piste, en boucle. Pause / reprise de session suivies, curseur de volume en direct.
- **Fin de session** : la musique est coupée côté natif (`stopAll`) et tout le son Web Audio passe par un bus maître débranché à
  l'arrêt (plus de tirs « programmés à l'avance » qui continuent).
- Permission ajoutée : INTERNET. Pendant un import, l'écran reste allumé (pour que le téléchargement ne soit pas coupé).
- Si YouTube change et que la recherche échoue : monter la version `NewPipeExtractor` dans `app/build.gradle.kts`.
