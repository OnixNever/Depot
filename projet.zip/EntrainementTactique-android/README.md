# Entraînement Tactique — version Android

Projet Android (Kotlin) qui embarque l'appli web `entrainement-tactique_08` dans une WebView,
avec un service de premier plan : la session continue écran éteint ou appli en arrière-plan.

- Notification persistante : minuteur, dernière annonce (couleur / ordre) avec son âge,
  événement en cours (couverture, repli, rechargement, blessure, changement d'arme), arme, exercice.
  Boutons Pause / Reprendre et Arrêter directement dans la notification.
- Voix : synthèse vocale native Android (repli automatique sur celle du navigateur).
- Wake lock CPU pendant la session ; demande d'exclusion d'optimisation batterie au 1er lancement de session.
- Bouton Retour pendant une session : met l'appli en arrière-plan sans arrêter la session.
- Le code de l appli web est dans `app/src/main/assets/www/index.html` (v08 + sauvegarde automatique de l état + pont Android)
  (la seule différence avec la v08 : un bloc JS ajouté à la fin, inactif hors Android).

Compilation : `./gradlew assembleDebug` (JDK 17) → `app/build/outputs/apk/debug/app-debug.apk`

## Persistance (v1.1.0)

Tout est gardé après fermeture complète de l'appli :
- réglages, cases cochées, curseurs, configurations nommées : doublés dans un stockage natif (`SharedPreferences`, écriture immédiate) ;
- sons d'ambiance importés : fichiers dans le stockage interne de l'appli (`files/amb/`), servis à la page via `/amb/…`.
Les données d'avant la mise à jour (localStorage / IndexedDB) sont recopiées automatiquement au premier lancement.
La page est aussi forcée de sauvegarder dès que l'appli quitte l'écran (`onPause` / `onStop`).
