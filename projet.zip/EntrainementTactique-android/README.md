# Entraînement Tactique — version Android

Projet Android (Kotlin) qui embarque l'appli web `entrainement-tactique_08` dans une WebView,
avec un service de premier plan : la session continue écran éteint ou appli en arrière-plan.

- Notification persistante : minuteur, dernière annonce (couleur / ordre) avec son âge,
  événement en cours (couverture, repli, rechargement, blessure, changement d'arme), arme, exercice.
  Boutons Pause / Reprendre et Arrêter directement dans la notification.
- Voix : synthèse vocale native Android (repli automatique sur celle du navigateur).
- Wake lock CPU pendant la session ; demande d'exclusion d'optimisation batterie au 1er lancement de session.
- Bouton Retour pendant une session : met l'appli en arrière-plan sans arrêter la session.
- Le code de l appli web est dans `app/src/main/assets/www/index.html` (v08 + sauvegarde automatique de l état + pont Android)
  (la seule différence avec la v08 : un bloc JS ajouté à la fin, inactif hors Android).

Compilation : `./gradlew assembleDebug` (JDK 17) → `app/build/outputs/apk/debug/app-debug.apk`

## Persistance (v1.1.0)

Tout est gardé après fermeture complète de l'appli :
- réglages, cases cochées, curseurs, configurations nommées : doublés dans un stockage natif (`SharedPreferences`, écriture immédiate) ;
- sons d'ambiance importés : fichiers dans le stockage interne de l'appli (`files/amb/`), servis à la page via `/amb/…`.
Les données d'avant la mise à jour (localStorage / IndexedDB) sont recopiées automatiquement au premier lancement.
La page est aussi forcée de sauvegarder dès que l'appli quitte l'écran (`onPause` / `onStop`).

## Musiques, playlists, YouTube (v1.3.0)

Bloc « Ambiance sonore » :
- **Musiques du téléphone** : bouton « Choisir des musiques » (sélecteur système, plusieurs fichiers). Les fichiers sont *pointés*
  (permission persistante), pas copiés : aucune place en plus, aucun chargement.
- **YouTube** : barre « recherche, lien de vidéo ou de playlist ». Vidéo seule → un son ; playlist (jusqu'à 300 pistes) ou
  sélection de plusieurs résultats → playlist, avec cases à cocher, barre de progression globale (piste n / N + %), bouton Annuler.
  Aucune clé d'API : bibliothèque NewPipeExtractor (`YouTube.kt`). Pas de limite de durée.
- **Playlists** : puce « ♪ nom (n) » dans la liste des ambiances ; ✎ ouvre l'édition (retirer une piste, renommer, mode aléatoire,
  ajouter des pistes YouTube ou du téléphone, supprimer). Une piste déjà téléchargée n'est jamais re-téléchargée.
- **Lecture native en flux** (`MusicPlayer.kt`, MediaPlayer) : plus de décodage en mémoire. Un son = boucle ; playlist = piste après
  piste, en boucle. Pause / reprise de session suivies, curseur de volume en direct.
- **Fin de session** : la musique est coupée côté natif (`stopAll`) et tout le son Web Audio passe par un bus maître débranché à
  l'arrêt (plus de tirs « programmés à l'avance » qui continuent).
- Permission ajoutée : INTERNET. Pendant un import, l'écran reste allumé (pour que le téléchargement ne soit pas coupé).
- Si YouTube change et que la recherche échoue : monter la version `NewPipeExtractor` dans `app/build.gradle.kts`.

## Gâchette Bluetooth + progression (v1.4.0)

Bloc « Gâchette & progression » (premier bloc du menu) :
- **Capteur** : ESP32 + fil de cuivre sur G4 (`test_tactile_G4.ino`, version 2). L'appli cherche le service BLE
  `6e400001-…`, se connecte (`BleGachette.kt`), active les notifications et se reconnecte toute seule si la liaison tombe.
  Autorisations demandées au 1er clic sur « Connecter » (Bluetooth ; localisation sur Android 11 et avant, avec la localisation activée).
- **Temps de réaction** : chaque annonce (couleur, ordre, leurre) est un « stimulus ». Le toucher suivant donne le temps,
  mesuré depuis le début réel de la voix native (événement `onStart`), moins la moitié de la latence Bluetooth mesurée par ping.
  Annonce sans toucher en 10 s = manquée ; toucher sur un leurre = erreur ; toucher sans annonce = « hors annonce ».
- **Fin de session** : fenêtre de résumé → « Sauvegarder dans mes stats » ou « Ne pas garder » (étiquette facultative).
  Si l'appli est fermée avant ton choix, la fenêtre revient à l'ouverture suivante.
- **Progression** : courbes (moyenne, médiane, meilleur temps, régularité, % manqués), filtre par couleur / ordre / arme / exercice,
  période (10 / 30 / toutes), barres par couleur et par ordre, liste des sessions (détail, suppression), export / import par texte.
- Stockage : `files/stats.json` (écrit via fichier temporaire, jamais à moitié écrit). Exporte avant de désinstaller.
- Fichiers touchés : `BleGachette.kt` (nouveau), `AndroidBridge.kt`, `MainActivity.kt`, `AndroidManifest.xml`, `index.html`.

## Mesure adaptative + stats de performance (v1.5.0)

Même règle de mesure pour tous les modes, seuls ou combinés (full shoot, séance mixte, cibles multiples, leurres) :
- **Attribution dans l'ordre** : un toucher valide l'annonce *réelle* la plus ancienne encore en attente (avant : la plus récente, ce qui faussait full shoot et cibles multiples). Un leurre n'est retenu que s'il n'y a aucune vraie annonce en attente.
- **Fenêtre adaptative** : cible simple = ~2,2 × l'écart habituel entre annonces (min 2 s, max 10 s) → full shoot court, séance mixte large. Séquence « cibles multiples » et ordres : fenêtre large (10 s) pour laisser le temps de se déplacer.
- **Anticipation gardée** : un tir après l'affichage de la cible mais avant la voix, ou à moins de 120 ms de son début, n'est plus jeté : il est compté à part (valeur = ms après l'affichage) et n'entre pas dans les temps de réaction.
- **Anti-rebond** : deux touchers à moins de 120 ms = un seul tir.
- **Stats de performance** : plus de stats par couleur. Filtres : cibles simples / multiples (par cible) / ordres / arme / exercice. Nouvelles courbes : anticipations (%), tirs par session, précision (touchés / tirs). Chaque toucher compte comme un tir ; à la fin de session, saisie facultative des tirs touchés (ratés = tirs − touchés).
- Les anciennes sessions restent lisibles (champs ajoutés, rien d'enlevé). Le temps de réaction reste mesuré depuis le début de la voix, donc comparable à l'historique.
- Fichiers touchés : `index.html` (bloc gâchette), `README.md`, `app/build.gradle.kts`.

## Correctif sons de tir (v1.5.1)

- **Bug** : après la fin d'une première session (ou après un test ▶ suivi d'une session terminée), les tirs devenaient muets jusqu'à la fermeture complète de l'appli.
  Cause : `killAllSound()` remplace le bus maître à la fin de session, mais la chaîne audio des tirs (`shotBus`, compresseur) restait branchée sur l'ancien bus débranché.
- **Correction** : `killAllSound()` abandonne maintenant les chaînes mises en cache (`shotBus` et la réverbération des ambiances `ambWet`), recréées sur le nouveau bus au lancement suivant. Les sons déjà programmés restent bien coupés à la fin de session.
- Fichier touché : `index.html` (fonction `killAllSound`), plus version dans `app/build.gradle.kts`.

## Catégories de sauvegarde + stats enrichies (v1.6.0)

**Pourquoi** : un temps de réaction en *full shoot* (posé, tu touches tes cibles) et en *déplacement tactique* (tu te déplaces à couvert vers une zone annoncée) ne sont pas comparables. Tout mélanger faussait moyennes et taux.

**Catégories**
- À la fin d'une session, un menu « Catégorie » (par défaut : la dernière utilisée) + bouton « + Nouvelle ». Les sessions sans catégorie (anciennes sauvegardes) sont rangées dans « Général » (non supprimable).
- Progression → menu de catégorie en haut : toutes les stats se calculent pour la catégorie choisie. « Toutes » reste possible, avec un avertissement car cela mélange des séances de nature différente.
- Bouton « Gérer » : créer, renommer, supprimer. Supprimer une catégorie ne supprime pas ses sessions : elles passent dans « Général ».
- Déplacer : bouton « Déplacer » sur chaque session, ou « Sélectionner » pour en déplacer (ou supprimer) plusieurs d'un coup.
- Export / import : les catégories sont incluses ; un ancien export (sans catégories) s'importe dans « Général ».

**Stats ajoutées** (toujours par catégorie et par période)
- Périodes : 5 / 10 / 30 sessions, 7 / 30 / 90 jours, toutes.
- Vue d'ensemble : sessions, temps d'entraînement, tirs, réactions, moyenne, médiane, meilleur, P90, régularité relative, précision, manquées, anticipations, erreurs leurres, cadence (tirs/min), avec flèche vs période précédente de même taille (vert = mieux).
- Courbe : 15 mesures au choix (dont P90, cadence, durée…), moyenne mobile, tendance chiffrée par session, meilleure session entourée.
- Répartition des temps (histogramme + médiane / P90), « début → fin de session » (échauffement ou fatigue), par type / ordre / arme / exercice / niveau de fatigue / moment de la journée.
- Comparer les catégories (tableau, chaque catégorie calculée à part), records personnels, assiduité (12 semaines, séries de jours).
- Chaque session de la liste est comparée à la moyenne de sa catégorie.
- Fichiers touchés : `index.html` (module stats), `README.md`, `app/build.gradle.kts`. Aucun changement Kotlin.

## Mesure sur l'horloge de la carte + choix de catégorie (v1.6.1)

- **Temps de réaction** : au début de chaque session l'appli envoie « G » à la carte (son chrono repart à zéro). Chaque « T,<ms> » est ensuite daté par la carte elle-même, plus par l'heure d'arrivée du message : la gigue Bluetooth / Android / JavaScript disparaît des mesures. Si la synchro paraît incohérente (reset de la carte, reconnexion), l'appli la refait et utilise l'heure d'arrivée en attendant.
- **Anti-rebond** : le second anti-rebond (120 ms) de la page est supprimé ; seul celui de la carte (80 ms) reste. Tous les touchers envoyés par la carte sont comptés (en « tirs sans annonce » s'il n'y a aucune annonce en attente).
- **Fin de session** : le petit menu déroulant de catégorie est remplacé par de grandes tuiles (2 par ligne, nom + nombre de sessions, ✓ sur la catégorie choisie, dernière utilisée présélectionnée) et une tuile « + Nouvelle catégorie ».
- **Résumé de fin** : libellés plus explicites (« Tirs sur une annonce », « Tirs partis trop tôt (avant la voix) », « Annonces sans tir (ratées) », « Tirs sans annonce », « Tirs sur de faux ordres (leurres) »…).
- Fichiers touchés : `index.html` (bloc gâchette + fenêtre de fin), `README.md`, `app/build.gradle.kts`. Le `.ino` n'est pas modifié.
