# Entraînement Tactique — version Android

Projet Android (Kotlin) qui embarque l'appli web `entrainement-tactique_08` dans une WebView,
avec un service de premier plan : la session continue écran éteint ou appli en arrière-plan.

- Notification persistante : minuteur, dernière annonce (couleur / ordre) avec son âge,
  événement en cours (couverture, repli, rechargement, blessure, changement d'arme), arme, exercice.
  Boutons Pause / Reprendre et Arrêter directement dans la notification.
- Voix : synthèse vocale native Android (repli automatique sur celle du navigateur).
- Wake lock CPU pendant la session ; demande d'exclusion d'optimisation batterie au 1er lancement de session.
- Bouton Retour pendant une session : met l'appli en arrière-plan sans arrêter la session.
- Le code de l'appli web est dans `app/src/main/assets/www/index.html`
  (la seule différence avec la v08 : un bloc JS ajouté à la fin, inactif hors Android).

Compilation : `./gradlew assembleDebug` (JDK 17) → `app/build/outputs/apk/debug/app-debug.apk`
