package com.exemple.pressepapiers

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class SyncService : Service() {
    private val images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private var dernierId = 0L
    private var depuis = System.currentTimeMillis() / 1000

    @Volatile
    private var actif = true
    private lateinit var observateur: ContentObserver

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sync", "Synchronisation", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("recu", "Reçu du PC", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(this, "sync")
            .setContentTitle("Presse-papiers partagé actif")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }

        dernierId = lireDernierId()
        observateur = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                Thread { verifierCaptures() }.start()
            }
        }
        contentResolver.registerContentObserver(images, true, observateur)
        Thread { ecouterPc() }.start()
    }

    override fun onDestroy() {
        actif = false
        contentResolver.unregisterContentObserver(observateur)
        super.onDestroy()
    }

    // ---------------- Téléphone -> PC ----------------

    private fun lireDernierId(): Long {
        try {
            contentResolver.query(
                images,
                arrayOf(MediaStore.Images.Media._ID),
                null,
                null,
                MediaStore.Images.Media._ID + " DESC"
            )?.use {
                if (it.moveToFirst()) return it.getLong(0)
            }
        } catch (e: Exception) {
        }
        return 0L
    }

    @Synchronized
    private fun verifierCaptures() {
        try {
            Thread.sleep(700)
            val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH)
            contentResolver.query(
                images,
                proj,
                MediaStore.Images.Media._ID + " > ?",
                arrayOf(dernierId.toString()),
                MediaStore.Images.Media._ID + " ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    dernierId = maxOf(dernierId, id)
                    val chemin = c.getString(1) ?: ""
                    if (chemin.contains("screenshot", ignoreCase = true)) envoyerCapture(id)
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun envoyerCapture(id: Long) {
        val uri = ContentUris.withAppendedId(images, id)
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        val sortie = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, sortie)
        val cx = URL(Config.url(this) + "/image").openConnection() as HttpURLConnection
        cx.requestMethod = "POST"
        cx.doOutput = true
        cx.connectTimeout = 10000
        cx.readTimeout = 20000
        cx.setRequestProperty("X-Jeton", Config.jeton(this))
        cx.setRequestProperty("Content-Type", "image/jpeg")
        cx.setRequestProperty("ngrok-skip-browser-warning", "1")
        cx.outputStream.use { it.write(sortie.toByteArray()) }
        cx.responseCode
        cx.disconnect()
    }

    // ---------------- PC -> Téléphone ----------------

    private fun ecouterPc() {
        while (actif) {
            try {
                val adresse = "https://ntfy.sh/" + Config.sujet(this) + "/json?since=" + depuis
                val cx = URL(adresse).openConnection() as HttpURLConnection
                cx.readTimeout = 90000
                cx.inputStream.bufferedReader().forEachLine { ligne ->
                    if (ligne.isNotBlank()) {
                        try {
                            traiter(JSONObject(ligne))
                        } catch (e: Exception) {
                        }
                    }
                }
            } catch (e: Exception) {
            }
            if (actif) Thread.sleep(5000)
        }
    }

    private fun traiter(j: JSONObject) {
        if (j.optString("event") != "message") return
        depuis = j.optLong("time") + 1
        val att = j.optJSONObject("attachment")
        if (att == null) {
            notifier(j.optString("message"), null)
            return
        }
        val octets = telecharger(att.getString("url"))
        if (att.optString("type").startsWith("image")) {
            val dossier = File(cacheDir, "partage").apply { mkdirs() }
            val f = File(dossier, "pc_" + j.optLong("time") + ".jpg")
            f.writeBytes(octets)
            notifier(null, f)
        } else {
            notifier(String(octets, Charsets.UTF_8), null)
        }
    }

    private fun telecharger(adresse: String): ByteArray {
        val cx = URL(adresse).openConnection() as HttpURLConnection
        cx.connectTimeout = 10000
        cx.readTimeout = 30000
        return cx.inputStream.use { it.readBytes() }
    }

    private fun notifier(texte: String?, fichier: File?) {
        val id = (System.currentTimeMillis() % 100000).toInt()
        val copier = Intent(this, CopyReceiver::class.java)
        if (texte != null) copier.putExtra("texte", texte)
        if (fichier != null) copier.putExtra("fichier", fichier.absolutePath)
        val pi = PendingIntent.getBroadcast(
            this, id, copier,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, "recu")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Reçu du PC")
            .setAutoCancel(true)
            .addAction(0, "Copier", pi)
        if (texte != null) {
            b.setContentText(texte).setStyle(Notification.BigTextStyle().bigText(texte))
        } else if (fichier != null) {
            b.setStyle(Notification.BigPictureStyle().bigPicture(BitmapFactory.decodeFile(fichier.absolutePath)))
        }
        getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}
