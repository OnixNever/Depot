package com.exemple.pressepapiers

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ctx = this
        val l = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        val titre = TextView(ctx).apply {
            text = "Presse-papiers partagé"
            textSize = 22f
        }
        val url = EditText(ctx).apply {
            hint = "Adresse ngrok (https://xxx.ngrok-free.app)"
            setText(Config.url(ctx))
        }
        val jeton = EditText(ctx).apply {
            hint = "Jeton (copié depuis le PC)"
            setText(Config.jeton(ctx))
        }
        val sujet = EditText(ctx).apply {
            hint = "Sujet ntfy (copié depuis le PC)"
            setText(Config.sujet(ctx))
        }
        val marche = Button(ctx).apply { text = "Démarrer" }
        val arret = Button(ctx).apply { text = "Arrêter" }

        marche.setOnClickListener {
            Config.save(ctx, url.text.toString(), jeton.text.toString(), sujet.text.toString())
            val p = if (Build.VERSION.SDK_INT >= 33) {
                arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.POST_NOTIFICATIONS)
            } else {
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            requestPermissions(p, 1)
        }
        arret.setOnClickListener { stopService(Intent(ctx, SyncService::class.java)) }

        listOf(titre, url, jeton, sujet, marche, arret).forEach { l.addView(it) }
        setContentView(l)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        startForegroundService(Intent(this, SyncService::class.java))
    }
}
