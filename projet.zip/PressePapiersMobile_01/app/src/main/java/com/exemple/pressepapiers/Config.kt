package com.exemple.pressepapiers

import android.content.Context

object Config {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun url(c: Context) = p(c).getString("url", "") ?: ""
    fun jeton(c: Context) = p(c).getString("jeton", "") ?: ""
    fun sujet(c: Context) = p(c).getString("sujet", "") ?: ""

    fun save(c: Context, url: String, jeton: String, sujet: String) {
        p(c).edit()
            .putString("url", url.trim().trimEnd('/'))
            .putString("jeton", jeton.trim())
            .putString("sujet", sujet.trim())
            .apply()
    }
}
