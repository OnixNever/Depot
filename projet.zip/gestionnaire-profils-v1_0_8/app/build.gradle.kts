plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.profils"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.profils"
        minSdk = 26
        targetSdk = 34
        // Le workflow GitHub fournit VERSION_CODE (minutes écoulées depuis 1970) : il augmente à chaque build,
        // même si le dépôt est recréé. En local, on garde la valeur de secours.
        versionCode = System.getenv("VERSION_CODE")?.toIntOrNull() ?: 18
        versionName = "1.0.8"
    }

    // Clé de signature FIXE, fournie par les secrets GitHub. Même clé à chaque build = mise à jour par-dessus
    // sans désinstaller, donc profils et comptes conservés.
    signingConfigs {
        create("release") {
            val chemin = System.getenv("KEYSTORE_PATH")
            if (chemin != null) {
                storeFile = file(chemin)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (System.getenv("KEYSTORE_PATH") != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
