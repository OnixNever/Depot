# Scanner sans pub (v2)

Moteur de scan maison : caméra intégrée avec détection du document en direct (cadre vert),
capture automatique quand le cadre est stable, recadrage manuel par 4 coins, redressement de
perspective, puis filtres : Document (ombres supprimées, fond blanc, texte net), Noir & blanc,
Gris, Écran (réduit le moiré des photos d'écran) et Original.
Multi-pages, import depuis la galerie, nom du document, PDF, partage en images,
texte sélectionnable (OCR local). Zéro pub, tout en local.

## Compiler
1. Pousse tout le contenu de ce dossier sur GitHub (y compris `.github`).
2. Onglet **Actions** > **Build APK**.
3. Télécharge l'artefact `scanner-apk` et installe `app-debug.apk`.

## Logo
Feuille blanche + faisceau de scan vert sur fond dégradé bleu nuit -> turquoise.
- Premier plan : `res/drawable/ic_fg.xml` (pour ton PNG : supprime-le et mets `ic_fg.png`).
- Fond : `res/drawable/ic_bg_grad.xml` (couleurs de début et de fin du dégradé).
- Icône monochrome (thèmes Android 13+) : `res/drawable/ic_mono.xml`.

## Réglages du traitement d'image
Tout est dans `DocScanner.kt` : détection (`detect`), redressement (`warp`), filtres (`process`,
`flatten`, `levels`, `sharpen`, `blackWhite`, `descreen`). Les valeurs (niveaux, netteté,
seuils) sont faciles à ajuster.

## Utilisation (v3)
- Dans un document : **Enregistrer** (PDF dans Téléchargements/Scanner, images dans Images/Scanner)
  et **Partager**, chacun avec le choix PDF ou images.
- Bandeau de pages : maintiens une page et glisse pour la déplacer, ✕ pour la supprimer.
  Disponible pendant la prise de photos et après l'enregistrement.
- **Ajouter des pages** à un document existant (caméra ou galerie).
- Onglet **Document** : touche une ligne pour la sélectionner, ou maintiens puis glisse pour en
  sélectionner plusieurs, puis **Copier**. Onglet **Texte** : sélection native mot par mot.
- Android 10 minimum (enregistrement direct sans permission).

## Version 5 : photo plus nette, filtre Photo

- **Filtre Auto (par défaut)** : si la page est très colorée ou sombre (couverture de livre, photo), l'appli prend le filtre **Photo** (couleurs d'origine, lumière corrigée, netteté douce). Sinon elle prend **Document**. Tu peux toujours changer à la main.
- **Capture auto seulement si l'image est nette** : le cadre doit être stable ET la netteté au maximum. Le message « Mise au point… » s'affiche tant que ce n'est pas bon.
- **Mise au point sur le document** : dès qu'un document est détecté, l'appli fait le point dessus. Le bouton « Photo » refait aussi le point juste avant de déclencher.
- **Résolution maximale** pour la capture, JPEG des pages à 97 %, PDF jusqu'à 3000 px de côté (avant : 2400).
- Réglages dans le code :
  - `CameraScreen.kt` : `stable >= 3` (vitesse de déclenchement), `sharp > 20.0` (netteté minimale), `peak * 0.85` (exigence de netteté).
  - `DocScanner.kt` : `looksLikePhoto` (seuils 0.30 pour décider Photo/Document), `photo()` et le filtre DOCUMENT (netteté).

## Version 6 : prise rapide, rafale, lumière adaptative, nouvelle icône

- **Rafale à chaque photo** : un appui prend `BURST` photos (3 par défaut), mesure la netteté de chacune
  et garde la meilleure. Corrige le léger tremblement de main. Réglage : `BURST` en haut de `CameraScreen.kt`
  (1 = rafale désactivée).
- **Capture auto plus rapide** : stabilité `stable >= 2` (avant 3), netteté minimale `sharp > 12.0` (avant 20.0),
  exigence de pic `peak * 0.75` (avant 0.85). La rafale choisit ensuite la meilleure image, donc plus besoin
  d'attendre la position parfaite. Si tu obtiens trop de photos floues, remonte ces valeurs.
- **Lumière adaptative (filtre Document et Gris)** : les niveaux (point noir / point blanc) sont calculés sur chaque
  image au lieu de valeurs fixes (`adaptiveLevels` dans `DocScanner.kt`). Fini l'effet « flash » en lumière forte.
- **Lumière faible** : gain du nettoyage de fond limité (`Core.max(bg, Scalar(45.0), bg)` dans `background`), et
  netteté réduite quand la page est sombre (`lightFactor`), pour ne pas gonfler le bruit.
- **Auto Photo/Document plus juste** : « sombre » est maintenant relatif à la luminosité de la page
  (`looksLikePhoto`). Un document pris dans une pièce peu éclairée n'est plus pris pour une photo.
- **Nouvelle icône** (voir plus haut).
