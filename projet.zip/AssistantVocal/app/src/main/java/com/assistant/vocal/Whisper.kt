package com.assistant.vocal

import android.content.Context
import android.os.SystemClock
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Découpe le micro en phrases : début quand ça parle, fin après un court silence.
 * Le seuil suit le bruit ambiant (il monte tout seul si le bruit de fond monte).
 * Appelé depuis le thread micro ; reset() peut venir d'un autre thread.
 */
class UtteranceCutter(private val prefs: Prefs) {
    private val sr = 16000
    private val maxSamples = sr * 10
    private val data = ShortArray(sr * 12)
    private var len = 0
    private val pre = ArrayList<ShortArray>()
    private var preLen = 0
    private var speaking = false
    private var speechMs = 0
    private var silenceMs = 0
    private var noise = 0f

    @Volatile var busy = false
        private set
    @Volatile var busySince = 0L
        private set

    @Synchronized
    fun reset() {
        speaking = false
        len = 0
        speechMs = 0
        silenceMs = 0
        pre.clear()
        preLen = 0
        busy = false
    }

    /** Une phrase est partie vers Whisper : on n'écoute plus tant que la commande n'est pas terminée. */
    @Synchronized
    fun markBusy(now: Long) { busy = true; busySince = now }

    /** Vrai si le son ressemble à une voix (périodique entre 80 et 400 Hz) : un moteur ou le vent ne le sont pas. */
    private fun voiced(b: ShortArray, n: Int): Boolean {
        if (n < 800) return false
        var e0 = 0.0
        for (i in 0 until n) e0 += b[i].toDouble() * b[i]
        if (e0 < 1.0) return false
        var best = 0.0
        var lag = 40
        while (lag <= 200) {
            var c = 0.0
            var i = lag
            while (i < n) { c += b[i].toDouble() * b[i - lag]; i += 2 }
            val r = c * 2.0 / e0
            if (r > best) best = r
            lag += 2
        }
        return best > 0.35
    }

    private var sinceVoice = 0

    @Synchronized
    fun feed(b: ShortArray, n: Int, rms: Float): ShortArray? {
        if (busy) return null
        if (noise == 0f) noise = prefs.noiseRms.coerceIn(60f, 600f)
        val ms = n * 1000 / sr
        val vc = voiced(b, n)
        val thr = (noise * 2.5f).coerceAtLeast(150f)
        if (!speaking) {
            // Début : une voix nette un peu au-dessus du bruit, ou un son franchement fort
            val start = (vc && rms > (noise * 1.7f).coerceAtLeast(120f)) || rms > thr * 2.5f
            if (!start) {
                // Le bruit de fond suit : lentement quand c'est calme, plus vite quand ça gronde sans être une voix
                noise = if (rms > thr) (noise * 0.9f + rms.coerceAtMost(noise * 4f) * 0.1f).coerceAtMost(2500f)
                        else noise * 0.97f + rms.coerceAtMost(noise * 2.5f) * 0.03f
                keepPre(b, n)
                return null
            }
            speaking = true
            speechMs = 0
            silenceMs = 0
            sinceVoice = 0
            len = 0
            for (c in pre) append(c, c.size)
            pre.clear()
            preLen = 0
        }
        append(b, n)
        if (vc) sinceVoice = 0 else sinceVoice += ms
        // Parole = voix, ou son fort juste après une voix (fin de mot) ; le bruit seul ne compte plus au bout de 0,6 s
        val speech = vc || (rms > thr * 0.6f && sinceVoice < 600)
        if (speech) { speechMs += ms; silenceMs = 0 } else silenceMs += ms
        if (silenceMs >= 550 || len >= maxSamples || len + 1600 > data.size) return finish()
        return null
    }

    private fun keepPre(b: ShortArray, n: Int) {
        pre.add(b.copyOf(n))
        preLen += n
        while (preLen > sr * 4 / 10 && pre.size > 1) preLen -= pre.removeAt(0).size
    }

    private fun append(b: ShortArray, n: Int) {
        val k = minOf(n, data.size - len)
        if (k <= 0) return
        System.arraycopy(b, 0, data, len, k)
        len += k
    }

    private fun finish(): ShortArray? {
        val ok = speechMs >= 350
        val trim = (silenceMs - 250).coerceAtLeast(0) * sr / 1000
        val outLen = (len - trim).coerceAtLeast(0)
        val out = if (ok) data.copyOf(outLen) else null
        speaking = false
        len = 0
        speechMs = 0
        silenceMs = 0
        return out
    }
}

/**
 * Transcription Whisper via Groq (gratuit avec la clé Groq) : bien meilleure que Google dans le bruit.
 * Au moindre souci (quota, réseau, clé), le service se met en pause et l'appli retombe sur Google puis Vosk.
 */
object Whisper {
    @Volatile private var cool = 0L
    @Volatile var lastError = ""

    private const val URL_STT = "https://api.groq.com/openai/v1/audio/transcriptions"

    private fun now() = SystemClock.elapsedRealtime()

    fun ready(p: Prefs) = p.groqKey.isNotBlank() && now() >= cool
    fun resetCooldown() { cool = 0L }

    private fun fail(code: Int, detail: String, retryAfterSec: Int) {
        val ms = when (code) {
            401, 403, 400, 404 -> 600_000L
            429 -> (if (retryAfterSec > 0) retryAfterSec * 1000L else 60_000L).coerceIn(20_000L, 1_800_000L)
            0 -> 4_000L          // coupure réseau (4G en mouvement) : on réessaie très vite
            else -> 20_000L
        }
        cool = now() + ms
        lastCode = code
        lastError = detail
        Status.log("Whisper : impossible ($detail) → pause ${ms / 1000} s")
    }

    private fun wav(pcm: ShortArray): ByteArray {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + dataLen); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(16000); bb.putInt(32000); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(dataLen)
        for (s in pcm) bb.putShort(s)
        return bb.array()
    }

    private fun multipart(boundary: String, fields: Map<String, String>, wav: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        fun w(s: String) = o.write(s.toByteArray(Charsets.UTF_8))
        for ((k, v) in fields) w("--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n")
        w("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
        o.write(wav)
        w("\r\n--$boundary--\r\n")
        return o.toByteArray()
    }

    // Phrases que Whisper invente quand il n'y a que du bruit
    private val ghosts = listOf(
        "sous titr", "merci d avoir regarde", "abonnez vous", "amara org", "n oubliez pas de vous abonner",
        "a bientot pour de nouvelles videos", "commande vocale pour un telephone"
    )

    private fun isGhost(t: String): Boolean {
        val n = Txt.norm(t)
        return n.isEmpty() || ghosts.any { n.contains(it) }
    }

    /** Texte entendu ; "" = rien de compris (bruit) ; null = échec (le cloud est mis en pause, l'appelant se rabat sur le local). */
    fun transcribe(ctx: Context, pcm: ShortArray, hint: String): String? {
        val r = transcribeOnce(ctx, pcm, hint)
        // Une coupure réseau passagère (4G) ne doit pas faire perdre la phrase : une seule nouvelle tentative
        if (r == null && lastError.isNotEmpty() && lastCode == 0) {
            cool = 0L
            try { Thread.sleep(300) } catch (_: Throwable) {}
            return transcribeOnce(ctx, pcm, hint)
        }
        return r
    }

    @Volatile private var lastCode = -1

    private fun transcribeOnce(ctx: Context, pcm: ShortArray, hint: String): String? {
        val p = Prefs(ctx)
        val t0 = now()
        try {
            val boundary = "----av" + System.nanoTime()
            val fields = linkedMapOf(
                "model" to p.sttModel, "language" to "fr",
                "response_format" to "verbose_json", "temperature" to "0"
            )
            if (hint.isNotBlank()) fields["prompt"] = hint
            val body = multipart(boundary, fields, wav(pcm))
            val c = URL(URL_STT).openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 3000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Authorization", "Bearer ${p.groqKey}")
                c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                c.setRequestProperty("User-Agent", "AssistantVocal/0.8")
                c.setFixedLengthStreamingMode(body.size)
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val ra = c.getHeaderField("retry-after")?.trim()?.toDoubleOrNull()?.toInt() ?: 0
                    fail(code, "HTTP $code ${txt.take(140)}", ra)
                    return null
                }
                val js = JSONObject(txt)
                val text = js.optString("text").trim()
                // Whisper dit lui-même quand il pense n'avoir entendu aucune parole
                val segs = js.optJSONArray("segments")
                if (segs != null && segs.length() > 0) {
                    var speech = false
                    for (i in 0 until segs.length()) {
                        if (segs.getJSONObject(i).optDouble("no_speech_prob", 0.0) < 0.6) speech = true
                    }
                    if (!speech) return ""
                }
                lastError = ""
                lastCode = 200
                Status.log("Whisper : ${now() - t0} ms")
                return if (isGhost(text)) "" else text
            } finally {
                c.disconnect()
            }
        } catch (t: Throwable) {
            fail(0, t.javaClass.simpleName, 0)
            return null
        }
    }

    /** Test depuis l'écran principal : envoie 0,6 s de silence. */
    fun ping(ctx: Context): String {
        resetCooldown()
        val r = transcribe(ctx, ShortArray(9600), "")
        return if (r != null) "OK ✔" else "échec (${lastError.ifBlank { "voir le journal" }})"
    }
}
