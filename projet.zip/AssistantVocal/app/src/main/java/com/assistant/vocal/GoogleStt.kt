package com.assistant.vocal

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Reconnaissance vocale de Google, SANS clé : c'est le service de reconnaissance déjà installé sur le téléphone
 * (l'appli Google). À utiliser uniquement depuis le thread principal.
 * Ce service prend le micro pour lui seul : le micro de l'assistant doit donc être fermé pendant l'écoute.
 */
class GoogleStt(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onFail: (Int) -> Unit
) {
    companion object {
        fun available(ctx: Context): Boolean =
            try { SpeechRecognizer.isRecognitionAvailable(ctx) } catch (_: Throwable) { false }
    }

    private var rec: SpeechRecognizer? = null
    private var active = false

    private val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            if (!active) return
            active = false
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""
            if (t.isEmpty()) onFail(SpeechRecognizer.ERROR_NO_MATCH) else onText(t)
        }

        override fun onError(error: Int) {
            if (!active) return
            active = false
            onFail(error)
        }
    }

    fun start() {
        cancel()
        try {
            val r = rec ?: SpeechRecognizer.createSpeechRecognizer(ctx).also {
                it.setRecognitionListener(listener)
                rec = it
            }
            active = true
            r.startListening(intent)
        } catch (t: Throwable) {
            destroy()
            onFail(SpeechRecognizer.ERROR_CLIENT)
        }
    }

    fun cancel() {
        if (!active) return
        active = false
        try { rec?.cancel() } catch (_: Throwable) {}
    }

    fun destroy() {
        active = false
        try { rec?.destroy() } catch (_: Throwable) {}
        rec = null
    }
}
