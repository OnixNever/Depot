package com.assistant.vocal

import android.content.Context
import java.text.Normalizer

object Txt {
    /** Minuscules sans accents, longueur identique à l'original (pour extraire des arguments). */
    fun fold(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()

    /** Forme comparable : lettres/chiffres et espaces simples uniquement. */
    fun norm(s: String): String =
        fold(s).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Enlève le « s » final des mots : « listes de lecture » ~ « liste de lecture ». */
    fun stem(s: String): String =
        s.split(" ").joinToString(" ") { if (it.length > 3 && it.endsWith("s")) it.dropLast(1) else it }
}

/** État partagé, affiché dans l'écran de diagnostic. */
object Status {
    @Volatile var listening = false
    @Volatile var session = false
    @Volatile var heard = ""
    @Volatile var action = ""
    @Volatile var error = ""

    private val logs = java.util.ArrayDeque<String>()
    private val fmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.FRANCE)

    /** Journal des derniers événements (affiché dans l'écran principal pour comprendre les pannes). */
    fun log(s: String) = synchronized(logs) {
        logs.addFirst(fmt.format(java.util.Date()) + "  " + s)
        while (logs.size > 150) logs.removeLast()
    }

    fun logText(n: Int = 12): String = synchronized(logs) { logs.take(n).joinToString("\n") }
}

class Prefs(ctx: Context) {
    companion object {
        const val BRAIN_MODEL = "claude-haiku-5-5"
        const val PROV_GROQ = "groq"
        const val PROV_ANTHROPIC = "anthropic"
        const val GROQ_MODEL = "openai/gpt-oss-120b"
    }

    private val sp = ctx.applicationContext.getSharedPreferences("assistant", Context.MODE_PRIVATE)

    /** Nom de l'assistant / phrase d'activation (texte indicatif en mode « ma voix »). */
    var phrase: String
        get() = sp.getString("phrase", "salut onix") ?: "salut onix"
        set(v) { sp.edit().putString("phrase", v.trim().lowercase()).apply() }

    /** "voice" = reconnaissance de TA voix (n'importe quel mot) ; "words" = mots français du modèle. */
    var wakeMode: String
        get() = sp.getString("wakeMode", "voice") ?: "voice"
        set(v) { sp.edit().putString("wakeMode", v).apply() }

    /** Mode mots : confiance minimale. */
    var minConf: Float
        get() = sp.getFloat("minConf", 0.45f)
        set(v) { sp.edit().putFloat("minConf", v).apply() }

    /** Mode voix : distance maximale acceptée (réglée seule) et valeur de base du calibrage. */
    var voiceThr: Float
        get() = sp.getFloat("voiceThr", 0f)
        set(v) { sp.edit().putFloat("voiceThr", v).apply() }
    var voiceBase: Float
        get() = sp.getFloat("voiceBase", 0f)
        set(v) { sp.edit().putFloat("voiceBase", v).apply() }

    var maxGain: Float
        get() = sp.getFloat("maxGain", 6f)
        set(v) { sp.edit().putFloat("maxGain", v).apply() }

    var noiseRms: Float
        get() = sp.getFloat("noiseRms", 150f)
        set(v) { sp.edit().putFloat("noiseRms", v).apply() }

    var calibrated: Boolean
        get() = sp.getBoolean("calibrated", false)
        set(v) { sp.edit().putBoolean("calibrated", v).apply() }

    /** Cerveau local (petit modèle de langage) : utilisé quand les règles simples ne comprennent pas. */
    var brainOn: Boolean
        get() = sp.getBoolean("brainOn", true)
        set(v) { sp.edit().putBoolean("brainOn", v).apply() }

    /** Reconnaissance vocale de Google (sans clé) quand il y a du réseau ; sinon Vosk en local. */
    var googleStt: Boolean
        get() = sp.getBoolean("googleStt", true)
        set(v) { sp.edit().putBoolean("googleStt", v).apply() }

    /** Cloud : cerveau Claude quand il y a du réseau (sinon petit cerveau local). */
    var cloudBrain: Boolean
        get() = sp.getBoolean("cloudBrain", true)
        set(v) { sp.edit().putBoolean("cloudBrain", v).apply() }

    var brainModel: String
        get() = sp.getString("brainModel", BRAIN_MODEL) ?: BRAIN_MODEL
        set(v) { sp.edit().putString("brainModel", v).apply() }
    /** Fournisseur du cerveau cloud : "groq" (gratuit, par défaut) ou "anthropic" (payant). */
    /** Transcription Whisper (Groq) en session, quand il y a une clé Groq et du réseau. */
    /** Veille par Whisper : pas de calibrage, tient dans le bruit (envoie seulement les moments de parole). */
    var whisperWake: Boolean
        get() = sp.getBoolean("whisperWake", true)
        set(v) { sp.edit().putBoolean("whisperWake", v).apply() }

    /** Micro intégré du téléphone uniquement (évite que le micro de la voiture ou du Bluetooth, de mauvaise qualité, soit pris à la place). */
    var micPhone: Boolean
        get() = sp.getBoolean("micPhone", true)
        set(v) { sp.edit().putBoolean("micPhone", v).apply() }

    /** Veille par la reconnaissance Google continue dans une WebView invisible (comme la page de dictée), sans quota Groq. */
    var webWake: Boolean
        get() = sp.getBoolean("webWake", true)
        set(v) { sp.edit().putBoolean("webWake", v).apply() }

    var whisperStt: Boolean
        get() = sp.getBoolean("whisperStt", true)
        set(v) { sp.edit().putBoolean("whisperStt", v).apply() }
    var sttModel: String
        get() = sp.getString("sttModel", "whisper-large-v3-turbo") ?: "whisper-large-v3-turbo"
        set(v) { sp.edit().putString("sttModel", v).apply() }
    var brainProvider: String
        get() = sp.getString("brainProvider", PROV_GROQ) ?: PROV_GROQ
        set(v) { sp.edit().putString("brainProvider", v).apply() }
    var groqModel: String
        get() = sp.getString("groqModel", GROQ_MODEL) ?: GROQ_MODEL
        set(v) { sp.edit().putString("groqModel", v).apply() }
    var groqKey: String
        get() = sp.getString("groqKey", "") ?: ""
        set(v) { sp.edit().putString("groqKey", v).apply() }
    var brainKey: String
        get() = sp.getString("brainKey", "") ?: ""
        set(v) { sp.edit().putString("brainKey", v).apply() }

    var wasListening: Boolean
        get() = sp.getBoolean("wasListening", false)
        set(v) { sp.edit().putBoolean("wasListening", v).apply() }
}
