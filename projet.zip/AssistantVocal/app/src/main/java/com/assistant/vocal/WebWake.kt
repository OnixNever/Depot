package com.assistant.vocal

import android.annotation.SuppressLint
import android.content.Context
import android.content.MutableContextWrapper
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Veille « comme ta page de dictée » : la reconnaissance vocale continue de Google, dans une WebView invisible.
 * Aucune amorce, aucun calibrage, aucun quota Groq. Elle ne tourne qu'en veille : dès que « Onyx » est entendu,
 * elle s'arrête (le micro est rendu à l'assistant) et redémarre à la fermeture de la session.
 * Si la WebView ne sait pas faire (API absente, micro refusé, aucun signe de vie), onFail est appelé
 * et l'assistant revient seul à la veille Whisper.
 */
class WebWake(
    private val ctx: Context,
    private val onText: (String, Boolean) -> Unit,
    private val onFail: (String, Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var attached = false
    private var loaded = false
    @Volatile var running = false
        private set
    private var startedAt = 0L
    private var lastEvent = 0L
    private var everStarted = false
    private var netErrors = 0
    private var reloads = 0

    private val html = """
<!DOCTYPE html><html><body><script>
var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
window.__run = false;
if (!SR) { Native.onState('unsupported'); }
else {
  var r = new SR();
  r.lang = 'fr-FR'; r.continuous = true; r.interimResults = true;
  r.onstart = function(){ Native.onState('started'); };
  r.onresult = function(e){
    for (var i = e.resultIndex; i < e.results.length; i++) {
      Native.onText(e.results[i][0].transcript, e.results[i].isFinal);
    }
  };
  r.onerror = function(e){ Native.onState('error:' + e.error); };
  r.onend = function(){
    Native.onState('ended');
    if (window.__run) setTimeout(function(){ try { r.start(); } catch(x) {} }, 150);
  };
  window.startWake = function(){ window.__run = true; try { r.start(); } catch(x) {} };
  window.stopWake = function(){ window.__run = false; try { r.abort(); } catch(x) {} };
  Native.onState('ready');
}
</script></body></html>
"""

    private inner class Bridge {
        @JavascriptInterface fun onText(t: String, final: Boolean) {
            main.post { lastEvent = SystemClock.elapsedRealtime(); if (running) onText(t, final) }
        }
        @JavascriptInterface fun onState(s: String) { main.post { state(s) } }
    }

    private fun state(s: String) {
        lastEvent = SystemClock.elapsedRealtime()
        when {
            s == "unsupported" -> fail("l'API de reconnaissance n'existe pas dans cette WebView", true)
            s == "started" -> { everStarted = true; netErrors = 0 }
            s == "ready" -> { if (running) web?.evaluateJavascript("startWake()", null) }
            s.startsWith("error:") -> {
                when (val e = s.removePrefix("error:")) {
                    "no-speech", "aborted" -> {}
                    "network" -> { netErrors++; if (netErrors >= 4) fail("réseau instable", false) }
                    "not-allowed", "service-not-allowed", "audio-capture", "language-not-supported" ->
                        fail("refusé par Android ($e)", true)
                    else -> {}
                }
            }
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.elapsedRealtime()
            if (!everStarted && now - startedAt > 10_000) { fail("la reconnaissance ne démarre pas", true); return }
            if (now - lastEvent > 90_000) {
                reloads++
                if (reloads > 3) { fail("la page ne répond plus", false); return }
                Status.log("Veille WebView : relance de la page")
                everStarted = false; startedAt = now; lastEvent = now
                loaded = false
                web?.loadDataWithBaseURL("https://assistant.local/", html, "text/html", "utf-8", null)
            }
            main.postDelayed(this, 5000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun ensureView() {
        if (web != null) return
        val w = WebView(MutableContextWrapper(ctx.applicationContext))
        w.settings.javaScriptEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        w.settings.allowFileAccess = false
        w.addJavascriptInterface(Bridge(), "Native")
        w.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                main.post { try { request.grant(request.resources) } catch (_: Throwable) {} }
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { loaded = true }
        }
        // Fenêtre de 1 pixel, invisible et non touchable : Android traite la page comme « visible », ce que la reconnaissance exige parfois
        try {
            val wm = ctx.getSystemService(WindowManager::class.java)
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(w, lp)
            attached = true
        } catch (_: Throwable) {}
        web = w
        w.loadDataWithBaseURL("https://assistant.local/", html, "text/html", "utf-8", null)
    }

    fun start() {
        main.post {
            if (running) return@post
            try {
                running = true
                startedAt = SystemClock.elapsedRealtime()
                lastEvent = startedAt
                everStarted = false
                netErrors = 0
                ensureView()
                if (loaded) web?.evaluateJavascript("startWake()", null)
                main.removeCallbacks(watchdog)
                main.postDelayed(watchdog, 5000)
            } catch (t: Throwable) { fail("erreur WebView (${t.javaClass.simpleName})", true) }
        }
    }

    fun stop() {
        main.post {
            running = false
            main.removeCallbacks(watchdog)
            try { web?.evaluateJavascript("stopWake()", null) } catch (_: Throwable) {}
        }
    }

    private fun fail(why: String, permanent: Boolean) {
        if (!running) return
        running = false
        main.removeCallbacks(watchdog)
        try { web?.evaluateJavascript("stopWake()", null) } catch (_: Throwable) {}
        onFail(why, permanent)
    }

    fun destroy() {
        main.post {
            running = false
            main.removeCallbacks(watchdog)
            try {
                web?.let { w ->
                    if (attached) ctx.getSystemService(WindowManager::class.java).removeView(w)
                    w.destroy()
                }
            } catch (_: Throwable) {}
            web = null
            attached = false
            loaded = false
        }
    }
}
