package com.assistant.vocal

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.SystemClock
import kotlin.math.sqrt

/**
 * Capture micro 16 kHz mono + gain automatique (pour entendre de plus loin).
 * Robuste : si Android coupe le micro (silence numérique, erreur de lecture), il est redémarré tout seul.
 * onChunk reçoit le signal déjà amplifié et le niveau brut (RMS) avant amplification.
 */
class AudioLoop(private val prefs: Prefs, private val onChunk: (ShortArray, Int, Float) -> Unit) {
    @Volatile var running = false
    @Volatile var paused = false
        set(v) { field = v; if (v) pausedSince = SystemClock.elapsedRealtime() }
    @Volatile var testMode = false
    @Volatile var lastChunkAt = 0L
    var onError: (() -> Unit)? = null
    var audioManager: AudioManager? = null
    private var thread: Thread? = null
    private var gain = 1f
    @Volatile private var pausedSince = 0L

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            var fails = 0
            while (running) {
                val ok = session()
                if (!running) break
                if (!ok) {
                    fails++
                    if (fails >= 3) { running = false; onError?.invoke(); break }
                } else fails = 0
                try { Thread.sleep(600) } catch (_: Throwable) {}
            }
        }.also { it.start() }
    }

    /** Une session d'enregistrement. false = impossible d'ouvrir le micro ; true = arrêt pour redémarrage. */
    @SuppressLint("MissingPermission")
    private fun session(): Boolean {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400) * 2
            )
        } catch (e: Throwable) { null }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            try { rec?.release() } catch (_: Throwable) {}
            return false
        }
        // Filtres du téléphone : suppression de bruit + annulation d'écho (la musique du téléphone ne couvre plus ta voix)
        // Micro du téléphone : en voiture, Android peut prendre le micro de la voiture / du Bluetooth, bien moins bon
        if (prefs.micPhone) {
            try {
                val dev = audioManager?.getDevices(AudioManager.GET_DEVICES_INPUTS)?.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
                if (dev != null) rec.setPreferredDevice(dev)
            } catch (_: Throwable) {}
        }
        var agc: AutomaticGainControl? = null
        var ns: NoiseSuppressor? = null
        var aec: AcousticEchoCanceler? = null
        try { if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true } } catch (_: Throwable) {}
        try { if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true } } catch (_: Throwable) {}
        try { if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(rec.audioSessionId)?.also { it.enabled = true } } catch (_: Throwable) {}
        try {
            rec.startRecording()
            try {
                val rd = rec.routedDevice
                val kind = when (rd?.type) { AudioDeviceInfo.TYPE_BUILTIN_MIC -> "micro du téléphone"; AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (voiture/casque)"; AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "micro filaire/USB"; null -> "inconnu"; else -> "type ${rd?.type}" }
                Status.log("Micro utilisé : $kind (NS=${ns != null}, écho=${aec != null}, AGC=${agc != null})")
            } catch (_: Throwable) {}
            val buf = ShortArray(1600) // 100 ms
            var bad = 0
            var dead = 0
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) {
                    bad++
                    if (bad > 25) { Status.log("Micro : lecture en échec, redémarrage"); break }
                    try { Thread.sleep(80) } catch (_: Throwable) {}
                    continue
                }
                bad = 0
                lastChunkAt = SystemClock.elapsedRealtime()
                if (paused) {
                    // Sécurité : une pause ne dure jamais plus de 12 s (sinon l'assistant resterait sourd)
                    if (lastChunkAt - pausedSince > 12000) { paused = false; Status.log("Micro : reprise forcée") }
                    continue
                }
                highPass(buf, n)
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
                val rms = sqrt(sum / n).toFloat()
                // Silence numérique parfait pendant 6 s = Android a coupé le micro à l'appli
                if (rms == 0f) { dead++; if (dead > 60) { Status.log("Micro coupé par Android, redémarrage"); break } } else dead = 0
                applyGain(buf, n, rms)
                statMax = maxOf(statMax, rms); statSum += rms; statN++
                if (lastChunkAt - statAt > 30_000) {
                    if (statN > 0 && statAt != 0L && !Status.session)
                        Status.log("Micro : bruit moyen ${(statSum / statN).toInt()}, pic ${statMax.toInt()}, gain ×${"%.1f".format(gain)}")
                    statAt = lastChunkAt; statMax = 0f; statSum = 0f; statN = 0
                }
                try { onChunk(buf, n, rms) } catch (_: Throwable) {}
            }
        } finally {
            try { rec.stop() } catch (_: Throwable) {}
            try { ns?.release() } catch (_: Throwable) {}
            try { agc?.release() } catch (_: Throwable) {}
            try { aec?.release() } catch (_: Throwable) {}
            try { rec.release() } catch (_: Throwable) {}
        }
        return true
    }

    fun stopAndWait() {
        running = false
        try { thread?.join(1200) } catch (_: Throwable) {}
    }

    // Filtre passe-haut ~120 Hz : retire le grondement du moteur, de la route et du vent sans toucher à la voix
    private var hpPrevIn = 0f
    private var hpPrevOut = 0f
    private fun highPass(b: ShortArray, n: Int) {
        val a = 0.955f
        var pi = hpPrevIn
        var po = hpPrevOut
        for (i in 0 until n) {
            val x = b[i].toFloat()
            val y = a * (po + x - pi)
            pi = x
            po = y
            b[i] = y.coerceIn(-32768f, 32767f).toInt().toShort()
        }
        hpPrevIn = pi
        hpPrevOut = po
    }

    // Statistiques du micro, écrites de temps en temps dans le journal (utile en voiture)
    private var statAt = 0L
    private var statMax = 0f
    private var statSum = 0f
    private var statN = 0

    private fun applyGain(b: ShortArray, n: Int, rms: Float) {
        // Plafond bas : un gain fort amplifie le bruit autant que la voix et sature
        val maxG = if (testMode) 12f else minOf(prefs.maxGain, 3f)
        val speech = rms > prefs.noiseRms * 2.5f
        val desired = if (speech) (2500f / rms.coerceAtLeast(1f)).coerceIn(1f, maxG) else 1f
        gain += (desired - gain) * (if (speech) 0.35f else 0.05f)
        for (i in 0 until n) {
            val v = (b[i] * gain).toInt()
            b[i] = v.coerceIn(-32768, 32767).toShort()
        }
    }
}
