package com.assistant.vocal

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

enum class VZone { ANY, TOP, MIDDLE, BOTTOM }
enum class HZone { ANY, LEFT, CENTER, RIGHT }

/** Un élément décrit par sa place à l'écran : « le bouton en haut à droite », « les trois points », « le deuxième ». */
class Spec(
    val v: VZone = VZone.ANY,
    val h: HZone = HZone.ANY,
    val big: Boolean = false,
    val small: Boolean = false,
    val dots: Boolean = false,
    val nth: Int = 0,
    val last: Boolean = false
)

/** Les « yeux et les doigts » de l'assistant : lit l'écran, touche, défile, écrit, maintient un appui. */
class AssistantAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AssistantAccessibilityService? = null

        private val arabic = mapOf(
            'ا' to "a", 'أ' to "a", 'إ' to "a", 'آ' to "a", 'ٱ' to "a", 'ب' to "b", 'پ' to "p", 'ت' to "t", 'ث' to "t",
            'ج' to "j", 'چ' to "ch", 'ح' to "h", 'خ' to "kh", 'د' to "d", 'ذ' to "d", 'ر' to "r", 'ز' to "z",
            'س' to "s", 'ش' to "ch", 'ص' to "s", 'ض' to "d", 'ط' to "t", 'ظ' to "z", 'ع' to "a", 'غ' to "gh",
            'ف' to "f", 'ڤ' to "v", 'ق' to "q", 'ك' to "k", 'ک' to "k", 'گ' to "g", 'ل' to "l", 'م' to "m", 'ن' to "n",
            'ه' to "h", 'ة' to "a", 'و' to "w", 'ؤ' to "w", 'ي' to "y", 'ى' to "a", 'ی' to "y", 'ئ' to "y"
        )

        /** Lettres arabes -> lettres latines approchantes (les voyelles courtes ne s'écrivent pas : c'est approximatif). */
        fun translit(s: String): String {
            var has = false
            for (c in s) if (c in '\u0600'..'\u06FF') { has = true; break }
            if (!has) return s
            val sb = StringBuilder(s.length * 2)
            for (c in s) {
                val m = arabic[c]
                when {
                    m != null -> sb.append(m)
                    c in '\u064B'..'\u065F' || c == '\u0640' || c == '\u0670' || c == 'ء' -> {}
                    else -> sb.append(c)
                }
            }
            return sb.toString()
        }

        /** Comme Txt.norm, mais les titres écrits en arabe deviennent comparables à ce que Google transcrit en lettres latines. */
        fun normT(s: String): String = Txt.norm(translit(s))

        /** Squelette de consonnes : « Fairuz », « Fayrouz » et « فيروز » donnent presque la même chose. */
        private fun skel(s: String): String {
            val p = phon(s)
            val sb = StringBuilder()
            for (c in p) if (c !in "aeiou") sb.append(c)
            return sb.toString()
        }

        /** Comparaison par le son : « ya habibi » ~ « yaa habiby ». */
        fun phon(s: String): String {
            var t = normT(s).replace(" ", "")
            val rules = listOf(
                "ph" to "f", "ch" to "5", "sh" to "5", "ou" to "u", "qu" to "k", "gu" to "g", "ck" to "k",
                "eau" to "o", "au" to "o", "ai" to "e", "ei" to "e", "oi" to "wa", "y" to "i", "w" to "u",
                "h" to "", "c" to "k", "q" to "k", "z" to "s", "x" to "ks", "ee" to "e", "ii" to "i", "aa" to "a", "oo" to "o"
            )
            for ((a, b) in rules) t = t.replace(a, b)
            val sb = StringBuilder()
            for (c in t) if (sb.isEmpty() || sb.last() != c) sb.append(c)
            var r = sb.toString()
            while (r.length > 3 && (r.endsWith("s") || r.endsWith("t") || r.endsWith("d") || r.endsWith("e"))) r = r.dropLast(1)
            return r
        }

        fun lev(a: String, b: String): Int {
            if (a == b) return 0
            if (a.isEmpty()) return b.length
            if (b.isEmpty()) return a.length
            var prev = IntArray(b.length + 1) { it }
            for (i in 1..a.length) {
                val cur = IntArray(b.length + 1)
                cur[0] = i
                for (j in 1..b.length) {
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
                }
                prev = cur
            }
            return prev[b.length]
        }
    }

    class Item(val label: String, val node: AccessibilityNodeInfo)

    private val ui = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this; Status.log("Accessibilité connectée") }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; Status.log("Accessibilité déconnectée"); return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val r = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { r.add(it) }
        try {
            for (w in windows) {
                val x = w.root
                if (x != null && r.none { it == x }) r.add(x)
            }
        } catch (_: Throwable) {}
        return r
    }

    /** Tous les noms possibles d'un élément : texte, description, indice, info-bulle, identifiant technique. */
    private fun labelsOf(n: AccessibilityNodeInfo): List<Pair<String, Boolean>> {
        val out = ArrayList<Pair<String, Boolean>>(4) // (nom, vient de l'identifiant technique ?)
        n.text?.toString()?.let { if (it.isNotBlank()) out.add(it to false) }
        n.contentDescription?.toString()?.let { if (it.isNotBlank()) out.add(it to false) }
        try { if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString()?.let { if (it.isNotBlank()) out.add(it to false) } } catch (_: Throwable) {}
        try { if (Build.VERSION.SDK_INT >= 28) n.tooltipText?.toString()?.let { if (it.isNotBlank()) out.add(it to false) } } catch (_: Throwable) {}
        try {
            n.viewIdResourceName?.substringAfterLast('/')?.replace('_', ' ')?.replace('-', ' ')?.let {
                if (it.isNotBlank()) out.add(it to true)
            }
        } catch (_: Throwable) {}
        return out
    }

    private class Cand(val node: AccessibilityNodeInfo, val labels: List<Pair<String, Boolean>>)

    private fun candidates(): List<Cand> {
        val res = ArrayList<Cand>()
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (n.isVisibleToUser) {
                val l = labelsOf(n)
                if (l.isNotEmpty()) res.add(Cand(n, l))
            }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        for (r in roots()) visit(r, 0)
        return res
    }

    /** Éléments utiles à l'écran (pour le cerveau) : visibles, avec un nom, cliquables en priorité. */
    fun screenItems(max: Int = 40): List<Item> = try {
        val seen = HashSet<String>()
        val list = ArrayList<Item>()
        for (c in candidates()) {
            val real = c.labels.firstOrNull { !it.second }?.first
            // Identifiant technique seul et long (ex. « googleapp third party search widget ») : bruit pour le cerveau
            if (real == null && c.labels.first().first.trim().split(Regex("\\s+")).size > 3) continue
            val name = real ?: c.labels.first().first
            val clean = name.replace(Regex("\\s+"), " ").trim().take(40)
            var clickable = false
            var p: AccessibilityNodeInfo? = c.node
            var k = 0
            while (p != null && k < 6) { if (p.isClickable) { clickable = true; break }; p = p.parent; k++ }
            if (!clickable && !c.node.isEditable) continue
            if (seen.add(normT(clean))) list.add(Item(clean, c.node))
            if (list.size >= max) break
        }
        list
    } catch (_: Throwable) { emptyList() }

    /** Cherche le nœud visible dont le nom correspond le mieux ; à défaut, celui qui ressemble le plus par le son. */
    fun findNode(q: String): AccessibilityNodeInfo? = try { findNodeUnsafe(q) } catch (_: Throwable) { null }

    private fun findNodeUnsafe(q: String): AccessibilityNodeInfo? {
        val nq = normT(q)
        if (nq.isEmpty()) return null
        val sq = Txt.stem(nq)
        val sigQ = sq.split(" ").filter { it.length >= 4 }
        var best: AccessibilityNodeInfo? = null
        var bestRank = 99

        fun rankOf(t: String): Int {
            if (t == nq) return 0
            if (" $t ".contains(" $nq ")) return 1
            val st = Txt.stem(t)
            if (st == sq) return 1
            if (" $st ".contains(" $sq ")) return 2
            if (sigQ.size >= 2) {
                val sigT = st.split(" ")
                if (sigQ.all { it in sigT }) return 2
            }
            if (t.length >= 3 && " $nq ".contains(" $t ")) return 3
            return 99
        }

        val cands = candidates()
        for (c in cands) {
            for ((raw, fromId) in c.labels) {
                val t = normT(raw)
                if (t.isEmpty()) continue
                var rank = rankOf(t)
                if (rank == 99) continue
                if (fromId) rank += 1 // un identifiant technique vaut un peu moins qu'un vrai texte
                if (rank < bestRank) { bestRank = rank; best = c.node }
            }
        }
        if (best != null) return best

        // Plan B : ressemblance sonore (noms étrangers, mal transcrits)
        if (nq.length < 4) return null
        val pq = phon(nq)
        if (pq.length < 3) return null
        val kq = skel(nq)
        val qWords = nq.split(" ").size
        var bestScore = 0f
        for (c in cands) {
            for ((raw, fromId) in c.labels) {
                if (fromId) continue
                val words = normT(raw).split(" ").filter { it.isNotEmpty() }
                if (words.isEmpty()) continue
                val windows = ArrayList<String>()
                if (words.size <= qWords + 1) windows.add(words.joinToString(" "))
                else for (i in 0..(words.size - qWords)) windows.add(words.subList(i, i + qWords).joinToString(" "))
                for (w in windows) {
                    val pw = phon(w)
                    if (pw.length < 3) continue
                    val d = lev(pq, pw)
                    var score = 1f - d.toFloat() / maxOf(pq.length, pw.length)
                    if (kq.length >= 3) {
                        val kw = skel(w)
                        if (kw.length >= 3) {
                            val sk = 1f - lev(kq, kw).toFloat() / maxOf(kq.length, kw.length)
                            if (sk >= 0.8f) score = maxOf(score, sk - 0.05f)
                        }
                    }
                    if (score > bestScore) { bestScore = score; best = c.node }
                }
            }
        }
        return if (bestScore >= 0.72f) best else null
    }

    fun clickText(q: String): Boolean = try {
        val n = findNode(q)
        if (n == null) false else click(n)
    } catch (_: Throwable) { false }

    fun click(n: AccessibilityNodeInfo): Boolean {
        try {
            var p: AccessibilityNodeInfo? = n
            while (p != null) {
                if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                p = p.parent
            }
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) { tap(r.exactCenterX(), r.exactCenterY()); return true }
        } catch (_: Throwable) {}
        return false
    }

    private fun focusedInput(): AccessibilityNodeInfo? {
        for (r in roots()) {
            val f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null && f.isEditable) return f
        }
        var found: AccessibilityNodeInfo? = null
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || found != null || depth > 40) return
            if (n.isEditable && n.isVisibleToUser) { found = n; return }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        for (r in roots()) visit(r, 0)
        return found
    }

    fun setText(text: String): Boolean = try {
        val node = focusedInput()
        if (node == null) false else {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val b = Bundle()
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        }
    } catch (_: Throwable) { false }

    /** Plus grande zone défilable visible (liste de contacts, de chansons…). */
    private fun findScrollable(): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (n.isScrollable && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val a = r.width() * r.height()
                if (a > bestArea) { bestArea = a; best = n }
            }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        for (r in roots()) visit(r, 0)
        return best
    }

    /** Saute tout en haut (top = true) ou tout en bas de la liste affichée. */
    fun scrollEdge(top: Boolean): Boolean {
        val n = try { findScrollable() } catch (_: Throwable) { null }
        if (n == null) {
            repeat(8) { scroll(!top); Thread.sleep(450) }
            return true
        }
        val action = if (top) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        var i = 0
        try {
            while (i < 60) {
                n.refresh()
                if (!n.performAction(action)) break
                Thread.sleep(160)
                i++
            }
        } catch (_: Throwable) {}
        return true
    }

    fun scroll(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val a = dm.heightPixels * (if (down) 0.70f else 0.30f)
        val b = dm.heightPixels * (if (down) 0.30f else 0.70f)
        swipe(x, a, x, b, 350)
    }

    fun tap(x: Float, y: Float) = swipe(x, y, x, y, 60)

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        try {
            val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
            dispatchGesture(
                GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(),
                null, null
            )
        } catch (_: Throwable) {}
    }

    // ---- Éléments décrits par leur place (icônes sans nom comprises) ----

    private class Clk(val node: AccessibilityNodeInfo, val r: Rect, val label: String)

    /** Zone de référence : la fenêtre de l'appli au premier plan (à défaut, tout l'écran). */
    private fun refRect(): Rect {
        val r = Rect()
        try { rootInActiveWindow?.getBoundsInScreen(r) } catch (_: Throwable) {}
        if (r.width() <= 0 || r.height() <= 0) {
            val dm = resources.displayMetrics
            r.set(0, 0, dm.widthPixels, dm.heightPixels)
        }
        return r
    }

    /** Tout ce qui se touche, avec ou sans nom : c'est ce qui permet de viser une icône muette. */
    private fun clickables(root: AccessibilityNodeInfo? = null, wide: Boolean = false): List<Clk> {
        val ref = refRect()
        val maxW = if (wide) ref.width() * 2f else ref.width() * 0.8f
        val res = ArrayList<Clk>()
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (n.isVisibleToUser && n.isClickable && n.isEnabled) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() >= 24 && r.height() >= 24 && r.width() <= maxW) {
                    res.add(Clk(n, r, labelsOf(n).firstOrNull { !it.second }?.first ?: ""))
                }
            }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        if (root != null) {
            visit(root, 0)
        } else {
            for (x in roots()) visit(x, 0)
        }
        return res
    }

    private val dotsWords = Regex("plus d.?options|more options|options|menu|overflow|more|plus|autres?")

    /** Petit bouton collé au bord droit (trois points), ou bouton nommé « options », « plus »… */
    private fun isDots(c: Clk, ref: Rect): Boolean {
        if (c.r.width() > ref.width() * 0.18f || c.r.height() > ref.height() * 0.12f) return false
        val fx = (c.r.exactCenterX() - ref.left) / ref.width()
        val l = Txt.norm(c.label)
        return if (l.isNotEmpty()) fx > 0.6f && dotsWords.containsMatchIn(l) else fx > 0.86f
    }

    fun clickSpec(sp: Spec): Boolean {
        return try { clickSpecUnsafe(sp) } catch (_: Throwable) { false }
    }

    private fun clickSpecUnsafe(sp: Spec): Boolean {
        val ref = refRect()
        if (sp.nth > 0 || sp.last) {
            val n = findNth(sp, ref) ?: return false
            return click(n)
        }
        var list = clickables()
        if (sp.dots) list = list.filter { isDots(it, ref) }
        list = list.filter { c ->
            val fx = (c.r.exactCenterX() - ref.left) / ref.width()
            val fy = (c.r.exactCenterY() - ref.top) / ref.height()
            val okH = when (sp.h) {
                HZone.LEFT -> fx < 0.4f
                HZone.CENTER -> fx in 0.25f..0.75f
                HZone.RIGHT -> fx > 0.6f
                HZone.ANY -> true
            }
            val okV = when (sp.v) {
                VZone.TOP -> fy < 0.4f
                VZone.MIDDLE -> fy in 0.25f..0.75f
                VZone.BOTTOM -> fy > 0.6f
                VZone.ANY -> true
            }
            val ratio = c.r.width().toFloat() / c.r.height()
            val okShape = !sp.big || ratio in 0.6f..1.6f
            okH && okV && okShape
        }
        if (list.isEmpty()) return false
        val anchorX = when (sp.h) { HZone.LEFT -> 0.08f; HZone.CENTER -> 0.5f; HZone.RIGHT -> 0.92f; HZone.ANY -> -1f }
        val anchorY = when (sp.v) { VZone.TOP -> 0.06f; VZone.MIDDLE -> 0.5f; VZone.BOTTOM -> 0.94f; VZone.ANY -> -1f }
        val best: Clk = when {
            sp.big -> list.maxByOrNull { it.r.width() * it.r.height() }
            sp.small -> list.minByOrNull { it.r.width() * it.r.height() }
            sp.dots && sp.v == VZone.ANY -> list.minByOrNull { it.r.top }
            else -> list.minByOrNull { c ->
                val fx = (c.r.exactCenterX() - ref.left) / ref.width()
                val fy = (c.r.exactCenterY() - ref.top) / ref.height()
                val dx = if (anchorX < 0f) 0f else fx - anchorX
                val dy = if (anchorY < 0f) 0f else fy - anchorY
                dx * dx + dy * dy
            }
        } ?: return false
        return click(best.node)
    }

    /** « le deuxième », « le dernier » : les lignes touchables de la plus grande liste, de haut en bas. */
    private fun findNth(sp: Spec, ref: Rect): AccessibilityNodeInfo? {
        val sc = findScrollable()
        val base = clickables(sc, wide = true).filter {
            it.r.width() >= ref.width() * 0.45f && it.r.height() <= ref.height() * 0.35f
        }
        val sorted = base.sortedWith(compareBy<Clk>({ it.r.top }, { -(it.r.width() * it.r.height()) }))
        val kept = ArrayList<Clk>()
        for (c in sorted) if (kept.none { k -> k.r.contains(c.r) }) kept.add(c)
        return if (sp.last) kept.lastOrNull()?.node else kept.getOrNull(sp.nth - 1)?.node
    }

    /** « les trois points à côté de X » : on remonte de X jusqu'à sa ligne, puis on y cherche le petit bouton voulu. */
    fun clickNextTo(query: String, sp: Spec): Boolean {
        return try { clickNextToUnsafe(query, sp) } catch (_: Throwable) { false }
    }

    private fun clickNextToUnsafe(query: String, sp: Spec): Boolean {
        val anchor = findNodeUnsafe(query) ?: return false
        val ref = refRect()
        val ar = Rect()
        anchor.getBoundsInScreen(ar)
        var p: AccessibilityNodeInfo? = anchor
        var k = 0
        while (k < 7) {
            val par = p?.parent ?: return false
            val pr = Rect()
            par.getBoundsInScreen(pr)
            if (pr.height() > ref.height() * 0.4f) return false
            val inRow = clickables(par, wide = true).filter { c ->
                !c.r.contains(ar) && c.r.width() <= ref.width() * 0.25f && (!sp.dots || isDots(c, ref))
            }
            if (inRow.isNotEmpty()) {
                val pick = if (sp.h == HZone.LEFT) inRow.minByOrNull { it.r.left } else inRow.maxByOrNull { it.r.right }
                if (pick != null) return click(pick.node)
            }
            p = par
            k++
        }
        return false
    }

    // ---- Diagnostic : ce que l'assistant voit vraiment à l'écran ----

    fun dumpScreen(): String {
        val sb = StringBuilder()
        var lines = 0
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || lines > 500 || sb.length > 60000) return
            val r = Rect()
            n.getBoundsInScreen(r)
            val cls = n.className?.toString()?.substringAfterLast('.') ?: "?"
            val id = n.viewIdResourceName?.substringAfterLast('/') ?: ""
            val flags = (if (n.isClickable) "C" else "") + (if (n.isScrollable) "S" else "") +
                (if (n.isEditable) "E" else "") + (if (n.isVisibleToUser) "V" else "-")
            val t = n.text?.toString()?.replace("\n", " ")?.take(60) ?: ""
            val d = n.contentDescription?.toString()?.replace("\n", " ")?.take(60) ?: ""
            if (t.isNotEmpty() || d.isNotEmpty() || n.isClickable || id.isNotEmpty()) {
                sb.append("  ".repeat(minOf(depth, 12))).append(cls).append(" [").append(flags).append("] ")
                sb.append(r.left).append(',').append(r.top).append('-').append(r.right).append(',').append(r.bottom)
                if (t.isNotEmpty()) sb.append(" texte=\"").append(t).append('"')
                if (d.isNotEmpty()) sb.append(" desc=\"").append(d).append('"')
                if (id.isNotEmpty()) sb.append(" id=").append(id)
                sb.append('\n')
                lines++
            }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        for (r in roots()) {
            sb.append("== fenêtre ==\n")
            visit(r, 0)
        }
        return sb.toString()
    }

    /** Copie le diagnostic dans le presse-papiers (pour le coller dans une discussion) ; renvoie le nombre de lignes. */
    fun copyScreenDump(): Int {
        val txt = dumpScreen()
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ecran", txt))
        } catch (_: Throwable) {}
        val n = txt.count { it == '\n' }
        Status.log("Écran copié ($n lignes)")
        return n
    }

    // ---- Appui maintenu (message vocal : on garde le doigt sur le micro) ----
    @Volatile private var holdRelease = false
    @Volatile var holding = false
        private set

    /** Maintient le doigt sur l'élément pendant `seconds` secondes puis relâche (bloquant). */
    fun holdFor(n: AccessibilityNodeInfo, seconds: Int): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        holdRelease = false
        holding = true
        val x = r.exactCenterX()
        val y = r.exactCenterY()
        val segments = (seconds * 1000 / 600).coerceIn(2, 100)
        var count = 0

        fun segment(prev: GestureDescription.StrokeDescription?) {
            count++
            val last = holdRelease || count >= segments
            val path = Path().apply { moveTo(x, y) }
            val sd = try {
                if (prev == null) GestureDescription.StrokeDescription(path, 0, 600, !last)
                else prev.continueStroke(path, 0, 600, !last)
            } catch (_: Throwable) { holding = false; return }
            val cb = object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    if (last) holding = false else segment(sd)
                }
                override fun onCancelled(g: GestureDescription?) { holding = false }
            }
            try { dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), cb, ui) } catch (_: Throwable) { holding = false }
        }
        segment(null)
        val deadline = System.currentTimeMillis() + seconds * 1000L + 4000L
        while (holding && System.currentTimeMillis() < deadline) Thread.sleep(100)
        holdRelease = true
        return true
    }
}
