package com.assistant.vocal

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Service d'écoute permanent.
 * Veille : reconnaît ta phrase d'activation (par ta voix, ou par mots français selon le mode).
 * Session : tout ce que tu dis est exécuté ; redire la phrase (ou « c'est fini ») referme la session.
 */
class ListenService : Service() {

    companion object {
        private const val CH = "assistant"
        const val ACT_STOP = "stop"
        private val END = listOf(
            "c est fini", "c est termine", "fin de la discussion", "fin de discussion",
            "arrete d ecouter", "on a fini", "a plus tard", "termine la session"
        )

        fun start(c: Context) { c.startForegroundService(Intent(c, ListenService::class.java)) }

        fun stop(c: Context) {
            Prefs(c).wasListening = false
            c.stopService(Intent(c, ListenService::class.java))
        }

        /** Android refuse parfois de démarrer le micro en arrière-plan (ex. après redémarrage). */
        fun askRestart(c: Context) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Assistant vocal", NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(
                c, 0,
                Intent(c, MainActivity::class.java).putExtra("autostart", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            nm.notify(
                2,
                Notification.Builder(c, CH)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle("Assistant vocal arrêté")
                    .setContentText("Touche pour relancer l'écoute")
                    .setContentIntent(pi).setAutoCancel(true).build()
            )
        }
    }

    private lateinit var prefs: Prefs
    private lateinit var router: CommandRouter
    @Volatile private var loop: AudioLoop? = null
    private var wake: Speech? = null
    private var full: Speech? = null
    private var voiceWake: VoiceWake? = null
    private var templates: List<Array<FloatArray>> = emptyList()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wl: PowerManager.WakeLock? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val resumeRunnable = Runnable { resume() }
    private val tone: ToneGenerator? by lazy {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (_: Throwable) { null }
    }

    private var gotCommand = false
    private var sessionStart = 0L
    private var lastActivity = 0L
    private var lastRejectedAt = 0L
    private var lastSessionEnd = 0L

    // Reconnaissance Google (sans clé) : prend le micro à la place de l'assistant pendant une session
    private var gs: GoogleStt? = null
    @Volatile private var googleCool = 0L
    private var segStart = 0L
    @Volatile private var speakUntil = 0L
    private val GOOGLE_IDLE_MS = 120_000L

    override fun onBind(i: Intent?): IBinder? = null

    private var lastHeal = 0L

    /** Surveillance : Android (surtout Samsung) peut couper le service d'accessibilité ou le micro sans prévenir. */
    private val watchdog = object : Runnable {
        override fun run() {
            try {
                if (Status.listening) {
                    if (AssistantAccessibilityService.instance == null) {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastHeal > 30_000) {
                            lastHeal = now
                            Status.log("Accessibilité coupée : tentative de réactivation")
                            try { ShizukuSetup.enableAccessibility(this@ListenService) } catch (_: Throwable) {}
                        }
                    }
                    val l = loop
                    if (l != null && l.running && !l.paused && l.lastChunkAt > 0 &&
                        SystemClock.elapsedRealtime() - l.lastChunkAt > 8000
                    ) Status.log("Micro : aucune donnée depuis 8 s")
                    handler.postDelayed(this, 6000)
                }
            } catch (_: Throwable) { handler.postDelayed(this, 6000) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        Net.start(this)
        router = CommandRouter(this)
        router.onSpeak = { say(it) }
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = (tts?.setLanguage(Locale.FRENCH) ?: -1) >= 0
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { handler.post { resume() } }
                    override fun onError(id: String?) { handler.post { resume() } }
                })
            }
        }
        wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "assistant:listen").also { it.acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_STOP) {
            Prefs(this).wasListening = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (Status.listening) return START_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Assistant vocal", NotificationManager.IMPORTANCE_LOW))
        try {
            val n = notif("En veille — dis « ${prefs.phrase} »")
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (t: Throwable) {
            Status.error = "Android a refusé le démarrage : ouvre l'appli et appuie sur Démarrer"
            askRestart(this)
            stopSelf()
            return START_NOT_STICKY
        }
        Status.listening = true
        Status.error = ""
        prefs.wasListening = true
        Thread { init() }.start()
        return START_STICKY
    }

    private fun notif(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Assistant vocal").setContentText(text)
            .setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", stop).build())
            .build()
    }

    private fun init() {
        try {
            if (!ModelManager.isReady(this)) { Status.error = "Modèle vocal absent"; stopSelf(); return }
            val m = ModelManager.get(this)
            full = Speech(m, null)
            if (prefs.wakeMode == "voice" && VoiceStore.exists(this) && prefs.voiceThr > 0f) {
                templates = VoiceStore.load(this)
                voiceWake = VoiceWake()
            } else {
                wake = Speech(m, prefs.phrase)
                if (prefs.wakeMode == "voice") Status.error = "Pas de calibrage de ta voix : mode mots français utilisé"
            }
            ensureLoop()
            if (Brain.enabled(this)) Thread { Brain.get(this) }.start()
            handler.post { handler.postDelayed(watchdog, 6000) }
        } catch (t: Throwable) {
            Status.error = "Erreur : ${t.message}"
            stopSelf()
        }
    }

    // ---- Boucle audio (thread micro) ----
    private fun onChunk(b: ShortArray, n: Int, rms: Float) {
        try {
            val now = SystemClock.elapsedRealtime()
            val vw = voiceWake
            if (!Status.session) {
                if (vw != null) {
                    val u = vw.feed(b, n) ?: return
                    onVoiceWake(u, now)
                } else {
                    val out = wake?.feed(b, n) ?: return
                    onWake(out, now)
                }
            } else {
                if (!gotCommand && now - sessionStart > 10_000) { falseAlarm(); return }
                if (now - lastActivity > 600_000) { endSession(true); return }
                var out = full?.feed(b, n)
                // Beaucoup de bruit : Vosk ne détecte pas de pause. Après 10 s on force la fin de phrase.
                if (out == null && now - segStart > 10_000) {
                    val t = full?.flush() ?: ""
                    segStart = now
                    if (t.isNotBlank()) out = Speech.Out(t, 0f)
                }
                if (out == null) return
                onUtterance(out.text, now)
            }
        } catch (t: Throwable) {
            Status.error = "Écoute : ${t.message}"
        }
    }

    private fun onVoiceWake(u: VoiceWake.Utt, now: Long) {
        if (now - lastSessionEnd < 3000) return          // pas de réactivation juste après une fermeture
        if (u.ms < 450 || u.ms > 2600) return
        // La durée doit ressembler à celle de tes enregistrements (évite de réagir à n'importe quelle phrase)
        val lens = templates.map { it.size }.sorted()
        if (lens.isNotEmpty()) {
            val med = lens[lens.size / 2].toFloat()
            val r = u.feat.size / med
            if (r < 0.65f || r > 1.5f) return
        }
        val d = VoiceStore.score(u.feat, templates)
        val thr = prefs.voiceThr
        Status.heard = "Voix : distance ${"%.2f".format(d)} (seuil ${"%.2f".format(thr)})"
        Status.log("Voix d=${"%.2f".format(d)} seuil=${"%.2f".format(thr)} ${if (d <= thr) "→ activation" else "refusé"}")
        if (d <= thr) { startSession(); return }
        // Presque bon : si tu répètes dans les 6 s on accepte, avec un assouplissement très limité
        if (d <= thr * 1.15f) {
            if (now - lastRejectedAt < 6000) {
                prefs.voiceThr = min(thr * 1.04f, max(prefs.voiceBase, 0.1f) * 1.2f)
                startSession()
            } else lastRejectedAt = now
        }
    }

    private fun onWake(out: Speech.Out, now: Long) {
        if (!Txt.norm(out.text).contains(Txt.norm(prefs.phrase))) return
        Status.heard = "« ${out.text} » ${(out.conf * 100).toInt()} % (seuil ${(prefs.minConf * 100).toInt()} %)"
        Status.log("Mot d'activation entendu : ${(out.conf * 100).toInt()} % (seuil ${(prefs.minConf * 100).toInt()} %)")
        if (out.conf >= prefs.minConf) { startSession(); return }
        if (now - lastRejectedAt < 6000) {
            prefs.minConf = (prefs.minConf - 0.03f).coerceAtLeast(0.25f)
            startSession()
        } else lastRejectedAt = now
    }

    private fun startSession() {
        Status.session = true
        Status.log("Session ouverte")
        gotCommand = false
        sessionStart = SystemClock.elapsedRealtime()
        lastActivity = sessionStart
        full?.reset()
        voiceWake?.reset()
        segStart = sessionStart
        val locked = getSystemService(KeyguardManager::class.java).isKeyguardLocked
        if (locked) { wakeScreen(); say("Déverrouille ton téléphone") } else say("Oui, bonjour")
    }

    // ---- Micro de l'assistant (veille + repli Vosk) ----
    @Synchronized
    private fun ensureLoop() {
        val cur = loop
        if (cur != null && cur.running) return
        val l = AudioLoop(prefs) { b, n, rms -> onChunk(b, n, rms) }
        l.onError = { Status.error = "Micro indisponible (autorisation ?)"; stopSelf() }
        loop = l
        l.start()
    }

    @Synchronized
    private fun stopLoop() {
        val l = loop ?: return
        loop = null
        l.stopAndWait()
    }

    // ---- Fin de phrase côté Vosk (hors ligne, ou repli) ----
    private fun onUtterance(text: String, now: Long) {
        if (text.isBlank()) return
        gotCommand = true
        lastActivity = now
        segStart = now
        exec.execute { handleCommand(text, false) }
    }

    // ---- Reconnaissance Google (en ligne, sans clé) ----
    private fun googleUsable() =
        prefs.googleStt && Net.online && SystemClock.elapsedRealtime() >= googleCool && GoogleStt.available(this)

    /** Session ouverte + réseau : Google écoute à la place du micro de l'assistant (qui doit être fermé). */
    private fun beginGoogle() {
        stopLoop()
        val g = gs ?: GoogleStt(this, { t -> onGoogleText(t) }, { e -> onGoogleFail(e) }).also { gs = it }
        g.start()
    }

    private fun onGoogleText(raw: String) {
        if (!Status.session) return
        val text = Cloud.tidy(raw)
        if (text.isBlank()) { onGoogleFail(SpeechRecognizer.ERROR_NO_MATCH); return }
        gotCommand = true
        lastActivity = SystemClock.elapsedRealtime()
        exec.execute { handleCommand(text, true) }
    }

    private fun onGoogleFail(code: Int) {
        if (!Status.session) return
        val now = SystemClock.elapsedRealtime()
        when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                // Rien dit ou rien compris : mêmes garde-fous qu'avec le micro local
                if (!gotCommand && now - sessionStart > 10_000) { falseAlarm(); return }
                if (now - lastActivity > GOOGLE_IDLE_MS) { endSession(true); return }
                handler.postDelayed({ if (Status.session) resume() }, 250)
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                gs?.destroy(); gs = null
                handler.postDelayed({ if (Status.session) resume() }, 700)
            }
            else -> {
                googleCool = now + 20_000
                Status.log("Google : indisponible (erreur $code) → micro local 20 s")
                gs?.destroy(); gs = null
                resume() // googleUsable() est faux : on repasse sur Vosk
            }
        }
    }

    private fun handleCommand(text: String, google: Boolean) {
        lastActivity = SystemClock.elapsedRealtime()
        Status.heard = if (google) "$text  ☁" else text
        val t = Txt.norm(text)
        if (t.contains(Txt.norm(prefs.phrase)) || END.any { t.contains(it) }) {
            handler.post { endSession(true) }
            return
        }
        try {
            val err = router.execute(text)
            Status.action = if (err == null) "OK : $text" else "$err ($text)"
            Status.log("« $text » ${if (google) "☁ " else ""}→ ${err ?: "OK"}")
            // Jamais de voix sur erreur : le micro réentendrait l'appli et ça bouclerait
            loop?.paused = true // le bip ne doit pas être pris pour une commande
            tone?.startTone(if (err == null) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 120)
            Thread.sleep(350)
        } catch (t2: Throwable) {
            Status.action = "Erreur évitée : ${t2.javaClass.simpleName} ($text)"
        }
        lastActivity = SystemClock.elapsedRealtime()
        // Si l'assistant est en train de parler, c'est la fin de la voix qui rouvre le micro
        if (SystemClock.elapsedRealtime() >= speakUntil) handler.post { resume() }
    }

    private fun endSession(speak: Boolean) {
        lastSessionEnd = SystemClock.elapsedRealtime()
        Status.log("Session fermée")
        Status.session = false
        gs?.cancel()
        ensureLoop() // la veille a besoin du micro de l'assistant
        wake?.reset()
        voiceWake?.reset()
        if (speak) say("À bientôt")
    }

    /** Rien dit après l'activation : probablement une fausse alerte, on devient plus strict. */
    private fun falseAlarm() {
        if (voiceWake != null) {
            prefs.voiceThr = max(prefs.voiceThr * 0.98f, prefs.voiceBase * 0.92f)
            Status.action = "Fausse alerte : seuil resserré (${"%.2f".format(prefs.voiceThr)})"
        } else {
            prefs.minConf = (prefs.minConf + 0.03f).coerceAtMost(0.8f)
            Status.action = "Fausse alerte : seuil relevé à ${(prefs.minConf * 100).toInt()} %"
        }
        tone?.startTone(ToneGenerator.TONE_PROP_NACK, 100)
        endSession(false)
    }

    // ---- Voix / écran ----
    private fun say(t: String) {
        if (!ttsReady) { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150); return }
        loop?.paused = true // le micro ne doit pas s'entendre lui-même
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
        handler.removeCallbacks(resumeRunnable)
        speakUntil = SystemClock.elapsedRealtime() + 4000L + t.length * 90L
        handler.postDelayed(resumeRunnable, 4000L + t.length * 90L)
    }

    private fun resume() {
        handler.removeCallbacks(resumeRunnable)
        wake?.reset()
        full?.reset()
        voiceWake?.reset()
        segStart = SystemClock.elapsedRealtime()
        if (Status.session && googleUsable()) { beginGoogle(); return }
        ensureLoop()
        loop?.paused = false
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            getSystemService(PowerManager::class.java).newWakeLock(
                PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "assistant:screen"
            ).acquire(8000)
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        Status.listening = false
        Status.session = false
        handler.removeCallbacksAndMessages(null)
        gs?.destroy()
        loop?.stopAndWait()
        wake?.close()
        full?.close()
        exec.shutdownNow()
        tts?.shutdown()
        tone?.release()
        try { wl?.release() } catch (_: Throwable) {}
        super.onDestroy()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs(c).wasListening) {
            try { ListenService.start(c) } catch (_: Throwable) { ListenService.askRestart(c) }
        }
    }
}
