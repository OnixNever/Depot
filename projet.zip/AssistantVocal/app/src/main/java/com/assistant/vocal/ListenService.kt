package com.assistant.vocal

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Service d'écoute permanent.
 * Veille : reconnaît ta phrase d'activation (par ta voix, ou par mots français selon le mode).
 * Session : tout ce que tu dis est exécuté ; redire la phrase (ou « c'est fini ») referme la session.
 */
class ListenService : Service() {

    companion object {
        private const val CH = "assistant"
        const val ACT_STOP = "stop"
        private val END = listOf(
            "c est fini", "c est termine", "fin de la discussion", "fin de discussion",
            "arrete d ecouter", "on a fini", "a plus tard", "termine la session"
        )

        fun start(c: Context) { c.startForegroundService(Intent(c, ListenService::class.java)) }

        fun stop(c: Context) {
            Prefs(c).wasListening = false
            c.stopService(Intent(c, ListenService::class.java))
        }

        /** Android refuse parfois de démarrer le micro en arrière-plan (ex. après redémarrage). */
        fun askRestart(c: Context) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Assistant vocal", NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(
                c, 0,
                Intent(c, MainActivity::class.java).putExtra("autostart", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            nm.notify(
                2,
                Notification.Builder(c, CH)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle("Assistant vocal arrêté")
                    .setContentText("Touche pour relancer l'écoute")
                    .setContentIntent(pi).setAutoCancel(true).build()
            )
        }
    }

    private lateinit var prefs: Prefs
    private lateinit var router: CommandRouter
    @Volatile private var loop: AudioLoop? = null
    private var wake: Speech? = null
    private var full: Speech? = null
    private var voiceWake: VoiceWake? = null
    private var templates: List<Array<FloatArray>> = emptyList()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wl: PowerManager.WakeLock? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val resumeRunnable = Runnable { resume() }
    private val tone: ToneGenerator? by lazy {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 100) } catch (_: Throwable) { null }
    }

    private var gotCommand = false
    private var sessionStart = 0L
    private var lastActivity = 0L
    private var lastRejectedAt = 0L
    private var lastSessionEnd = 0L

    // Reconnaissance Google (sans clé) : prend le micro à la place de l'assistant pendant une session
    private var gs: GoogleStt? = null

    // Whisper (Groq) : l'assistant enregistre ta phrase lui-même et l'envoie à Groq ; Vosk écoute en parallèle (filet de sécurité)
    private lateinit var cutter: UtteranceCutter
    @Volatile private var voskText = ""
    @Volatile private var voskAt = 0L
    @Volatile private var googleCool = 0L
    private var segStart = 0L
    @Volatile private var speakUntil = 0L
    private val GOOGLE_IDLE_MS = 120_000L

    override fun onBind(i: Intent?): IBinder? = null

    private var lastHeal = 0L

    /** Surveillance : Android (surtout Samsung) peut couper le service d'accessibilité ou le micro sans prévenir. */
    private val watchdog = object : Runnable {
        override fun run() {
            try {
                if (Status.listening) {
                    if (AssistantAccessibilityService.instance == null) {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastHeal > 30_000) {
                            lastHeal = now
                            Status.log("Accessibilité coupée : tentative de réactivation")
                            try { ShizukuSetup.enableAccessibility(this@ListenService) } catch (_: Throwable) {}
                        }
                    }
                    val l = loop
                    if (l != null && l.running && !l.paused && l.lastChunkAt > 0 &&
                        SystemClock.elapsedRealtime() - l.lastChunkAt > 8000
                    ) Status.log("Micro : aucune donnée depuis 8 s")
                    handler.postDelayed(this, 6000)
                }
            } catch (_: Throwable) { handler.postDelayed(this, 6000) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        cutter = UtteranceCutter(prefs)
        Net.start(this)
        router = CommandRouter(this)
        router.onSpeak = { say(it) }
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = (tts?.setLanguage(Locale.FRENCH) ?: -1) >= 0
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { handler.post { resume() } }
                    override fun onError(id: String?) { handler.post { resume() } }
                })
            }
        }
        wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "assistant:listen").also { it.acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_STOP) {
            Prefs(this).wasListening = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (Status.listening) return START_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Assistant vocal", NotificationManager.IMPORTANCE_LOW))
        try {
            val n = notif("En veille — dis « ${prefs.phrase} »")
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (t: Throwable) {
            Status.error = "Android a refusé le démarrage : ouvre l'appli et appuie sur Démarrer"
            askRestart(this)
            stopSelf()
            return START_NOT_STICKY
        }
        Status.listening = true
        Status.error = ""
        prefs.wasListening = true
        Thread { init() }.start()
        return START_STICKY
    }

    private fun notif(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Assistant vocal").setContentText(text)
            .setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", stop).build())
            .build()
    }

    private fun init() {
        try {
            if (!ModelManager.isReady(this)) { Status.error = "Modèle vocal absent"; stopSelf(); return }
            val m = ModelManager.get(this)
            full = Speech(m, null)
            if (prefs.wakeMode == "voice" && VoiceStore.exists(this) && prefs.voiceThr > 0f) {
                templates = VoiceStore.load(this)
                voiceWake = VoiceWake()
            } else {
                wake = Speech(m, prefs.phrase)
                if (prefs.wakeMode == "voice") Status.error = "Pas de calibrage de ta voix : mode mots français utilisé"
            }
            ensureLoop()
            if (Brain.enabled(this)) Thread { Brain.get(this) }.start()
            handler.post { handler.postDelayed(watchdog, 6000) }
        } catch (t: Throwable) {
            Status.error = "Erreur : ${t.message}"
            stopSelf()
        }
    }

    // ---- Boucle audio (thread micro) ----
    private fun onChunk(b: ShortArray, n: Int, rms: Float) {
        try {
            val now = SystemClock.elapsedRealtime()
            val vw = voiceWake
            if (!Status.session) {
                if (whisperWakeUsable(now)) { wakeWhisper(b, n, rms, now); return }
                if (vw != null) {
                    val u = vw.feed(b, n) ?: return
                    onVoiceWake(u, now)
                } else {
                    val out = wake?.feed(b, n) ?: return
                    onWake(out, now)
                }
            } else {
                if (!gotCommand && now - sessionStart > 10_000) { falseAlarm(); return }
                val whisper = whisperUsable()
                if (now - lastActivity > (if (whisper) 120_000L else 600_000L)) { endSession(true); return }
                if (whisper) {
                    if (cutter.busy) {
                        if (now - cutter.busySince > 20_000) cutter.reset()
                        return
                    }
                    val vo = full?.feed(b, n)
                    if (vo != null && vo.text.isNotBlank()) { voskText = vo.text; voskAt = now }
                    val seg = cutter.feed(b, n, rms) ?: return
                    onWhisperSegment(seg, now)
                    return
                }
                var out = full?.feed(b, n)
                // Beaucoup de bruit : Vosk ne détecte pas de pause. Après 10 s on force la fin de phrase.
                if (out == null && now - segStart > 10_000) {
                    val t = full?.flush() ?: ""
                    segStart = now
                    if (t.isNotBlank()) out = Speech.Out(t, 0f)
                }
                if (out == null) return
                onUtterance(out.text, now)
            }
        } catch (t: Throwable) {
            Status.error = "Écoute : ${t.message}"
        }
    }

    // ---- Veille par Whisper : aucun calibrage, ça tient dans le bruit ----
    @Volatile private var wakeFailUntil = 0L
    private val wakeCalls = ArrayList<Long>()
    private var wakeLimitLogged = 0L
    private val onyxRx = Regex("^h?on+[iy]+(x|ks|cs|k|ques?|s)$")

    private fun whisperWakeUsable(now: Long) =
        prefs.whisperWake && now >= wakeFailUntil && whisperUsable()

    private fun isOnyx(tok: String): Boolean {
        if (onyxRx.matches(tok)) return true
        val last = Txt.norm(prefs.phrase).split(' ').lastOrNull { it.length >= 4 } ?: return false
        return tok == last
    }

    private fun wakeWhisper(b: ShortArray, n: Int, rms: Float, now: Long) {
        if (cutter.busy) {
            if (now - cutter.busySince > 20_000) cutter.reset()
            return
        }
        if (now - lastSessionEnd < 1500) return
        val seg = cutter.feed(b, n, rms) ?: return
        val ms = seg.size * 1000 / 16000
        if (ms < 350 || ms > 6000) return
        // Économie du quota gratuit : 15 envois par minute au maximum
        synchronized(wakeCalls) {
            wakeCalls.removeAll { now - it > 60_000 }
            if (wakeCalls.size >= 15) {
                if (now - wakeLimitLogged > 30_000) { Status.log("Veille : trop de sons, pause pour économiser Groq"); wakeLimitLogged = now }
                return
            }
            wakeCalls.add(now)
        }
        cutter.markBusy(now)
        exec.execute {
            val heard = try { Whisper.transcribe(this, seg, "") } catch (_: Throwable) { null }
            cutter.reset()
            if (heard == null) {
                wakeFailUntil = SystemClock.elapsedRealtime() + 8_000
                Status.log("Veille Whisper indisponible (${Whisper.lastError.take(60)}) : ancienne veille 8 s")
                return@execute
            }
            if (heard.isBlank()) { Status.log("Veille : voix ${ms} ms, rien de compris (bruit ?)"); return@execute }
            val toks = Txt.norm(heard).split(' ').filter { it.isNotBlank() }
            val k = toks.indexOfFirst { isOnyx(it) }
            if (k < 0) { Status.log("Veille : entendu « ${heard.take(40)} » (pas Onyx)"); return@execute }
            val rest = toks.drop(k + 1).joinToString(" ")
            Status.heard = "« $heard »  ☁"
            Status.log("Veille Whisper : « $heard » → activation")
            if (rest.length >= 3) {
                startSession(quiet = true)
                gotCommand = true
                handleCommand(rest, true)
            } else startSession()
        }
    }

    /** Baisse la musique des autres applis pendant que tu parles à l'assistant. */
    private var focusReq: AudioFocusRequest? = null
    private fun duck(on: Boolean) {
        try {
            val am = getSystemService(AudioManager::class.java)
            if (on) {
                if (focusReq == null) {
                    val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setOnAudioFocusChangeListener { }
                        .build()
                    if (am.requestAudioFocus(r) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) focusReq = r
                }
            } else {
                focusReq?.let { am.abandonAudioFocusRequest(it) }
                focusReq = null
            }
        } catch (_: Throwable) {}
    }

    private fun onVoiceWake(u: VoiceWake.Utt, now: Long) {
        if (now - lastSessionEnd < 3000) return          // pas de réactivation juste après une fermeture
        if (u.ms < 450 || u.ms > 2600) return
        // La durée doit ressembler à celle de tes enregistrements (évite de réagir à n'importe quelle phrase)
        val lens = templates.map { it.size }.sorted()
        if (lens.isNotEmpty()) {
            val med = lens[lens.size / 2].toFloat()
            val r = u.feat.size / med
            if (r < 0.65f || r > 1.5f) return
        }
        val d = VoiceStore.score(u.feat, templates)
        val thr = prefs.voiceThr
        Status.heard = "Voix : distance ${"%.2f".format(d)} (seuil ${"%.2f".format(thr)})"
        Status.log("Voix d=${"%.2f".format(d)} seuil=${"%.2f".format(thr)} ${if (d <= thr) "→ activation" else "refusé"}")
        if (d <= thr) { startSession(); return }
        // Presque bon : si tu répètes dans les 6 s on accepte, avec un assouplissement très limité
        if (d <= thr * 1.15f) {
            if (now - lastRejectedAt < 6000) {
                prefs.voiceThr = min(thr * 1.04f, max(prefs.voiceBase, 0.1f) * 1.2f)
                startSession()
            } else lastRejectedAt = now
        }
    }

    private fun onWake(out: Speech.Out, now: Long) {
        if (!Txt.norm(out.text).contains(Txt.norm(prefs.phrase))) return
        Status.heard = "« ${out.text} » ${(out.conf * 100).toInt()} % (seuil ${(prefs.minConf * 100).toInt()} %)"
        Status.log("Mot d'activation entendu : ${(out.conf * 100).toInt()} % (seuil ${(prefs.minConf * 100).toInt()} %)")
        if (out.conf >= prefs.minConf) { startSession(); return }
        if (now - lastRejectedAt < 6000) {
            prefs.minConf = (prefs.minConf - 0.03f).coerceAtLeast(0.25f)
            startSession()
        } else lastRejectedAt = now
    }

    private fun startSession(quiet: Boolean = false) {
        Status.session = true
        duck(true)
        Status.log("Session ouverte")
        gotCommand = false
        sessionStart = SystemClock.elapsedRealtime()
        lastActivity = sessionStart
        full?.reset()
        voiceWake?.reset()
        cutter.reset()
        segStart = sessionStart
        val locked = getSystemService(KeyguardManager::class.java).isKeyguardLocked
        if (locked) { wakeScreen(); say("Déverrouille ton téléphone") }
        else if (!quiet) {
            tone?.startTone(ToneGenerator.TONE_PROP_PROMPT, 150) // bip : « je t'écoute »
            say("Oui ?")
        }
    }

    // ---- Micro de l'assistant (veille + repli Vosk) ----
    @Synchronized
    private fun ensureLoop() {
        val cur = loop
        if (cur != null && cur.running) return
        val l = AudioLoop(prefs) { b, n, rms -> onChunk(b, n, rms) }
        l.onError = { Status.error = "Micro indisponible (autorisation ?)"; stopSelf() }
        loop = l
        l.start()
    }

    @Synchronized
    private fun stopLoop() {
        val l = loop ?: return
        loop = null
        l.stopAndWait()
    }

    // ---- Fin de phrase côté Vosk (hors ligne, ou repli) ----
    private fun onUtterance(text: String, now: Long) {
        if (text.isBlank()) return
        gotCommand = true
        lastActivity = now
        segStart = now
        exec.execute { handleCommand(text, false) }
    }

    // ---- Whisper via Groq (en ligne, clé Groq) ----
    private fun whisperUsable() = prefs.whisperStt && Net.online && Whisper.ready(prefs)

    /** Les mots de l'écran aident Whisper à bien entendre les noms (« recherche », « playlist », titres…). */
    private fun screenHint(): String {
        val a = AssistantAccessibilityService.instance ?: return ""
        val names = try { a.screenItems(30).filter { !it.unnamed }.map { it.label } } catch (_: Throwable) { emptyList() }
        if (names.isEmpty()) return ""
        val sb = StringBuilder("Commande vocale pour un téléphone : ouvre, appuie sur, clique sur, retour. À l'écran : ")
        for (n in names) { if (sb.length > 330) break; sb.append(n).append(", ") }
        return sb.toString().trimEnd(',', ' ') + "."
    }

    private fun onWhisperSegment(seg: ShortArray, now: Long) {
        cutter.markBusy(now)
        gotCommand = true
        lastActivity = now
        val fallback = if (now - voskAt < 5000) voskText else ""
        voskText = ""
        exec.execute {
            val heard = try { Whisper.transcribe(this, seg, screenHint()) } catch (_: Throwable) { null }
            // null = Whisper en panne : on se rabat sur ce que Vosk a entendu pendant ce temps
            val text = Cloud.tidy(heard ?: fallback)
            if (text.isBlank()) {
                if (heard != null) Status.log("Whisper : rien de compris (bruit ?)")
                handler.post { resume() }
            } else handleCommand(text, heard != null)
        }
    }

    // ---- Reconnaissance Google (en ligne, sans clé) ----
    private fun googleUsable() =
        prefs.googleStt && Net.online && SystemClock.elapsedRealtime() >= googleCool && GoogleStt.available(this)

    /** Session ouverte + réseau : Google écoute à la place du micro de l'assistant (qui doit être fermé). */
    private fun beginGoogle() {
        stopLoop()
        val g = gs ?: GoogleStt(this, { t -> onGoogleText(t) }, { e -> onGoogleFail(e) }).also { gs = it }
        g.start()
    }

    private fun onGoogleText(raw: String) {
        if (!Status.session) return
        val text = Cloud.tidy(raw)
        if (text.isBlank()) { onGoogleFail(SpeechRecognizer.ERROR_NO_MATCH); return }
        gotCommand = true
        lastActivity = SystemClock.elapsedRealtime()
        exec.execute { handleCommand(text, true) }
    }

    private fun onGoogleFail(code: Int) {
        if (!Status.session) return
        val now = SystemClock.elapsedRealtime()
        when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                // Rien dit ou rien compris : mêmes garde-fous qu'avec le micro local
                if (!gotCommand && now - sessionStart > 10_000) { falseAlarm(); return }
                if (now - lastActivity > GOOGLE_IDLE_MS) { endSession(true); return }
                handler.postDelayed({ if (Status.session) resume() }, 250)
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                gs?.destroy(); gs = null
                handler.postDelayed({ if (Status.session) resume() }, 700)
            }
            else -> {
                googleCool = now + 20_000
                Status.log("Google : indisponible (erreur $code) → micro local 20 s")
                gs?.destroy(); gs = null
                resume() // googleUsable() est faux : on repasse sur Vosk
            }
        }
    }

    private fun handleCommand(text: String, google: Boolean) {
        lastActivity = SystemClock.elapsedRealtime()
        Status.heard = if (google) "$text  ☁" else text
        val t = Txt.norm(text)
        if (t.contains(Txt.norm(prefs.phrase)) || END.any { t.contains(it) }) {
            handler.post { endSession(true) }
            return
        }
        try {
            val err = router.execute(text)
            Status.action = if (err == null) "OK : $text" else "$err ($text)"
            Status.log("« $text » ${if (google) "☁ " else ""}→ ${err ?: "OK"}")
            // Jamais de voix sur erreur : le micro réentendrait l'appli et ça bouclerait
            loop?.paused = true // le bip ne doit pas être pris pour une commande
            tone?.startTone(if (err == null) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 120)
            Thread.sleep(350)
        } catch (t2: Throwable) {
            Status.action = "Erreur évitée : ${t2.javaClass.simpleName} ($text)"
        }
        lastActivity = SystemClock.elapsedRealtime()
        // Si l'assistant est en train de parler, c'est la fin de la voix qui rouvre le micro
        if (SystemClock.elapsedRealtime() >= speakUntil) handler.post { resume() }
    }

    private fun endSession(speak: Boolean) {
        lastSessionEnd = SystemClock.elapsedRealtime()
        Status.log("Session fermée")
        Status.session = false
        duck(false)
        gs?.cancel()
        ensureLoop() // la veille a besoin du micro de l'assistant
        wake?.reset()
        voiceWake?.reset()
        cutter.reset()
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, 200) // double bip : « session fermée »
        if (speak) say("En veille")
    }

    /** Rien dit après l'activation : probablement une fausse alerte, on devient plus strict. */
    private fun falseAlarm() {
        if (voiceWake != null) {
            prefs.voiceThr = max(prefs.voiceThr * 0.98f, prefs.voiceBase * 0.92f)
            Status.action = "Fausse alerte : seuil resserré (${"%.2f".format(prefs.voiceThr)})"
        } else {
            prefs.minConf = (prefs.minConf + 0.03f).coerceAtMost(0.8f)
            Status.action = "Fausse alerte : seuil relevé à ${(prefs.minConf * 100).toInt()} %"
        }
        tone?.startTone(ToneGenerator.TONE_PROP_NACK, 100)
        endSession(false)
    }

    // ---- Voix / écran ----
    private fun say(t: String) {
        if (!ttsReady) { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150); return }
        loop?.paused = true // le micro ne doit pas s'entendre lui-même
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
        handler.removeCallbacks(resumeRunnable)
        speakUntil = SystemClock.elapsedRealtime() + 4000L + t.length * 90L
        handler.postDelayed(resumeRunnable, 4000L + t.length * 90L)
    }

    private fun resume() {
        handler.removeCallbacks(resumeRunnable)
        wake?.reset()
        full?.reset()
        voiceWake?.reset()
        cutter.reset()
        segStart = SystemClock.elapsedRealtime()
        if (Status.session && !whisperUsable() && googleUsable()) { beginGoogle(); return }
        ensureLoop()
        loop?.paused = false
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            getSystemService(PowerManager::class.java).newWakeLock(
                PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "assistant:screen"
            ).acquire(8000)
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        Status.listening = false
        Status.session = false
        handler.removeCallbacksAndMessages(null)
        gs?.destroy()
        loop?.stopAndWait()
        wake?.close()
        full?.close()
        exec.shutdownNow()
        tts?.shutdown()
        tone?.release()
        try { wl?.release() } catch (_: Throwable) {}
        super.onDestroy()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs(c).wasListening) {
            try { ListenService.start(c) } catch (_: Throwable) { ListenService.askRestart(c) }
        }
    }
}
