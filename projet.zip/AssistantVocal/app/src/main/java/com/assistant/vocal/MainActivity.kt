package com.assistant.vocal

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.Locale

class MainActivity : Activity() {

    private class Item(val label: String, val ok: Boolean, val fix: (() -> Unit)? = null)

    private lateinit var prefs: Prefs
    private lateinit var statusBox: LinearLayout
    private lateinit var toggle: Button
    private lateinit var modeBtn: Button
    private lateinit var brainBtn: Button
    private lateinit var googleBtn: Button
    private lateinit var cloudBrainBtn: Button
    private lateinit var brainModelEdit: EditText
    private lateinit var brainKeyEdit: EditText
    private lateinit var progress: TextView
    private lateinit var phraseEdit: EditText
    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsFr = false
    private var lastSig = ""

    private val ticker = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1500) }
    }

    private val shizukuL = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            if (result == PackageManager.PERMISSION_GRANTED) autoSetup() else toast("Shizuku : autorisation refusée")
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        Net.start(this)
        tts = TextToSpeech(this) { st ->
            ttsFr = st == TextToSpeech.SUCCESS && (tts?.setLanguage(Locale.FRENCH) ?: -1) >= 0
        }
        try { Shizuku.addRequestPermissionResultListener(shizukuL) } catch (_: Throwable) {}

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(label("Assistant vocal", 24f, true))
        statusBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(statusBox)

        toggle = btn("") { toggleListening() }
        root.addView(toggle)
        root.addView(btn("⚙ Configuration automatique (Shizuku)") { autoSetup() })
        root.addView(btn("⬇ Modèle vocal léger (~40 Mo, rapide)") { downloadModel(false) })
        root.addView(btn("⬇ Modèle vocal PRÉCIS (~1,4 Go, wifi conseillé)") { downloadModel(true) })
        root.addView(btn("📂 Importer un modèle (.zip)") { importModel() })
        root.addView(label("Cerveau local : comprend les phrases libres et trouve les boutons sans texte", 14f, true))
        root.addView(btn("🧠 Installer le cerveau (~1,6 Go, wifi conseillé)") { downloadBrain() })
        root.addView(btn("📂 Importer un cerveau (.task)") { importBrain() })
        brainBtn = btn("") { toggleBrain() }
        root.addView(brainBtn)

        root.addView(label("Reconnaissance vocale Google : avec du réseau, c'est Google qui te comprend (aucune clé à saisir, bien meilleur dans le bruit). Sans réseau, tout reste local.", 14f, true))
        googleBtn = btn("") { toggleGoogle() }
        root.addView(googleBtn)
        root.addView(label("Option avancée, à ignorer si tu veux : cerveau cloud (Claude), demande une clé Anthropic.", 12f, false))
        cloudBrainBtn = btn("") { toggleCloudBrain() }
        root.addView(cloudBrainBtn)
        root.addView(label("Cerveau cloud : modèle Claude", 12f, false))
        brainModelEdit = EditText(this).apply { setText(prefs.brainModel); setSingleLine() }
        root.addView(brainModelEdit)
        root.addView(label("Cerveau cloud : clé API Anthropic (vide = garder l'actuelle)", 12f, false))
        brainKeyEdit = secret(prefs.brainKey.isNotBlank())
        root.addView(brainKeyEdit)
        root.addView(btn("Enregistrer le cerveau cloud") { saveCloud() })
        root.addView(btn("🧪 Tester Google et le cloud") { testCloud() })
        root.addView(label("Test : copier un rapport à me coller dans le chat", 14f, true))
        root.addView(btn("📋 Copier le rapport de test") { copyReport() })
        root.addView(btn("⚑ Marquer : la dernière activation était FAUSSE") {
            Status.log("▶ MARQUÉ : la dernière activation était FAUSSE"); toast("Noté : fausse activation")
        })
        root.addView(btn("✔ Marquer : la dernière activation était VRAIE") {
            Status.log("▶ MARQUÉ : la dernière activation était VRAIE"); toast("Noté : vraie activation")
        })
        root.addView(btn("🎙 Calibrage vocal (apprend ta voix)") { startActivity(Intent(this, CalibrationActivity::class.java)) })
        modeBtn = btn("") { toggleMode() }
        root.addView(modeBtn)
        root.addView(btn("🔊 Tester la voix") { tts?.speak("Bonjour, la synthèse vocale fonctionne.", TextToSpeech.QUEUE_FLUSH, null, "t") })

        root.addView(label("Nom de l'assistant / phrase d'activation (ex. salut onix)", 14f, true))
        phraseEdit = EditText(this).apply { setText(prefs.phrase); setSingleLine() }
        root.addView(phraseEdit)
        root.addView(btn("Enregistrer la phrase") { savePhrase() })

        progress = label("", 13f, false)
        root.addView(progress)

        root.addView(label(
            "Commandes : ouvre <appli> · retour · accueil · descends / monte · clique sur <texte> · " +
                "va dans <texte> · écris <message> · envoie · cherche <texte> · pause / suivant / précédent · " +
                "volume plus / moins · mets en boucle · « puis » pour enchaîner. " +
                "Avec le cerveau installé, tu peux parler librement. " +
                "Pour terminer : dis « c'est fini ».", 13f, false
        ))

        if (intent.getBooleanExtra("autostart", false)) toggleListening()
    }

    override fun onResume() { super.onResume(); h.post(ticker) }
    override fun onPause() { super.onPause(); h.removeCallbacks(ticker) }
    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuL) } catch (_: Throwable) {}
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun label(t: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { f() }
    }

    private fun diag(): List<Item> {
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val secureOk = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
        val batOk = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        return listOf(
            Item("Modèle vocal français installé", ModelManager.isReady(this)) { downloadModel(false) },
            Item("Autorisation micro", micOk) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
            },
            Item("Notifications (pour l'écoute en arrière-plan)", notifOk) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            },
            Item("Autorisation spéciale (réglages sécurisés)", secureOk) { autoSetup() },
            Item("Service d'accessibilité actif", AssistantAccessibilityService.instance != null) { fixAccessibility() },
            Item("Affichage par-dessus les autres applis (lancer des applis)", Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            },
            Item("Batterie : sans restriction", batOk) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            },
            Item("Synthèse vocale en français", ttsFr) {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Throwable) {}
            },
            Item("Cerveau local installé (comprend les phrases libres)", BrainManager.isReady(this)) { downloadBrain() },
            Item("Reconnaissance vocale Google disponible (en ligne, sans clé)", GoogleStt.available(this)) {
                toast("Installe ou active l'appli Google (service de reconnaissance vocale)")
                try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Throwable) {}
            },
            Item("Calibrage vocal effectué", prefs.calibrated) {
                startActivity(Intent(this, CalibrationActivity::class.java))
            },
            Item("Écoute en cours", Status.listening) { toggleListening() }
        )
    }

    private fun refresh() {
        toggle.text = if (Status.listening) "■ Arrêter l'écoute" else "▶ Démarrer l'écoute"
        modeBtn.text = if (prefs.wakeMode == "voice") "Activation : par ma voix (toucher pour passer aux mots français)" else "Activation : mots français (toucher pour passer à ma voix)"
        brainBtn.text = if (prefs.brainOn) "Cerveau : activé (toucher pour désactiver)" else "Cerveau : désactivé (toucher pour activer)"
        googleBtn.text = if (prefs.googleStt) "Reconnaissance Google : activée (toucher pour désactiver)" else "Reconnaissance Google : désactivée (toucher pour activer)"
        cloudBrainBtn.text = if (prefs.cloudBrain) "Cerveau cloud : activé (toucher pour désactiver)" else "Cerveau cloud : désactivé (toucher pour activer)"
        val items = diag()
        val info = buildString {
            append(
                when {
                    Status.session -> "Session ouverte : je t'écoute\n"
                    Status.listening -> "En veille : dis « ${prefs.phrase} »\n"
                    else -> "Écoute arrêtée\n"
                }
            )
            if (Status.heard.isNotEmpty()) append("Dernière phrase : ${Status.heard}\n")
            if (Status.action.isNotEmpty()) append("Dernière action : ${Status.action}\n")
            if (Status.error.isNotEmpty()) append("⚠ ${Status.error}\n")
            append(if (prefs.wakeMode == "voice") "Activation par ta voix · seuil ${"%.2f".format(prefs.voiceThr)} · gain max ×${"%.1f".format(prefs.maxGain)}" else "Activation par mots français · seuil ${(prefs.minConf * 100).toInt()} % · gain max ×${"%.1f".format(prefs.maxGain)}")
            append("\nRéseau : ${if (Net.online) "en ligne" else "hors ligne"} · reconnaissance ${if (prefs.googleStt && Net.online && GoogleStt.available(this@MainActivity)) "Google" else "locale"} · cerveau ${if (Cloud.brainReady(this@MainActivity)) "cloud" else "local"}")
            val lg = Status.logText(12)
            if (lg.isNotEmpty()) append("\n\n— Journal —\n").append(lg)
        }
        val sig = info + items.joinToString("|") { "${it.label}${it.ok}" }
        if (sig == lastSig) return
        lastSig = sig

        statusBox.removeAllViews()
        for (d in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                TextView(this).apply { text = (if (d.ok) "🟢 " else "🔴 ") + d.label; textSize = 14f },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            if (!d.ok && d.fix != null) {
                row.addView(Button(this).apply {
                    text = "Corriger"
                    isAllCaps = false
                    setOnClickListener { d.fix.invoke() }
                })
            }
            statusBox.addView(row)
        }
        statusBox.addView(label(info, 13f, false))
    }

    // ---------- Actions ----------
    private fun toggleListening() {
        if (Status.listening) { ListenService.stop(this); return }
        if (!ModelManager.isReady(this)) { toast("Installe d'abord le modèle vocal"); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        ListenService.start(this)
    }

    private fun autoSetup() {
        if (!ShizukuSetup.available()) { toast("Shizuku n'est pas lancé : démarre-le d'abord, puis reviens ici"); return }
        if (!ShizukuSetup.granted()) { ShizukuSetup.request(100); return }
        progress.text = "Configuration en cours…"
        Thread {
            val log = ShizukuSetup.run(this).joinToString("\n")
            h.post {
                progress.text = log + "\n\nTerminé : tu peux fermer Shizuku, il n'est plus nécessaire."
                lastSig = ""
                refresh()
            }
        }.start()
    }

    private fun fixAccessibility() {
        if (checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            ShizukuSetup.enableAccessibility(this)
            lastSig = ""
        } else {
            toast("Active « Assistant vocal » dans les services d'accessibilité")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun downloadModel(big: Boolean) {
        if (Status.listening) ListenService.stop(this)
        progress.text = if (big) "Téléchargement du modèle précis (1,4 Go, patience)…" else "Téléchargement du modèle…"
        Thread {
            try {
                ModelManager.download(this, big) { p -> h.post { progress.text = "Téléchargement : $p" } }
                h.post { progress.text = "Modèle installé ✔"; lastSig = ""; refresh() }
            } catch (t: Throwable) {
                h.post { progress.text = "Échec du téléchargement : ${t.message}" }
            }
        }.start()
    }

    /** Rapport complet copié dans le presse-papiers : il suffit de le coller dans le chat. */
    private fun copyReport() {
        val sb = StringBuilder()
        sb.append("RAPPORT ONIX v0.5.0\n")
        sb.append("Mode : ${prefs.wakeMode} | phrase : ${prefs.phrase}\n")
        sb.append("Seuil voix : ${"%.2f".format(prefs.voiceThr)} | base calibrage : ${"%.2f".format(prefs.voiceBase)} | ")
        sb.append("gain max : ${"%.1f".format(prefs.maxGain)} | bruit : ${prefs.noiseRms.toInt()} | seuil mots : ${(prefs.minConf * 100).toInt()} %\n")
        sb.append("Cerveau : ${if (BrainManager.isReady(this)) "installé" else "absent"}, ${if (prefs.brainOn) "activé" else "désactivé"}\n")
        sb.append("Réseau : ${if (Net.online) "oui" else "non"} | Google dispo : ${if (GoogleStt.available(this)) "oui" else "non"} (${if (prefs.googleStt) "activé" else "désactivé"}) | cerveau cloud : ${if (Cloud.configuredBrain(this)) "configuré (${prefs.brainModel})" else "non configuré"}\n")
        for (d in diag()) sb.append(if (d.ok) "[OK] " else "[KO] ").append(d.label).append('\n')
        sb.append("Dernière phrase : ${Status.heard}\nDernière action : ${Status.action}\nErreur : ${Status.error}\n")
        sb.append("--- Journal (le plus récent en premier) ---\n").append(Status.logText(150))
        val cm = getSystemService(android.content.ClipboardManager::class.java)
        cm.setPrimaryClip(android.content.ClipData.newPlainText("rapport", sb.toString()))
        toast("Rapport copié : colle-le dans le chat")
    }

    private fun secret(has: Boolean) = EditText(this).apply {
        setSingleLine()
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        hint = if (has) "(clé enregistrée)" else "colle la clé ici"
    }

    private fun toggleGoogle() {
        prefs.googleStt = !prefs.googleStt
        lastSig = ""
        toast(if (prefs.googleStt) "Reconnaissance Google activée" else "Reconnaissance Google désactivée : Vosk local seul")
    }

    private fun toggleCloudBrain() {
        prefs.cloudBrain = !prefs.cloudBrain
        lastSig = ""
        toast(if (prefs.cloudBrain) "Cerveau cloud activé" else "Cerveau cloud désactivé : cerveau local seul")
    }

    private fun saveCloud() {
        prefs.brainModel = brainModelEdit.text.toString().trim().ifBlank { Prefs.BRAIN_MODEL }
        val k2 = brainKeyEdit.text.toString().trim()
        if (k2.isNotEmpty()) { prefs.brainKey = k2; brainKeyEdit.setText(""); brainKeyEdit.hint = "(clé enregistrée)" }
        Cloud.resetCooldown()
        lastSig = ""
        toast("Cerveau cloud enregistré (pas besoin de relancer l'écoute)")
    }

    private fun testCloud() {
        saveCloud()
        progress.text = "Test en cours…"
        Thread {
            val r = try { Cloud.selfTest(this) } catch (t: Throwable) { "Erreur : ${t.message}" }
            h.post { progress.text = r }
        }.start()
    }

    private fun toggleBrain() {
        prefs.brainOn = !prefs.brainOn
        lastSig = ""
        toast(if (prefs.brainOn) "Cerveau activé : relance l'écoute" else "Cerveau désactivé")
    }

    private fun downloadBrain() {
        if (Status.listening) ListenService.stop(this)
        progress.text = "Téléchargement du cerveau (1,6 Go, patience, laisse l'écran allumé)…"
        Thread {
            try {
                BrainManager.download(this) { p -> h.post { progress.text = "Cerveau : $p" } }
                h.post { progress.text = "Cerveau installé ✔ (relance l'écoute)"; lastSig = ""; refresh() }
            } catch (t: Throwable) {
                h.post { progress.text = "Échec du téléchargement du cerveau : ${t.message}" }
            }
        }.start()
    }

    private fun importBrain() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 8
        )
    }

    private fun importModel() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 7
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req == 8 && res == RESULT_OK) {
            progress.text = "Installation du cerveau…"
            Thread {
                try {
                    val input = contentResolver.openInputStream(uri) ?: throw Exception("Fichier illisible")
                    BrainManager.save(this, input, 0) { p -> h.post { progress.text = "Cerveau : $p" } }
                    h.post { progress.text = "Cerveau installé ✔"; lastSig = ""; refresh() }
                } catch (t: Throwable) {
                    h.post { progress.text = "Échec de l'import : ${t.message}" }
                }
            }.start()
            return
        }
        if (req != 7 || res != RESULT_OK) return
        progress.text = "Installation du modèle…"
        Thread {
            try {
                val input = contentResolver.openInputStream(uri) ?: throw Exception("Fichier illisible")
                ModelManager.install(this, input, 0) { p -> h.post { progress.text = "Installation : $p" } }
                h.post { progress.text = "Modèle installé ✔"; lastSig = ""; refresh() }
            } catch (t: Throwable) {
                h.post { progress.text = "Échec de l'import : ${t.message}" }
            }
        }.start()
    }

    private fun toggleMode() {
        if (prefs.wakeMode == "voice") prefs.wakeMode = "words"
        else {
            if (!VoiceStore.exists(this)) { toast("Fais d'abord le calibrage vocal (ta voix)"); return }
            prefs.wakeMode = "voice"
        }
        lastSig = ""
        toast("Relance l'écoute pour appliquer")
    }

    private fun savePhrase() {
        val p = phraseEdit.text.toString().trim()
        if (p.length < 4) { toast("Phrase trop courte"); return }
        prefs.phrase = p
        prefs.calibrated = false
        lastSig = ""
        toast("Phrase enregistrée : refais le calibrage, puis relance l'écoute")
    }
}
