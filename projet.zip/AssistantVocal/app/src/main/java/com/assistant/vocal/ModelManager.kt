package com.assistant.vocal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object ModelManager {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip"
    private const val BIG_URL = "https://alphacephei.com/vosk/models/vosk-model-fr-0.22.zip"
    private var model: Model? = null

    fun dir(ctx: Context) = File(ctx.filesDir, "model")
    fun isReady(ctx: Context) = File(dir(ctx), "conf").isDirectory && File(dir(ctx), "am").isDirectory

    @Synchronized
    fun get(ctx: Context): Model {
        model?.let { return it }
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        val m = Model(dir(ctx).absolutePath)
        model = m
        return m
    }

    @Synchronized
    fun release() {
        try { model?.close() } catch (_: Throwable) {}
        model = null
    }

    private class Counting(i: InputStream, val onBytes: (Long) -> Unit) : FilterInputStream(i) {
        var n = 0L
        override fun read(): Int {
            val r = super.read(); if (r >= 0) { n++; onBytes(n) }; return r
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len); if (r > 0) { n += r; onBytes(n) }; return r
        }
    }

    /** Dézippe un modèle Vosk (zip officiel avec ou sans dossier racine) dans filesDir/model. */
    fun install(ctx: Context, input: InputStream, total: Long, progress: (String) -> Unit) {
        release()
        val tmp = File(ctx.filesDir, "model_tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        var last = -1
        val counted = Counting(input) { n ->
            val p = if (total > 0) (n * 100 / total).toInt() else (n / 2_000_000).toInt()
            if (p != last) {
                last = p
                progress(if (total > 0) "$p %" else "${n / 1_000_000} Mo")
            }
        }
        ZipInputStream(BufferedInputStream(counted)).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val out = File(tmp, e.name)
                if (!out.canonicalPath.startsWith(tmp.canonicalPath)) throw IOException("zip invalide")
                if (e.isDirectory) out.mkdirs()
                else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zin.copyTo(it) }
                }
                e = zin.nextEntry
            }
        }
        val root = tmp.walkTopDown().firstOrNull {
            it.isDirectory && File(it, "am").isDirectory && File(it, "conf").isDirectory
        } ?: throw IOException("Ce zip ne contient pas un modèle Vosk")
        val dest = dir(ctx)
        dest.deleteRecursively()
        if (!root.renameTo(dest)) throw IOException("Impossible d'installer le modèle")
        tmp.deleteRecursively()
    }

    /** Téléchargement unique (la seule fois où internet est utilisé). */
    fun download(ctx: Context, big: Boolean, progress: (String) -> Unit) {
        val c = URL(if (big) BIG_URL else MODEL_URL).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.connect()
        install(ctx, c.inputStream, c.contentLengthLong, progress)
    }
}

/** Enveloppe d'un Recognizer Vosk. phrase != null => vocabulaire limité à cette phrase (veille). */
class Speech(model: Model, phrase: String?) {
    class Out(val text: String, val conf: Float)

    private val rec: Recognizer =
        if (phrase != null)
            Recognizer(model, 16000f, JSONArray(listOf(phrase.lowercase(), "[unk]")).toString())
        else Recognizer(model, 16000f)

    init { rec.setWords(true) }

    /**
     * Renvoie un résultat final (phrase terminée) ou null.
     * keepEmpty : une fin de phrase où Vosk n'a rien compris est quand même signalée (texte vide),
     * pour que le cloud puisse tenter de comprendre l'audio.
     */
    fun feed(buf: ShortArray, n: Int, keepEmpty: Boolean = false): Out? {
        if (!rec.acceptWaveForm(buf, n)) return null
        val j = JSONObject(rec.result)
        val text = j.optString("text", "").trim()
        if (text.isEmpty()) return if (keepEmpty) Out("", 0f) else null
        var sum = 0f
        var c = 0
        val arr = j.optJSONArray("result")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                if (w.optString("word") != "[unk]") { sum += w.optDouble("conf", 1.0).toFloat(); c++ }
            }
        }
        return Out(text, if (c > 0) sum / c else 0f)
    }

    /** Force la fin de phrase (utile quand le bruit empêche Vosk de détecter une pause). */
    fun flush(): String = try { JSONObject(rec.finalResult).optString("text", "").trim() } catch (_: Throwable) { "" }

    fun reset() { rec.reset() }
    fun close() { try { rec.close() } catch (_: Throwable) {} }
}
