plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.assistant.vocal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.assistant.vocal"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "0.5.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Reconnaissance vocale 100 % locale (hors ligne)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    // Cerveau local : petit modèle de langage sur le téléphone (comprend les phrases libres)
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // Shizuku : uniquement pour accorder les autorisations au premier lancement
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
