# Assistant vocal (Android, hybride cloud / local)

Compilation : glisse ce dossier dans APK Builder (JDK 17, Gradle 8.7+).
Pas de gradlew fourni : le workflow doit utiliser `gradle assembleDebug`
ou générer le wrapper (`gradle wrapper --gradle-version 8.7`).

Premier lancement :
1. Installe l'APK, ouvre l'appli.
2. Lance Shizuku, puis dans l'appli : « Configuration automatique (Shizuku) ».
3. « Télécharger le modèle vocal » (une seule fois, ~40 Mo) ou « Importer un modèle (.zip) ».
4. « Calibrage vocal », puis « Démarrer l'écoute ».
Shizuku n'est ensuite plus nécessaire.

## Version 0.3.0 — cerveau local
- Bouton « Installer le cerveau » : télécharge une fois Qwen2.5-1.5B (≈1,6 Go, format MediaPipe, licence Apache 2.0).
  Il ne sert qu'en dernier recours, quand les règles simples ne comprennent pas ; tout reste sur le téléphone.
- Boutons sans texte : l'appli lit aussi les descriptions cachées et identifiants des boutons (play, next, voice message…).
- Noms de titres étrangers : comparaison par le son quand l'orthographe ne correspond pas.
- Journal des derniers événements sur l'écran principal.

## Version 0.5.0 — reconnaissance Google, sans clé
- Avec du réseau, une fois la session ouverte (phrase d'activation), c'est la reconnaissance vocale de Google (déjà sur le téléphone) qui te comprend : AUCUNE clé à saisir.
- Hors ligne, ou si Google échoue (erreur, lenteur) : retour automatique à Vosk + petit cerveau local, Google remis en pause 20 s.
- La veille (phrase d'activation) reste 100 % locale : rien ne part vers Google tant que la session n'est pas ouverte.
- Pendant que Google écoute, le micro de l'assistant est fermé (Google a besoin du micro pour lui seul) ; il est rendu à la veille à la fin de la session.
- Option avancée : un cerveau cloud (Claude) si tu saisis une clé Anthropic. Il reçoit la liste des boutons visibles à l'écran. À ignorer sans clé.
- Session silencieuse : fermée après 2 minutes sans commande en mode Google (10 minutes en mode local).
- Bouton « Tester Google et le cloud ».

## Version 0.6.0 — ordres par position, icônes muettes, noms arabes
- Ordres spatiaux : « clique sur le bouton en haut à droite », « le gros bouton au milieu », « les trois points », « le deuxième », « le dernier ». Marche aussi sur les icônes SANS nom (play, menu, engrenage…), car l'assistant repère maintenant tout ce qui est touchable, avec ou sans texte.
- « Les trois points à côté de X » : il retrouve la ligne de X puis touche le petit bouton de cette ligne.
- « Appuie sur play / pause / suivant / précédent » : par le nom du bouton, sinon touche média du système.
- Retour : « fais retour », « fais un retour », « reviens en arrière », « page précédente ».
- Titres écrits en arabe : ils sont translittérés en lettres latines pour être comparés à ce que Google transcrit ; comparaison aussi par squelette de consonnes (Fairuz ~ Fayrouz ~ فيروز).
- Diagnostic : dis « que vois-tu » (ou « décris l'écran »). L'assistant copie dans le presse-papiers la liste de ce qu'il voit (texte, description, identifiant, position, cliquable ou non). À coller dans une discussion pour comprendre pourquoi un élément n'est pas trouvé.
