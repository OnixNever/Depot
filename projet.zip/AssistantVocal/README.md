# Assistant vocal (Android, hybride cloud / local)

Compilation : glisse ce dossier dans APK Builder (JDK 17, Gradle 8.7+).
Pas de gradlew fourni : le workflow doit utiliser `gradle assembleDebug`
ou générer le wrapper (`gradle wrapper --gradle-version 8.7`).

Premier lancement :
1. Installe l'APK, ouvre l'appli.
2. Lance Shizuku, puis dans l'appli : « Configuration automatique (Shizuku) ».
3. « Télécharger le modèle vocal » (une seule fois, ~40 Mo) ou « Importer un modèle (.zip) ».
4. « Calibrage vocal », puis « Démarrer l'écoute ».
Shizuku n'est ensuite plus nécessaire.

## Version 0.3.0 — cerveau local
- Bouton « Installer le cerveau » : télécharge une fois Qwen2.5-1.5B (≈1,6 Go, format MediaPipe, licence Apache 2.0).
  Il ne sert qu'en dernier recours, quand les règles simples ne comprennent pas ; tout reste sur le téléphone.
- Boutons sans texte : l'appli lit aussi les descriptions cachées et identifiants des boutons (play, next, voice message…).
- Noms de titres étrangers : comparaison par le son quand l'orthographe ne correspond pas.
- Journal des derniers événements sur l'écran principal.

## Version 0.5.0 — reconnaissance Google, sans clé
- Avec du réseau, une fois la session ouverte (phrase d'activation), c'est la reconnaissance vocale de Google (déjà sur le téléphone) qui te comprend : AUCUNE clé à saisir.
- Hors ligne, ou si Google échoue (erreur, lenteur) : retour automatique à Vosk + petit cerveau local, Google remis en pause 20 s.
- La veille (phrase d'activation) reste 100 % locale : rien ne part vers Google tant que la session n'est pas ouverte.
- Pendant que Google écoute, le micro de l'assistant est fermé (Google a besoin du micro pour lui seul) ; il est rendu à la veille à la fin de la session.
- Option avancée : un cerveau cloud (Claude) si tu saisis une clé Anthropic. Il reçoit la liste des boutons visibles à l'écran. À ignorer sans clé.
- Session silencieuse : fermée après 2 minutes sans commande en mode Google (10 minutes en mode local).
- Bouton « Tester Google et le cloud ».

## Version 0.6.0 — ordres par position, icônes muettes, noms arabes
- Ordres spatiaux : « clique sur le bouton en haut à droite », « le gros bouton au milieu », « les trois points », « le deuxième », « le dernier ». Marche aussi sur les icônes SANS nom (play, menu, engrenage…), car l'assistant repère maintenant tout ce qui est touchable, avec ou sans texte.
- « Les trois points à côté de X » : il retrouve la ligne de X puis touche le petit bouton de cette ligne.
- « Appuie sur play / pause / suivant / précédent » : par le nom du bouton, sinon touche média du système.
- Retour : « fais retour », « fais un retour », « reviens en arrière », « page précédente ».
- Titres écrits en arabe : ils sont translittérés en lettres latines pour être comparés à ce que Google transcrit ; comparaison aussi par squelette de consonnes (Fairuz ~ Fayrouz ~ فيروز).
- Diagnostic : dis « que vois-tu » (ou « décris l'écran »). L'assistant copie dans le presse-papiers la liste de ce qu'il voit (texte, description, identifiant, position, cliquable ou non). À coller dans une discussion pour comprendre pourquoi un élément n'est pas trouvé.

## Version 0.7.0 — cerveau cloud GRATUIT (Groq)
- Le cerveau cloud accepte maintenant **Groq** (gratuit, sans carte bancaire), choisi par défaut. Anthropic reste possible (payant) via le bouton « Fournisseur ».
- Mise en place : crée un compte sur console.groq.com, génère une clé API, colle-la dans « clé API du fournisseur choisi », touche « Enregistrer le cerveau cloud », puis « Tester Google et le cloud ».
- Modèle par défaut : `openai/gpt-oss-120b` (modifiable dans le champ « nom du modèle » si Groq change son catalogue).
- Quota atteint (erreur 429) : le cloud se met en pause le temps indiqué par Groq (20 s à 1 h) et le petit cerveau local prend le relais, sans rien casser.
- Le cloud n'est appelé que lorsque les règles simples n'ont pas compris la phrase : ça économise le quota gratuit.
- Les clés Groq et Anthropic sont stockées séparément ; changer de fournisseur ne perd rien.

## Version 0.8.0 — Whisper (Groq) + clics fiables
- **Transcription Whisper** : une fois la session ouverte, l'appli enregistre elle-même chaque phrase (elle détecte le début et la fin toute seule) et l'envoie à Groq (`whisper-large-v3-turbo`, gratuit, **même clé Groq** que le cerveau). Bien meilleur que Google dans le bruit et sur les accents.
- Whisper reçoit aussi les noms affichés à l'écran (Recherche, Playlist, titres…) pour mieux les entendre.
- **Secours automatique** : si Whisper est indisponible (quota, réseau, clé), l'appli utilise ce que Vosk a entendu en parallèle, puis Google. Retour à Whisper après la pause.
- Session Whisper fermée après 2 minutes sans commande (chaque bruit envoyé consomme un peu de quota gratuit).
- Confidentialité : la veille (« salut Onix ») reste 100 % locale. En session, ta voix et les noms visibles à l'écran partent vers Groq.
- **Clics dans les pages web** (WebView) : `ACTION_CLICK` répondait « OK » sans rien faire. L'assistant fait maintenant un vrai toucher sur l'écran dans ce cas. Le journal indique sur quoi il a cliqué (« Clic : … ») avec les coordonnées.
- **Icônes sans nom** (engrenage, menu…) : elles sont maintenant données au cerveau avec leur position (haut/milieu/bas, gauche/centre/droite), il peut donc répondre à « appuie sur l'engrenage en haut ».
- Le cerveau reçoit aussi la position des boutons nommés, et sait que l'ordre peut être mal transcrit.
- Bouton « Transcription Whisper : activée/désactivée » sur l'écran principal ; « Tester Google et le cloud » teste aussi Whisper.

## Version 0.8.1 — clics vérifiés
- **Le « OK » ne ment plus.** Avant, le vrai toucher était envoyé sans attendre le résultat et l'assistant répondait OK même si rien ne se passait. Maintenant le toucher est attendu : si Android le refuse, l'ordre échoue vraiment.
- **Contrôle de l'écran après le clic** (pages web) : si l'écran n'a pas changé après le toucher, l'assistant tente le clic d'accessibilité en renfort.
- **Journal détaillé** pour chaque clic : élément visé et coordonnées, « Toucher x,y : envoyé / refusé », « Écran modifié » ou « Écran inchangé ». Si ces lignes n'apparaissent pas dans le journal, c'est que l'ancienne version est encore installée.
- Toucher un peu plus long (100 ms) pour les pages web.
- Le cerveau cloud connaît les équivalences : engrenage = Réglages, loupe = Recherche, trois points = Options / Plus.

## Version 0.9.0 — veille sans calibrage, tient dans le bruit
- **Veille Whisper** (activée par défaut, bouton dans l'écran principal) : l'assistant ne compare plus ta voix à un calibrage. Un détecteur local repère quand quelqu'un parle, envoie ce bout à Whisper (Groq) et ouvre la session si le mot « Onyx » est entendu. Max 15 envois par minute pour ménager le quota gratuit. Si Whisper est en panne, hors ligne ou si le quota tombe, l'ancienne veille reprend seule pendant 30 s.
- **« Salut Onyx, ouvre WhatsApp »** en une seule phrase : l'ordre qui suit « Onyx » est exécuté directement.
- **Bips** : bip montant quand la session s'ouvre (+ « Oui ? »), double bip + « En veille » quand elle se ferme. Volume des bips au maximum.
- **La musique baisse** pendant la session (focus audio « ducking »), puis remonte à la fermeture.
- **Micro filtré** : suppression de bruit et annulation d'écho du téléphone activées sur le micro (la musique du téléphone couvre moins ta voix).
- **« Quitte l'application »** (aussi « sors de l'appli », « ferme l'application ») : retour à l'accueil du premier coup.
- **« Ouvre WhatsApp »** : alias supplémentaires et tolérance aux noms mal transcrits (« whatsap », « youtub »…).
