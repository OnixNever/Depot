# Routage Audio v0.8.1

- Sortie par appli : tout le son de l'appli (média, appels, navigation) vise l'appareil choisi ;
  les autres profils du même appareil (ex. « appel » d'écouteurs Bluetooth) sont autorisés aussi.
- Micro : réglage séparé de la sortie. Il est COMMUN à toutes les applis (Android ne sait pas
  choisir un micro par appli de façon fiable). Appliqué aux usages micro, vocal, reconnaissance,
  communication et enregistrement.
- « Tout en automatique » remet sorties, applis et micro en automatique.
- Tout est sauvegardé et ré-appliqué à l'ouverture ; le service Shizuku garde le routage actif
  appli fermée (tant que Shizuku tourne).
- « Journal » (en bas) : détail technique en cas de problème.

- v0.6.0 : service Shizuku relancé avec le nouveau code (version 3) ; les erreurs sont écrites dans le Journal
  au lieu de fermer l'appli ; un plantage est enregistré et affiché à la réouverture suivante.

- v0.6.0 : un appareil Bluetooth = UNE ligne (profils média + appel regroupés) ; plusieurs applis sur le même
  appareil partagent un seul mix (Android refuse deux mix pour la même adresse) ; service relancé (version 4).
- Micro : toujours un réglage commun à toutes les applis (pas d'API Android pour un micro par appli).

- v0.6.1 : correctif « appareil introuvable » : Android masque l'adresse Bluetooth côté appli (XX:XX:XX:XX:B6:4C) alors que le service Shizuku voit l'adresse complète ; la comparaison se fait maintenant sur les 2 derniers octets. Le Journal liste aussi toutes les sorties vues par le service.

- v0.7.1 : curseurs de volume retirés de l'écran (ils ne fonctionnaient pas). Correctif du plantage « RejectedExecutionException » : la connexion Shizuku arrivait après la fermeture de l'écran.

- v0.8.0 : « Téléphone » force à nouveau le son de l'appli sur l'audio interne du téléphone (la v0.7.2 ne forçait plus rien, donc le son restait sur le Bluetooth).
- v0.8.0 : PANNEAU DE VOLUME. Bouton « Panneau de volume › Activer » (active un service d'accessibilité via Shizuku). Ensuite, à chaque appui sur une touche de volume, un panneau affiche pour le téléphone et chaque appareil Bluetooth un curseur Média et un curseur Appel (volume propre à chaque appareil). Les touches gardent leur effet normal. En cas d'échec, le panneau affiche la cause. Service Shizuku relancé (version 7).
- v0.8.1 : volume par appareil : 3 méthodes essayées dans l'ordre ([A] cmd audio set-device-volume, [B] AudioManager.setDeviceVolume, [C] AudioSystem), chacune détaillée. Le panneau affiche le résultat complet. Le Journal indique le volume actuel de chaque appareil routé et le statut de la politique audio. Service relancé (version 8).

- v0.8.2 : PANNEAU DE VOLUME redessiné et plus sobre. Une carte arrondie par appareil (téléphone en premier, les appareils connectés en dessous) avec icône et curseurs plus épais. Le texte de diagnostic orange n'est plus dans le panneau : tout va dans le « Journal » (nouveau bouton « Copier »). Un petit ⚠ n'apparaît que si un réglage échoue.
- v0.8.2 : les curseurs gardent leur dernier niveau (mémorisé par appareil et par type, Média/Appel) au lieu de revenir au centre ; le vrai volume est relu en plus quand Android le permet.
- v0.8.2 : le panneau n'occupe plus que ~74 % de la largeur, calé à gauche, en haut : la bande du volet One UI (à droite) reste accessible. Il grandit vers le bas quand d'autres appareils se connectent.
- v0.8.2 : bouton ⚙️ en haut de l'écran principal → « Réglages » → interrupteur « Panneau de volume » (activer ET désactiver). Remplace l'ancien bouton « Activer ». Le service Shizuku n'a pas changé (version 8).
