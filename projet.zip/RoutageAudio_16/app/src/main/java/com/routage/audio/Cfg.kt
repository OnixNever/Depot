package com.routage.audio

import android.content.ComponentName
import rikka.shizuku.Shizuku

/** Une seule définition du service Shizuku, partagée par l'écran et par le panneau de volume. */
object Cfg {
    const val SERVICE_VERSION = 8
    fun args(pkg: String): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(ComponentName(pkg, UserService::class.java.name))
            .daemon(true).processNameSuffix("audio").debuggable(false).version(SERVICE_VERSION)
}
