package com.routage.audio

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * Panneau de volume : à chaque appui sur une touche de volume, affiche une carte par appareil de sortie
 * (téléphone en premier, puis les appareils connectés) avec un curseur « Média » et un curseur « Appel ».
 * Les touches continuent de fonctionner normalement (on ne les consomme pas).
 *
 * v0.8.2 : panneau épuré (cartes arrondies, icônes, curseurs épais), aucun texte de diagnostic
 * (tout va dans le Journal), dernier niveau de chaque curseur mémorisé, et le panneau laisse libre
 * la bande du volet One UI (il n'occupe que la partie gauche de l'écran).
 */
class VolumePanelService : AccessibilityService() {

    private class Row(
        val title: String, val icon: String,
        val mType: Int, val mAddr: String, val cType: Int, val cAddr: String
    )

    private val TEAL = Color.parseColor("#4FD1C5")
    private val TRACK = Color.parseColor("#2E3846")
    private val GRAY = Color.parseColor("#8B97A6")
    private val BADGE = Color.parseColor("#26303D")
    private val CARD = Color.parseColor("#F2171C24")

    private var svc: IUserService? = null
    private var binding = false
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var panel: View? = null
    private val hide = Runnable { hidePanel() }
    private val readFailLogged = HashSet<String>()
    private val saved by lazy { getSharedPreferences("volumes", MODE_PRIVATE) }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = IUserService.Stub.asInterface(b); binding = false
            handler.post { if (panel != null) rebuild() }
        }
        override fun onServiceDisconnected(n: ComponentName?) { svc = null; binding = false }
    }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        connectShizuku()
    }

    private fun connectShizuku() {
        if (svc != null || binding) return
        try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                LogStore.add("Panneau : Shizuku indisponible (non lancé ou non autorisé)")
                return
            }
            binding = true
            Shizuku.bindUserService(Cfg.args(packageName), conn)
        } catch (t: Throwable) { binding = false; LogStore.add("Panneau : connexion Shizuku impossible : $t") }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (event.action == KeyEvent.ACTION_DOWN && (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            handler.post { showPanel() }
        }
        return false // la touche garde son effet normal
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(hide); hidePanel(); worker.shutdown(); super.onDestroy()
    }

    // ───────────── Appareils ─────────────
    private fun rows(): List<Row> {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val out = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val res = ArrayList<Row>()
        if (out.any { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER })
            res.add(Row("Téléphone", "📱", AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, "", AudioDeviceInfo.TYPE_BUILTIN_EARPIECE, ""))
        val bt = setOf(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET)
        val seen = HashSet<String>()
        for (d in out.filter { it.type in bt }) {
            val a = d.address ?: ""
            if (!seen.add(a)) continue
            val g = out.filter { it.type in bt && (it.address ?: "") == a }
            val media = g.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP } ?: g.first()
            val call = g.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO } ?: media
            val name = media.productName?.toString()?.takeIf { it.isNotBlank() } ?: "Bluetooth"
            res.add(Row(name, "🎧", media.type, a, call.type, a))
        }
        out.filter { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }
            .forEach { res.add(Row(it.productName?.toString() ?: "Casque filaire", "🎧", it.type, it.address ?: "", it.type, it.address ?: "")) }
        return res
    }

    // ───────────── Panneau ─────────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showPanel() {
        connectShizuku()
        if (panel == null) {
            val v = build()
            // On n'occupe que ~74 % de la largeur, calé à gauche : la bande du volet One UI
            // (à droite, avec les trois points) reste libre et utilisable.
            val lp = WindowManager.LayoutParams(
                (resources.displayMetrics.widthPixels * 0.74f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(10); y = dp(90) }
            try { wm?.addView(v, lp); panel = v } catch (t: Throwable) {
                LogStore.add("Panneau : affichage impossible : $t"); return
            }
        }
        rearm()
    }

    private fun rebuild() {
        val old = panel ?: return
        try { wm?.removeView(old) } catch (_: Throwable) {}
        panel = null
        showPanel()
    }

    private fun rearm() { handler.removeCallbacks(hide); handler.postDelayed(hide, 4500) }

    private fun hidePanel() {
        panel?.let { try { wm?.removeView(it) } catch (_: Throwable) {} }
        panel = null
    }

    private fun label(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun build(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rows().forEach { r ->
            root.addView(card(r), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        return root
    }

    /** Une carte arrondie par appareil : icône + nom, puis les curseurs Média et Appel. */
    private fun card(r: Row): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(14), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(26).toFloat(); setColor(CARD) }
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = r.icon; textSize = 17f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BADGE) }
        }, LinearLayout.LayoutParams(dp(36), dp(36)))
        head.addView(label(r.title, 16f, true).apply {
            setPadding(dp(12), 0, dp(8), 0); setSingleLine(); ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -2, 1f))
        // Petit point d'alerte : visible seulement si un réglage échoue (le détail est dans le Journal).
        val warn = TextView(this).apply { text = "⚠"; textSize = 15f; setTextColor(Color.parseColor("#F6AD55")); visibility = View.GONE }
        head.addView(warn)
        c.addView(head)
        c.addView(slider("Média", r.mType, r.mAddr, 3, warn))
        c.addView(slider("Appel", r.cType, r.cAddr, 0, warn))
        return c
    }

    private fun trackDrawable(): Drawable {
        val bg = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(TRACK); setSize(-1, dp(14)) }
        val fg = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(TEAL); setSize(-1, dp(14)) }
        val clip = ClipDrawable(fg, Gravity.LEFT, ClipDrawable.HORIZONTAL)
        return LayerDrawable(arrayOf<Drawable>(bg, clip)).apply {
            setId(0, android.R.id.background); setId(1, android.R.id.progress)
        }
    }

    private fun thumbDrawable(): Drawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(Color.WHITE); setSize(dp(26), dp(26))
    }

    private fun slider(name: String, type: Int, addr: String, stream: Int, warn: View): View {
        val key = "$type|$addr|$stream"
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(label(name, 13f).apply { setTextColor(GRAY) }, LinearLayout.LayoutParams(dp(50), -2))
        val bar = SeekBar(this).apply {
            max = 100
            progressDrawable = trackDrawable()
            thumb = thumbDrawable()
            splitTrack = false
            setPadding(dp(14), 0, dp(14), 0)
            progress = saved.getInt(key, 50) // dernier niveau réglé (évite le retour au centre)
        }
        line.addView(bar, LinearLayout.LayoutParams(0, dp(40), 1f))

        val touched = booleanArrayOf(false)
        val last = arrayOf("")

        // Lecture du vrai volume (si Android la donne) ; sinon on garde le dernier niveau mémorisé.
        val s = svc
        if (s != null) worker.execute {
            val r = try { s.getDeviceVolume(type, addr, stream) } catch (t: Throwable) { "" }
            val p = Regex("vol=(-?\\d+)").find(r)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            if (p >= 0) {
                handler.post {
                    if (panel != null && !touched[0]) bar.progress = p
                    saved.edit().putInt(key, p).apply()
                }
            } else if (readFailLogged.add(key)) {
                LogStore.add("Panneau : lecture du volume impossible ($name, type $type) — dernier niveau mémorisé utilisé. " + r.trim().take(200))
            }
        }

        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                rearm()
                saved.edit().putInt(key, p).apply()
                val sv = svc ?: run {
                    last[0] = "Service Shizuku non connecté"
                    warn.visibility = View.VISIBLE
                    return
                }
                worker.execute {
                    val r = try { sv.setDeviceVolume(type, addr, stream, p) } catch (t: Throwable) { "ERREUR : $t" }
                    last[0] = r.trim()
                    val fail = r.contains("ERREUR")
                    handler.post { warn.visibility = if (fail) View.VISIBLE else View.GONE }
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { touched[0] = true; handler.removeCallbacks(hide) }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                rearm()
                LogStore.add("Panneau : $name (type $type) → ${bar.progress} %\n" + last[0])
            }
        })
        return line
    }
}
