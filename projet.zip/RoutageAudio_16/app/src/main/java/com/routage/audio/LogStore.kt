package com.routage.audio

/**
 * Journal commun à l'écran principal et au panneau de volume (même processus).
 * Tout le détail technique y est écrit ; rien n'est affiché dans le panneau lui-même.
 */
object LogStore {
    private val sb = StringBuilder()

    fun add(s: String) {
        synchronized(sb) {
            sb.append(s.trimEnd()).append('\n')
            if (sb.length > 20000) sb.delete(0, sb.length - 15000)
        }
    }

    fun text(): String = synchronized(sb) { sb.toString() }
}
