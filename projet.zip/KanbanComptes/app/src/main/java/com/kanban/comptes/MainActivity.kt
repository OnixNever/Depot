package com.kanban.comptes

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("simple et sans dépendance")
    override fun onBackPressed() {
        web.evaluateJavascript("window.goBack&&window.goBack()") { if (it != "true") finish() }
    }

    inner class Bridge {
        private fun pi(id: String, title: String = ""): PendingIntent {
            val i = Intent(this@MainActivity, AlarmReceiver::class.java).putExtra("title", title)
            return PendingIntent.getBroadcast(
                this@MainActivity, id.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        @JavascriptInterface
        fun setReminder(id: String, title: String, at: Double) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            val p = pi(id, title)
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at.toLong(), p)
            else
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at.toLong(), p)
        }

        @JavascriptInterface
        fun cancelReminder(id: String) {
            (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi(id))
        }
    }
}
