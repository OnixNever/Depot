"""
Archivage des conversations directes (téléphone à téléphone) sur le serveur PC.

À brancher dans serveur.py (3 lignes) :

    from p2p_archive import make_router
    app.include_router(make_router(verify_token=ma_fonction))

`ma_fonction(token: str) -> str | None` doit renvoyer le nom d'utilisateur si le token est valide, sinon None
(c'est la même vérification que celle de ta route /verify_token).
Les messages sont enregistrés dans data/p2p_archive.json ; chaque message n'est gardé qu'une fois, même si
les deux téléphones de la conversation l'envoient. Les fichiers passent par /upload_file existant.
"""
import json
import threading
from pathlib import Path
from typing import Callable, Optional

from fastapi import APIRouter, HTTPException

FILE = Path("data") / "p2p_archive.json"


def make_router(verify_token: Callable[[str], Optional[str]], path: Path = FILE) -> APIRouter:
    router = APIRouter()
    lock = threading.Lock()
    path.parent.mkdir(parents=True, exist_ok=True)

    def load() -> dict:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def save(data: dict) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    def auth(username: str, token: str) -> str:
        user = verify_token((token or "").strip())
        if not user:
            raise HTTPException(401, "Session invalide ou expirée")
        if user != (username or "").strip():
            raise HTTPException(403, "Utilisateur non autorisé")
        return user

    @router.post("/p2p/archive")
    def archive_post(body: dict):
        user = auth(body.get("username", ""), body.get("token", ""))
        dev = (body.get("device_id") or "").strip()
        if not dev:
            raise HTTPException(400, "Identifiant d'appareil manquant")
        msgs = body.get("messages") or []
        saved = 0
        with lock:
            data = load()
            for m in msgs:
                mid, peer = m.get("id"), m.get("peer_id")
                if not mid or not peer:
                    continue
                key = "_".join(sorted([dev, peer]))
                conv = data.setdefault(key, {"devices": {}, "owners": [], "messages": []})
                conv["devices"][dev] = body.get("device_name", "")
                conv["devices"][peer] = m.get("peer_name", "")
                if user not in conv["owners"]:
                    conv["owners"].append(user)
                if any(x.get("id") == mid for x in conv["messages"]):
                    continue
                conv["messages"].append({k: m.get(k) for k in ("id", "from", "content", "ts", "file_name", "file_size", "file_url")})
                saved += 1
            if saved:
                save(data)
        return {"saved": saved, "received": len(msgs)}

    @router.get("/p2p/archive")
    def archive_get(username: str = "", token: str = ""):
        user = auth(username, token)
        with lock:
            data = load()
        return [
            {"conversation": k, "devices": c["devices"], "messages": c["messages"]}
            for k, c in data.items() if user in c.get("owners", [])
        ]

    return router
