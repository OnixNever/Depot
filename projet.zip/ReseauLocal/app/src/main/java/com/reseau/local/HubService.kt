package com.reseau.local

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.view.KeyEvent
import android.media.RingtoneManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Service au premier plan : garde la connexion, les appels WebRTC et l'écoute vocale
 * en vie écran éteint ou appli fermée.
 */
class HubService : Service() {
    companion object {
        const val CH_STATUS = "status"
        const val CH_CALL = "call"
        const val CH_MSG = "msg"
        const val NID = 1
        const val NID_CALL = 2
        const val NID_MSG = 3
        const val ACTION_DECLINE = "decline"
        const val ACTION_HANGUP = "hangup"
        const val ACTION_MUTE = "mute"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, HubService::class.java))
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, HubService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var ringtone: Ringtone? = null
    private var msgCount = 0
    private var session: MediaSession? = null

    /** Bouton du casque / des écouteurs : couper-réactiver le micro en appel, répondre quand ça sonne. */
    @Suppress("DEPRECATION")
    private fun setupSession() {
        val s = MediaSession(this, "reseaulocal")
        s.setCallback(object : MediaSession.Callback() {
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                val e = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT) ?: return false
                if (e.action != KeyEvent.ACTION_DOWN) return true
                when (e.keyCode) {
                    KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                    KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        val ui = CallEngine.ui.value
                        when {
                            ui.phase == Phase.IDLE && ui.incoming.isNotEmpty() -> CallEngine.accept(ui.incoming.last().callId)
                            ui.phase == Phase.ACTIVE -> CallEngine.setMuted(!ui.muted)
                        }
                    }
                    KeyEvent.KEYCODE_MEDIA_STOP -> CallEngine.hangup()
                }
                return true
            }
        })
        s.setPlaybackState(
            PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_STOP)
                .setState(PlaybackState.STATE_PLAYING, 0, 1f).build()
        )
        session = s
    }

    private fun nm() = getSystemService(NotificationManager::class.java)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        createChannels()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, statusNotif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else startForeground(NID, statusNotif())
        } catch (e: Exception) {
            stopSelf()
            return
        }
        if (Prefs.token.isBlank()) { stopSelf(); return }

        if (Prefs.hostMode) {
            try { LocalServer.start(applicationContext) } catch (e: Exception) { Hub.events.tryEmit("Serveur du téléphone : ${e.message}") }
        }
        Hub.start(application)
        CallEngine.init(application)
        Voice.enabled.value = Prefs.voiceEnabled
        Voice.start(this)

        val pm = getSystemService(PowerManager::class.java)
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "reseaulocal:hub").apply { acquire() }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        wifi = wm.createWifiLock(
            if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF,
            "reseaulocal:wifi"
        ).apply { acquire() }

        Hub.onMessage = { m -> notifyMessage(m) }
        setupSession()
        scope.launch { Hub.kicked.collect { Prefs.token = ""; stopSelf() } }

        scope.launch {
            combine(Hub.connected, CallEngine.ui, Voice.ready, Voice.enabled) { _, ui, _, _ -> ui }.collect { ui ->
                nm().notify(NID, statusNotif())
                updateIncoming(ui)
                // Le casque ne pilote l'appli que pendant un appel ou une sonnerie (on ne vole pas les boutons à ta musique)
                session?.isActive = ui.phase != Phase.IDLE || ui.incoming.isNotEmpty()
            }
        }
        scope.launch {
            combine(CallEngine.ui.map { it.phase }.distinctUntilChanged(), Voice.enabled, Voice.ready) { ph, en, rd ->
                ph == Phase.IDLE && en && rd
            }.distinctUntilChanged().collect { if (it) Voice.startIdleMic() else Voice.stopIdleMic() }
        }
        scope.launch { Hub.users.collect { Voice.markDirty() } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DECLINE -> CallEngine.decline(intent.getStringExtra("id").orEmpty())
            ACTION_HANGUP -> CallEngine.hangup()
            ACTION_MUTE -> CallEngine.setMuted(!CallEngine.ui.value.muted)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        Voice.stopIdleMic()
        ring(false)
        session?.release()
        Hub.onMessage = null
        Hub.stop()
        LocalServer.stop()
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notifications
    private fun createChannels() {
        nm().createNotificationChannel(NotificationChannel(CH_STATUS, "Connexion", NotificationManager.IMPORTANCE_LOW))
        nm().createNotificationChannel(NotificationChannel(CH_CALL, "Appels entrants", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false)
        })
        nm().createNotificationChannel(NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun openApp(extra: String? = null, id: String = ""): PendingIntent {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (extra != null) i.putExtra(extra, id)
        return PendingIntent.getActivity(this, (extra ?: "x").hashCode() + id.hashCode(), i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun action(a: String, id: String = ""): PendingIntent =
        PendingIntent.getService(
            this, a.hashCode() + id.hashCode(),
            Intent(this, HubService::class.java).setAction(a).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun statusNotif(): Notification {
        val ui = CallEngine.ui.value
        val text = when {
            ui.phase == Phase.ACTIVE -> "Appel en cours · ${ui.participants.size} participant(s)"
            ui.phase != Phase.IDLE -> "Appel : connexion…"
            Hub.connected.value -> "Connecté · ${Prefs.username}" + if (Voice.ready.value && Voice.enabled.value) " · écoute vocale" else ""
            else -> "Reconnexion au serveur…"
        }
        val b = NotificationCompat.Builder(this, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat).setContentTitle("Réseau local").setContentText(text)
            .setOngoing(true).setContentIntent(openApp()).setCategory(NotificationCompat.CATEGORY_SERVICE)
        if (ui.phase != Phase.IDLE) {
            b.addAction(0, if (ui.muted) "Micro on" else "Micro off", action(ACTION_MUTE))
            b.addAction(0, "Raccrocher", action(ACTION_HANGUP))
        }
        return b.build()
    }

    private fun updateIncoming(ui: CallUi) {
        val inc = ui.incoming.lastOrNull()
        if (ui.phase == Phase.IDLE && inc != null) {
            val n = NotificationCompat.Builder(this, CH_CALL)
                .setSmallIcon(R.drawable.ic_stat).setContentTitle("Appel de ${inc.from}")
                .setContentText("Appel entrant").setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX).setOngoing(true).setAutoCancel(false)
                .setFullScreenIntent(openApp(), true).setContentIntent(openApp())
                .addAction(0, "Répondre", openApp("answer", inc.callId))
                .addAction(0, "Refuser", action(ACTION_DECLINE, inc.callId))
                .build()
            nm().notify(NID_CALL, n)
            ring(true)
        } else {
            nm().cancel(NID_CALL)
            ring(false)
        }
    }

    private fun ring(on: Boolean) {
        val vib = getSystemService(Vibrator::class.java)
        if (on && ringtone == null) {
            val r = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
            r.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            ringtone = r
            vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 500), 0))
        } else if (!on && ringtone != null) {
            ringtone?.stop()
            ringtone = null
            vib.cancel()
        }
    }

    private fun notifyMessage(m: Msg) {
        if (Hub.foreground) return
        msgCount++
        val body = m.content.ifBlank { m.fileName ?: "Fichier" }
        nm().notify(
            NID_MSG,
            NotificationCompat.Builder(this, CH_MSG)
                .setSmallIcon(R.drawable.ic_stat).setContentTitle(m.sender).setContentText(body)
                .setNumber(msgCount).setAutoCancel(true).setContentIntent(openApp()).build()
        )
    }
}
