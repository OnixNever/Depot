package com.reseau.local

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow

/** Annonce le serveur du téléphone sur le réseau local et retrouve ceux des autres appareils. */
object Nsd {
    private const val TYPE = "_reseaulocal._tcp."

    data class Found(val name: String, val host: String, val port: Int)

    val found = MutableStateFlow<List<Found>>(emptyList())

    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    private fun mgr(c: Context) = c.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager

    fun register(c: Context, port: Int) {
        try {
            val info = NsdServiceInfo().apply {
                serviceName = "ReseauLocal-" + Build.MODEL.take(20).replace(' ', '_')
                serviceType = TYPE
                setPort(port)
            }
            val l = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            }
            mgr(c).registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
            reg = l
        } catch (_: Exception) {}
    }

    fun unregister(c: Context) {
        try { reg?.let { mgr(c).unregisterService(it) } } catch (_: Exception) {}
        reg = null
    }

    fun startDiscovery(c: Context) {
        if (disc != null) return
        found.value = emptyList()
        val m = mgr(c)
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) { disc = null }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceFound(i: NsdServiceInfo) { synchronized(queue) { queue.addLast(i) }; resolveNext(m) }
            override fun onServiceLost(i: NsdServiceInfo) { found.value = found.value.filter { it.name != i.serviceName } }
        }
        try { m.discoverServices(TYPE, NsdManager.PROTOCOL_DNS_SD, l); disc = l } catch (_: Exception) {}
    }

    fun stopDiscovery(c: Context) {
        try { disc?.let { mgr(c).stopServiceDiscovery(it) } } catch (_: Exception) {}
        disc = null
    }

    @Suppress("DEPRECATION")
    private fun resolveNext(m: NsdManager) {
        val next = synchronized(queue) {
            if (resolving) return
            val n = queue.removeFirstOrNull() ?: return
            resolving = true
            n
        }
        try {
            m.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) { synchronized(queue) { resolving = false }; resolveNext(m) }
                override fun onServiceResolved(i: NsdServiceInfo) {
                    val host = i.host?.hostAddress
                    if (host != null && found.value.none { it.name == i.serviceName }) {
                        found.value = found.value + Found(i.serviceName, host, i.port)
                    }
                    synchronized(queue) { resolving = false }
                    resolveNext(m)
                }
            })
        } catch (_: Exception) { synchronized(queue) { resolving = false } }
    }
}
