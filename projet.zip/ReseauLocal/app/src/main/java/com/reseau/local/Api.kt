package com.reseau.local

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class Msg(
    val id: Long, val sender: String, val content: String, val hour: String, val date: String,
    val fileUrl: String?, val fileName: String?, val fileSize: String?, val color: String
)

data class UserInfo(val name: String, val online: Boolean, val color: String, val role: String)

class ApiError(message: String) : Exception(message)

object Api {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()
    val base: String get() = Prefs.serverUrl

    /** "192.168.1.20" -> "http://192.168.1.20:8000" ; une URL complète (tunnel https) est gardée telle quelle. */
    fun normalize(raw: String): String {
        var u = raw.trim().trimEnd('/')
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "http://$u"
        if (u.startsWith("http://") && !u.substringAfter("://").contains(":")) u += ":8000"
        return u
    }

    fun wsUrl(user: String) = base.replaceFirst("http", "ws") + "/ws/" + Uri.encode(user)
    fun abs(path: String) = if (path.startsWith("http") || path.startsWith("file:")) path else base + path

    private fun JSONObject.str(k: String): String? =
        if (isNull(k)) null else optString(k).ifBlank { null }

    private fun runText(req: Request, client: OkHttpClient = http): String {
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val d = try { JSONObject(body).optString("detail") } catch (_: Exception) { "" }
                throw ApiError(d.ifBlank { "Erreur ${r.code}" })
            }
            return body
        }
    }

    private fun run(req: Request, client: OkHttpClient = http): JSONObject {
        val body = runText(req, client)
        return if (body.isBlank()) JSONObject() else JSONObject(body)
    }

    private fun post(path: String, body: JSONObject) =
        run(Request.Builder().url(base + path).post(body.toString().toRequestBody(JSON)).build())

    private fun get(path: String) = run(Request.Builder().url(base + path).get().build())

    /** POST JSON bloquant (à appeler hors du thread principal). */
    fun rawPost(path: String, body: JSONObject): JSONObject = post(path, body)

    fun parseMsg(o: JSONObject) = Msg(
        o.optLong("id"), o.optString("sender"), o.optString("content"),
        o.optString("hour"), o.optString("date"),
        o.str("file_url"), o.str("file_name"), o.str("file_size"),
        o.optString("sender_color", "#6366f1").ifBlank { "#6366f1" }
    )

    suspend fun login(u: String, p: String) = withContext(Dispatchers.IO) {
        post("/login", JSONObject().put("username", u).put("password", p))
    }

    suspend fun verify(token: String) = withContext(Dispatchers.IO) {
        post("/verify_token", JSONObject().put("token", token))
    }

    suspend fun logout(user: String, token: String) = withContext(Dispatchers.IO) {
        runCatching { post("/logout", JSONObject().put("username", user).put("token", token)) }
    }

    suspend fun users(): List<UserInfo> = withContext(Dispatchers.IO) {
        val o = get("/users")
        o.keys().asSequence().mapNotNull { k ->
            val u = o.optJSONObject(k) ?: return@mapNotNull null
            UserInfo(k, u.optBoolean("online"), u.optString("color", "#6366f1"), u.optString("role", "user"))
        }.toList()
    }

    suspend fun messages(): List<Msg> = withContext(Dispatchers.IO) {
        val arr = get("/messages?limit=200").optJSONArray("messages")
        val out = ArrayList<Msg>()
        if (arr != null) for (i in 0 until arr.length()) out.add(parseMsg(arr.getJSONObject(i)))
        out
    }

    suspend fun send(text: String, fileUrl: String? = null, fileName: String? = null, fileSize: String? = null) =
        withContext(Dispatchers.IO) {
            post(
                "/send_message", JSONObject()
                    .put("sender", Prefs.username).put("content", text)
                    .put("file_url", fileUrl ?: JSONObject.NULL)
                    .put("file_name", fileName ?: JSONObject.NULL)
                    .put("file_size", fileSize ?: JSONObject.NULL)
            )
        }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        post("/delete_message", JSONObject().put("message_id", id).put("username", Prefs.username))
    }

    fun upload(file: File, name: String): JSONObject {
        val mime = when (name.substringAfterLast('.', "").lowercase()) {
            "m4a", "aac" -> "audio/mp4"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            else -> "application/octet-stream"
        }
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", name, file.asRequestBody(mime.toMediaTypeOrNull()))
            .build()
        return run(Request.Builder().url("$base/upload_file").post(body).build())
    }

    /** Envoie un fichier local puis le publie comme message. */
    suspend fun sendFile(file: File, name: String) = withContext(Dispatchers.IO) {
        val f = upload(file, name)
        post(
            "/send_message", JSONObject()
                .put("sender", Prefs.username).put("content", "")
                .put("file_url", f.getString("file_url")).put("file_name", name)
                .put("file_size", f.optString("file_size"))
        )
    }

    suspend fun sendUri(cr: ContentResolver, uri: Uri, cacheDir: File) = withContext(Dispatchers.IO) {
        var name = "fichier"
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        val tmp = File(cacheDir, "up_${System.currentTimeMillis()}")
        cr.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        try {
            val f = upload(tmp, name)
            post(
                "/send_message", JSONObject()
                    .put("sender", Prefs.username).put("content", "")
                    .put("file_url", f.getString("file_url")).put("file_name", name)
                    .put("file_size", f.optString("file_size"))
            )
        } finally {
            tmp.delete()
        }
    }

    // ------------------------------------------------------------------ projets (cartes mentales)
    data class ProjectInfo(val id: String, val name: String, val updatedAt: String, val nodeCount: Int)

    private val q get() = "username=" + Uri.encode(Prefs.username)

    suspend fun projectsList(): List<ProjectInfo> = withContext(Dispatchers.IO) {
        val arr = JSONArray(runText(Request.Builder().url("$base/projects/list?$q").get().build()))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ProjectInfo(o.getString("id"), o.optString("name"), o.optString("updated_at"), o.optInt("node_count"))
        }
    }

    suspend fun projectGet(id: String): JSONObject = withContext(Dispatchers.IO) { get("/projects/get/$id?$q") }

    suspend fun projectCreate(name: String): JSONObject = withContext(Dispatchers.IO) {
        post("/projects/create", JSONObject().put("username", Prefs.username).put("name", name))
    }

    suspend fun projectSave(id: String, name: String, tree: JSONObject) = withContext(Dispatchers.IO) {
        post("/projects/save", JSONObject().put("username", Prefs.username).put("project_id", id).put("name", name).put("tree", tree))
    }

    suspend fun projectDelete(id: String) = withContext(Dispatchers.IO) {
        post("/projects/delete", JSONObject().put("username", Prefs.username).put("project_id", id))
    }

    suspend fun projectExport(id: String): JSONObject = withContext(Dispatchers.IO) { get("/projects/export/$id?$q") }

    suspend fun projectImport(name: String, tree: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        post("/projects/import", JSONObject().put("username", Prefs.username).put("name", name).put("tree", tree))
    }

    /** Sous-thèmes proposés par l'IA locale (Ollama sur le PC, appelée par le serveur). */
    suspend fun generateSegments(theme: String, path: List<String>): List<String> = withContext(Dispatchers.IO) {
        val slow = http.newBuilder().readTimeout(150, TimeUnit.SECONDS).build()
        val body = JSONObject().put("username", Prefs.username).put("theme", theme)
            .put("path", JSONArray(path)).put("ollama_url", Prefs.ollamaUrl).put("model", Prefs.ollamaModel)
        val r = run(Request.Builder().url("$base/generate_segments").post(body.toString().toRequestBody(JSON)).build(), slow)
        val a = r.optJSONArray("segments") ?: JSONArray()
        (0 until a.length()).map { a.getString(it) }
    }
}
