package com.reseau.local

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Petites briques cryptographiques du mode direct (HMAC-SHA256, hexadécimal, base32 pour les codes saisis à la main). */
object P2pCrypto {
    private val rnd = SecureRandom()
    private const val B32 = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

    fun rand(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    fun fromHex(s: String): ByteArray {
        val t = s.trim()
        if (t.length % 2 != 0) return ByteArray(0)
        return try { ByteArray(t.length / 2) { t.substring(it * 2, it * 2 + 2).toInt(16).toByte() } } catch (_: Exception) { ByteArray(0) }
    }

    fun hmac(key: ByteArray, data: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(if (key.isEmpty()) ByteArray(1) else key, "HmacSHA256"))
        return hex(m.doFinal(data.toByteArray(Charsets.UTF_8)))
    }

    /** Comparaison en temps constant. */
    fun eq(a: String, b: String): Boolean = MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    fun b32(bytes: ByteArray): String {
        var buf = 0
        var bits = 0
        val sb = StringBuilder()
        for (x in bytes) {
            buf = (buf shl 8) or (x.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                sb.append(B32[(buf shr (bits - 5)) and 31])
                bits -= 5
            }
            buf = buf and ((1 shl bits) - 1)
        }
        if (bits > 0) sb.append(B32[(buf shl (5 - bits)) and 31])
        return sb.toString()
    }

    /** Décode un code saisi par l'utilisateur (tirets, espaces et minuscules tolérés ; O→0, I/L→1). */
    fun b32decode(text: String): ByteArray? {
        val clean = text.uppercase().filter { it != '-' && !it.isWhitespace() }
            .replace('O', '0').replace('I', '1').replace('L', '1')
        val out = ArrayList<Byte>()
        var buf = 0
        var bits = 0
        for (ch in clean) {
            val v = B32.indexOf(ch)
            if (v < 0) return null
            buf = (buf shl 5) or v
            bits += 5
            if (bits >= 8) {
                out.add(((buf shr (bits - 8)) and 0xFF).toByte())
                bits -= 8
                buf = buf and ((1 shl bits) - 1)
            }
        }
        return out.toByteArray()
    }
}

/** Contenu d'un QR code ou d'un code d'authentification d'appairage. */
object Pairing {
    class Parsed(val hostId: String?, val hostName: String?, val ips: List<String>, val port: Int, val secret: ByteArray)

    /** QR : « RLP1: » + JSON (id, nom, adresses, port, secret de 16 octets). */
    fun parse(raw: String): Parsed? {
        val t = raw.trim()
        if (t.startsWith("RLP1:")) {
            return try {
                val j = JSONObject(t.removePrefix("RLP1:"))
                val a = j.optJSONArray("a")
                val ips = ArrayList<String>()
                if (a != null) for (i in 0 until a.length()) ips.add(a.getString(i))
                val secret = P2pCrypto.fromHex(j.getString("s"))
                if (ips.isEmpty() || secret.size < 8) null
                else Parsed(j.optString("i").ifBlank { null }, j.optString("n").ifBlank { null }, ips, j.optInt("p", P2p.PORT), secret)
            } catch (_: Exception) { null }
        }
        return decodeCode(t)
    }

    /** Code saisi à la main : adresse IPv4 (4 octets) + secret (8 octets) en base32, 20 caractères. */
    fun encodeCode(ip: String, secret: ByteArray): String? {
        val parts = ip.split('.').mapNotNull { it.toIntOrNull() }
        if (parts.size != 4 || parts.any { it !in 0..255 } || secret.size < 8) return null
        val raw = ByteArray(12)
        for (i in 0 until 4) raw[i] = parts[i].toByte()
        System.arraycopy(secret, 0, raw, 4, 8)
        return P2pCrypto.b32(raw).chunked(5).joinToString("-")
    }

    fun decodeCode(text: String): Parsed? {
        val bytes = P2pCrypto.b32decode(text) ?: return null
        if (text.filter { it != '-' && !it.isWhitespace() }.length != 20 || bytes.size < 12) return null
        val ip = (0 until 4).joinToString(".") { (bytes[it].toInt() and 0xFF).toString() }
        return Parsed(null, null, listOf(ip), P2p.PORT, bytes.copyOfRange(4, 12))
    }
}

/** Un appareil appairé. [key] = clé partagée (hex) établie lors de l'appairage. */
data class PeerRec(
    val id: String,
    val name: String,
    val key: String,
    val host: String = "",
    val port: Int = 0,
    val pairedAt: Long = 0L,
    /** Suppressions de messages à transmettre quand l'appareil sera de nouveau joignable. */
    val pendingDel: List<String> = emptyList()
) {
    val keyBytes: ByteArray get() = P2pCrypto.fromHex(key)
}

/** Un message d'une conversation directe. */
data class PMsg(
    val id: String,
    val peerId: String,
    val mine: Boolean,
    val content: String,
    val ts: Long,
    val fileId: String? = null,
    val fileName: String? = null,
    val fileSize: String? = null,
    val localPath: String? = null,
    /** Pour mes messages : l'autre appareil a confirmé la réception. */
    val delivered: Boolean = false,
    /** Copie envoyée au serveur (archivage). */
    val synced: Boolean = false,
    val serverUrl: String? = null
) {
    /** Identifiant numérique stable pour l'affichage (clé des listes). */
    val numId: Long get() = id.take(15).toLongOrNull(16) ?: id.hashCode().toLong()
    val hour: String get() = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
    val date: String get() = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
}

/** Stockage local du mode direct : appareils appairés, conversations, fichiers. Tout reste sur le téléphone. */
object P2pStore {
    private lateinit var dir: File
    lateinit var filesDir: File
        private set
    private val lock = Any()
    private var inited = false

    val peers = MutableStateFlow<List<PeerRec>>(emptyList())
    val chats = MutableStateFlow<Map<String, List<PMsg>>>(emptyMap())

    val myId: String get() = Prefs.deviceId

    fun init(ctx: Context) {
        synchronized(lock) {
            if (inited) return
            Prefs.init(ctx)
            dir = File(ctx.applicationContext.filesDir, "p2p").apply { mkdirs() }
            filesDir = File(dir, "files").apply { mkdirs() }
            peers.value = readPeers()
            val m = HashMap<String, List<PMsg>>()
            dir.listFiles()?.forEach { f ->
                if (f.name.startsWith("chat_") && f.name.endsWith(".json")) {
                    m[f.name.removePrefix("chat_").removeSuffix(".json")] = readChat(f)
                }
            }
            chats.value = m
            inited = true
        }
    }

    // ------------------------------------------------------------------ lecture / écriture
    private fun writeAtomic(f: File, text: String) {
        val t = File(f.path + ".tmp")
        t.writeText(text)
        if (!t.renameTo(f)) { f.writeText(text); t.delete() }
    }

    private fun readPeers(): List<PeerRec> = try {
        val f = File(dir, "peers.json")
        if (!f.exists()) emptyList() else {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val del = o.optJSONArray("pending_del")
                PeerRec(
                    o.getString("id"), o.optString("name"), o.optString("key"), o.optString("host"),
                    o.optInt("port"), o.optLong("paired_at"),
                    if (del == null) emptyList() else (0 until del.length()).map { del.getString(it) }
                )
            }
        }
    } catch (_: Exception) { emptyList() }

    private fun savePeers() {
        val a = JSONArray()
        peers.value.forEach { p ->
            a.put(
                JSONObject().put("id", p.id).put("name", p.name).put("key", p.key).put("host", p.host)
                    .put("port", p.port).put("paired_at", p.pairedAt).put("pending_del", JSONArray(p.pendingDel))
            )
        }
        writeAtomic(File(dir, "peers.json"), a.toString())
    }

    private fun readChat(f: File): List<PMsg> = try {
        val a = JSONArray(f.readText())
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            PMsg(
                o.getString("id"), o.optString("peer"), o.optBoolean("mine"), o.optString("content"), o.optLong("ts"),
                o.optString("fid").ifBlank { null }, o.optString("fname").ifBlank { null }, o.optString("fsize").ifBlank { null },
                o.optString("path").ifBlank { null }, o.optBoolean("delivered"), o.optBoolean("synced"),
                o.optString("server_url").ifBlank { null }
            )
        }.sortedBy { it.ts }
    } catch (_: Exception) { emptyList() }

    private fun saveChat(peerId: String) {
        val a = JSONArray()
        chats.value[peerId].orEmpty().forEach { m ->
            a.put(
                JSONObject().put("id", m.id).put("peer", m.peerId).put("mine", m.mine).put("content", m.content)
                    .put("ts", m.ts).put("fid", m.fileId ?: "").put("fname", m.fileName ?: "").put("fsize", m.fileSize ?: "")
                    .put("path", m.localPath ?: "").put("delivered", m.delivered).put("synced", m.synced)
                    .put("server_url", m.serverUrl ?: "")
            )
        }
        writeAtomic(File(dir, "chat_$peerId.json"), a.toString())
    }

    // ------------------------------------------------------------------ appareils
    fun peer(id: String): PeerRec? = peers.value.firstOrNull { it.id == id }

    fun putPeer(p: PeerRec) {
        synchronized(lock) {
            val cur = peers.value
            peers.value = if (cur.any { it.id == p.id }) cur.map { if (it.id == p.id) p else it } else cur + p
            savePeers()
        }
    }

    fun updatePeer(id: String, f: (PeerRec) -> PeerRec) {
        synchronized(lock) {
            val cur = peers.value.firstOrNull { it.id == id } ?: return
            val n = f(cur)
            if (n == cur) return
            peers.value = peers.value.map { if (it.id == id) n else it }
            savePeers()
        }
    }

    fun removePeer(id: String) {
        synchronized(lock) {
            peers.value = peers.value.filter { it.id != id }
            savePeers()
            chats.value[id]?.forEach { m -> m.localPath?.let { File(it).delete() } }
            chats.value = chats.value - id
            File(dir, "chat_$id.json").delete()
        }
    }

    // ------------------------------------------------------------------ messages
    fun chat(peerId: String): List<PMsg> = chats.value[peerId].orEmpty()

    fun hasMsg(peerId: String, id: String): Boolean = chat(peerId).any { it.id == id }

    fun addMsg(m: PMsg): Boolean {
        synchronized(lock) {
            val cur = chats.value[m.peerId].orEmpty()
            if (cur.any { it.id == m.id }) return false
            chats.value = chats.value + (m.peerId to (cur + m).sortedBy { it.ts })
            saveChat(m.peerId)
            return true
        }
    }

    fun updateMsg(peerId: String, id: String, f: (PMsg) -> PMsg) {
        synchronized(lock) {
            val cur = chats.value[peerId] ?: return
            chats.value = chats.value + (peerId to cur.map { if (it.id == id) f(it) else it })
            saveChat(peerId)
        }
    }

    /** Supprime un message (et son fichier). [onlyTheirs] : l'autre appareil ne peut effacer que ses propres messages. */
    fun removeMsg(peerId: String, id: String, onlyTheirs: Boolean): Boolean {
        synchronized(lock) {
            val cur = chats.value[peerId] ?: return false
            val m = cur.firstOrNull { it.id == id } ?: return false
            if (onlyTheirs && m.mine) return false
            m.localPath?.let { File(it).delete() }
            chats.value = chats.value + (peerId to cur.filter { it.id != id })
            saveChat(peerId)
            return true
        }
    }

    fun markSynced(ids: Set<String>) {
        synchronized(lock) {
            val touched = HashSet<String>()
            val next = chats.value.mapValues { (pid, list) ->
                list.map { if (it.id in ids && !it.synced) { touched.add(pid); it.copy(synced = true) } else it }
            }
            chats.value = next
            touched.forEach { saveChat(it) }
        }
    }

    /** Messages à envoyer au serveur (les fichiers reçus doivent d'abord être téléchargés). */
    fun unsynced(): List<PMsg> =
        chats.value.values.flatten().filter { !it.synced && (it.fileId == null || it.localPath != null) }.sortedBy { it.ts }

    // ------------------------------------------------------------------ fichiers
    fun newFile(name: String, prefix: String): File {
        val ext = name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(8)
        val n = prefix + "_" + UUID.randomUUID().toString().replace("-", "").take(16) + if (ext.isNotEmpty()) ".$ext" else ""
        return File(filesDir, n)
    }

    /** Fichier que j'ai envoyé à [peerId], pour que celui-ci puisse le récupérer. */
    fun fileFor(peerId: String, fileId: String): File? =
        chat(peerId).firstOrNull { it.fileId == fileId && it.mine }?.localPath?.let { File(it) }?.takeIf { it.isFile }

    fun fmtSize(n: Long) = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> "%.1f KB".format(n / 1024.0)
        n < 1024L * 1024 * 1024 -> "%.1f MB".format(n / (1024.0 * 1024))
        else -> "%.1f GB".format(n / (1024.0 * 1024 * 1024))
    }
}
