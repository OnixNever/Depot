package com.reseau.local

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

// ====================================================================== QR code
private fun qrBitmap(text: String, size: Int = 720): Bitmap {
    val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 1)
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
    val pixels = IntArray(size * size)
    for (y in 0 until size) for (x in 0 until size) pixels[y * size + x] = if (m.get(x, y)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    return Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
}

private fun saveToDownloads(ctx: Context, src: File, name: String): Boolean = try {
    if (Build.VERSION.SDK_INT >= 29) {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
        if (uri == null) false else {
            ctx.contentResolver.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, done, null, null)
            true
        }
    } else {
        val d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        d.mkdirs()
        src.copyTo(File(d, name), overwrite = true)
        true
    }
} catch (_: Exception) { false }

private fun PMsg.toMsg(peerName: String, me: String): Msg {
    val path = localPath
    val pending = fileId != null && path == null
    val text = if (pending) (content + "\n⏳ " + (fileName ?: "fichier") + " (réception…)").trim() else content
    return Msg(
        numId, if (mine) me else peerName, text, hour, date,
        if (path != null) android.net.Uri.fromFile(File(path)).toString() else null,
        fileName, fileSize, if (mine) "#6366f1" else "#14b8a6"
    )
}

// ====================================================================== conversation directe
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PeerChat(peerId: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val chats by P2pStore.chats.collectAsStateWithLifecycle()
    val peers by P2p.peers.collectAsStateWithLifecycle()
    val online by P2p.online.collectAsStateWithLifecycle()
    val typing by P2p.typing.collectAsStateWithLifecycle()
    val call by CallEngine.ui.collectAsStateWithLifecycle()
    val peer = peers.firstOrNull { it.id == peerId } ?: return
    val list = chats[peerId].orEmpty()
    val isOn = peerId in online
    var text by remember(peerId) { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<String?>(null) }
    val rec = remember { VoiceNote(ctx) }
    val state = rememberLazyListState()
    val me = Prefs.deviceName

    LaunchedEffect(list.size) { if (list.isNotEmpty()) state.animateScrollToItem(list.lastIndex) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        scope.launch {
            for (uri in uris) {
                try { P2p.sendUri(ctx, peerId, uri) } catch (e: Exception) { Hub.events.tryEmit("Fichier non envoyé : ${e.message}") }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(peer.name, fontWeight = FontWeight.Bold)
                Text(
                    if (isOn) "● connecté en direct" else "○ hors de portée : les messages partiront dès qu'il sera joignable",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isOn) Color(0xFF2E7D32) else MaterialTheme.colorScheme.outline
                )
            }
            IconButton(enabled = isOn && call.phase == Phase.IDLE, onClick = { CallEngine.startPeerCall(peerId) }) { Icon(Icons.Filled.Call, "Appeler") }
        }
        HorizontalDivider()
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = state,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { pm ->
                val m = pm.toMsg(peer.name, me)
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (pm.mine) Alignment.End else Alignment.Start) {
                    Box {
                        Column(
                            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (pm.mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .combinedClickable(onClick = {}, onLongClick = { menuFor = pm.id })
                                .padding(10.dp)
                        ) {
                            if (m.content.isNotBlank()) Text(m.content)
                            FileBlock(m, { viewer = it }) { _ ->
                                val f = pm.localPath?.let { File(it) }
                                val ok = f != null && saveToDownloads(ctx, f, pm.fileName ?: f.name)
                                Hub.events.tryEmit(if (ok) "Fichier enregistré dans Téléchargements" else "Enregistrement impossible")
                            }
                            Text(
                                pm.hour + if (pm.mine) (if (pm.delivered) "  ✓" else "  ⏳") else "",
                                style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.End)
                            )
                        }
                        DropdownMenu(expanded = menuFor == pm.id, onDismissRequest = { menuFor = "" }) {
                            if (pm.content.isNotBlank()) DropdownMenuItem(text = { Text("Copier") }, onClick = {
                                menuFor = ""
                                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("message", pm.content))
                                Hub.events.tryEmit("Message copié")
                            })
                            if (pm.localPath != null) DropdownMenuItem(text = { Text("Enregistrer dans Téléchargements") }, onClick = {
                                menuFor = ""
                                val ok = saveToDownloads(ctx, File(pm.localPath), pm.fileName ?: "fichier")
                                Hub.events.tryEmit(if (ok) "Fichier enregistré dans Téléchargements" else "Enregistrement impossible")
                            })
                            DropdownMenuItem(text = { Text("Supprimer") }, onClick = {
                                menuFor = ""
                                if (pm.mine) P2p.deleteMine(peerId, pm.id) else P2pStore.removeMsg(peerId, pm.id, onlyTheirs = false)
                            })
                        }
                    }
                }
            }
        }
        viewer?.let { u ->
            Dialog(onDismissRequest = { viewer = null }) {
                AsyncImage(model = u, contentDescription = null, modifier = Modifier.fillMaxWidth().clickable { viewer = null })
            }
        }
        if (peerId in typing) Text(
            "${peer.name} écrit…", Modifier.padding(horizontal = 12.dp),
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline
        )
        HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { picker.launch("*/*") }) { Icon(Icons.Filled.AttachFile, "Joindre") }
            OutlinedTextField(
                text, { text = it; if (it.isNotBlank()) P2p.notifyTyping(peerId) },
                Modifier.weight(1f), placeholder = { Text("Message") }, maxLines = 4
            )
            if (text.isBlank()) {
                IconButton(
                    enabled = call.phase == Phase.IDLE,
                    onClick = {
                        if (!recording) recording = rec.start()
                        else {
                            recording = false
                            val f = rec.stop()
                            if (f != null) scope.launch {
                                try { P2p.sendLocalFile(peerId, f, f.name) } catch (e: Exception) { Hub.events.tryEmit("Vocal non envoyé") }
                                f.delete()
                            }
                        }
                    }
                ) { Icon(if (recording) Icons.Filled.Stop else Icons.Filled.Mic, "Message vocal", tint = if (recording) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurface) }
            } else {
                IconButton(onClick = { val t = text; text = ""; P2p.sendText(peerId, t) }) { Icon(Icons.AutoMirrored.Filled.Send, "Envoyer") }
            }
        }
    }
}

// ====================================================================== onglet Appareils
@Composable
fun DevicesTab(onOpenChat: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val peers by P2p.peers.collectAsStateWithLifecycle()
    val online by P2p.online.collectAsStateWithLifecycle()
    val sync by P2pSync.status.collectAsStateWithLifecycle()
    val call by CallEngine.ui.collectAsStateWithLifecycle()
    var showMine by remember { mutableStateOf(false) }
    var showCode by remember { mutableStateOf(false) }
    var forget by remember { mutableStateOf<PeerRec?>(null) }
    var name by remember { mutableStateOf(Prefs.deviceName) }
    var autoSync by remember { mutableStateOf(Prefs.autoSync) }
    var busy by remember { mutableStateOf(false) }

    val scanner = rememberLauncherForActivityResult(ScanContract()) { r ->
        val txt = r.contents
        if (txt != null) {
            busy = true
            scope.launch {
                val e = P2p.pairWith(txt)
                busy = false
                if (e != null) Hub.events.tryEmit(e)
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Appareils (sans serveur)", style = MaterialTheme.typography.titleLarge)
        Text(
            "Deux téléphones qui ont l'appli, sur le même Wi-Fi (ou le point d'accès de l'un d'eux), discutent et s'appellent directement. " +
                "Pour les relier : l'un affiche son QR code, l'autre le scanne. Les deux peuvent afficher ou scanner.",
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true, label = { Text("Mon nom affiché") })
            TextButton(enabled = name.isNotBlank() && name.trim() != Prefs.deviceName, onClick = {
                Prefs.deviceName = name; P2p.announceName(); Voice.markDirty()
            }) { Text("OK") }
        }
        Button(modifier = Modifier.fillMaxWidth(), enabled = !busy, onClick = { showMine = true }) { Text("Afficher mon QR code") }
        Button(
            modifier = Modifier.fillMaxWidth(), enabled = !busy,
            onClick = {
                scanner.launch(
                    ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                        .setPrompt("Scanne le QR code de l'autre appareil").setBeepEnabled(false)
                )
            }
        ) { Text(if (busy) "Connexion…" else "Scanner un QR code") }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), enabled = !busy, onClick = { showCode = true }) { Text("Saisir un code d'authentification") }

        HorizontalDivider()
        Text("Appareils appairés", style = MaterialTheme.typography.titleMedium)
        if (peers.isEmpty()) Text("Aucun pour l'instant.", style = MaterialTheme.typography.bodySmall)
        peers.forEach { p ->
            val on = p.id in online
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text(
                                if (on) "● connecté en direct" else "○ hors de portée",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (on) Color(0xFF2E7D32) else MaterialTheme.colorScheme.outline
                            )
                        }
                        TextButton(onClick = { forget = p }) { Text("Oublier") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onOpenChat(p.id) }) { Text("Message") }
                        Button(enabled = on && call.phase == Phase.IDLE, onClick = { CallEngine.startPeerCall(p.id) }) { Text("Appeler") }
                    }
                }
            }
        }

        HorizontalDivider()
        Text("Sauvegarde sur le serveur", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Envoyer les conversations directes au serveur quand il est ouvert", Modifier.weight(1f))
            Switch(checked = autoSync, onCheckedChange = { autoSync = it; Prefs.autoSync = it; P2pSync.poke() })
        }
        Text(sync.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall)
        Text(
            "Les conversations restent d'abord sur les téléphones. Si ce téléphone est connecté à un serveur, il y archive " +
                "les messages et fichiers échangés en direct, sans rien changer à la façon de discuter.",
            style = MaterialTheme.typography.bodySmall
        )
    }

    if (showMine) MyCodeDialog { showMine = false }
    if (showCode) CodeEntryDialog(onClose = { showCode = false }) { code ->
        showCode = false
        busy = true
        scope.launch {
            val e = P2p.pairWith(code)
            busy = false
            if (e != null) Hub.events.tryEmit(e)
        }
    }
    forget?.let { p ->
        AlertDialog(
            onDismissRequest = { forget = null },
            title = { Text("Oublier ${p.name} ?") },
            text = { Text("La conversation et les fichiers reçus de cet appareil seront supprimés de ce téléphone. Pour se reconnecter, il faudra refaire l'appairage.") },
            confirmButton = { TextButton(onClick = { P2p.forget(p.id); forget = null }) { Text("Oublier") } },
            dismissButton = { TextButton(onClick = { forget = null }) { Text("Annuler") } }
        )
    }
}

// ====================================================================== mon QR code / mon code
@Composable
fun MyCodeDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var offer by remember { mutableStateOf<P2p.Offer?>(null) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var left by remember { mutableLongStateOf(0L) }

    fun renew() {
        val o = P2p.beginPairing()
        offer = o
        bmp = try { qrBitmap(o.qr) } catch (_: Exception) { null }
    }
    LaunchedEffect(Unit) { renew() }
    DisposableEffect(Unit) { onDispose { P2p.cancelPairing() } }
    LaunchedEffect(Unit) { P2p.paired.collect { onClose() } }
    LaunchedEffect(offer) {
        while (true) {
            val o = offer ?: break
            left = maxOf(0L, (o.expiresAt - System.currentTimeMillis()) / 1000)
            if (left == 0L) { renew(); break }
            delay(1000)
        }
    }

    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Mon code d'appairage", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text("L'autre appareil scanne ce QR code (ou saisit le code ci-dessous).", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                val o = offer
                if (o != null && o.ips.isEmpty()) {
                    Text("Aucun réseau détecté : connecte-toi à un Wi-Fi ou active le point d'accès.", color = MaterialTheme.colorScheme.error)
                }
                bmp?.let {
                    Box(Modifier.background(Color.White).padding(8.dp)) {
                        Image(it.asImageBitmap(), "QR code d'appairage", Modifier.size(260.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                val code = o?.code
                if (code != null) {
                    Text(code, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = {
                        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("code", code))
                        Hub.events.tryEmit("Code copié")
                    }) { Text("Copier le code") }
                } else if (o != null) {
                    Text("Code texte indisponible (port occupé) : utilise le QR code.", style = MaterialTheme.typography.bodySmall)
                }
                Text("Valable encore ${left / 60}:%02d".format(left % 60), style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { renew() }) { Text("Nouveau code") }
                    Button(onClick = onClose) { Text("Fermer") }
                }
            }
        }
    }
}

@Composable
fun CodeEntryDialog(onClose: () -> Unit, onSubmit: (String) -> Unit) {
    var code by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Code d'authentification") },
        text = {
            Column {
                Text("Saisis le code affiché sur l'autre appareil (« Afficher mon QR code »).", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(code, { code = it }, singleLine = true, placeholder = { Text("XXXXX-XXXXX-XXXXX-XXXXX") })
            }
        },
        confirmButton = { TextButton(enabled = code.isNotBlank(), onClick = { onSubmit(code) }) { Text("Se connecter") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Annuler") } }
    )
}
