package com.reseau.local

import android.app.Application
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject

/** Connexion unique au serveur (WebSocket + état partagé). Vit dans le service au premier plan. */
object Hub {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val connected = MutableStateFlow(false)
    val users = MutableStateFlow<List<UserInfo>>(emptyList())
    val online = MutableStateFlow<Set<String>>(emptySet())
    val messages = MutableStateFlow<List<Msg>>(emptyList())
    val events = MutableSharedFlow<String>(extraBufferCapacity = 32)

    @Volatile var foreground = false
    var onMessage: ((Msg) -> Unit)? = null

    lateinit var app: Application
    private var ws: WebSocket? = null
    private var wanted = false
    private var retry = 0
    private var job: Job? = null

    fun start(a: Application) {
        app = a
        if (wanted) return
        wanted = true
        job = scope.launch { loop() }
    }

    fun stop() {
        wanted = false
        job?.cancel()
        job = null
        ws?.close(1000, null)
        ws = null
        connected.value = false
    }

    fun send(o: JSONObject): Boolean = ws?.send(o.toString()) == true

    suspend fun refresh() {
        val u = Api.users()
        users.value = u
        online.value = u.filter { it.online }.map { it.name }.toSet()
        messages.value = Api.messages()
    }

    private suspend fun loop() {
        while (wanted) {
            try {
                refresh()
                val closed = CompletableDeferred<Unit>()
                val req = Request.Builder().url(Api.wsUrl(Prefs.username)).build()
                ws = Api.http.newWebSocket(req, object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        scope.launch { connected.value = true; retry = 0 }
                    }
                    override fun onMessage(webSocket: WebSocket, text: String) {
                        scope.launch { handle(text) }
                    }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { closed.complete(Unit) }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { closed.complete(Unit) }
                })
                val pinger = scope.launch {
                    while (true) { delay(25_000); ws?.send("{\"type\":\"ping\"}") }
                }
                closed.await()
                pinger.cancel()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
            connected.value = false
            CallEngine.onSocketLost()
            if (!wanted) break
            delay((2000L shl minOf(retry, 3)).coerceAtMost(15_000))
            retry++
        }
    }

    private suspend fun handle(text: String) {
        val j = try { JSONObject(text) } catch (_: Exception) { return }
        when (val t = j.optString("type")) {
            "new_message" -> j.optJSONObject("message")?.let { m ->
                val msg = Api.parseMsg(m)
                if (messages.value.none { it.id == msg.id }) {
                    messages.value = messages.value + msg
                    if (msg.sender != Prefs.username) onMessage?.invoke(msg)
                }
            }
            "delete_message" -> {
                val id = j.optLong("message_id")
                messages.value = messages.value.filter { it.id != id }
            }
            "clear_messages" -> messages.value = emptyList()
            "user_status" -> {
                val a = j.optJSONArray("online_users")
                val s = HashSet<String>()
                if (a != null) for (i in 0 until a.length()) s.add(a.getString(i))
                online.value = s
                users.value = users.value.map { it.copy(online = it.name in s) }
            }
            "user_color_updated" -> try { users.value = Api.users() } catch (_: Exception) {}
            else -> if (t.startsWith("call_")) CallEngine.onMessage(j)
        }
    }
}
