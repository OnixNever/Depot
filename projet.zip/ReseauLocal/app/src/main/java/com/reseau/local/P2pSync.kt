package com.reseau.local

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Archivage des conversations directes sur le serveur.
 * Les appareils n'ont pas besoin du serveur pour se parler ; mais dès qu'un serveur est joignable
 * (PC ou téléphone hôte) et que ce téléphone y est connecté, les messages et fichiers échangés en direct
 * lui sont envoyés pour être sauvegardés (une seule fois chacun, même si les deux appareils les envoient).
 */
object P2pSync {
    val status = MutableStateFlow("")

    private var job: Job? = null
    private val wake = Channel<Unit>(Channel.CONFLATED)
    @Volatile private var unsupportedUntil = 0L

    fun start() {
        if (job != null) return
        job = Hub.scope.launch(Dispatchers.IO) {
            while (isActive) {
                withTimeoutOrNull(20_000) { wake.receive() }
                if (!Prefs.autoSync) { status.value = "Synchronisation désactivée"; continue }
                if (Prefs.token.isBlank()) { status.value = "Aucun serveur : les conversations restent sur ce téléphone"; continue }
                try { syncOnce() } catch (e: Exception) { status.value = "Serveur injoignable : synchronisation en attente" }
            }
        }
    }

    fun stop() { job?.cancel(); job = null }

    /** À appeler quand un message est ajouté ou qu'un fichier arrive : la synchro repart sans attendre. */
    fun poke() { wake.trySend(Unit) }

    private fun syncOnce() {
        val t = System.currentTimeMillis()
        if (t < unsupportedUntil) { status.value = "Ce serveur ne gère pas encore l'archivage des conversations directes"; return }
        val todo = P2pStore.unsynced().take(40)
        if (todo.isEmpty()) { status.value = "Conversations directes à jour sur le serveur"; return }

        val items = JSONArray()
        val ids = HashSet<String>()
        for (m in todo) {
            var url = m.serverUrl
            val path = m.localPath
            if (m.fileId != null && url == null && path != null) {
                val f = File(path)
                if (!f.isFile) continue
                url = Api.upload(f, m.fileName ?: f.name).optString("file_url").ifBlank { null }
                if (url != null) P2pStore.updateMsg(m.peerId, m.id) { it.copy(serverUrl = url) }
            }
            val peerName = P2pStore.peer(m.peerId)?.name ?: "Appareil"
            items.put(
                JSONObject().put("id", m.id).put("peer_id", m.peerId).put("peer_name", peerName)
                    .put("from", if (m.mine) Prefs.deviceName else peerName).put("mine", m.mine)
                    .put("content", m.content).put("ts", m.ts)
                    .put("file_name", m.fileName ?: JSONObject.NULL).put("file_size", m.fileSize ?: JSONObject.NULL)
                    .put("file_url", url ?: JSONObject.NULL)
            )
            ids.add(m.id)
        }
        if (items.length() == 0) return
        val body = JSONObject().put("username", Prefs.username).put("token", Prefs.token)
            .put("device_id", P2pStore.myId).put("device_name", Prefs.deviceName).put("messages", items)
        try {
            Api.rawPost("/p2p/archive", body)
        } catch (e: ApiError) {
            val m = e.message.orEmpty()
            if (m.contains("Not Found", true) || m.contains("Introuvable", true) || m.contains("404")) {
                unsupportedUntil = System.currentTimeMillis() + 10 * 60_000
                status.value = "Ce serveur ne gère pas encore l'archivage des conversations directes"
                return
            }
            throw e
        }
        P2pStore.markSynced(ids)
        status.value = "Conversations directes sauvegardées sur le serveur"
        if (P2pStore.unsynced().isNotEmpty()) poke()
    }
}
