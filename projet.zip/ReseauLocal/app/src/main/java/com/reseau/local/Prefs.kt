package com.reseau.local

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("reseau_local", Context.MODE_PRIVATE)
        }
    }

    private fun s(k: String, d: String = "") = sp.getString(k, d) ?: d
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)

    var serverUrl: String
        get() = s("serverUrl")
        set(v) = sp.edit().putString("serverUrl", v.trim().trimEnd('/')).apply()
    var username: String
        get() = s("username")
        set(v) = sp.edit().putString("username", v).apply()
    var token: String
        get() = s("token")
        set(v) = sp.edit().putString("token", v).apply()
    var wakeWord: String
        get() = s("wakeWord", "assistant")
        set(v) = sp.edit().putString("wakeWord", v.trim().lowercase()).apply()
    var voiceEnabled: Boolean
        get() = b("voiceEnabled", true)
        set(v) = sp.edit().putBoolean("voiceEnabled", v).apply()
    var requireWake: Boolean
        get() = b("requireWake", true)
        set(v) = sp.edit().putBoolean("requireWake", v).apply()
}
