package com.reseau.local

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("reseau_local", Context.MODE_PRIVATE)
        }
    }

    private fun s(k: String, d: String = "") = sp.getString(k, d) ?: d
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)

    var serverUrl: String
        get() = s("serverUrl")
        set(v) = sp.edit().putString("serverUrl", v.trim().trimEnd('/')).apply()
    var username: String
        get() = s("username")
        set(v) = sp.edit().putString("username", v).apply()
    var token: String
        get() = s("token")
        set(v) = sp.edit().putString("token", v).apply()
    var ollamaUrl: String
        get() = s("ollamaUrl", "http://localhost:11434")
        set(v) = sp.edit().putString("ollamaUrl", v.trim().ifBlank { "http://localhost:11434" }).apply()
    var ollamaModel: String
        get() = s("ollamaModel", "llama3.2")
        set(v) = sp.edit().putString("ollamaModel", v.trim().ifBlank { "llama3.2" }).apply()
    var hostMode: Boolean
        get() = b("hostMode", false)
        set(v) = sp.edit().putBoolean("hostMode", v).apply()
    var wakeWord: String
        get() = s("wakeWord", "assistant")
        set(v) = sp.edit().putString("wakeWord", v.trim().lowercase()).apply()
    var voiceEnabled: Boolean
        get() = b("voiceEnabled", true)
        set(v) = sp.edit().putBoolean("voiceEnabled", v).apply()
    var requireWake: Boolean
        get() = b("requireWake", true)
        set(v) = sp.edit().putBoolean("requireWake", v).apply()

    // ------------------------------------------------------------------ mode direct (appareil à appareil, sans serveur)
    /** Vrai quand l'utilisateur utilise l'appli sans serveur (aucun compte, seulement des appareils appairés). */
    var directMode: Boolean
        get() = b("directMode", false)
        set(v) = sp.edit().putBoolean("directMode", v).apply()
    /** Identifiant stable de cet appareil pour l'appairage (généré une seule fois). */
    val deviceId: String
        get() {
            val cur = s("deviceId")
            if (cur.isNotBlank()) return cur
            val id = java.util.UUID.randomUUID().toString().replace("-", "")
            sp.edit().putString("deviceId", id).apply()
            return id
        }
    /** Nom affiché aux appareils appairés. Par défaut : le nom d'utilisateur du serveur, sinon le modèle du téléphone. */
    var deviceName: String
        get() = s("deviceName").ifBlank { username.ifBlank { android.os.Build.MODEL.orEmpty().ifBlank { "Mon téléphone" } } }
        set(v) = sp.edit().putString("deviceName", v.trim()).apply()
    /** Envoie automatiquement les conversations directes au serveur dès qu'il est joignable. */
    var autoSync: Boolean
        get() = b("autoSync", true)
        set(v) = sp.edit().putBoolean("autoSync", v).apply()
}
