package com.reseau.local

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import java.text.Normalizer

/**
 * Port fidèle du moteur de commandes de vocal.js (NLU) : mêmes listes de formulations,
 * mêmes règles (mots parasites, négations, tolérance aux erreurs de transcription,
 * reconnaissance des pseudos, 9 mots maximum).
 */
object Nlu {
    const val MAX_WORDS = 9
    val NEGATIONS = listOf("pas", "jamais", "surtout", "interdit")

    val MUTE = listOf(
        "coupe le son", "couper le son", "coupe mon son", "coupe le micro", "couper le micro",
        "coupe mon micro", "désactive le micro", "désactiver le micro", "mute", "micro off",
        "coupe moi le micro", "coupe moi le son", "coupe ma voix", "coupe mon audio", "coupe l'audio",
        "mute moi", "mute mon micro", "mute le micro", "mets mon micro en sourdine",
        "mets le micro en sourdine", "mets moi en sourdine", "mets moi en muet", "micro en sourdine",
        "passe en muet", "passe en sourdine", "mode muet", "mets en muet", "mets en sourdine",
        "ferme mon micro", "ferme le micro", "éteins le micro", "éteins mon micro",
        "éteindre le micro", "désactive mon micro", "désactiver mon micro", "je coupe mon micro",
        "je me mute", "je me mets en muet", "micro coupé", "micro désactivé", "micro muet",
        "on coupe le micro", "micro mute"
    )
    val UNMUTE = listOf(
        "reprends le son", "reprend le son", "reprendre le son", "remets le son", "remet le son",
        "remettre le son", "active le micro", "activer le micro", "réactive le micro",
        "réactiver le micro", "remets le micro", "remet le micro", "rallume le micro",
        "rallumer le micro", "unmute", "micro on",
        "démute", "démute moi", "démute mon micro", "démute le micro", "active mon micro",
        "activer mon micro", "réactive mon micro", "remets mon micro", "remets moi le micro",
        "remets moi le son", "rallume mon micro", "allume le micro", "allume mon micro",
        "ouvre le micro", "ouvre mon micro", "rouvre le micro", "micro actif", "micro activé",
        "micro réactivé", "sors de sourdine", "sors de la sourdine", "enlève la sourdine",
        "retire la sourdine", "enlève le mute", "retire le mute", "fin du mute", "fin de la sourdine",
        "sors du mode muet", "retire le mode muet", "reprends la parole", "reprendre la parole",
        "je reprends la parole", "rends moi la parole", "rends moi le son", "rétablis le micro",
        "rétablir le micro", "rétablis mon micro", "je veux parler"
    )
    val HANGUP = listOf(
        "raccroche", "raccroches", "raccrocher", "raccrochez", "arrête l'appel", "arrêter l'appel",
        "termine l'appel", "terminer l'appel", "coupe l'appel", "couper l'appel", "fin de l'appel",
        "raccroche l'appel", "raccroche le téléphone", "on raccroche", "je raccroche",
        "quitte l'appel", "quitter l'appel", "quitte la conversation", "quitter la conversation",
        "sors de l'appel", "sortir de l'appel", "termine la conversation", "terminer la conversation",
        "fin d'appel", "mets fin à l'appel", "mettre fin à l'appel", "mets fin à la conversation",
        "stop l'appel", "stoppe l'appel", "arrête la conversation", "arrêter la conversation",
        "ferme l'appel", "fermer l'appel", "déconnecte moi", "je me déconnecte"
    )
    val MUTE_OTHERS = listOf(
        "coupe le son des autres", "coupe le son de tout le monde", "coupe tout le monde",
        "coupe les autres", "coupe le micro des autres", "coupe le micro de tout le monde",
        "mute les autres", "mute tout le monde", "mute tous les participants", "mute tous",
        "mets les autres en sourdine", "mets tout le monde en sourdine", "mets tout le monde en muet",
        "mets les autres en muet", "mets en sourdine tout le monde", "mets en sourdine les autres",
        "silence pour tout le monde", "silence tout le monde", "fais taire tout le monde",
        "fais taire les autres", "faire taire tout le monde", "faire taire les autres",
        "éteins le son des autres", "désactive le son des autres", "désactive les autres",
        "coupe le haut parleur", "mute le haut parleur", "coupe tout le son", "coupe le volume",
        "plus de son des autres", "je ne veux plus entendre personne"
    )
    val UNMUTE_OTHERS = listOf(
        "remets le son des autres", "remets le son de tout le monde", "remets tout le monde",
        "rétablis le son des autres", "rétablis tout le monde", "réactive le son des autres",
        "réactive les autres", "réactive tout le monde", "active le son des autres",
        "démute les autres", "démute tout le monde", "démute tous les participants",
        "unmute tout le monde", "unmute les autres", "rends le son aux autres",
        "rends la parole à tout le monde", "rends la parole aux autres",
        "sors tout le monde de sourdine", "enlève la sourdine des autres",
        "retire la sourdine à tout le monde", "je veux entendre les autres",
        "je veux entendre tout le monde", "je veux les entendre", "remets le haut parleur",
        "réactive le haut parleur", "rallume le son des autres", "rallume tout le monde",
        "reprends le son des autres", "reprends tout le monde", "remets le volume"
    )
    val LOCK = listOf(
        "verrouille l'écran", "verrouille écran", "verrouille le téléphone", "verrouille",
        "verrouiller l'écran", "bloque l'écran", "bloquer l'écran", "active le verrou",
        "activer le verrou", "mets le verrou", "verrouille l'écran tactile", "verrouille le tactile"
    )
    val MUTE_VERBS = listOf(
        "coupe", "coupes", "couper", "coupez", "coupons", "mute", "mutes", "muter", "muet",
        "sourdine", "taire", "désactive", "désactiver", "éteins", "éteindre", "ferme", "fermer",
        "bloque", "bloquer", "silence"
    )
    val UNMUTE_VERBS = listOf(
        "reprends", "reprend", "reprendre", "remets", "remet", "remettre", "remettez",
        "réactive", "réactiver", "active", "activer", "démute", "démuter", "unmute", "rallume",
        "rallumer", "allume", "allumer", "rétablis", "rétablir", "retire", "retirer", "enlève",
        "enlever", "sors", "sortir", "ouvre", "ouvrir", "rouvre", "rouvrir", "redonne", "rends",
        "rendre", "libère", "libérer", "débloque", "débloquer", "restaure"
    )
    val SELF_OBJECTS = listOf("micro", "microphone", "son", "voix", "audio", "moi", "parole")
    val OTHERS_WORDS = listOf(
        "autre", "autres", "tous", "tout le monde", "participants", "participant", "eux",
        "gens", "haut parleur", "casque"
    )
    val FILLERS = listOf(
        "euh", "heu", "hum", "ben", "bah", "bon", "alors", "allez", "ok", "okay", "claude",
        "maintenant", "merci", "stp", "svp", "s'il te plaît", "s'il vous plaît", "please",
        "peux tu", "tu peux", "pourrais tu", "pourriez vous", "pouvez vous", "tu veux bien",
        "veux tu", "vas y", "allez y", "du coup", "donc", "voilà", "rapidement", "tout de suite"
    )

    /** Tous les mots utiles à la grammaire du moteur de reconnaissance (accents conservés). */
    fun vocabulary(): Set<String> {
        val all = MUTE + UNMUTE + HANGUP + MUTE_OTHERS + UNMUTE_OTHERS + LOCK + MUTE_VERBS +
            UNMUTE_VERBS + SELF_OBJECTS + OTHERS_WORDS + FILLERS
        val out = LinkedHashSet<String>()
        all.forEach { p -> p.lowercase().split(Regex("[^\\p{L}0-9]+")).filter { it.isNotBlank() }.forEach(out::add) }
        return out
    }

    sealed class Cmd {
        object Hangup : Cmd()
        object Lock : Cmd()
        object Mute : Cmd()
        object Unmute : Cmd()
        object MuteOthers : Cmd()
        object UnmuteOthers : Cmd()
        data class MuteUser(val name: String) : Cmd()
        data class UnmuteUser(val name: String) : Cmd()
        data class Ambiguous(val names: List<String>) : Cmd()
        object UnknownUser : Cmd()
    }

    fun normalize(t: String): String =
        Normalizer.normalize(t.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("[\\u0300-\\u036f]"), "")
            .replace(Regex("[’'`´]"), " ")
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ").trim()

    private fun split(t: String) = normalize(t).split(' ').filter { it.isNotEmpty() }

    fun stripFillers(words: List<String>): List<String> {
        var text = words.joinToString(" ")
        val fillers = FILLERS.map { normalize(it) }.filter { it.isNotEmpty() }.sortedByDescending { it.length }
        var changed = true
        while (changed && text.isNotEmpty()) {
            changed = false
            for (f in fillers) {
                if (text == f) { text = ""; changed = true; break }
                if (text.startsWith("$f ")) { text = text.substring(f.length + 1); changed = true; break }
                if (text.endsWith(" $f")) { text = text.substring(0, text.length - (f.length + 1)); changed = true; break }
            }
        }
        return if (text.isEmpty()) emptyList() else text.split(' ')
    }

    fun wordDist(a: String, b: String): Int {
        if (a == b) return 0
        val m = a.length; val n = b.length
        if (m == 0) return n
        if (n == 0) return m
        val d = Array(m + 1) { IntArray(n + 1) }
        for (i in 0..m) d[i][0] = i
        for (j in 0..n) d[0][j] = j
        for (i in 1..m) for (j in 1..n) {
            d[i][j] = if (a[i - 1] == b[j - 1]) d[i - 1][j - 1]
            else 1 + minOf(d[i - 1][j], d[i][j - 1], d[i - 1][j - 1])
        }
        return d[m][n]
    }

    fun wordsClose(a: String, b: String): Boolean {
        if (a == b) return true
        val maxLen = maxOf(a.length, b.length)
        if (maxLen <= 3) return false
        return wordDist(a, b) <= (if (maxLen <= 6) 1 else 2)
    }

    private fun matchScore(said: List<String>, phrase: List<String>): Double {
        if (phrase.isEmpty()) return 0.0
        var hit = 0
        val remaining = said.toMutableList()
        for (pw in phrase) {
            val idx = remaining.indexOfFirst { wordsClose(it, pw) }
            if (idx != -1) { hit++; remaining.removeAt(idx) }
        }
        return hit.toDouble() / phrase.size
    }

    private fun matches(words: List<String>, list: List<String>): Boolean {
        if (words.isEmpty()) return false
        return list.any { matchScore(words, split(it)) >= 0.8 }
    }

    private class Found(val name: String?, val ambiguous: List<String>?)

    private fun findParticipant(words: List<String>, participants: List<String>, me: String): Found? {
        val hits = ArrayList<String>()
        for (u in participants.filter { it != me }) {
            val toks = split(u).filter { it.length >= 2 }
            if (toks.isEmpty()) continue
            val full = toks.joinToString("")
            val ok = words.any { w ->
                w == full || toks.any { t ->
                    w == t || (t.length >= 4 && wordsClose(w, t)) ||
                        (w.length >= 4 && (t.startsWith(w) || w.startsWith(t)) && t.length >= 4)
                }
            }
            if (ok) hits.add(u)
        }
        return when {
            hits.size == 1 -> Found(hits[0], null)
            hits.size > 1 -> Found(null, hits)
            else -> null
        }
    }

    fun parse(said: String, participants: List<String>, me: String): Cmd? {
        val words = stripFillers(split(said))
        if (words.isEmpty() || words.size > MAX_WORDS) return null
        if (words.any { w -> NEGATIONS.any { normalize(it) == w } }) return null
        val text = words.joinToString(" ")
        fun has(list: List<String>): Boolean {
            val l = list.map { normalize(it) }
            return words.any { w -> l.any { x -> w == x || (x.length >= 7 && w.length >= 7 && wordDist(w, x) <= 1) } }
        }
        fun hasPhrase(list: List<String>) = list.map { normalize(it) }.any { " $text ".contains(" $it ") }

        if (matches(words, HANGUP)) return Cmd.Hangup
        if (matches(words, LOCK)) return Cmd.Lock

        val unmuteVerb = has(UNMUTE_VERBS)
        val muteVerb = !unmuteVerb && has(MUTE_VERBS)
        val wantsUnmute = unmuteVerb

        val othersWord = hasPhrase(OTHERS_WORDS)
        if (unmuteVerb || !muteVerb) { if (matches(words, UNMUTE_OTHERS)) return Cmd.UnmuteOthers }
        if (muteVerb || !unmuteVerb) { if (matches(words, MUTE_OTHERS)) return Cmd.MuteOthers }
        if (othersWord && (muteVerb || unmuteVerb)) return if (wantsUnmute) Cmd.UnmuteOthers else Cmd.MuteOthers

        if (!muteVerb && !unmuteVerb && !matches(words, MUTE) && !matches(words, UNMUTE)) return null

        val who = findParticipant(words, participants, me)
        if (who?.ambiguous != null) return Cmd.Ambiguous(who.ambiguous)
        if (who?.name != null) return if (wantsUnmute) Cmd.UnmuteUser(who.name) else Cmd.MuteUser(who.name)
        if (Regex("\\b(son|micro|voix|audio|parole)\\s+(de|du|d)\\s+(?!moi\\b|mon\\b|ma\\b|mes\\b|me\\b)\\w+").containsMatchIn(text)) {
            return Cmd.UnknownUser
        }

        val selfObj = has(SELF_OBJECTS)
        val phraseMute = matches(words, MUTE)
        val phraseUnmute = matches(words, UNMUTE)
        if (wantsUnmute) return if (phraseUnmute || selfObj) Cmd.Unmute else null
        if (muteVerb) return if (phraseMute || selfObj) Cmd.Mute else null
        if (phraseUnmute) return Cmd.Unmute
        if (phraseMute) return Cmd.Mute
        return null
    }
}

/** Exécution des commandes : en appel (sans mot d'activation, comme vocal.js) ou hors appel (avec mot d'activation). */
object Commands {
    val IDLE_VOCAB = listOf(
        "appelle", "appeler", "appel", "lance", "un", "tout", "le", "monde", "tous",
        "réponds", "répondre", "décroche", "accepte", "refuse", "rejette", "ignore"
    )

    fun words(t: String): List<String> =
        t.lowercase().split(Regex("[^\\p{L}0-9]+")).filter { it.isNotBlank() }

    private fun feedback(text: String) {
        Hub.events.tryEmit("🎙 $text")
        try {
            val v = Hub.app.getSystemService(Vibrator::class.java)
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(60, 120))
        } catch (_: Exception) {}
    }

    fun handle(raw: String) {
        if (!Prefs.voiceEnabled) return
        val ui = CallEngine.ui.value
        when (ui.phase) {
            Phase.ACTIVE -> inCall(raw, ui)
            Phase.IDLE -> idle(raw, ui)
            else -> {}
        }
    }

    private fun inCall(raw: String, ui: CallUi) {
        // Le mot d'activation est facultatif en appel : on l'ignore s'il est prononcé
        val wake = Nlu.normalize(Prefs.wakeWord)
        val said = if (wake.isNotEmpty()) Nlu.normalize(raw).split(' ').filter { it.isNotEmpty() && it != wake }.joinToString(" ") else raw
        val me = Prefs.username
        when (val c = Nlu.parse(said, ui.participants, me)) {
            null -> {}
            Nlu.Cmd.Hangup -> { feedback("raccroche"); CallEngine.hangup() }
            Nlu.Cmd.Lock -> { feedback("écran verrouillé"); CallEngine.setLocked(true) }
            Nlu.Cmd.Mute -> { CallEngine.setMuted(true); feedback("micro coupé") }
            Nlu.Cmd.Unmute -> { CallEngine.setMuted(false); feedback("micro actif") }
            Nlu.Cmd.MuteOthers -> { CallEngine.setAllOthersMuted(true); feedback("les autres sont coupés") }
            Nlu.Cmd.UnmuteOthers -> { CallEngine.setAllOthersMuted(false); feedback("les autres sont remis") }
            is Nlu.Cmd.MuteUser -> { CallEngine.setPeerMuted(c.name, true); feedback("${c.name} coupé") }
            is Nlu.Cmd.UnmuteUser -> { CallEngine.setPeerMuted(c.name, false); feedback("${c.name} remis") }
            is Nlu.Cmd.Ambiguous -> feedback("Précise : ${c.names.joinToString(" ou ")}")
            Nlu.Cmd.UnknownUser -> feedback("Personne inconnue dans l'appel")
        }
    }

    private fun idle(raw: String, ui: CallUi) {
        var w = Nlu.normalize(raw).split(' ').filter { it.isNotBlank() }
        val wake = Nlu.normalize(Prefs.wakeWord).split(' ').filter { it.isNotBlank() }
        val wi = if (wake.isEmpty()) -1 else (w.indices.firstOrNull { i ->
            i + wake.size <= w.size && wake.indices.all { k -> Nlu.wordsClose(w[i + k], wake[k]) }
        } ?: -1)
        if (wi >= 0) w = w.drop(wi + wake.size) else if (Prefs.requireWake) return
        if (w.isEmpty()) return

        fun any(vararg o: String) = w.any { x -> o.any { Nlu.wordsClose(x, it) } }
        val me = Prefs.username
        val others = Hub.users.value.map { it.name }.filter { it != me }
        val named = others.filter { n ->
            val toks = Nlu.normalize(n).split(' ').filter { it.isNotBlank() }
            toks.isNotEmpty() && toks.all { t -> w.any { x -> Nlu.wordsClose(x, t) } }
        }
        val everyone = (w.contains("tout") && w.contains("monde")) || any("tous")

        when {
            ui.incoming.isNotEmpty() && any("reponds", "repondre", "decroche", "accepte") -> {
                CallEngine.accept(ui.incoming.last().callId); feedback("réponds")
            }
            ui.incoming.isNotEmpty() && any("refuse", "rejette", "ignore") -> {
                CallEngine.decline(ui.incoming.last().callId); feedback("refuse")
            }
            any("appelle", "appeler", "appel", "lance") -> {
                val targets = if (named.isNotEmpty()) named
                else if (everyone) Hub.online.value.filter { it != me } else emptyList()
                if (targets.isNotEmpty()) { CallEngine.startCall(targets); feedback("appelle ${targets.joinToString()}") }
            }
        }
    }
}
