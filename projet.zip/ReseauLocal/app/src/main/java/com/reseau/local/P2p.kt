package com.reseau.local

import android.content.Context
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoWSD
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Une liaison directe ouverte avec un autre appareil (entrante ou sortante). */
interface Link {
    val outgoing: Boolean
    val peerId: String
    val peerName: String
    val remoteHost: String
    /** Port du serveur direct de l'autre appareil (pour récupérer ses fichiers). */
    val remotePort: Int
    val lastRx: Long
    val alive: Boolean
    fun sendText(s: String): Boolean
    fun closeQuiet()
}

/**
 * Mode direct : deux appareils qui ont l'appli se parlent sans serveur (messages, fichiers, messages vocaux, appels).
 * Chaque téléphone écoute sur le port [PORT] et se connecte aux appareils appairés. L'appairage se fait par QR code
 * ou par code saisi à la main ; il établit une clé partagée qui sert ensuite à s'authentifier à chaque connexion.
 */
object P2p {
    const val PORT = 8765
    const val SERVICE_PREFIX = "RLP-"
    private const val PING = "{\"type\":\"ping\"}"
    private const val PAIR_SECONDS = 180L

    @Volatile var port: Int = PORT
        private set

    private val scope get() = Hub.scope
    val peers get() = P2pStore.peers
    /** Identifiants des appareils actuellement connectés. */
    val online = MutableStateFlow<Set<String>>(emptySet())
    /** Appareils en train d'écrire. */
    val typing = MutableStateFlow<Set<String>>(emptySet())
    /** Demande d'ouverture d'une conversation (depuis l'onglet Appareils). */
    val openChat = MutableStateFlow<String?>(null)
    /** Émis quand un appairage vient d'aboutir (de l'un ou l'autre côté). */
    val paired = MutableSharedFlow<PeerRec>(extraBufferCapacity = 4)

    internal val client: OkHttpClient by lazy {
        Api.http.newBuilder().connectTimeout(4, TimeUnit.SECONDS).pingInterval(15, TimeUnit.SECONDS).build()
    }

    private val links = ConcurrentHashMap<String, Link>()
    private val dialing: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val downloading: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val nextTry = ConcurrentHashMap<String, Long>()
    private val fails = ConcurrentHashMap<String, Int>()

    private var server: PeerServer? = null
    private var loop: Job? = null
    @Volatile private var running = false
    private var lastPing = 0L
    private lateinit var appCtx: Context

    // ------------------------------------------------------------------ cycle de vie
    fun start(ctx: Context) {
        if (running) return
        running = true
        appCtx = ctx.applicationContext
        P2pStore.init(appCtx)
        scope.launch(Dispatchers.IO) {
            val s = try {
                PeerServer(PORT).also { it.start(0, true) }
            } catch (_: Exception) {
                try { PeerServer(0).also { it.start(0, true) } } catch (e: Exception) {
                    Hub.events.tryEmit("Mode direct : impossible d'ouvrir le port (${e.message})")
                    null
                }
            }
            if (s != null) {
                server = s
                port = s.listeningPort
                P2pNsd.register(appCtx, port)
            }
        }
        P2pNsd.startDiscovery(appCtx)
        loop = scope.launch {
            while (isActive) {
                try { tick() } catch (_: Exception) {}
                delay(3000)
            }
        }
        P2pSync.start()
    }

    fun stop() {
        if (!running) return
        running = false
        loop?.cancel(); loop = null
        P2pSync.stop()
        P2pNsd.stopDiscovery(appCtx)
        P2pNsd.unregister(appCtx)
        links.values.toList().forEach { it.closeQuiet() }
        links.clear()
        online.value = emptySet()
        typing.value = emptySet()
        try { server?.stop() } catch (_: Exception) {}
        server = null
        pairing = null
    }

    private fun now() = System.currentTimeMillis()

    fun isOnline(peerId: String) = links[peerId]?.alive == true
    fun peer(id: String): PeerRec? = P2pStore.peer(id)
    fun peerName(id: String) = P2pStore.peer(id)?.name ?: "Appareil"

    private fun updateOnline() { online.value = links.filterValues { it.alive }.keys.toSet() }

    fun sendTo(peerId: String, o: JSONObject): Boolean = links[peerId]?.sendText(o.toString()) == true

    /** À appeler quand mon nom change : prévient les appareils connectés. */
    fun announceName() {
        val s = JSONObject().put("type", "rename").put("name", Prefs.deviceName).toString()
        links.values.forEach { it.sendText(s) }
    }

    /** Un appareil vient d'être repéré sur le réseau : on retente tout de suite la connexion. */
    internal fun nudge(idPrefix: String) {
        P2pStore.peers.value.filter { it.id.startsWith(idPrefix) }.forEach { nextTry.remove(it.id) }
    }

    // ------------------------------------------------------------------ connexion aux appareils appairés
    private fun tick() {
        val t = now()
        for (p in P2pStore.peers.value) {
            if (links[p.id]?.alive == true || p.id in dialing) continue
            if (t < (nextTry[p.id] ?: 0L)) continue
            dialing.add(p.id)
            scope.launch(Dispatchers.IO) {
                try { dial(p) } finally { dialing.remove(p.id) }
            }
        }
        links.values.toList().forEach { l ->
            if (t - l.lastRx > 45_000) { l.closeQuiet(); onClosed(l) }
        }
        if (t - lastPing > 15_000) {
            lastPing = t
            links.values.forEach { it.sendText(PING) }
        }
    }

    private suspend fun dial(p: PeerRec) {
        val addrs = ArrayList<Pair<String, Int>>()
        P2pNsd.addressOf(p.id)?.let { addrs.add(it) }
        if (p.host.isNotBlank() && p.port > 0 && addrs.none { it.first == p.host && it.second == p.port }) addrs.add(p.host to p.port)
        var ok = false
        for ((h, pt) in addrs) {
            val l = ClientLink(h, pt, p.id, p.keyBytes, null)
            if (l.open()) { ok = true; break }
        }
        if (ok) {
            fails.remove(p.id); nextTry.remove(p.id)
        } else {
            val f = (fails[p.id] ?: 0) + 1
            fails[p.id] = f
            nextTry[p.id] = now() + minOf(2000L shl minOf(f, 4), 20_000L)
        }
    }

    // ------------------------------------------------------------------ appairage
    private class PairSession(val qrSecret: ByteArray, val codeSecret: ByteArray, val expiresAt: Long) {
        @Volatile var fails = 0
    }

    @Volatile private var pairing: PairSession? = null

    /** Ce que l'autre appareil doit scanner (QR) ou saisir (code). */
    class Offer(val qr: String, val code: String?, val expiresAt: Long, val ips: List<String>)

    /** Ouvre une fenêtre d'appairage de 3 minutes : l'autre appareil scanne le QR ou saisit le code. */
    fun beginPairing(): Offer {
        val sQr = P2pCrypto.rand(16)
        val sCode = P2pCrypto.rand(8)
        val exp = now() + PAIR_SECONDS * 1000
        pairing = PairSession(sQr, sCode, exp)
        val ips = LocalServer.localIps()
        val json = JSONObject().put("i", P2pStore.myId).put("n", Prefs.deviceName)
            .put("a", JSONArray(ips)).put("p", port).put("s", P2pCrypto.hex(sQr))
        val best = ips.firstOrNull { it.startsWith("192.168.") } ?: ips.firstOrNull()
        val code = if (best != null && port == PORT) Pairing.encodeCode(best, sCode) else null
        return Offer("RLP1:$json", code, exp, ips)
    }

    fun cancelPairing() { pairing = null }

    internal fun pairingSecrets(): List<ByteArray>? {
        val p = pairing ?: return null
        if (now() >= p.expiresAt || p.fails >= 5) { pairing = null; return null }
        return listOf(p.qrSecret, p.codeSecret)
    }

    internal fun pairingActive(): Boolean = pairingSecrets() != null
    internal fun pairingFailed() { pairing?.let { it.fails++ } }

    /** Rejoint un appareil à partir du texte d'un QR code ou d'un code saisi. Renvoie un message d'erreur, ou null si c'est réussi. */
    suspend fun pairWith(text: String): String? = withContext(Dispatchers.IO) {
        val p = Pairing.parse(text) ?: return@withContext "QR code ou code non reconnu"
        if (p.hostId == P2pStore.myId) return@withContext "C'est le code de cet appareil"
        var lastErr: String? = null
        for (ip in p.ips) {
            val link = ClientLink(ip, p.port, p.hostId, null, p.secret)
            if (link.open()) return@withContext null
            lastErr = link.failure
            if (lastErr?.startsWith("Pas de réponse") != true) break
        }
        lastErr ?: "Appareil injoignable"
    }

    private fun uniqueName(name: String, id: String): String {
        val base = name.trim().ifBlank { "Appareil" }
        var n = base
        var i = 2
        while (P2pStore.peers.value.any { it.id != id && it.name.equals(n, true) } || n.equals(Prefs.deviceName, true)) {
            n = "$base ($i)"; i++
        }
        return n
    }

    // ------------------------------------------------------------------ liaison établie
    /** Appelé quand l'authentification est terminée. [keyHex] est non nul uniquement lors d'un appairage. */
    internal fun onReady(link: Link, keyHex: String?) {
        val id = link.peerId
        val known = P2pStore.peer(id)
        val rec: PeerRec
        if (keyHex != null) {
            val nm = uniqueName(link.peerName, id)
            rec = PeerRec(id, nm, keyHex, link.remoteHost, link.remotePort, now(), known?.pendingDel.orEmpty())
            P2pStore.putPeer(rec)
            if (!link.outgoing) pairing = null
            Hub.events.tryEmit("Appairé avec $nm")
            paired.tryEmit(rec)
        } else if (known != null) {
            val nm = if (link.peerName.isNotBlank() && !link.peerName.equals(known.name, true)) uniqueName(link.peerName, id) else known.name
            rec = if (nm != known.name || known.host != link.remoteHost || known.port != link.remotePort)
                known.copy(name = nm, host = link.remoteHost, port = link.remotePort).also { P2pStore.putPeer(it) }
            else known
        } else {
            link.closeQuiet(); return
        }

        val old = links[id]
        if (old != null && old.alive && old !== link) {
            // Deux connexions simultanées : on garde celle initiée par l'appareil dont l'identifiant est le plus petit
            val dialerNew = if (link.outgoing) P2pStore.myId else id
            val dialerOld = if (old.outgoing) P2pStore.myId else id
            if (dialerNew <= dialerOld) { links[id] = link; old.closeQuiet() } else { link.closeQuiet(); return }
        } else links[id] = link
        updateOnline()
        fails.remove(id); nextTry.remove(id)

        scope.launch {
            val pr = P2pStore.peer(rec.id) ?: return@launch
            if (pr.pendingDel.isNotEmpty()) {
                pr.pendingDel.forEach { d -> link.sendText(JSONObject().put("type", "chat_delete").put("id", d).toString()) }
                P2pStore.updatePeer(rec.id) { it.copy(pendingDel = emptyList()) }
            }
            P2pStore.chat(rec.id).forEach { m ->
                if (m.mine && !m.delivered) sendChatFrame(link, m)
                else if (!m.mine && m.fileId != null && m.localPath == null) downloadAsync(link, m)
            }
            P2pSync.poke()
        }
    }

    internal fun onClosed(link: Link) {
        val id = link.peerId
        if (id.isBlank()) return
        if (links.remove(id, link)) {
            updateOnline()
            typing.value = typing.value - id
            scope.launch { CallEngine.onPeerLost(id) }
        }
    }

    // ------------------------------------------------------------------ messages reçus
    internal fun onFrame(link: Link, j: JSONObject) {
        when (val t = j.optString("type")) {
            "ping" -> link.sendText("{\"type\":\"pong\"}")
            "pong" -> {}
            "typing" -> scope.launch {
                typing.value = if (j.optBoolean("is_typing")) typing.value + link.peerId else typing.value - link.peerId
            }
            "chat" -> scope.launch { receiveChat(link, j) }
            "ack" -> scope.launch {
                P2pStore.updateMsg(link.peerId, j.optString("id")) { if (it.mine) it.copy(delivered = true) else it }
            }
            "chat_delete" -> scope.launch { P2pStore.removeMsg(link.peerId, j.optString("id"), onlyTheirs = true) }
            "rename" -> scope.launch {
                val nm = j.optString("name").trim()
                val r = P2pStore.peer(link.peerId)
                if (r != null && nm.isNotEmpty() && !nm.equals(r.name, true)) P2pStore.putPeer(r.copy(name = uniqueName(nm, r.id)))
            }
            else -> if (t.startsWith("call_")) scope.launch { CallEngine.onPeerMessage(link.peerId, peerName(link.peerId), j) }
        }
    }

    private fun receiveChat(link: Link, j: JSONObject) {
        val id = j.optString("id")
        if (id.isBlank()) return
        val peer = P2pStore.peer(link.peerId) ?: return
        if (!P2pStore.hasMsg(peer.id, id)) {
            val f = j.optJSONObject("file")
            val m = PMsg(
                id, peer.id, false, j.optString("content").take(5000), j.optLong("ts", now()),
                f?.optString("id")?.ifBlank { null }, f?.optString("name")?.ifBlank { null }, f?.optString("size")?.ifBlank { null },
                null, delivered = true
            )
            if (P2pStore.addMsg(m)) {
                Hub.onMessage?.invoke(Msg(m.numId, peer.name, m.content, m.hour, m.date, null, m.fileName, m.fileSize, "#6366f1"))
                if (m.fileId != null) downloadAsync(link, m)
                P2pSync.poke()
            }
        }
        link.sendText(JSONObject().put("type", "ack").put("id", id).toString())
    }

    /** Récupère le fichier d'un message directement chez l'expéditeur (HTTP, signé avec la clé partagée). */
    private fun downloadAsync(link: Link, m: PMsg) {
        val rec = P2pStore.peer(link.peerId) ?: return
        val fid = m.fileId ?: return
        if (!downloading.add(m.id)) return
        scope.launch(Dispatchers.IO) {
            var dest: File? = null
            try {
                val ts = now()
                val sig = P2pCrypto.hmac(rec.keyBytes, "file|$fid|$ts")
                val url = "http://${link.remoteHost}:${link.remotePort}/p2p/file/$fid?peer=${P2pStore.myId}&ts=$ts&sig=$sig"
                val d = P2pStore.newFile(m.fileName ?: "fichier", "in")
                dest = d
                client.newCall(Request.Builder().url(url).get().build()).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                    r.body!!.byteStream().use { i -> d.outputStream().use { o -> i.copyTo(o) } }
                }
                if (P2pStore.hasMsg(rec.id, m.id)) {
                    P2pStore.updateMsg(rec.id, m.id) { it.copy(localPath = d.absolutePath) }
                    P2pSync.poke()
                } else d.delete()
            } catch (_: Exception) {
                dest?.delete()
            } finally {
                downloading.remove(m.id)
            }
        }
    }

    // ------------------------------------------------------------------ messages envoyés
    private fun newId() = UUID.randomUUID().toString().replace("-", "")

    private fun sendChatFrame(link: Link, m: PMsg) {
        val o = JSONObject().put("type", "chat").put("id", m.id).put("content", m.content).put("ts", m.ts)
        if (m.fileId != null) o.put("file", JSONObject().put("id", m.fileId).put("name", m.fileName ?: "fichier").put("size", m.fileSize ?: ""))
        link.sendText(o.toString())
    }

    /** Envoie un message. Si l'autre appareil n'est pas joignable, il part dès qu'il l'est. */
    fun sendText(peerId: String, text: String) {
        val t = text.trim().take(5000)
        if (t.isEmpty()) return
        val m = PMsg(newId(), peerId, true, t, now())
        P2pStore.addMsg(m)
        links[peerId]?.let { sendChatFrame(it, m) }
        P2pSync.poke()
    }

    private fun addOutgoingFile(peerId: String, dest: File, name: String) {
        val id = newId()
        val m = PMsg(id, peerId, true, "", now(), fileId = id, fileName = name, fileSize = P2pStore.fmtSize(dest.length()), localPath = dest.absolutePath)
        P2pStore.addMsg(m)
        links[peerId]?.let { sendChatFrame(it, m) }
        P2pSync.poke()
    }

    suspend fun sendUri(ctx: Context, peerId: String, uri: Uri) = withContext(Dispatchers.IO) {
        var name = "fichier"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        val dest = P2pStore.newFile(name, "out")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        addOutgoingFile(peerId, dest, name)
    }

    suspend fun sendLocalFile(peerId: String, f: File, name: String) = withContext(Dispatchers.IO) {
        val dest = P2pStore.newFile(name, "out")
        f.copyTo(dest, overwrite = true)
        addOutgoingFile(peerId, dest, name)
    }

    /** Supprime un de mes messages ici, et chez l'autre appareil (dès qu'il est joignable). */
    fun deleteMine(peerId: String, id: String) {
        if (!P2pStore.removeMsg(peerId, id, onlyTheirs = false)) return
        val ok = links[peerId]?.sendText(JSONObject().put("type", "chat_delete").put("id", id).toString()) == true
        if (!ok) P2pStore.updatePeer(peerId) { it.copy(pendingDel = it.pendingDel + id) }
    }

    private var typingTo: String? = null
    private var typingJob: Job? = null

    /** « en train d'écrire… » vers [peerId]. */
    fun notifyTyping(peerId: String) {
        if (typingTo != peerId) {
            typingTo = peerId
            sendTo(peerId, JSONObject().put("type", "typing").put("is_typing", true))
        }
        typingJob?.cancel()
        typingJob = scope.launch {
            delay(2500)
            sendTo(peerId, JSONObject().put("type", "typing").put("is_typing", false))
            typingTo = null
        }
    }

    fun forget(peerId: String) {
        links.remove(peerId)?.closeQuiet()
        updateOnline()
        P2pStore.removePeer(peerId)
    }

    // ------------------------------------------------------------------ liaison sortante (je me connecte à l'autre appareil)
    internal class ClientLink(
        val host: String,
        val port: Int,
        private val expectId: String?,
        private val key: ByteArray?,
        private val pairSecret: ByteArray?
    ) : WebSocketListener(), Link {
        override val outgoing = true
        override var peerId: String = expectId ?: ""
        override var peerName: String = ""
        override val remoteHost: String get() = host
        override var remotePort: Int = port
        @Volatile override var lastRx: Long = System.currentTimeMillis()
        @Volatile private var isUp = false
        override val alive: Boolean get() = isUp
        @Volatile var failure: String? = null

        private var ws: WebSocket? = null
        private val done = CompletableDeferred<Boolean>()
        private var ready = false
        private var nonceH = ""
        private var nonceJ = ""
        private var hostId = ""

        suspend fun open(): Boolean {
            val req = Request.Builder().url("ws://$host:$port/p2p").build()
            ws = P2p.client.newWebSocket(req, this)
            val ok = withTimeoutOrNull(8000) { done.await() } ?: false
            if (!ok) {
                if (failure == null) failure = "Pas de réponse : les deux appareils sont-ils sur le même réseau ?"
                closeQuiet()
            }
            return ok
        }

        override fun sendText(s: String): Boolean = ws?.send(s) == true
        override fun closeQuiet() { isUp = false; try { ws?.close(1000, null) } catch (_: Exception) {} }

        private fun fail(reason: String) {
            if (failure == null) failure = reason
            done.complete(false)
            closeQuiet()
        }

        override fun onOpen(webSocket: WebSocket, response: Response) {
            isUp = true
            webSocket.send(
                JSONObject().put("type", "hello").put("id", P2pStore.myId).put("name", Prefs.deviceName)
                    .put("port", P2p.port).put("pair", pairSecret != null).toString()
            )
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            lastRx = System.currentTimeMillis()
            val j = try { JSONObject(text) } catch (_: Exception) { return }
            if (ready) { P2p.onFrame(this, j); return }
            when (j.optString("type")) {
                "challenge" -> {
                    hostId = j.optString("id")
                    if (expectId != null && hostId != expectId) { fail("Ce n'est pas le bon appareil"); return }
                    peerId = hostId
                    peerName = j.optString("name")
                    remotePort = j.optInt("port", port)
                    nonceH = j.optString("nonce")
                    nonceJ = P2pCrypto.hex(P2pCrypto.rand(12))
                    val k = pairSecret ?: key
                    if (k == null || k.isEmpty()) { fail("Clé absente : refais l'appairage"); return }
                    val proof = P2pCrypto.hmac(k, "join|$nonceH|$nonceJ|${P2pStore.myId}|$hostId")
                    webSocket.send(JSONObject().put("type", "auth").put("nonce", nonceJ).put("proof", proof).toString())
                }
                "ok" -> {
                    val k = pairSecret ?: key ?: return
                    val expect = P2pCrypto.hmac(k, "host|$nonceH|$nonceJ|$hostId|${P2pStore.myId}")
                    if (!P2pCrypto.eq(expect, j.optString("proof"))) { fail("L'autre appareil n'a pas pu prouver son identité"); return }
                    val derived = if (pairSecret != null) P2pCrypto.hmac(pairSecret, "key|$nonceH|$nonceJ|$hostId|${P2pStore.myId}") else null
                    ready = true
                    P2p.onReady(this, derived)
                    done.complete(true)
                }
                "reject" -> fail(j.optString("reason").ifBlank { "Refusé par l'autre appareil" })
            }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            isUp = false
            if (!ready) { if (failure == null) failure = "Connexion fermée"; done.complete(false) }
            P2p.onClosed(this)
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            isUp = false
            if (!ready) { if (failure == null) failure = "Pas de réponse : ${t.message ?: "connexion impossible"}"; done.complete(false) }
            P2p.onClosed(this)
        }
    }

    // ------------------------------------------------------------------ liaison entrante (l'autre appareil se connecte à moi)
    private class ServerLink(hs: NanoHTTPD.IHTTPSession) : NanoWSD.WebSocket(hs), Link {
        override val outgoing = false
        override var peerId: String = ""
        override var peerName: String = ""
        override val remoteHost: String = hs.remoteIpAddress ?: ""
        override var remotePort: Int = P2p.PORT
        @Volatile override var lastRx: Long = System.currentTimeMillis()
        override val alive: Boolean get() = isOpen

        private var stage = 0
        private var nonceH = ""
        private var pairMode = false
        private var peerKey: ByteArray? = null

        override fun sendText(s: String): Boolean = try { send(s); true } catch (_: Exception) { false }
        override fun closeQuiet() { try { close(NanoWSD.WebSocketFrame.CloseCode.NormalClosure, "bye", false) } catch (_: Exception) {} }

        private fun reject(reason: String) {
            sendText(JSONObject().put("type", "reject").put("reason", reason).toString())
            closeQuiet()
        }

        override fun onOpen() {}
        override fun onClose(code: NanoWSD.WebSocketFrame.CloseCode?, reason: String?, initiatedByRemote: Boolean) { P2p.onClosed(this) }
        override fun onPong(pong: NanoWSD.WebSocketFrame?) {}
        override fun onException(exception: IOException?) {}

        override fun onMessage(message: NanoWSD.WebSocketFrame) {
            message.setUnmasked()
            val text = message.textPayload ?: return
            lastRx = System.currentTimeMillis()
            val j = try { JSONObject(text) } catch (_: Exception) { return }
            when (stage) {
                0 -> hello(j)
                1 -> auth(j)
                else -> P2p.onFrame(this, j)
            }
        }

        private fun hello(j: JSONObject) {
            if (j.optString("type") != "hello") { reject("Protocole inconnu"); return }
            val id = j.optString("id")
            if (id.isBlank() || id == P2pStore.myId) { reject("Identifiant invalide"); return }
            peerId = id
            peerName = j.optString("name")
            remotePort = j.optInt("port", P2p.PORT)
            pairMode = j.optBoolean("pair")
            if (pairMode) {
                if (!P2p.pairingActive()) { reject("Aucun appairage en cours sur cet appareil (affiche d'abord ton code)"); return }
            } else {
                val r = P2pStore.peer(id)
                if (r == null) { reject("Cet appareil ne te connaît pas : refais l'appairage"); return }
                peerKey = r.keyBytes
            }
            nonceH = P2pCrypto.hex(P2pCrypto.rand(12))
            sendText(
                JSONObject().put("type", "challenge").put("id", P2pStore.myId).put("name", Prefs.deviceName)
                    .put("port", P2p.port).put("nonce", nonceH).toString()
            )
            stage = 1
        }

        private fun auth(j: JSONObject) {
            if (j.optString("type") != "auth") { reject("Protocole inconnu"); return }
            val nonceJ = j.optString("nonce")
            val proof = j.optString("proof")
            val me = P2pStore.myId
            val joinData = "join|$nonceH|$nonceJ|$peerId|$me"
            if (pairMode) {
                val hit = P2p.pairingSecrets()?.firstOrNull { P2pCrypto.eq(proof, P2pCrypto.hmac(it, joinData)) }
                if (hit == null) { P2p.pairingFailed(); reject("Code incorrect ou expiré"); return }
                val keyHex = P2pCrypto.hmac(hit, "key|$nonceH|$nonceJ|$me|$peerId")
                sendText(JSONObject().put("type", "ok").put("proof", P2pCrypto.hmac(hit, "host|$nonceH|$nonceJ|$me|$peerId")).toString())
                stage = 2
                P2p.onReady(this, keyHex)
            } else {
                val k = peerKey ?: run { reject("Clé absente"); return }
                if (!P2pCrypto.eq(proof, P2pCrypto.hmac(k, joinData))) { reject("Authentification refusée"); return }
                sendText(JSONObject().put("type", "ok").put("proof", P2pCrypto.hmac(k, "host|$nonceH|$nonceJ|$me|$peerId")).toString())
                stage = 2
                P2p.onReady(this, null)
            }
        }
    }

    // ------------------------------------------------------------------ serveur du mode direct (WebSocket + fichiers)
    private class PeerServer(p: Int) : NanoWSD(p) {
        override fun openWebSocket(handshake: NanoHTTPD.IHTTPSession): NanoWSD.WebSocket = ServerLink(handshake)

        override fun serveHttp(session: NanoHTTPD.IHTTPSession): NanoHTTPD.Response {
            val st = NanoHTTPD.Response.Status.FORBIDDEN
            val uri = session.uri
            if (uri.startsWith("/p2p/file/")) {
                val fid = uri.substringAfterLast('/')
                val q = session.parms
                val rec = P2pStore.peer(q["peer"].orEmpty()) ?: return text(st, "Appareil inconnu")
                val ts = q["ts"]?.toLongOrNull() ?: 0L
                if (Math.abs(System.currentTimeMillis() - ts) > 300_000) return text(st, "Demande expirée")
                val sig = q["sig"].orEmpty()
                if (!P2pCrypto.eq(sig, P2pCrypto.hmac(rec.keyBytes, "file|$fid|$ts"))) return text(st, "Signature invalide")
                val f = P2pStore.fileFor(rec.id, fid) ?: return text(NanoHTTPD.Response.Status.NOT_FOUND, "Fichier introuvable")
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
                return NanoHTTPD.newFixedLengthResponse(NanoHTTPD.Response.Status.OK, mime, FileInputStream(f), f.length())
            }
            return text(NanoHTTPD.Response.Status.OK, "Réseau local : mode direct")
        }

        private fun text(s: NanoHTTPD.Response.Status, t: String) =
            NanoHTTPD.newFixedLengthResponse(s, "text/plain; charset=utf-8", t)
    }
}

/** Annonce cet appareil sur le réseau local et retrouve les appareils appairés (même si leur adresse a changé). */
object P2pNsd {
    private const val TYPE = "_rlp2p._tcp."
    private val found = ConcurrentHashMap<String, Pair<String, Int>>()
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    private fun mgr(c: Context) = c.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private fun ownPrefix() = P2p.SERVICE_PREFIX + P2pStore.myId.take(16)

    fun addressOf(peerId: String): Pair<String, Int>? {
        val key = P2p.SERVICE_PREFIX + peerId.take(16)
        return found.entries.firstOrNull { it.key.startsWith(key) }?.value
    }

    fun register(c: Context, port: Int) {
        try {
            val info = NsdServiceInfo().apply {
                serviceName = ownPrefix()
                serviceType = TYPE
                setPort(port)
            }
            val l = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            }
            mgr(c).registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
            reg = l
        } catch (_: Exception) {}
    }

    fun unregister(c: Context) {
        try { reg?.let { mgr(c).unregisterService(it) } } catch (_: Exception) {}
        reg = null
    }

    fun startDiscovery(c: Context) {
        if (disc != null) return
        val m = mgr(c)
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) { disc = null }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                if (i.serviceName.startsWith(ownPrefix())) return
                synchronized(queue) { queue.addLast(i) }
                resolveNext(m)
            }
            override fun onServiceLost(i: NsdServiceInfo) { found.remove(i.serviceName) }
        }
        try { m.discoverServices(TYPE, NsdManager.PROTOCOL_DNS_SD, l); disc = l } catch (_: Exception) {}
    }

    fun stopDiscovery(c: Context) {
        try { disc?.let { mgr(c).stopServiceDiscovery(it) } } catch (_: Exception) {}
        disc = null
        found.clear()
    }

    @Suppress("DEPRECATION")
    private fun resolveNext(m: NsdManager) {
        val next = synchronized(queue) {
            if (resolving) return
            val n = queue.removeFirstOrNull() ?: return
            resolving = true
            n
        }
        try {
            m.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) { synchronized(queue) { resolving = false }; resolveNext(m) }
                override fun onServiceResolved(i: NsdServiceInfo) {
                    val host = i.host?.hostAddress
                    if (host != null) {
                        found[i.serviceName] = host to i.port
                        P2p.nudge(i.serviceName.removePrefix(P2p.SERVICE_PREFIX).take(16))
                    }
                    synchronized(queue) { resolving = false }
                    resolveNext(m)
                }
            })
        } catch (_: Exception) { synchronized(queue) { resolving = false } }
    }
}
