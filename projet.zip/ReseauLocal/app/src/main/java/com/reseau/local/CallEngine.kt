package com.reseau.local

import android.app.Application
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule

enum class Phase { IDLE, STARTING, JOINING, ACTIVE }

data class Incoming(val callId: String, val from: String)

data class CallUi(
    val phase: Phase = Phase.IDLE,
    val callId: String = "",
    val participants: List<String> = emptyList(),
    val invited: Set<String> = emptySet(),
    val muted: Boolean = false,
    val speaker: Boolean = false,
    val mutedPeers: Set<String> = emptySet(),
    val status: Map<String, String> = emptyMap(),
    val startedAt: Long = 0L,
    val incoming: List<Incoming> = emptyList(),
    val locked: Boolean = false
)

/**
 * Appels de groupe en WebRTC natif. Même protocole de signalisation que le serveur actuel
 * (call_start / call_join / call_signal ...), donc compatible avec les pages web existantes.
 * Tout tourne dans le service au premier plan : l'appel survit à la veille et au changement d'appli.
 */
object CallEngine {
    val ui = MutableStateFlow(CallUi())

    private lateinit var app: Application
    private var factory: PeerConnectionFactory? = null
    private var source: AudioSource? = null
    private var track: AudioTrack? = null
    private var focus: AudioFocusRequest? = null
    private val peers = HashMap<String, Peer>()
    private var statsJob: Job? = null
    @Volatile private var lastRemoteVoice = 0L

    /** Vrai si quelqu'un d'autre (non coupé) est en train de parler : sert à ignorer les commandes parasites. */
    val remoteSpeaking: Boolean get() = System.currentTimeMillis() - lastRemoteVoice < 600

    private fun pollStats() {
        val muted = ui.value.mutedPeers
        peers.values.toList().forEach { p ->
            if (p.user in muted) return@forEach
            try {
                p.pc.getStats { report ->
                    report.statsMap.values.forEach { s ->
                        if (s.type == "inbound-rtp" && (s.members["kind"] == "audio" || s.members["mediaType"] == "audio")) {
                            val lvl = (s.members["audioLevel"] as? Number)?.toDouble() ?: 0.0
                            if (lvl > 0.02) lastRemoteVoice = System.currentTimeMillis()
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private class Peer(val user: String, val pc: PeerConnection) {
        var remoteSet = false
        val cand = ArrayList<IceCandidate>()
        var remote: AudioTrack? = null
    }

    open class SdpAdapter : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) {}
        override fun onSetFailure(e: String?) {}
    }

    fun init(a: Application) { app = a }

    private fun upd(f: (CallUi) -> CallUi) { ui.value = f(ui.value) }
    private fun audioManager() = app.getSystemService(AudioManager::class.java)

    // ------------------------------------------------------------------ WebRTC
    private fun ensureFactory(): PeerConnectionFactory {
        factory?.let { return it }
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions()
        )
        // Le micro d'appel est « écouté » aussi par la reconnaissance vocale : un seul micro, deux usages.
        val adm = JavaAudioDeviceModule.builder(app)
            .setUseHardwareAcousticEchoCanceler(true)
            .setUseHardwareNoiseSuppressor(true)
            .setSamplesReadyCallback { s -> Voice.onCallSamples(s.data, s.sampleRate, s.channelCount) }
            .createAudioDeviceModule()
        return PeerConnectionFactory.builder().setAudioDeviceModule(adm)
            .createPeerConnectionFactory().also { factory = it }
    }

    private fun startMedia() {
        val f = ensureFactory()
        val c = MediaConstraints()
        listOf("googEchoCancellation", "googNoiseSuppression", "googAutoGainControl", "googHighpassFilter")
            .forEach { c.mandatory.add(MediaConstraints.KeyValuePair(it, "true")) }
        val src = f.createAudioSource(c)
        source = src
        track = f.createAudioTrack("mic0", src).also { it.setEnabled(!ui.value.muted) }
        audioOn()
        statsJob?.cancel()
        statsJob = Hub.scope.launch { while (true) { delay(250); pollStats() } }
    }

    @Suppress("DEPRECATION")
    private fun audioOn() {
        val am = audioManager()
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            ).build()
        am.requestAudioFocus(req)
        focus = req
        am.isSpeakerphoneOn = ui.value.speaker
    }

    @Suppress("DEPRECATION")
    private fun audioOff() {
        val am = audioManager()
        focus?.let { am.abandonAudioFocusRequest(it) }
        focus = null
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    private fun signal(to: String, payload: JSONObject) {
        Hub.send(
            JSONObject().put("type", "call_signal").put("call_id", ui.value.callId)
                .put("to", to).put("payload", payload)
        )
    }

    private fun setStatus(user: String, s: String) = upd { it.copy(status = it.status + (user to s)) }

    private fun createPeer(user: String): Peer {
        peers[user]?.let { return it }
        val cfg = PeerConnection.RTCConfiguration(emptyList()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        lateinit var peer: Peer
        val pc = ensureFactory().createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                signal(
                    user, JSONObject().put("kind", "ice").put(
                        "candidate", JSONObject().put("candidate", c.sdp)
                            .put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)
                    )
                )
            }
            override fun onConnectionChange(s: PeerConnection.PeerConnectionState) {
                Hub.scope.launch {
                    setStatus(
                        user, when (s) {
                            PeerConnection.PeerConnectionState.CONNECTED -> "connecté"
                            PeerConnection.PeerConnectionState.FAILED -> "connexion échouée"
                            PeerConnection.PeerConnectionState.DISCONNECTED -> "connexion instable"
                            else -> "connexion…"
                        }
                    )
                }
            }
            override fun onAddTrack(r: RtpReceiver, s: Array<out MediaStream>) {
                val t = r.track() as? AudioTrack ?: return
                Hub.scope.launch {
                    peer.remote = t
                    t.setEnabled(user !in ui.value.mutedPeers)
                }
            }
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
        })!!
        peer = Peer(user, pc)
        track?.let { pc.addTrack(it, listOf("stream0")) }
        peers[user] = peer
        setStatus(user, "connexion…")
        return peer
    }

    private fun closePeer(user: String) {
        val p = peers.remove(user) ?: return
        try { p.pc.close(); p.pc.dispose() } catch (_: Exception) {}
        upd { it.copy(status = it.status - user) }
    }

    private fun makeOffer(user: String) {
        val p = createPeer(user)
        p.pc.createOffer(object : SdpAdapter() {
            override fun onCreateSuccess(d: SessionDescription?) {
                d ?: return
                p.pc.setLocalDescription(object : SdpAdapter() {
                    override fun onSetSuccess() {
                        signal(user, JSONObject().put("kind", "offer")
                            .put("sdp", JSONObject().put("type", "offer").put("sdp", d.description)))
                    }
                }, d)
            }
        }, MediaConstraints())
    }

    private fun flush(p: Peer) {
        p.cand.toList().forEach { p.pc.addIceCandidate(it) }
        p.cand.clear()
    }

    private fun onSignal(from: String, p: JSONObject) {
        val s = ui.value
        if (s.phase != Phase.ACTIVE || from !in s.participants) return
        val peer = createPeer(from)
        when (p.optString("kind")) {
            "offer" -> {
                val sdp = p.getJSONObject("sdp").getString("sdp")
                peer.pc.setRemoteDescription(object : SdpAdapter() {
                    override fun onSetSuccess() {
                        Hub.scope.launch {
                            peer.remoteSet = true
                            flush(peer)
                            peer.pc.createAnswer(object : SdpAdapter() {
                                override fun onCreateSuccess(d: SessionDescription?) {
                                    d ?: return
                                    peer.pc.setLocalDescription(object : SdpAdapter() {
                                        override fun onSetSuccess() {
                                            signal(from, JSONObject().put("kind", "answer")
                                                .put("sdp", JSONObject().put("type", "answer").put("sdp", d.description)))
                                        }
                                    }, d)
                                }
                            }, MediaConstraints())
                        }
                    }
                }, SessionDescription(SessionDescription.Type.OFFER, sdp))
            }
            "answer" -> {
                val sdp = p.getJSONObject("sdp").getString("sdp")
                peer.pc.setRemoteDescription(object : SdpAdapter() {
                    override fun onSetSuccess() {
                        Hub.scope.launch { peer.remoteSet = true; flush(peer) }
                    }
                }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
            }
            "ice" -> {
                val c = p.optJSONObject("candidate") ?: return
                val mid = if (c.isNull("sdpMid")) null else c.optString("sdpMid")
                val ic = IceCandidate(mid, c.optInt("sdpMLineIndex", 0), c.optString("candidate"))
                if (peer.remoteSet) peer.pc.addIceCandidate(ic) else peer.cand.add(ic)
            }
        }
    }

    // ------------------------------------------------------------------ actions
    fun startCall(invitees: List<String>) {
        if (ui.value.phase != Phase.IDLE || invitees.isEmpty()) return
        upd { it.copy(phase = Phase.STARTING) }
        Hub.send(JSONObject().put("type", "call_start").put("invitees", JSONArray(invitees)))
        guard(Phase.STARTING)
    }

    fun accept(callId: String) {
        if (ui.value.phase != Phase.IDLE || callId.isBlank()) return
        upd { it.copy(phase = Phase.JOINING, callId = callId, incoming = emptyList()) }
        Hub.send(JSONObject().put("type", "call_join").put("call_id", callId))
        guard(Phase.JOINING)
    }

    fun decline(callId: String) {
        Hub.send(JSONObject().put("type", "call_decline").put("call_id", callId).put("reason", "declined"))
        upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callId }) }
    }

    fun hangup() {
        if (ui.value.phase == Phase.IDLE) return
        Hub.send(JSONObject().put("type", "call_leave"))
        endLocal(null)
    }

    fun invite(users: List<String>) {
        val s = ui.value
        if (s.phase != Phase.ACTIVE || users.isEmpty()) return
        Hub.send(JSONObject().put("type", "call_invite").put("call_id", s.callId).put("invitees", JSONArray(users)))
    }

    /** Verrou tactile : l'écran ne répond plus qu'à un appui long sur « déverrouiller ». */
    fun setLocked(on: Boolean) {
        if (on && ui.value.phase != Phase.ACTIVE) return
        upd { it.copy(locked = on) }
    }

    fun setMuted(on: Boolean) {
        track?.setEnabled(!on)
        upd { it.copy(muted = on) }
    }

    @Suppress("DEPRECATION")
    fun setSpeaker(on: Boolean) {
        upd { it.copy(speaker = on) }
        if (ui.value.phase != Phase.IDLE) audioManager().isSpeakerphoneOn = on
    }

    fun setPeerMuted(user: String, on: Boolean) {
        peers[user]?.remote?.setEnabled(!on)
        upd { it.copy(mutedPeers = if (on) it.mutedPeers + user else it.mutedPeers - user) }
    }

    fun setAllOthersMuted(on: Boolean) {
        ui.value.participants.filter { it != Prefs.username }.forEach { setPeerMuted(it, on) }
    }

    private fun guard(p: Phase) {
        Hub.scope.launch {
            delay(12_000)
            if (ui.value.phase == p) {
                Hub.events.tryEmit("Pas de réponse du serveur pour l'appel")
                endLocal(null)
            }
        }
    }

    private fun enter(call: JSONObject, existing: List<String>) {
        val parts = strings(call.optJSONArray("participants"))
        upd {
            it.copy(
                phase = Phase.ACTIVE, callId = call.getString("call_id"), participants = parts,
                invited = strings(call.optJSONArray("invited")).toSet(),
                startedAt = System.currentTimeMillis(), incoming = emptyList()
            )
        }
        startMedia()
        // Le nouvel arrivant envoie une offre à chaque personne déjà présente
        existing.filter { it != Prefs.username }.forEach { makeOffer(it) }
    }

    private fun endLocal(notice: String?) {
        statsJob?.cancel(); statsJob = null
        peers.keys.toList().forEach { closePeer(it) }
        try { track?.dispose(); source?.dispose() } catch (_: Exception) {}
        track = null; source = null
        if (ui.value.phase != Phase.IDLE) audioOff()
        val keep = ui.value
        ui.value = CallUi(speaker = keep.speaker, incoming = keep.incoming)
        notice?.let { Hub.events.tryEmit(it) }
    }

    fun onSocketLost() {
        if (ui.value.phase != Phase.IDLE) endLocal("Connexion au serveur perdue : appel coupé")
        upd { it.copy(incoming = emptyList()) }
    }

    private fun strings(a: JSONArray?): List<String> {
        val out = ArrayList<String>()
        if (a != null) for (i in 0 until a.length()) out.add(a.getString(i))
        return out
    }

    // ------------------------------------------------------------------ messages du serveur
    fun onMessage(d: JSONObject) {
        val s = ui.value
        val callIdMsg = d.optString("call_id")
        when (d.optString("type")) {
            "call_started" -> {
                val c = d.getJSONObject("call")
                if (s.phase == Phase.STARTING) enter(c, emptyList())
                else Hub.send(JSONObject().put("type", "call_leave"))
            }
            "call_joined" -> {
                val c = d.getJSONObject("call")
                if (s.phase == Phase.JOINING) enter(c, strings(d.optJSONArray("peers")))
                else Hub.send(JSONObject().put("type", "call_leave"))
            }
            "call_incoming" -> {
                val id = d.getJSONObject("call").getString("call_id")
                if (s.phase != Phase.IDLE) {
                    Hub.send(JSONObject().put("type", "call_decline").put("call_id", id).put("reason", "busy"))
                } else if (s.incoming.none { it.callId == id }) {
                    upd { it.copy(incoming = it.incoming + Incoming(id, d.optString("from"))) }
                }
            }
            "call_invited" -> if (callIdMsg == s.callId) {
                upd { it.copy(invited = strings(d.optJSONArray("invited")).toSet()) }
            }
            "call_participant_joined" -> if (callIdMsg == s.callId) {
                val u = d.optString("username")
                val inv = strings(d.optJSONObject("call")?.optJSONArray("invited")).toSet()
                upd {
                    it.copy(
                        participants = if (u in it.participants) it.participants else it.participants + u,
                        invited = inv
                    )
                }
                Hub.events.tryEmit("$u a rejoint l'appel")
            }
            "call_participant_left" -> if (callIdMsg == s.callId) {
                val u = d.optString("username")
                upd { it.copy(participants = it.participants - u) }
                closePeer(u)
                Hub.events.tryEmit("$u a quitté l'appel")
            }
            "call_declined" -> if (callIdMsg == s.callId) {
                val u = d.optString("username")
                upd { it.copy(invited = it.invited - u) }
                Hub.events.tryEmit(
                    when (d.optString("reason")) {
                        "no_answer" -> "$u n'a pas répondu"
                        "busy" -> "$u est déjà en appel"
                        else -> "$u a refusé l'appel"
                    }
                )
            }
            "call_invite_cancelled" -> {
                upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callIdMsg }) }
                if (d.optString("reason") == "missed") Hub.events.tryEmit("Appel manqué")
            }
            "call_signal" -> if (callIdMsg == s.callId) {
                d.optJSONObject("payload")?.let { onSignal(d.optString("from"), it) }
            }
            "call_ended" -> {
                if (callIdMsg == s.callId) endLocal(d.optString("reason").ifBlank { "Appel terminé" })
                else upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callIdMsg }) }
            }
            "call_notice" -> Hub.events.tryEmit(d.optString("text"))
            "call_error" -> {
                Hub.events.tryEmit(d.optString("text").ifBlank { "Erreur d'appel" })
                upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callIdMsg }) }
                if (s.phase == Phase.STARTING || s.phase == Phase.JOINING) endLocal(null)
            }
        }
    }
}
