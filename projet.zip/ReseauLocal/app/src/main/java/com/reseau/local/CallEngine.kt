package com.reseau.local

import android.app.Application
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import kotlinx.coroutines.Job
import java.util.UUID
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule

enum class Phase { IDLE, STARTING, JOINING, ACTIVE }

/** [via] : identifiant de l'appareil appairé quand l'appel arrive en direct (sans serveur). */
data class Incoming(val callId: String, val from: String, val via: String? = null)

data class CallUi(
    val phase: Phase = Phase.IDLE,
    val callId: String = "",
    val participants: List<String> = emptyList(),
    val invited: Set<String> = emptySet(),
    val muted: Boolean = false,
    val speaker: Boolean = false,
    val mutedPeers: Set<String> = emptySet(),
    val status: Map<String, String> = emptyMap(),
    val startedAt: Long = 0L,
    val incoming: List<Incoming> = emptyList(),
    val locked: Boolean = false,
    /** Appel direct entre deux appareils appairés (sans serveur). */
    val direct: Boolean = false
)

/**
 * Appels de groupe en WebRTC natif. Même protocole de signalisation que le serveur actuel
 * (call_start / call_join / call_signal ...), donc compatible avec les pages web existantes.
 * Tout tourne dans le service au premier plan : l'appel survit à la veille et au changement d'appli.
 */
object CallEngine {
    val ui = MutableStateFlow(CallUi())

    private lateinit var app: Application
    private var factory: PeerConnectionFactory? = null
    private var source: AudioSource? = null
    private var track: AudioTrack? = null
    private var focus: AudioFocusRequest? = null
    private val peers = HashMap<String, Peer>()
    private var statsJob: Job? = null
    /** Appareil appairé avec lequel l'appel direct est en cours (null = appel via le serveur). */
    private var via: String? = null
    private var ringJob: Job? = null
    private var lostJob: Job? = null
    @Volatile private var lastRemoteVoice = 0L

    /** Vrai si quelqu'un d'autre (non coupé) est en train de parler : sert à ignorer les commandes parasites. */
    val remoteSpeaking: Boolean get() = System.currentTimeMillis() - lastRemoteVoice < 600

    private fun pollStats() {
        val muted = ui.value.mutedPeers
        peers.values.toList().forEach { p ->
            if (p.user in muted) return@forEach
            try {
                p.pc.getStats { report ->
                    report.statsMap.values.forEach { s ->
                        if (s.type == "inbound-rtp" && (s.members["kind"] == "audio" || s.members["mediaType"] == "audio")) {
                            val lvl = (s.members["audioLevel"] as? Number)?.toDouble() ?: 0.0
                            if (lvl > 0.02) lastRemoteVoice = System.currentTimeMillis()
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private class Peer(val user: String, val pc: PeerConnection) {
        var remoteSet = false
        val cand = ArrayList<IceCandidate>()
        var remote: AudioTrack? = null
    }

    open class SdpAdapter : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) {}
        override fun onSetFailure(e: String?) {}
    }

    fun init(a: Application) { app = a }

    /** Mon nom dans l'appel en cours : nom d'appareil en appel direct, nom d'utilisateur du serveur sinon. */
    fun myName(): String = if (ui.value.direct) Prefs.deviceName else Prefs.username

    private fun upd(f: (CallUi) -> CallUi) { ui.value = f(ui.value) }
    private fun audioManager() = app.getSystemService(AudioManager::class.java)

    // ------------------------------------------------------------------ WebRTC
    private fun ensureFactory(): PeerConnectionFactory {
        factory?.let { return it }
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions()
        )
        // Le micro d'appel est « écouté » aussi par la reconnaissance vocale : un seul micro, deux usages.
        val adm = JavaAudioDeviceModule.builder(app)
            .setUseHardwareAcousticEchoCanceler(true)
            .setUseHardwareNoiseSuppressor(true)
            .setSamplesReadyCallback { s -> Voice.onCallSamples(s.data, s.sampleRate, s.channelCount) }
            .createAudioDeviceModule()
        return PeerConnectionFactory.builder().setAudioDeviceModule(adm)
            .createPeerConnectionFactory().also { factory = it }
    }

    private fun startMedia() {
        val f = ensureFactory()
        val c = MediaConstraints()
        listOf("googEchoCancellation", "googNoiseSuppression", "googAutoGainControl", "googHighpassFilter")
            .forEach { c.mandatory.add(MediaConstraints.KeyValuePair(it, "true")) }
        val src = f.createAudioSource(c)
        source = src
        track = f.createAudioTrack("mic0", src).also { it.setEnabled(!ui.value.muted) }
        audioOn()
        statsJob?.cancel()
        statsJob = Hub.scope.launch { while (true) { delay(250); pollStats() } }
    }

    @Suppress("DEPRECATION")
    private fun audioOn() {
        val am = audioManager()
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            ).build()
        am.requestAudioFocus(req)
        focus = req
        am.isSpeakerphoneOn = ui.value.speaker
    }

    @Suppress("DEPRECATION")
    private fun audioOff() {
        val am = audioManager()
        focus?.let { am.abandonAudioFocusRequest(it) }
        focus = null
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    private fun signal(to: String, payload: JSONObject) {
        val v = via
        if (v != null) {
            P2p.sendTo(v, JSONObject().put("type", "call_signal").put("call_id", ui.value.callId).put("payload", payload))
            return
        }
        Hub.send(
            JSONObject().put("type", "call_signal").put("call_id", ui.value.callId)
                .put("to", to).put("payload", payload)
        )
    }

    private fun setStatus(user: String, s: String) = upd { it.copy(status = it.status + (user to s)) }

    private fun createPeer(user: String): Peer {
        peers[user]?.let { return it }
        val cfg = PeerConnection.RTCConfiguration(emptyList()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        lateinit var peer: Peer
        val pc = ensureFactory().createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                signal(
                    user, JSONObject().put("kind", "ice").put(
                        "candidate", JSONObject().put("candidate", c.sdp)
                            .put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)
                    )
                )
            }
            override fun onConnectionChange(s: PeerConnection.PeerConnectionState) {
                Hub.scope.launch {
                    setStatus(
                        user, when (s) {
                            PeerConnection.PeerConnectionState.CONNECTED -> "connecté"
                            PeerConnection.PeerConnectionState.FAILED -> "connexion échouée"
                            PeerConnection.PeerConnectionState.DISCONNECTED -> "connexion instable"
                            else -> "connexion…"
                        }
                    )
                    // Appel direct : plus de serveur pour constater la rupture, c'est la liaison audio qui fait foi
                    if (s == PeerConnection.PeerConnectionState.FAILED && via != null && ui.value.phase != Phase.IDLE) {
                        hangup(); Hub.events.tryEmit("Connexion audio perdue : appel coupé")
                    }
                }
            }
            override fun onAddTrack(r: RtpReceiver, s: Array<out MediaStream>) {
                val t = r.track() as? AudioTrack ?: return
                Hub.scope.launch {
                    peer.remote = t
                    t.setEnabled(user !in ui.value.mutedPeers)
                }
            }
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
        })!!
        peer = Peer(user, pc)
        track?.let { pc.addTrack(it, listOf("stream0")) }
        peers[user] = peer
        setStatus(user, "connexion…")
        return peer
    }

    private fun closePeer(user: String) {
        val p = peers.remove(user) ?: return
        try { p.pc.close(); p.pc.dispose() } catch (_: Exception) {}
        upd { it.copy(status = it.status - user) }
    }

    private fun makeOffer(user: String) {
        val p = createPeer(user)
        p.pc.createOffer(object : SdpAdapter() {
            override fun onCreateSuccess(d: SessionDescription?) {
                d ?: return
                p.pc.setLocalDescription(object : SdpAdapter() {
                    override fun onSetSuccess() {
                        signal(user, JSONObject().put("kind", "offer")
                            .put("sdp", JSONObject().put("type", "offer").put("sdp", d.description)))
                    }
                }, d)
            }
        }, MediaConstraints())
    }

    private fun flush(p: Peer) {
        p.cand.toList().forEach { p.pc.addIceCandidate(it) }
        p.cand.clear()
    }

    private fun onSignal(from: String, p: JSONObject) {
        val s = ui.value
        if (s.phase != Phase.ACTIVE || from !in s.participants) return
        val peer = createPeer(from)
        when (p.optString("kind")) {
            "offer" -> {
                val sdp = p.getJSONObject("sdp").getString("sdp")
                peer.pc.setRemoteDescription(object : SdpAdapter() {
                    override fun onSetSuccess() {
                        Hub.scope.launch {
                            peer.remoteSet = true
                            flush(peer)
                            peer.pc.createAnswer(object : SdpAdapter() {
                                override fun onCreateSuccess(d: SessionDescription?) {
                                    d ?: return
                                    peer.pc.setLocalDescription(object : SdpAdapter() {
                                        override fun onSetSuccess() {
                                            signal(from, JSONObject().put("kind", "answer")
                                                .put("sdp", JSONObject().put("type", "answer").put("sdp", d.description)))
                                        }
                                    }, d)
                                }
                            }, MediaConstraints())
                        }
                    }
                }, SessionDescription(SessionDescription.Type.OFFER, sdp))
            }
            "answer" -> {
                val sdp = p.getJSONObject("sdp").getString("sdp")
                peer.pc.setRemoteDescription(object : SdpAdapter() {
                    override fun onSetSuccess() {
                        Hub.scope.launch { peer.remoteSet = true; flush(peer) }
                    }
                }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
            }
            "ice" -> {
                val c = p.optJSONObject("candidate") ?: return
                val mid = if (c.isNull("sdpMid")) null else c.optString("sdpMid")
                val ic = IceCandidate(mid, c.optInt("sdpMLineIndex", 0), c.optString("candidate"))
                if (peer.remoteSet) peer.pc.addIceCandidate(ic) else peer.cand.add(ic)
            }
        }
    }

    // ------------------------------------------------------------------ actions
    fun startCall(invitees: List<String>) {
        if (ui.value.phase != Phase.IDLE || invitees.isEmpty()) return
        upd { it.copy(phase = Phase.STARTING) }
        Hub.send(JSONObject().put("type", "call_start").put("invitees", JSONArray(invitees)))
        guard(Phase.STARTING)
    }

    fun accept(callId: String) {
        if (ui.value.phase != Phase.IDLE || callId.isBlank()) return
        val direct = ui.value.incoming.firstOrNull { it.callId == callId }
        if (direct != null && direct.via != null) { acceptPeer(direct); return }
        upd { it.copy(phase = Phase.JOINING, callId = callId, incoming = emptyList()) }
        Hub.send(JSONObject().put("type", "call_join").put("call_id", callId))
        guard(Phase.JOINING)
    }

    fun decline(callId: String) {
        val viaPeer = ui.value.incoming.firstOrNull { it.callId == callId }?.via
        if (viaPeer != null) {
            P2p.sendTo(viaPeer, JSONObject().put("type", "call_decline").put("call_id", callId).put("reason", "declined"))
            upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callId }) }
            return
        }
        Hub.send(JSONObject().put("type", "call_decline").put("call_id", callId).put("reason", "declined"))
        upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callId }) }
    }

    fun hangup() {
        if (ui.value.phase == Phase.IDLE) return
        val v = via
        if (v != null) P2p.sendTo(v, JSONObject().put("type", "call_leave").put("call_id", ui.value.callId))
        else Hub.send(JSONObject().put("type", "call_leave"))
        endLocal(null)
    }

    fun invite(users: List<String>) {
        val s = ui.value
        if (s.phase != Phase.ACTIVE || users.isEmpty()) return
        if (via != null) { Hub.events.tryEmit("Un appel direct se fait à deux"); return }
        Hub.send(JSONObject().put("type", "call_invite").put("call_id", s.callId).put("invitees", JSONArray(users)))
    }

    /** Verrou tactile : l'écran ne répond plus qu'à un appui long sur « déverrouiller ». */
    fun setLocked(on: Boolean) {
        if (on && ui.value.phase != Phase.ACTIVE) return
        upd { it.copy(locked = on) }
    }

    fun setMuted(on: Boolean) {
        track?.setEnabled(!on)
        upd { it.copy(muted = on) }
    }

    @Suppress("DEPRECATION")
    fun setSpeaker(on: Boolean) {
        upd { it.copy(speaker = on) }
        if (ui.value.phase != Phase.IDLE) audioManager().isSpeakerphoneOn = on
    }

    fun setPeerMuted(user: String, on: Boolean) {
        peers[user]?.remote?.setEnabled(!on)
        upd { it.copy(mutedPeers = if (on) it.mutedPeers + user else it.mutedPeers - user) }
    }

    fun setAllOthersMuted(on: Boolean) {
        ui.value.participants.filter { it != myName() }.forEach { setPeerMuted(it, on) }
    }

    private fun guard(p: Phase) {
        Hub.scope.launch {
            delay(12_000)
            if (ui.value.phase == p) {
                Hub.events.tryEmit("Pas de réponse du serveur pour l'appel")
                endLocal(null)
            }
        }
    }

    private fun enter(call: JSONObject, existing: List<String>) {
        val parts = strings(call.optJSONArray("participants"))
        upd {
            it.copy(
                phase = Phase.ACTIVE, callId = call.getString("call_id"), participants = parts,
                invited = strings(call.optJSONArray("invited")).toSet(),
                startedAt = System.currentTimeMillis(), incoming = emptyList()
            )
        }
        startMedia()
        // Le nouvel arrivant envoie une offre à chaque personne déjà présente
        existing.filter { it != Prefs.username }.forEach { makeOffer(it) }
    }

    private fun endLocal(notice: String?) {
        ringJob?.cancel(); ringJob = null
        lostJob?.cancel(); lostJob = null
        via = null
        statsJob?.cancel(); statsJob = null
        peers.keys.toList().forEach { closePeer(it) }
        try { track?.dispose(); source?.dispose() } catch (_: Exception) {}
        track = null; source = null
        if (ui.value.phase != Phase.IDLE) audioOff()
        val keep = ui.value
        ui.value = CallUi(speaker = keep.speaker, incoming = keep.incoming)
        notice?.let { Hub.events.tryEmit(it) }
    }

    fun onSocketLost() {
        // Un appel direct ne dépend pas du serveur : il continue
        if (ui.value.phase != Phase.IDLE && via == null) endLocal("Connexion au serveur perdue : appel coupé")
        upd { it.copy(incoming = it.incoming.filter { i -> i.via != null }) }
    }

    private fun strings(a: JSONArray?): List<String> {
        val out = ArrayList<String>()
        if (a != null) for (i in 0 until a.length()) out.add(a.getString(i))
        return out
    }

    // ------------------------------------------------------------------ appels directs (sans serveur)
    /** Appelle un appareil appairé : la sonnerie, l'acceptation et la signalisation WebRTC passent par la liaison directe. */
    fun startPeerCall(peerId: String) {
        if (ui.value.phase != Phase.IDLE) return
        val rec = P2p.peer(peerId) ?: return
        if (!P2p.isOnline(peerId)) { Hub.events.tryEmit("${rec.name} n'est pas joignable (même réseau ?)"); return }
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        via = peerId
        upd {
            it.copy(
                phase = Phase.ACTIVE, callId = id, participants = listOf(Prefs.deviceName), invited = setOf(rec.name),
                startedAt = System.currentTimeMillis(), incoming = emptyList(), direct = true
            )
        }
        startMedia()
        P2p.sendTo(peerId, JSONObject().put("type", "call_invite").put("call_id", id).put("from", Prefs.deviceName))
        ringJob = Hub.scope.launch {
            delay(45_000)
            val s = ui.value
            if (s.callId == id && s.invited.isNotEmpty() && via == peerId) {
                P2p.sendTo(peerId, JSONObject().put("type", "call_cancel").put("call_id", id))
                endLocal("${rec.name} n'a pas répondu")
            }
        }
    }

    private fun acceptPeer(inc: Incoming) {
        val pid = inc.via ?: return
        if (ui.value.phase != Phase.IDLE) return
        if (!P2p.isOnline(pid)) {
            upd { it.copy(incoming = it.incoming.filter { i -> i.callId != inc.callId }) }
            Hub.events.tryEmit("${inc.from} n'est plus joignable")
            return
        }
        via = pid
        upd {
            it.copy(
                phase = Phase.ACTIVE, callId = inc.callId, participants = listOf(inc.from, Prefs.deviceName), invited = emptySet(),
                startedAt = System.currentTimeMillis(), incoming = emptyList(), direct = true
            )
        }
        startMedia()
        P2p.sendTo(pid, JSONObject().put("type", "call_accept").put("call_id", inc.callId))
        // Celui qui rejoint envoie l'offre WebRTC, comme dans un appel via le serveur
        makeOffer(inc.from)
    }

    /** Message d'appel reçu d'un appareil appairé. */
    fun onPeerMessage(peerId: String, name: String, d: JSONObject) {
        val s = ui.value
        val id = d.optString("call_id")
        val mine = via == peerId && id == s.callId
        when (d.optString("type")) {
            "call_invite" -> {
                if (s.phase != Phase.IDLE) {
                    P2p.sendTo(peerId, JSONObject().put("type", "call_decline").put("call_id", id).put("reason", "busy"))
                } else if (id.isNotBlank() && s.incoming.none { it.callId == id }) {
                    upd { it.copy(incoming = it.incoming + Incoming(id, name, peerId)) }
                }
            }
            "call_accept" -> if (mine && s.phase == Phase.ACTIVE) {
                ringJob?.cancel(); ringJob = null
                upd { it.copy(participants = if (name in it.participants) it.participants else it.participants + name, invited = it.invited - name) }
                Hub.events.tryEmit("$name a rejoint l'appel")
            }
            "call_decline" -> if (mine) {
                endLocal(if (d.optString("reason") == "busy") "$name est déjà en appel" else "$name a refusé l'appel")
            }
            "call_cancel" -> {
                upd { it.copy(incoming = it.incoming.filter { i -> i.callId != id }) }
                Hub.events.tryEmit("Appel manqué de $name")
            }
            "call_leave" -> if (mine) endLocal("$name a raccroché")
            "call_signal" -> if (mine) d.optJSONObject("payload")?.let { onSignal(name, it) }
        }
    }

    /** La liaison avec [peerId] est tombée : on laisse 15 s à la connexion pour revenir avant de couper un appel direct. */
    fun onPeerLost(peerId: String) {
        upd { it.copy(incoming = it.incoming.filter { i -> i.via != peerId }) }
        if (via != peerId || ui.value.phase == Phase.IDLE) return
        val id = ui.value.callId
        lostJob?.cancel()
        lostJob = Hub.scope.launch {
            delay(15_000)
            if (via == peerId && ui.value.callId == id && !P2p.isOnline(peerId)) {
                endLocal("Connexion avec ${P2p.peerName(peerId)} perdue : appel coupé")
            }
        }
    }

    // ------------------------------------------------------------------ messages du serveur
    fun onMessage(d: JSONObject) {
        val s = ui.value
        val callIdMsg = d.optString("call_id")
        when (d.optString("type")) {
            "call_started" -> {
                val c = d.getJSONObject("call")
                if (s.phase == Phase.STARTING) enter(c, emptyList())
                else Hub.send(JSONObject().put("type", "call_leave"))
            }
            "call_joined" -> {
                val c = d.getJSONObject("call")
                if (s.phase == Phase.JOINING) enter(c, strings(d.optJSONArray("peers")))
                else Hub.send(JSONObject().put("type", "call_leave"))
            }
            "call_incoming" -> {
                val id = d.getJSONObject("call").getString("call_id")
                if (s.phase != Phase.IDLE) {
                    Hub.send(JSONObject().put("type", "call_decline").put("call_id", id).put("reason", "busy"))
                } else if (s.incoming.none { it.callId == id }) {
                    upd { it.copy(incoming = it.incoming + Incoming(id, d.optString("from"))) }
                }
            }
            "call_invited" -> if (callIdMsg == s.callId) {
                upd { it.copy(invited = strings(d.optJSONArray("invited")).toSet()) }
            }
            "call_participant_joined" -> if (callIdMsg == s.callId) {
                val u = d.optString("username")
                val inv = strings(d.optJSONObject("call")?.optJSONArray("invited")).toSet()
                upd {
                    it.copy(
                        participants = if (u in it.participants) it.participants else it.participants + u,
                        invited = inv
                    )
                }
                Hub.events.tryEmit("$u a rejoint l'appel")
            }
            "call_participant_left" -> if (callIdMsg == s.callId) {
                val u = d.optString("username")
                upd { it.copy(participants = it.participants - u) }
                closePeer(u)
                Hub.events.tryEmit("$u a quitté l'appel")
            }
            "call_declined" -> if (callIdMsg == s.callId) {
                val u = d.optString("username")
                upd { it.copy(invited = it.invited - u) }
                Hub.events.tryEmit(
                    when (d.optString("reason")) {
                        "no_answer" -> "$u n'a pas répondu"
                        "busy" -> "$u est déjà en appel"
                        else -> "$u a refusé l'appel"
                    }
                )
            }
            "call_invite_cancelled" -> {
                upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callIdMsg }) }
                if (d.optString("reason") == "missed") Hub.events.tryEmit("Appel manqué")
            }
            "call_signal" -> if (callIdMsg == s.callId) {
                d.optJSONObject("payload")?.let { onSignal(d.optString("from"), it) }
            }
            "call_ended" -> {
                if (callIdMsg == s.callId) endLocal(d.optString("reason").ifBlank { "Appel terminé" })
                else upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callIdMsg }) }
            }
            "call_notice" -> Hub.events.tryEmit(d.optString("text"))
            "call_error" -> {
                Hub.events.tryEmit(d.optString("text").ifBlank { "Erreur d'appel" })
                upd { it.copy(incoming = it.incoming.filter { i -> i.callId != callIdMsg }) }
                if (s.phase == Phase.STARTING || s.phase == Phase.JOINING) endLocal(null)
            }
        }
    }
}
