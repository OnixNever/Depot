package com.reseau.local

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.app.NotificationManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        handleIntent(intent)
        setContent { AppTheme { Root() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        i?.getStringExtra("answer")?.let { id ->
            getSystemService(NotificationManager::class.java).cancel(HubService.NID_CALL)
            CallEngine.accept(id)
        }
    }

    /** Mute « physique » : écran verrouillé pendant un appel, les touches de volume coupent / réactivent le micro. */
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        val ui = CallEngine.ui.value
        if (ui.phase == Phase.ACTIVE && ui.locked &&
            (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP || keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN)
        ) {
            if (event?.repeatCount == 0) CallEngine.setMuted(!ui.muted)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() { super.onStart(); Hub.foreground = true }
    override fun onStop() { super.onStop(); Hub.foreground = false }
}

private fun hasMic(c: android.content.Context) =
    ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

@Composable
fun Root() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(if (Prefs.token.isNotBlank()) "checking" else "login") }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMic(ctx)) { screen = "main"; HubService.start(ctx) } else screen = "perm"
    }

    fun enterMain() {
        val need = ArrayList<String>()
        if (!hasMic(ctx)) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) { screen = "main"; HubService.start(ctx) } else perms.launch(need.toTypedArray())
    }

    when (screen) {
        "checking" -> {
            LaunchedEffect(Unit) {
                try {
                    Api.verify(Prefs.token)
                    enterMain()
                } catch (e: ApiError) {
                    Prefs.token = ""; screen = "login"
                } catch (e: Exception) {
                    enterMain() // serveur injoignable : le service retentera tout seul
                }
            }
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
            }
        }
        "login" -> ConnectScreen(onDone = { enterMain() })
        "perm" -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Le micro est nécessaire pour les appels et les commandes vocales.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = { enterMain() }) { Text("Autoriser le micro") }
        }
        else -> MainScreen(onLogout = { screen = "login" })
    }
}
