package com.reseau.local

import android.content.Context
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoWSD
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.NetworkInterface
import java.net.URLDecoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.TreeSet
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

private typealias Resp = NanoHTTPD.Response
private typealias St = NanoHTTPD.Response.Status
private typealias Sess = NanoHTTPD.IHTTPSession

/**
 * Serveur embarqué : le téléphone joue le rôle de serveur.py (même API HTTP, même WebSocket,
 * même « standard téléphonique » pour les appels). Les autres appareils (autres téléphones,
 * pages web) s'y connectent avec l'adresse du téléphone ; l'audio, lui, reste direct entre appareils.
 */
class LocalServer private constructor(private val ctx: Context, port: Int) : NanoWSD(port) {

    companion object {
        const val PORT = 8000
        private const val MAX_MESSAGE = 5000
        private const val RING_SECONDS = 45L
        private const val MAX_PARTICIPANTS = 8
        private val COLORS = listOf("#6366f1", "#ec4899", "#14b8a6", "#f59e0b", "#22c55e", "#3b82f6", "#ef4444", "#8b5cf6")

        @Volatile var instance: LocalServer? = null

        @Synchronized
        fun start(c: Context): LocalServer {
            instance?.let { return it }
            val s = LocalServer(c.applicationContext, PORT)
            s.start(0, true)
            instance = s
            Nsd.register(c.applicationContext, PORT)
            return s
        }

        @Synchronized
        fun stop() {
            instance?.let {
                try { it.stop() } catch (_: Exception) {}
                Nsd.unregister(it.ctx)
            }
            instance = null
        }

        fun localIps(): List<String> = try {
            NetworkInterface.getNetworkInterfaces().toList().flatMap { n ->
                if (!n.isUp || n.isLoopback) emptyList()
                else n.inetAddresses.toList().filter { it.isSiteLocalAddress && !it.hostAddress.contains(':') }.map { it.hostAddress }
            }
        } catch (_: Exception) { emptyList() }
    }

    private class HttpErr(val status: St, val msg: String) : Exception(msg)

    private val lock = Any()
    private val dir = File(ctx.filesDir, "server").apply { mkdirs() }
    private val uploads = File(dir, "uploads").apply { mkdirs() }
    private val users = LinkedHashMap<String, JSONObject>()
    private val sessions = HashMap<String, JSONObject>()
    private val messages = ArrayList<JSONObject>()
    private var lastId = 0L
    private val projects = LinkedHashMap<String, JSONObject>()
    private val conns = ConcurrentHashMap<String, Ws>()
    private val calls = HashMap<String, Call>()
    private val userCall = HashMap<String, String>()
    private val sched = Executors.newSingleThreadScheduledExecutor()
    private val rnd = SecureRandom()

    init {
        readObj(File(dir, "users.json")).let { o -> o.keys().forEach { k -> users[k] = o.getJSONObject(k) } }
        readObj(File(dir, "sessions.json")).let { o -> o.keys().forEach { k -> sessions[k] = o.getJSONObject(k) } }
        readObj(File(dir, "messages.json")).let { o ->
            lastId = o.optLong("last_id", 0)
            o.optJSONArray("messages")?.let { a -> for (i in 0 until a.length()) messages.add(a.getJSONObject(i)) }
        }
        readObj(File(dir, "projects.json")).let { o -> o.keys().forEach { k -> projects[k] = o.getJSONObject(k) } }
    }

    // ------------------------------------------------------------------ stockage
    private fun readObj(f: File): JSONObject = try { if (f.exists()) JSONObject(f.readText()) else JSONObject() } catch (_: Exception) { JSONObject() }

    private fun writeAtomic(f: File, text: String) {
        val t = File(f.path + ".tmp")
        t.writeText(text)
        if (!t.renameTo(f)) { f.writeText(text); t.delete() }
    }

    private fun saveUsers() = writeAtomic(File(dir, "users.json"), JSONObject().also { o -> users.forEach { (k, v) -> o.put(k, v) } }.toString())
    private fun saveSessions() = writeAtomic(File(dir, "sessions.json"), JSONObject().also { o -> sessions.forEach { (k, v) -> o.put(k, v) } }.toString())
    private fun saveMessages() = writeAtomic(File(dir, "messages.json"), JSONObject().put("last_id", lastId).put("messages", JSONArray(messages)).toString())
    private fun saveProjects() = writeAtomic(File(dir, "projects.json"), JSONObject().also { o -> projects.forEach { (k, v) -> o.put(k, v) } }.toString())

    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun newUser(pass: String, role: String): JSONObject {
        val salt = UUID.randomUUID().toString().take(12)
        return JSONObject().put("salt", salt).put("hash", sha("$salt:$pass")).put("role", role)
            .put("color", COLORS[users.size % COLORS.size]).put("created_at", LocalDateTime.now().toString())
    }
    private fun passOk(u: JSONObject, pass: String) = u.optString("hash") == sha("${u.optString("salt")}:$pass")

    // ------------------------------------------------------------------ gestion des comptes (côté téléphone hôte)
    fun listUsers(): List<Pair<String, String>> = synchronized(lock) { users.map { it.key to it.value.optString("role", "user") } }

    /** Premier lancement : le premier compte créé est administrateur. Ensuite : il faut s'identifier avec un compte existant. */
    fun registerFirstAdmin(name: String, pass: String): String? = synchronized(lock) {
        if (name.isBlank() || pass.isBlank()) return "Nom et mot de passe requis"
        if (users.isEmpty()) { users[name] = newUser(pass, "admin"); saveUsers(); return null }
        val u = users[name] ?: return "Ce téléphone est déjà serveur : connecte-toi avec un compte existant"
        return if (passOk(u, pass)) null else "Mot de passe incorrect"
    }

    fun addUser(name: String, pass: String): String? = synchronized(lock) {
        if (name.isBlank() || pass.isBlank()) return "Nom et mot de passe requis"
        if (users.containsKey(name)) return "Ce nom existe déjà"
        users[name] = newUser(pass, "user"); saveUsers(); null
    }

    fun deleteUser(name: String): String? {
        synchronized(lock) {
            if (!users.containsKey(name)) return "Utilisateur introuvable"
            users.remove(name)
            sessions.entries.removeAll { it.value.optString("username") == name }
            saveUsers(); saveSessions()
        }
        conns[name]?.let { w ->
            w.sendJson(JSONObject().put("type", "account_deleted").put("detail", "Votre compte a été supprimé"))
            try { w.close(NanoWSD.WebSocketFrame.CloseCode.NormalClosure, "supprimé", false) } catch (_: Exception) {}
        }
        return null
    }

    // ------------------------------------------------------------------ WebSocket
    inner class Ws(hs: Sess, val user: String, private val valid: Boolean) : NanoWSD.WebSocket(hs) {
        fun sendJson(o: JSONObject) { try { send(o.toString()) } catch (_: Exception) {} }

        override fun onOpen() {
            if (!valid) { try { close(NanoWSD.WebSocketFrame.CloseCode.PolicyViolation, "Utilisateur inconnu", false) } catch (_: Exception) {}; return }
            val old = conns.put(user, this)
            if (old != null && old !== this) try { old.close(NanoWSD.WebSocketFrame.CloseCode.NormalClosure, "remplacé", false) } catch (_: Exception) {}
            broadcastStatus()
        }

        override fun onClose(code: NanoWSD.WebSocketFrame.CloseCode?, reason: String?, initiatedByRemote: Boolean) {
            if (valid) disconnect(user, this)
        }

        override fun onMessage(message: NanoWSD.WebSocketFrame) {
            message.setUnmasked()
            if (valid) handleWs(user, message.textPayload ?: return)
        }

        override fun onPong(pong: NanoWSD.WebSocketFrame?) {}
        override fun onException(exception: IOException?) {}
    }

    override fun openWebSocket(handshake: Sess): NanoWSD.WebSocket {
        val raw = handshake.uri.substringAfter("/ws/", "")
        val name = try { URLDecoder.decode(raw, "UTF-8") } catch (_: Exception) { raw }
        return Ws(handshake, name, synchronized(lock) { users.containsKey(name) })
    }

    private fun broadcast(o: JSONObject) { conns.values.toList().forEach { it.sendJson(o) } }

    private fun broadcastStatus() {
        val names = conns.keys.toList()
        broadcast(JSONObject().put("type", "user_status").put("online_users", JSONArray(names)).put("count", names.size))
    }

    private fun disconnect(user: String, ws: Ws) {
        if (conns[user] !== ws) return
        synchronized(lock) { callLeaveAll(user) }
        conns.remove(user)
        broadcastStatus()
    }

    private fun handleWs(user: String, text: String) {
        val j = try { JSONObject(text) } catch (_: Exception) { return }
        when (val t = j.optString("type")) {
            "ping" -> conns[user]?.sendJson(JSONObject().put("type", "pong"))
            "typing" -> broadcast(JSONObject().put("type", "user_typing").put("username", user).put("is_typing", j.optBoolean("is_typing")))
            else -> if (t.startsWith("call_")) synchronized(lock) { try { callHandle(user, j) } catch (_: Exception) {} }
        }
    }

    // ------------------------------------------------------------------ appels (standard téléphonique)
    private class Call(val id: String, val host: String) {
        val participants = ArrayList<String>()
        val invited = TreeSet<String>()
    }

    private fun pub(c: Call) = JSONObject().put("call_id", c.id).put("host", c.host)
        .put("participants", JSONArray(c.participants)).put("invited", JSONArray(c.invited.toList()))

    private fun sendTo(u: String, o: JSONObject) { conns[u]?.sendJson(o) }
    private fun toParts(c: Call, o: JSONObject, exclude: String? = null) { c.participants.toList().forEach { if (it != exclude) sendTo(it, o) } }
    private fun callError(u: String, text: String, id: String = "") = sendTo(u, JSONObject().put("type", "call_error").put("text", text).put("call_id", id))
    private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optString(it).ifBlank { null } }

    private fun callHandle(user: String, m: JSONObject) {
        when (m.optString("type")) {
            "call_start" -> callStart(user, strs(m.optJSONArray("invitees")))
            "call_join" -> callJoin(user, m.optString("call_id"))
            "call_decline" -> callDecline(user, m.optString("call_id"), m.optString("reason", "declined"))
            "call_leave" -> callLeave(user)
            "call_invite" -> callInviteMsg(user, m.optString("call_id"), strs(m.optJSONArray("invitees")))
            "call_signal" -> callSignal(user, m.optString("call_id"), m.optString("to"), m.optJSONObject("payload"))
        }
    }

    private fun callStart(user: String, invitees: List<String>) {
        if (user in userCall) return callError(user, "Vous êtes déjà dans un appel.")
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        val c = Call(id, user)
        c.participants.add(user)
        calls[id] = c
        userCall[user] = id
        sendTo(user, JSONObject().put("type", "call_started").put("call", pub(c)).put("peers", JSONArray()))
        val notice = callInvite(c, user, invitees)
        if (notice.isNotEmpty()) sendTo(user, JSONObject().put("type", "call_notice").put("text", notice))
        checkEnd(c)
    }

    private fun callInvite(c: Call, inviter: String, invitees: List<String>): String {
        val offline = ArrayList<String>(); val busy = ArrayList<String>(); val now = ArrayList<String>()
        for (u in invitees.distinct()) {
            if (!users.containsKey(u) || u == inviter || u in c.participants || u in c.invited) continue
            if (c.participants.size + c.invited.size >= MAX_PARTICIPANTS) break
            if (!conns.containsKey(u)) { offline.add(u); continue }
            if (userCall.containsKey(u)) { busy.add(u); continue }
            c.invited.add(u); now.add(u)
            sendTo(u, JSONObject().put("type", "call_incoming").put("call", pub(c)).put("from", inviter))
        }
        if (now.isNotEmpty()) {
            toParts(c, JSONObject().put("type", "call_invited").put("call_id", c.id).put("invited", JSONArray(c.invited.toList())))
            sched.schedule(Runnable { synchronized(lock) { try { expire(c.id, now) } catch (_: Exception) {} } }, RING_SECONDS, TimeUnit.SECONDS)
        }
        val parts = ArrayList<String>()
        if (offline.isNotEmpty()) parts.add("hors ligne : " + offline.joinToString(", "))
        if (busy.isNotEmpty()) parts.add("déjà en appel : " + busy.joinToString(", "))
        return if (parts.isEmpty()) "" else "Non joignable(s) - " + parts.joinToString(" ; ")
    }

    private fun expire(id: String, names: List<String>) {
        val c = calls[id] ?: return
        for (u in names) {
            if (c.invited.remove(u)) {
                sendTo(u, JSONObject().put("type", "call_invite_cancelled").put("call_id", id).put("reason", "missed"))
                toParts(c, JSONObject().put("type", "call_declined").put("call_id", id).put("username", u).put("reason", "no_answer"))
            }
        }
        checkEnd(c)
    }

    private fun callJoin(user: String, id: String) {
        val c = calls[id] ?: return callError(user, "Cet appel est déjà terminé.", id)
        userCall[user]?.let { if (it == id) return else return callError(user, "Vous êtes déjà dans un autre appel.", id) }
        if (user !in c.invited) return callError(user, "Vous n'êtes pas invité à cet appel.", id)
        val peers = c.participants.toList()
        c.invited.remove(user)
        c.participants.add(user)
        userCall[user] = id
        sendTo(user, JSONObject().put("type", "call_joined").put("call", pub(c)).put("peers", JSONArray(peers)))
        toParts(c, JSONObject().put("type", "call_participant_joined").put("call_id", id).put("username", user).put("call", pub(c)), exclude = user)
    }

    private fun callDecline(user: String, id: String, reasonIn: String) {
        val c = calls[id] ?: return
        if (user !in c.invited) return
        c.invited.remove(user)
        val reason = if (reasonIn == "declined" || reasonIn == "busy") reasonIn else "declined"
        toParts(c, JSONObject().put("type", "call_declined").put("call_id", id).put("username", user).put("reason", reason))
        checkEnd(c)
    }

    private fun callLeave(user: String) {
        val id = userCall.remove(user) ?: return
        val c = calls[id] ?: return
        c.participants.remove(user)
        toParts(c, JSONObject().put("type", "call_participant_left").put("call_id", id).put("username", user))
        checkEnd(c)
    }

    private fun callInviteMsg(user: String, id: String, invitees: List<String>) {
        val c = calls[id]
        if (c == null || user !in c.participants) return callError(user, "Vous n'êtes pas dans cet appel.", id)
        val notice = callInvite(c, user, invitees)
        if (notice.isNotEmpty()) sendTo(user, JSONObject().put("type", "call_notice").put("text", notice))
    }

    private fun callSignal(user: String, id: String, to: String, payload: JSONObject?) {
        val c = calls[id]
        if (c == null || payload == null || user !in c.participants || to !in c.participants) return
        sendTo(to, JSONObject().put("type", "call_signal").put("call_id", id).put("from", user).put("payload", payload))
    }

    private fun callLeaveAll(user: String) {
        callLeave(user)
        for (c in calls.values.toList()) {
            if (c.invited.remove(user)) {
                toParts(c, JSONObject().put("type", "call_declined").put("call_id", c.id).put("username", user).put("reason", "declined"))
                checkEnd(c)
            }
        }
    }

    private fun checkEnd(c: Call) {
        if (!calls.containsKey(c.id)) return
        val alone = c.participants.size == 1 && c.invited.isEmpty()
        if (c.participants.isNotEmpty() && !alone) return
        for (u in c.participants.toList()) {
            userCall.remove(u)
            sendTo(u, JSONObject().put("type", "call_ended").put("call_id", c.id).put("reason", "Plus personne d'autre dans l'appel."))
        }
        for (u in c.invited.toList()) sendTo(u, JSONObject().put("type", "call_invite_cancelled").put("call_id", c.id).put("reason", "cancelled"))
        calls.remove(c.id)
    }

    // ------------------------------------------------------------------ HTTP
    private fun jr(o: JSONObject, st: St = St.OK): Resp = NanoHTTPD.newFixedLengthResponse(st, "application/json; charset=utf-8", o.toString())
    private fun detail(s: String) = JSONObject().put("detail", s)
    private fun sOrNull(o: JSONObject, k: String): String? = if (o.isNull(k)) null else o.optString(k).ifBlank { null }

    override fun serveHttp(session: Sess): Resp = try {
        route(session)
    } catch (e: HttpErr) {
        jr(detail(e.msg), e.status)
    } catch (e: Exception) {
        jr(detail("Erreur interne : ${e.message}"), St.INTERNAL_ERROR)
    }

    private fun userOrFail(name: String): String {
        if (!users.containsKey(name)) throw HttpErr(St.FORBIDDEN, "Utilisateur non autorisé")
        return name
    }

    private fun route(session: Sess): Resp {
        val uri = session.uri.let { if (it.length > 1) it.trimEnd('/') else it }
        val post = session.method == NanoHTTPD.Method.POST
        val files = HashMap<String, String>()
        if (post) session.parseBody(files)
        val body = try { JSONObject(files["postData"] ?: "{}") } catch (_: Exception) { JSONObject() }
        val q = session.parms

        return when {
            uri == "/" || uri == "/health" -> jr(JSONObject().put("status", "ok").put("mode", "telephone"))
            post && uri == "/login" -> login(body)
            post && uri == "/verify_token" -> verify(body)
            post && uri == "/logout" -> logout(body)
            uri == "/users" -> usersResp()
            post && uri == "/send_message" -> sendMessage(body)
            uri == "/messages" -> getMessages(q["limit"]?.toIntOrNull() ?: 100, q["offset"]?.toIntOrNull() ?: 0)
            post && uri == "/delete_message" -> deleteMessage(body)
            post && uri == "/upload_file" -> upload(session, files)
            uri.startsWith("/uploads/") -> serveFile(session, uri.substringAfterLast('/'))
            post && uri == "/projects/create" -> projectCreate(body)
            uri == "/projects/list" -> projectList(userOrFail(q["username"].orEmpty()))
            uri.startsWith("/projects/get/") -> jr(ownedProject(uri.substringAfterLast('/'), userOrFail(q["username"].orEmpty())))
            post && uri == "/projects/save" -> projectSave(body)
            post && uri == "/projects/delete" -> projectDelete(body)
            uri.startsWith("/projects/export/") -> projectExport(uri.substringAfterLast('/'), q["username"].orEmpty())
            post && uri == "/projects/import" -> projectImport(body)
            post && uri == "/generate_segments" -> generateSegments(body)
            else -> jr(detail("Introuvable"), St.NOT_FOUND)
        }
    }

    private fun login(d: JSONObject): Resp = synchronized(lock) {
        val name = d.optString("username").trim(); val pass = d.optString("password").trim()
        if (name.isEmpty() || pass.isEmpty()) throw HttpErr(St.BAD_REQUEST, "Champs requis")
        val u = users[name] ?: throw HttpErr(St.UNAUTHORIZED, "Utilisateur inconnu")
        if (!passOk(u, pass)) throw HttpErr(St.UNAUTHORIZED, "Mot de passe incorrect")
        u.put("last_login", LocalDateTime.now().toString())
        val token = ByteArray(32).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }
        sessions[token] = JSONObject().put("username", name).put("expires_at", LocalDateTime.now().plusDays(30).toString())
        saveUsers(); saveSessions()
        jr(JSONObject().put("detail", "Connecté").put("username", name).put("online", true)
            .put("color", u.optString("color")).put("role", u.optString("role", "user"))
            .put("token", token).put("expires_in_days", 30))
    }

    private fun sessionUser(token: String): String? {
        val s = sessions[token] ?: return null
        val ok = try { LocalDateTime.parse(s.optString("expires_at")).isAfter(LocalDateTime.now()) } catch (_: Exception) { false }
        val name = s.optString("username")
        if (!ok || !users.containsKey(name)) { sessions.remove(token); saveSessions(); return null }
        return name
    }

    private fun verify(d: JSONObject): Resp = synchronized(lock) {
        val name = sessionUser(d.optString("token").trim()) ?: throw HttpErr(St.UNAUTHORIZED, "Session invalide ou expirée")
        jr(JSONObject().put("valid", true).put("username", name).put("color", users[name]!!.optString("color")).put("role", users[name]!!.optString("role", "user")))
    }

    private fun logout(d: JSONObject): Resp {
        val name = d.optString("username").trim(); val token = d.optString("token").trim()
        synchronized(lock) {
            if (token.isNotEmpty() && sessions.remove(token) != null) saveSessions()
            if (users.containsKey(name)) callLeaveAll(name)
        }
        conns.remove(name)?.let { try { it.close(NanoWSD.WebSocketFrame.CloseCode.NormalClosure, "logout", false) } catch (_: Exception) {} }
        broadcastStatus()
        return jr(detail("Déconnecté"))
    }

    private fun usersResp(): Resp = synchronized(lock) {
        val o = JSONObject()
        users.forEach { (k, v) ->
            o.put(k, JSONObject().put("online", conns.containsKey(k)).put("color", v.optString("color")).put("role", v.optString("role", "user")))
        }
        jr(o)
    }

    private fun sendMessage(d: JSONObject): Resp {
        val msg: JSONObject
        synchronized(lock) {
            val sender = userOrFail(d.optString("sender").trim())
            val content = d.optString("content").trim()
            val fileUrl = sOrNull(d, "file_url")
            if (content.isEmpty() && fileUrl == null) throw HttpErr(St.BAD_REQUEST, "Message vide")
            if (content.length > MAX_MESSAGE) throw HttpErr(St.BAD_REQUEST, "Message trop long (max $MAX_MESSAGE caractères)")
            val now = LocalDateTime.now()
            msg = JSONObject().put("id", lastId).put("sender", sender).put("content", content)
                .put("time", now.toString()).put("hour", now.format(DateTimeFormatter.ofPattern("HH:mm")))
                .put("date", now.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                .put("file_url", fileUrl ?: JSONObject.NULL).put("file_name", sOrNull(d, "file_name") ?: JSONObject.NULL)
                .put("file_size", sOrNull(d, "file_size") ?: JSONObject.NULL)
                .put("sender_color", users[sender]!!.optString("color"))
            messages.add(msg); lastId++
            saveMessages()
        }
        broadcast(JSONObject().put("type", "new_message").put("message", msg))
        return jr(detail("Message envoyé").put("message_id", msg.getLong("id")))
    }

    private fun getMessages(limit: Int, offset: Int): Resp = synchronized(lock) {
        val start = maxOf(0, messages.size - offset - limit)
        val end = maxOf(start, messages.size - offset)
        jr(JSONObject().put("messages", JSONArray(messages.subList(start, end))).put("total", messages.size).put("limit", limit).put("offset", offset))
    }

    private fun deleteMessage(d: JSONObject): Resp {
        val id = d.optLong("message_id", -1)
        synchronized(lock) {
            val name = userOrFail(d.optString("username"))
            val m = messages.firstOrNull { it.optLong("id") == id } ?: throw HttpErr(St.NOT_FOUND, "Message non trouvé")
            val admin = users[name]!!.optString("role") == "admin"
            if (m.optString("sender") != name && !admin) throw HttpErr(St.FORBIDDEN, "Vous ne pouvez supprimer que vos messages")
            sOrNull(m, "file_url")?.let { File(uploads, it.substringAfterLast('/')).delete() }
            messages.remove(m)
            saveMessages()
        }
        broadcast(JSONObject().put("type", "delete_message").put("message_id", id))
        return jr(detail("Message supprimé"))
    }

    private fun fmtSize(n: Long) = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> "%.1f KB".format(n / 1024.0)
        n < 1024L * 1024 * 1024 -> "%.1f MB".format(n / (1024.0 * 1024))
        else -> "%.1f GB".format(n / (1024.0 * 1024 * 1024))
    }

    private fun upload(session: Sess, files: Map<String, String>): Resp {
        val tmp = files["file"] ?: throw HttpErr(St.BAD_REQUEST, "Aucun fichier")
        val original = session.parms["file"] ?: "fichier"
        val ext = if (original.contains('.')) "." + original.substringAfterLast('.').lowercase() else ""
        val name = UUID.randomUUID().toString() + ext
        val dest = File(uploads, name)
        File(tmp).copyTo(dest, overwrite = true)
        return jr(JSONObject().put("file_url", "/uploads/$name").put("file_name", original)
            .put("file_size", fmtSize(dest.length())).put("file_size_bytes", dest.length()).put("detail", "Fichier uploadé avec succès"))
    }

    private fun serveFile(session: Sess, name: String): Resp {
        val f = File(uploads, name.substringAfterLast('/'))
        if (!f.isFile) throw HttpErr(St.NOT_FOUND, "Fichier introuvable")
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
        val len = f.length()
        val range = session.headers["range"]
        if (range != null && range.startsWith("bytes=")) {
            val parts = range.removePrefix("bytes=").split('-')
            val start = parts[0].toLongOrNull() ?: 0L
            val end = (parts.getOrNull(1)?.toLongOrNull() ?: (len - 1)).coerceAtMost(len - 1)
            if (start in 0..end) {
                val fis = FileInputStream(f); fis.skip(start)
                return NanoHTTPD.newFixedLengthResponse(St.PARTIAL_CONTENT, mime, fis, end - start + 1).also {
                    it.addHeader("Content-Range", "bytes $start-$end/$len"); it.addHeader("Accept-Ranges", "bytes")
                }
            }
        }
        return NanoHTTPD.newFixedLengthResponse(St.OK, mime, FileInputStream(f), len).also { it.addHeader("Accept-Ranges", "bytes") }
    }

    // ------------------------------------------------------------------ projets (cartes mentales)
    private fun nodeId() = UUID.randomUUID().toString().take(8)
    private fun makeNode(name: String, id: String = nodeId()) = JSONObject().put("id", id).put("name", name).put("mastered", false).put("children", JSONArray())
    private fun countNodes(n: JSONObject): Int { var t = 1; n.optJSONArray("children")?.let { a -> for (i in 0 until a.length()) t += countNodes(a.getJSONObject(i)) }; return t }
    private fun reassign(n: JSONObject): JSONObject {
        n.put("id", nodeId()); if (!n.has("name")) n.put("name", "Sans titre"); if (!n.has("mastered")) n.put("mastered", false)
        val a = n.optJSONArray("children") ?: JSONArray().also { n.put("children", it) }
        for (i in 0 until a.length()) reassign(a.getJSONObject(i))
        return n
    }

    private fun ownedProject(id: String, user: String): JSONObject {
        val p = synchronized(lock) { projects[id] } ?: throw HttpErr(St.NOT_FOUND, "Projet introuvable")
        if (p.optString("owner") != user) throw HttpErr(St.FORBIDDEN, "Accès refusé à ce projet")
        return p
    }

    private fun projectCreate(d: JSONObject): Resp = synchronized(lock) {
        val user = userOrFail(d.optString("username").trim())
        val name = d.optString("name").trim().ifEmpty { "Nouveau projet" }
        val id = UUID.randomUUID().toString().replace("-", "")
        val now = LocalDateTime.now().toString()
        val p = JSONObject().put("id", id).put("owner", user).put("name", name).put("created_at", now).put("updated_at", now)
            .put("tree", makeNode(name, "root_" + nodeId()))
        projects[id] = p; saveProjects()
        jr(p)
    }

    private fun projectList(user: String): Resp = synchronized(lock) {
        val list = projects.values.filter { it.optString("owner") == user }.sortedByDescending { it.optString("updated_at") }
        jr2(JSONArray(list.map { JSONObject().put("id", it.getString("id")).put("name", it.optString("name")).put("created_at", it.optString("created_at")).put("updated_at", it.optString("updated_at")).put("node_count", countNodes(it.getJSONObject("tree"))) }))
    }

    private fun jr2(a: JSONArray): Resp = NanoHTTPD.newFixedLengthResponse(St.OK, "application/json; charset=utf-8", a.toString())

    private fun projectSave(d: JSONObject): Resp = synchronized(lock) {
        val user = userOrFail(d.optString("username").trim())
        val p = ownedProject(d.optString("project_id").trim(), user)
        val tree = d.optJSONObject("tree") ?: throw HttpErr(St.BAD_REQUEST, "Arborescence invalide")
        val name = d.optString("name").trim().ifEmpty { p.optString("name") }
        p.put("name", name); tree.put("name", name); p.put("tree", tree).put("updated_at", LocalDateTime.now().toString())
        saveProjects()
        jr(detail("Projet sauvegardé").put("project", p))
    }

    private fun projectDelete(d: JSONObject): Resp = synchronized(lock) {
        val user = userOrFail(d.optString("username").trim())
        ownedProject(d.optString("project_id").trim(), user)
        projects.remove(d.optString("project_id").trim()); saveProjects()
        jr(detail("Projet supprimé"))
    }

    private fun projectExport(id: String, username: String): Resp {
        val p = ownedProject(id, userOrFail(username))
        return jr(JSONObject().put("format", "reseau_local_mindmap").put("version", 1).put("name", p.optString("name")).put("tree", p.getJSONObject("tree")))
    }

    private fun projectImport(d: JSONObject): Resp = synchronized(lock) {
        val user = userOrFail(d.optString("username").trim())
        val tree = d.optJSONObject("tree") ?: throw HttpErr(St.BAD_REQUEST, "Fichier de projet invalide")
        reassign(tree)
        val name = d.optString("name").trim().ifEmpty { tree.optString("name").ifEmpty { "Projet importé" } }
        tree.put("name", name)
        val id = UUID.randomUUID().toString().replace("-", "")
        val now = LocalDateTime.now().toString()
        val p = JSONObject().put("id", id).put("owner", user).put("name", name).put("created_at", now).put("updated_at", now).put("tree", tree)
        projects[id] = p; saveProjects()
        jr(p)
    }

    /** IA locale (Ollama) : appelée depuis le téléphone vers l'adresse indiquée (ex. l'IP du PC). */
    private fun generateSegments(d: JSONObject): Resp {
        userOrFail(d.optString("username").trim())
        val theme = d.optString("theme").trim()
        if (theme.isEmpty()) throw HttpErr(St.BAD_REQUEST, "Thème manquant")
        val path = strs(d.optJSONArray("path"))
        val url = d.optString("ollama_url").ifBlank { "http://localhost:11434" }.trimEnd('/')
        val model = d.optString("model").ifBlank { "llama3.2" }
        val context = if (path.isNotEmpty()) " (dans le contexte de : ${path.joinToString(" > ")})" else ""
        val prompt = "Tu es un assistant pédagogique qui construit des cartes mentales d'apprentissage. " +
            "Pour le thème \"$theme\"$context, propose entre 4 et 8 sous-thèmes ou notions clés " +
            "à apprendre pour le maîtriser. Réponds UNIQUEMENT avec un tableau JSON de chaînes de " +
            "caractères courtes, sans aucun texte avant ou après, par exemple : " +
            "[\"Sous-thème 1\", \"Sous-thème 2\", \"Sous-thème 3\"]"
        val raw = try {
            val slow = Api.http.newBuilder().readTimeout(120, TimeUnit.SECONDS).build()
            val req = Request.Builder().url("$url/api/generate")
                .post(JSONObject().put("model", model).put("prompt", prompt).put("stream", false).toString()
                    .toRequestBody("application/json".toMediaType())).build()
            slow.newCall(req).execute().use { JSONObject(it.body?.string().orEmpty()).optString("response") }
        } catch (e: Exception) {
            throw HttpErr(St.INTERNAL_ERROR, "Impossible de contacter l'IA locale sur $url. Vérifiez qu'Ollama est lancé et joignable depuis le téléphone.")
        }
        val segs = parseSegments(raw)
        if (segs.isEmpty()) throw HttpErr(St.INTERNAL_ERROR, "L'IA locale n'a renvoyé aucun sous-thème exploitable")
        return jr(JSONObject().put("theme", theme).put("segments", JSONArray(segs)))
    }

    private fun parseSegments(text: String): List<String> {
        Regex("\\[[\\s\\S]*\\]").find(text)?.let { m ->
            try {
                val a = JSONArray(m.value)
                val cleaned = (0 until a.length()).map { a.get(it).toString().trim(' ', '"', '\'', '.', '-') }.filter { it.isNotBlank() }
                if (cleaned.isNotEmpty()) return cleaned.take(12)
            } catch (_: Exception) {}
        }
        return text.lines().map { it.trim() }.filter { it.isNotEmpty() }
            .map { it.replace(Regex("^[\\-*\\d.)\\s]+"), "").trim(' ', '"', '\'') }
            .filter { it.isNotEmpty() && it.length < 120 }.take(12)
    }
}
