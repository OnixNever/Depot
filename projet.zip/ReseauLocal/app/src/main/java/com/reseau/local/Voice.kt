package com.reseau.local

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.URL
import java.text.Normalizer
import java.util.concurrent.ArrayBlockingQueue
import java.util.zip.ZipInputStream

/**
 * Commandes vocales 100 % hors ligne (Vosk, gratuit, sans clé API).
 * - Hors appel : un AudioRecord 16 kHz écoute en continu (si activé).
 * - Pendant un appel : on récupère les échantillons du micro WebRTC (un seul micro, deux usages).
 * Les commandes doivent commencer par le mot d'activation (« assistant » par défaut)
 * pour ne pas réagir à la voix des autres participants.
 */
object Voice {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip"

    val status = MutableStateFlow("Modèle vocal non installé")
    val progress = MutableStateFlow(-1f)
    val ready = MutableStateFlow(false)
    val enabled = MutableStateFlow(true)

    private var model: Model? = null
    @Volatile private var rec: Recognizer? = null
    @Volatile private var dirty = true
    @Volatile private var remoteTaint = false
    private var worker: Thread? = null
    private val queue = ArrayBlockingQueue<ByteArray>(300)

    @Volatile private var idleRun = false
    private var idleThread: Thread? = null

    // ------------------------------------------------------------------ modèle
    /** Modèle déposé à la main dans Android/data/com.reseau.local/files/vosk-fr (option 100 % hors ligne), sinon téléchargé. */
    fun modelDir(ctx: Context): File {
        val manual = File(ctx.getExternalFilesDir(null), "vosk-fr")
        return if (File(manual, "am").exists()) manual else File(ctx.filesDir, "vosk-fr")
    }

    fun hasModel(ctx: Context) = File(modelDir(ctx), "am").exists()

    suspend fun download(ctx: Context) = withContext(Dispatchers.IO) {
        try {
            status.value = "Téléchargement du modèle vocal…"
            progress.value = 0f
            val tmp = File(ctx.cacheDir, "vosk.zip")
            val conn = URL(MODEL_URL).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }
            val total = conn.contentLengthLong
            conn.getInputStream().use { i ->
                tmp.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (total > 0) progress.value = done.toFloat() / total
                    }
                }
            }
            status.value = "Installation du modèle…"
            val out = File(ctx.filesDir, "vosk-fr")
            out.deleteRecursively(); out.mkdirs()
            ZipInputStream(tmp.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val rel = e.name.substringAfter('/')
                    if (rel.isNotEmpty()) {
                        val f = File(out, rel)
                        if (!f.canonicalPath.startsWith(out.canonicalPath)) throw SecurityException("zip invalide")
                        if (e.isDirectory) f.mkdirs() else {
                            f.parentFile?.mkdirs()
                            f.outputStream().use { z.copyTo(it) }
                        }
                    }
                    e = z.nextEntry
                }
            }
            tmp.delete()
            progress.value = -1f
            status.value = "Modèle installé"
            start(ctx)
        } catch (e: Exception) {
            progress.value = -1f
            status.value = "Échec du téléchargement : ${e.message}"
        }
    }

    // ------------------------------------------------------------------ moteur
    fun start(ctx: Context) {
        if (worker != null || !hasModel(ctx)) {
            if (!hasModel(ctx)) status.value = "Modèle vocal non installé"
            return
        }
        val dir = modelDir(ctx).absolutePath
        status.value = "Chargement du modèle…"
        worker = Thread {
            try {
                model = Model(dir)
            } catch (t: Throwable) {
                status.value = "Modèle illisible : ${t.message}"
                worker = null
                return@Thread
            }
            ready.value = true
            status.value = "Écoute prête"
            try {
                while (true) {
                    val chunk = queue.take()
                    if (dirty) { dirty = false; rebuild() }
                    val r = rec ?: continue
                    if (r.acceptWaveForm(chunk, chunk.size)) {
                        val text = JSONObject(r.result).optString("text")
                        val tainted = remoteTaint
                        remoteTaint = false
                        val inCall = CallEngine.ui.value.phase == Phase.ACTIVE
                        // Comme vocal.js (IGNORE_WHILE_REMOTE_SPEAKS) : on ignore ce qui a été capté pendant qu'un autre parle
                        if (text.isNotBlank() && !(inCall && tainted)) Hub.scope.launch { Commands.handle(text) }
                    }
                }
            } catch (_: InterruptedException) {
            }
        }.also { it.isDaemon = true; it.start() }
    }

    /** À appeler quand la liste des utilisateurs ou le mot d'activation change. */
    fun markDirty() { dirty = true }

    private fun rebuild() {
        val m = model ?: return
        val words = LinkedHashSet<String>(Nlu.vocabulary())
        words.addAll(Commands.IDLE_VOCAB)
        Commands.words(Prefs.wakeWord).forEach(words::add)
        Hub.users.value.forEach { u -> Commands.words(u.name).forEach(words::add) }
        P2p.peers.value.forEach { p -> Commands.words(p.name).forEach(words::add) }
        words.add("[unk]")
        rec?.close()
        rec = Recognizer(m, 16000f, JSONArray(words.toList()).toString())
    }

    private fun offer(b: ByteArray) { queue.offer(b) }

    // ------------------------------------------------------------------ micro hors appel
    @SuppressLint("MissingPermission")
    fun startIdleMic() {
        if (idleRun || !ready.value) return
        idleRun = true
        idleThread = Thread {
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val ar = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8000)
            )
            try {
                ar.startRecording()
                val buf = ByteArray(3200)
                while (idleRun) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n > 0) offer(buf.copyOf(n)) else if (n < 0) break
                }
            } catch (_: Exception) {
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stopIdleMic() {
        idleRun = false
        try { idleThread?.join(300) } catch (_: Exception) {}
        idleThread = null
    }

    // ------------------------------------------------------------------ micro pendant l'appel (échantillons WebRTC)
    private var rsPhase = 0.0

    fun onCallSamples(data: ByteArray, rate: Int, ch: Int) {
        if (!ready.value || !enabled.value) return
        if (CallEngine.remoteSpeaking) remoteTaint = true
        val out = toMono16k(data, rate, ch)
        if (out.isNotEmpty()) offer(out)
    }

    private fun toMono16k(data: ByteArray, rate: Int, ch: Int): ByteArray {
        val frames = data.size / 2 / ch
        if (frames == 0) return ByteArray(0)
        val step = rate / 16000.0
        val out = ByteArray(((frames / step).toInt() + 2) * 2)
        var o = 0
        var pos = rsPhase
        while (pos + step <= frames) {
            val a = pos.toInt()
            val b = maxOf(a + 1, (pos + step).toInt()).coerceAtMost(frames)
            var sum = 0L
            var n = 0
            for (i in a until b) {
                val idx = i * ch * 2
                sum += ((data[idx + 1].toInt() shl 8) or (data[idx].toInt() and 0xFF)).toShort().toInt()
                n++
            }
            val v = if (n > 0) (sum / n).toInt() else 0
            out[o++] = (v and 0xFF).toByte()
            out[o++] = ((v shr 8) and 0xFF).toByte()
            pos += step
        }
        rsPhase = maxOf(0.0, pos - frames)
        return out.copyOf(o)
    }
}
