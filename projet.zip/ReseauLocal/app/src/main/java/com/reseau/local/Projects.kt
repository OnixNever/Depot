package com.reseau.local

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Nœud d'une carte mentale (même structure que le serveur : id, name, mastered, children). */
class Node(val id: String, var name: String, var mastered: Boolean, val children: MutableList<Node>) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("mastered", mastered)
        .put("children", JSONArray().also { a -> children.forEach { a.put(it.toJson()) } })

    fun count(): Int = 1 + children.sumOf { it.count() }

    fun find(target: String): Node? =
        if (id == target) this else children.firstNotNullOfOrNull { it.find(target) }

    fun parentOf(target: String): Node? =
        if (children.any { it.id == target }) this else children.firstNotNullOfOrNull { it.parentOf(target) }

    fun pathTo(target: String, acc: List<String> = emptyList()): List<String>? {
        val here = acc + name
        if (id == target) return here
        for (c in children) c.pathTo(target, here)?.let { return it }
        return null
    }
}

fun nodeFromJson(o: JSONObject): Node {
    val kids = ArrayList<Node>()
    val a = o.optJSONArray("children")
    if (a != null) for (i in 0 until a.length()) kids.add(nodeFromJson(a.getJSONObject(i)))
    return Node(o.optString("id").ifBlank { UUID.randomUUID().toString().take(8) }, o.optString("name", "Sans titre"), o.optBoolean("mastered"), kids)
}

private val DEPTH_COLORS = listOf("#8b5cf6", "#6366f1", "#3b82f6", "#14b8a6", "#22c55e", "#f59e0b", "#f97316", "#ec4899")
private fun depthColor(d: Int): Color {
    val hex = if (d <= 0) DEPTH_COLORS[0] else DEPTH_COLORS[(d - 1) % DEPTH_COLORS.size]
    return Color(android.graphics.Color.parseColor(hex))
}

@Composable
fun TextPrompt(title: String, initial: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onOk(v.trim()) }, enabled = v.isNotBlank()) { Text("OK") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Annuler") } }
    )
}

@Composable
fun ProjectsTab() {
    var openId by remember { mutableStateOf<String?>(null) }
    val id = openId
    if (id == null) ProjectList(onOpen = { openId = it }) else ProjectEditor(id, onBack = { openId = null })
}

private fun writeJson(ctx: Context, uri: Uri, data: JSONObject) {
    ctx.contentResolver.openOutputStream(uri)?.use { it.write(data.toString(2).toByteArray()) }
}

private fun slug(n: String) = n.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "projet" }

@Composable
fun ProjectList(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Api.ProjectInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Api.ProjectInfo?>(null) }
    var exportData by remember { mutableStateOf<JSONObject?>(null) }

    suspend fun load() {
        loading = true
        try { list = Api.projectsList() } catch (e: Exception) { Hub.events.tryEmit("Projets : ${e.message}") }
        loading = false
    }
    LaunchedEffect(Unit) { load() }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            try {
                val text = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().decodeToString() }
                val j = JSONObject(text)
                val tree = j.optJSONObject("tree") ?: j
                Api.projectImport(j.optString("name"), tree)
                load()
                Hub.events.tryEmit("Projet importé")
            } catch (e: Exception) { Hub.events.tryEmit("Import impossible : ${e.message}") }
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val d = exportData
        if (uri != null && d != null) { writeJson(ctx, uri, d); Hub.events.tryEmit("Projet exporté") }
        exportData = null
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { creating = true }) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text("Nouveau") }
            OutlinedButton(onClick = { importer.launch("*/*") }) { Text("Importer") }
        }
        Spacer(Modifier.height(12.dp))
        if (loading) CircularProgressIndicator()
        else if (list.isEmpty()) Text("Aucun projet. Crée une carte mentale pour organiser ce que tu apprends.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(p.id) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text("${p.nodeCount} éléments · ${p.updatedAt.take(10)}", style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = {
                            scope.launch {
                                try { exportData = Api.projectExport(p.id); saver.launch("${slug(p.name)}.json") }
                                catch (e: Exception) { Hub.events.tryEmit("Export impossible") }
                            }
                        }) { Icon(Icons.Filled.Share, "Exporter") }
                        IconButton(onClick = { deleting = p }) { Icon(Icons.Filled.Delete, "Supprimer") }
                    }
                }
            }
        }
    }

    if (creating) TextPrompt("Nom du projet", "", onOk = { n ->
        creating = false
        scope.launch {
            try { val p = Api.projectCreate(n); load(); onOpen(p.getString("id")) }
            catch (e: Exception) { Hub.events.tryEmit("Création impossible") }
        }
    }, onCancel = { creating = false })

    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer « ${p.name} » ?") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch { try { Api.projectDelete(p.id); load() } catch (e: Exception) { Hub.events.tryEmit("Suppression impossible") } }
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } }
        )
    }
}

@Composable
fun ProjectEditor(projectId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var root by remember { mutableStateOf<Node?>(null) }
    var title by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var collapsed by remember { mutableStateOf(setOf<String>()) }
    var renaming by remember { mutableStateOf(false) }
    var aiSettings by remember { mutableStateOf(false) }
    var generating by remember { mutableStateOf(false) }
    var dirty by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var exportData by remember { mutableStateOf<JSONObject?>(null) }

    LaunchedEffect(projectId) {
        try {
            val p = Api.projectGet(projectId)
            val r = nodeFromJson(p.getJSONObject("tree"))
            title = p.optString("name")
            root = r
            // Comme la page web : on replie ce qui est à partir de la profondeur 2
            val c = HashSet<String>()
            fun walk(n: Node, d: Int) { if (d >= 2 && n.children.isNotEmpty()) c.add(n.id); n.children.forEach { walk(it, d + 1) } }
            walk(r, 0)
            collapsed = c
        } catch (e: Exception) { Hub.events.tryEmit("Projet introuvable"); onBack() }
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val d = exportData
        if (uri != null && d != null) { writeJson(ctx, uri, d); Hub.events.tryEmit("Projet exporté") }
        exportData = null
    }

    fun touch() { tick++; dirty = true }
    val r = root
    if (r == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return }
    @Suppress("UNUSED_VARIABLE") val t = tick
    val sel = selected?.let { r.find(it) }

    // Liste à plat des nœuds visibles
    val rows = ArrayList<Triple<Node, Int, Boolean>>()
    fun flat(n: Node, d: Int) {
        rows.add(Triple(n, d, n.id in collapsed))
        if (n.id !in collapsed) n.children.forEach { flat(it, d + 1) }
    }
    flat(r, 0)

    fun save() = scope.launch {
        try {
            r.name = title.ifBlank { r.name }
            Api.projectSave(projectId, title, r.toJson())
            dirty = false
            Hub.events.tryEmit("Projet sauvegardé")
        } catch (e: Exception) { Hub.events.tryEmit("Sauvegarde impossible : ${e.message}") }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Projets") }
            OutlinedTextField(title, { title = it; dirty = true }, Modifier.weight(1f), singleLine = true)
            TextButton(onClick = { save() }) { Text(if (dirty) "Sauver •" else "Sauver") }
            IconButton(onClick = {
                exportData = JSONObject().put("format", "reseau_local_mindmap").put("version", 1)
                    .put("name", title).put("tree", r.toJson())
                saver.launch("${slug(title)}.json")
            }) { Icon(Icons.Filled.Share, "Partager") }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)) {
            items(rows, key = { it.first.id }) { (n, depth, isCollapsed) ->
                val color = depthColor(depth)
                val isSel = n.id == selected
                Row(
                    Modifier.fillMaxWidth().padding(start = (depth * 18).dp, top = 3.dp, bottom = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) color.copy(alpha = 0.25f) else color.copy(alpha = 0.08f))
                        .clickable { selected = n.id }.padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (n.children.isNotEmpty()) {
                        IconButton(onClick = { collapsed = if (isCollapsed) collapsed - n.id else collapsed + n.id }, modifier = Modifier.size(28.dp)) {
                            Icon(if (isCollapsed) Icons.Filled.KeyboardArrowRight else Icons.Filled.KeyboardArrowDown, null)
                        }
                    } else Spacer(Modifier.width(28.dp))
                    Box(Modifier.size(10.dp).clip(CircleShape).background(if (n.mastered) Color(0xFF22C55E) else color))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        n.name, Modifier.weight(1f),
                        textDecoration = if (n.mastered) TextDecoration.LineThrough else null,
                        fontWeight = if (depth == 0) FontWeight.Bold else FontWeight.Normal
                    )
                    if (isCollapsed) Text("+${n.count() - 1}", style = MaterialTheme.typography.labelSmall)
                    if (generating && n.id == selected) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                }
            }
        }
        HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(enabled = sel != null, onClick = { renaming = true }) { Icon(Icons.Filled.Edit, "Renommer") }
            OutlinedButton(enabled = sel != null, onClick = {
                val s = sel ?: return@OutlinedButton
                val c = Node(UUID.randomUUID().toString().take(8), "Nouveau sous-thème", false, ArrayList())
                s.children.add(c)
                collapsed = collapsed - s.id
                selected = c.id
                renaming = true
                touch()
            }) { Icon(Icons.Filled.Add, "Ajouter") }
            OutlinedButton(enabled = sel != null, onClick = { sel?.let { it.mastered = !it.mastered; touch() } }) { Text("✓") }
            OutlinedButton(enabled = sel != null && sel !== r, onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Supprimer") }
            OutlinedButton(enabled = sel != null && !generating, onClick = {
                val s = sel ?: return@OutlinedButton
                generating = true
                scope.launch {
                    try {
                        val path = (r.pathTo(s.id) ?: emptyList()).dropLast(1)
                        val segs = Api.generateSegments(s.name, path)
                        val have = s.children.map { it.name.lowercase() }.toSet()
                        val fresh = segs.filter { it.lowercase() !in have }
                        fresh.forEach { s.children.add(Node(UUID.randomUUID().toString().take(8), it, false, ArrayList())) }
                        collapsed = collapsed - s.id
                        touch()
                        Hub.events.tryEmit("${fresh.size} sous-thème(s) généré(s)")
                    } catch (e: Exception) { Hub.events.tryEmit(e.message ?: "Génération impossible") }
                    generating = false
                }
            }) { Text("✨ IA") }
            TextButton(onClick = { aiSettings = true }) { Text("Réglages IA") }
        }
    }

    if (renaming && sel != null) TextPrompt("Renommer", sel.name, onOk = { n -> sel.name = n; renaming = false; touch() }, onCancel = { renaming = false })

    if (aiSettings) {
        var url by remember { mutableStateOf(Prefs.ollamaUrl) }
        var model by remember { mutableStateOf(Prefs.ollamaModel) }
        AlertDialog(
            onDismissRequest = { aiSettings = false },
            title = { Text("IA locale (Ollama sur le PC)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(url, { url = it }, singleLine = true, label = { Text("Adresse d'Ollama (côté PC)") })
                    OutlinedTextField(model, { model = it }, singleLine = true, label = { Text("Modèle") })
                }
            },
            confirmButton = { TextButton(onClick = { Prefs.ollamaUrl = url; Prefs.ollamaModel = model; aiSettings = false }) { Text("Enregistrer") } },
            dismissButton = { TextButton(onClick = { aiSettings = false }) { Text("Annuler") } }
        )
    }

    if (confirmDelete && sel != null) {
        val extra = sel.count() - 1
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(if (extra > 0) "Supprimer « ${sel.name} » et ses $extra sous-élément(s) ?" else "Supprimer « ${sel.name} » ?") },
            confirmButton = {
                TextButton(onClick = {
                    r.parentOf(sel.id)?.children?.removeAll { it.id == sel.id }
                    selected = null; confirmDelete = false; touch()
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } }
        )
    }
}
