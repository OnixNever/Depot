package com.reseau.local

import android.app.Activity
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Environment
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Lock
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.window.Dialog
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.compose.material3.TextButton
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme(),
        content = content
    )
}

suspend fun fullLogout(ctx: Context, notifyServer: Boolean) {
    CallEngine.hangup()
    if (notifyServer) Api.logout(Prefs.username, Prefs.token)
    HubService.stop(ctx)
    Hub.stop()
    Prefs.token = ""
}

private fun parseColor(hex: String): Color =
    try { Color(android.graphics.Color.parseColor(hex)) } catch (_: Exception) { Color(0xFF6366F1) }

// ====================================================================== connexion
@Composable
fun ConnectScreen(onDone: () -> Unit) {
    var url by remember { mutableStateOf(Prefs.serverUrl) }
    var user by remember { mutableStateOf(Prefs.username) }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Réseau local", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            url, { url = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("Serveur (ex. 192.168.1.20:8000)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nom d'utilisateur") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Mot de passe") },
            visualTransformation = PasswordVisualTransformation()
        )
        if (err.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(err, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = !busy && url.isNotBlank() && user.isNotBlank() && pass.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                busy = true; err = ""
                scope.launch {
                    try {
                        val normalized = Api.normalize(url)
                        if (normalized.contains("127.0.0.1") || normalized.contains("localhost")) {
                            withContext(Dispatchers.IO) { LocalServer.start(ctx.applicationContext) }
                            Prefs.hostMode = true
                        } else {
                            Prefs.hostMode = false
                            LocalServer.stop()
                        }
                        Prefs.serverUrl = normalized
                        val r = Api.login(user.trim(), pass.trim())
                        Prefs.username = user.trim()
                        Prefs.token = r.getString("token")
                        onDone()
                    } catch (e: ApiError) {
                        err = e.message ?: "Erreur"
                    } catch (e: Exception) {
                        err = "Serveur injoignable (${Prefs.serverUrl})"
                    }
                    busy = false
                }
            }
        ) { Text(if (busy) "Connexion…" else "Se connecter") }

        Spacer(Modifier.height(24.dp))
        HorizontalDivider()
        Spacer(Modifier.height(16.dp))
        Text("Sans PC", style = MaterialTheme.typography.titleMedium)
        Text(
            "Ce téléphone devient le serveur : les autres appareils se connectent à son adresse. " +
                "Le premier compte créé ici est l'administrateur.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            enabled = !busy && user.isNotBlank() && pass.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                busy = true; err = ""
                scope.launch {
                    try {
                        val e = withContext(Dispatchers.IO) {
                            LocalServer.start(ctx.applicationContext).registerFirstAdmin(user.trim(), pass.trim())
                        }
                        if (e != null) throw ApiError(e)
                        Prefs.hostMode = true
                        Prefs.serverUrl = "http://127.0.0.1:${LocalServer.PORT}"
                        val r = Api.login(user.trim(), pass.trim())
                        Prefs.username = user.trim()
                        Prefs.token = r.getString("token")
                        onDone()
                    } catch (e: ApiError) {
                        err = e.message ?: "Erreur"
                    } catch (e: Exception) {
                        err = "Impossible de démarrer le serveur : ${e.message}"
                    }
                    busy = false
                }
            }
        ) { Text("Créer / démarrer mon serveur sur ce téléphone") }

        val found by Nsd.found.collectAsStateWithLifecycle()
        DisposableEffect(Unit) {
            Nsd.startDiscovery(ctx)
            onDispose { Nsd.stopDiscovery(ctx) }
        }
        if (found.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Serveurs trouvés sur le réseau :", style = MaterialTheme.typography.labelMedium)
            found.forEach { f ->
                TextButton(onClick = { url = "${f.host}:${f.port}" }) { Text("${f.name} (${f.host})") }
            }
        }
    }
}

// ====================================================================== écran principal
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val call by CallEngine.ui.collectAsStateWithLifecycle()
    val connected by Hub.connected.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Hub.events.collect { snack.showSnackbar(it) } }
    LaunchedEffect(Unit) { Hub.kicked.collect { fullLogout(ctx, false); onLogout() } }

    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Discussion" to Icons.Filled.Chat, "Appels" to Icons.Filled.Call, "Projets" to Icons.Filled.AccountTree, "Réglages" to Icons.Filled.Settings
    )

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                TopAppBar(
                    title = { Text("Réseau local") },
                    actions = {
                        Text(
                            if (connected) "● en ligne" else "○ reconnexion…",
                            color = if (connected) Color(0xFF2E7D32) else Color(0xFFC62828),
                            modifier = Modifier.padding(end = 12.dp)
                        )
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, null) }, label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> ChatTab()
                    1 -> CallTab()
                    2 -> ProjectsTab()
                    else -> SettingsTab(onLogout)
                }
            }
        }
        if (call.phase == Phase.IDLE && call.incoming.isNotEmpty()) {
            IncomingBanner(call.incoming, Modifier.align(Alignment.TopCenter))
        }
        if (call.phase != Phase.IDLE) CallOverlay(call)
        if (call.locked && call.phase == Phase.ACTIVE) LockOverlay(call)
    }
}

@Composable
fun IncomingBanner(list: List<Incoming>, modifier: Modifier) {
    Column(modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { inc ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Appel entrant", style = MaterialTheme.typography.labelMedium)
                        Text(inc.from, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    FilledIconButton(
                        onClick = { CallEngine.decline(inc.callId) },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFFC62828))
                    ) { Icon(Icons.Filled.CallEnd, "Refuser") }
                    Spacer(Modifier.padding(6.dp))
                    FilledIconButton(
                        onClick = { CallEngine.accept(inc.callId) },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF2E7D32))
                    ) { Icon(Icons.Filled.Call, "Répondre") }
                }
            }
        }
    }
}

// ====================================================================== discussion
private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")
private val AUD = setOf("m4a", "mp3", "ogg", "wav", "aac", "webm", "flac")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs by Hub.messages.collectAsStateWithLifecycle()
    val call by CallEngine.ui.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var menuFor by remember { mutableLongStateOf(-1L) }
    var viewer by remember { mutableStateOf<String?>(null) }
    val typing by Hub.typing.collectAsStateWithLifecycle()
    val rec = remember { VoiceNote(ctx) }
    val list = rememberLazyListState()

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.lastIndex) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        scope.launch {
            for (uri in uris) {
                try { Api.sendUri(ctx.contentResolver, uri, ctx.cacheDir) }
                catch (e: Exception) { Hub.events.tryEmit("Fichier non envoyé : ${e.message}") }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs, key = { it.id }) { m ->
                val mine = m.sender == Prefs.username
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                    Box {
                        Column(
                            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .combinedClickable(onClick = {}, onLongClick = { menuFor = m.id })
                                .padding(10.dp)
                        ) {
                            if (!mine) Text(m.sender, color = parseColor(m.color), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            if (m.content.isNotBlank()) Text(m.content)
                            FileBlock(m) { viewer = it }
                            Text(m.hour, style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.End))
                        }
                        DropdownMenu(expanded = menuFor == m.id, onDismissRequest = { menuFor = -1L }) {
                            if (m.content.isNotBlank()) DropdownMenuItem(text = { Text("Copier") }, onClick = {
                                menuFor = -1L
                                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("message", m.content))
                                Hub.events.tryEmit("Message copié")
                            })
                            if (m.fileUrl != null) DropdownMenuItem(text = { Text("Télécharger") }, onClick = {
                                menuFor = -1L
                                try {
                                    val name = m.fileName ?: "fichier"
                                    val req = DownloadManager.Request(Uri.parse(Api.abs(m.fileUrl))).setTitle(name)
                                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                                    ctx.getSystemService(DownloadManager::class.java).enqueue(req)
                                    Hub.events.tryEmit("Téléchargement lancé")
                                } catch (e: Exception) { Hub.events.tryEmit("Téléchargement impossible") }
                            })
                            if (mine) DropdownMenuItem(text = { Text("Supprimer") }, onClick = {
                                menuFor = -1L
                                scope.launch { try { Api.delete(m.id) } catch (e: Exception) { Hub.events.tryEmit("Suppression impossible") } }
                            })
                        }
                    }
                }
            }
        }
        viewer?.let { u ->
            Dialog(onDismissRequest = { viewer = null }) {
                AsyncImage(model = u, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().clickable { viewer = null })
            }
        }
        if (typing.isNotEmpty()) Text(
            "${typing.joinToString()} écrit…", Modifier.padding(horizontal = 12.dp),
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline
        )
        HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { picker.launch("*/*") }) { Icon(Icons.Filled.AttachFile, "Joindre") }
            OutlinedTextField(text, { text = it; if (it.isNotBlank()) Hub.notifyTyping() }, Modifier.weight(1f), placeholder = { Text("Message") }, maxLines = 4)
            if (text.isBlank()) {
                IconButton(
                    enabled = call.phase == Phase.IDLE,
                    onClick = {
                        if (!recording) { recording = rec.start() }
                        else {
                            recording = false
                            val f = rec.stop()
                            if (f != null) scope.launch {
                                try { Api.sendFile(f, f.name) } catch (e: Exception) { Hub.events.tryEmit("Vocal non envoyé") }
                                f.delete()
                            }
                        }
                    }
                ) { Icon(if (recording) Icons.Filled.Stop else Icons.Filled.Mic, "Message vocal", tint = if (recording) Color(0xFFC62828) else LocalContentColorFallback()) }
            } else {
                IconButton(onClick = {
                    val t = text.trim(); text = ""
                    scope.launch { try { Api.send(t) } catch (e: Exception) { Hub.events.tryEmit("Message non envoyé"); text = t } }
                }) { Icon(Icons.AutoMirrored.Filled.Send, "Envoyer") }
            }
        }
    }
}

@Composable
private fun LocalContentColorFallback(): Color = MaterialTheme.colorScheme.onSurface

@Composable
private fun FileBlock(m: Msg, onImage: (String) -> Unit) {
    val url = m.fileUrl ?: return
    val ctx = LocalContext.current
    val ext = (m.fileName ?: url).substringAfterLast('.', "").lowercase()
    val abs = Api.abs(url)
    when {
        ext in IMG -> AsyncImage(
            model = abs, contentDescription = m.fileName, contentScale = ContentScale.Fit,
            modifier = Modifier.widthIn(max = 260.dp).clip(RoundedCornerShape(8.dp))
                .clickable { onImage(abs) }
        )
        ext in AUD -> AudioBubble(abs, m.fileName ?: "Message vocal")
        else -> Text(
            "📎 ${m.fileName ?: "Fichier"} (${m.fileSize ?: ""})",
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(abs)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        )
    }
}

@Composable
private fun AudioBubble(url: String, label: String) {
    var playing by remember { mutableStateOf(false) }
    val mp = remember { MediaPlayer() }
    DisposableEffect(Unit) { onDispose { try { mp.release() } catch (_: Exception) {} } }
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = {
            try {
                if (playing) { mp.reset(); playing = false }
                else {
                    mp.reset(); mp.setDataSource(url)
                    mp.setOnPreparedListener { it.start() }
                    mp.setOnCompletionListener { playing = false }
                    mp.setOnErrorListener { _, _, _ -> playing = false; true }
                    mp.prepareAsync(); playing = true
                }
            } catch (_: Exception) { playing = false }
        }) { Icon(if (playing) Icons.Filled.Stop else Icons.Filled.PlayArrow, "Lire") }
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

/** Enregistrement d'un message vocal (AAC / .m4a). */
class VoiceNote(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    fun start(): Boolean = try {
        val f = File(ctx.cacheDir, "vocal_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioSamplingRate(44100)
        r.setAudioEncodingBitRate(96000)
        r.setOutputFile(f.absolutePath)
        r.prepare(); r.start()
        rec = r; file = f
        true
    } catch (e: Exception) {
        Hub.events.tryEmit("Micro indisponible pour le message vocal")
        false
    }

    fun stop(): File? {
        val f = file
        try { rec?.stop() } catch (_: Exception) { f?.delete(); rec?.release(); rec = null; file = null; return null }
        rec?.release(); rec = null; file = null
        return f
    }
}

// ====================================================================== appels
@Composable
fun CallTab() {
    val users by Hub.users.collectAsStateWithLifecycle()
    val online by Hub.online.collectAsStateWithLifecycle()
    val me = Prefs.username
    val picked: SnapshotStateList<String> = remember { mutableStateListOf() }
    val wake = Prefs.wakeWord

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Text(
                "Commande vocale : dis « $wake appelle <nom> », « $wake raccroche », « $wake coupe le micro »…",
                Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium
            )
        }
        Spacer(Modifier.height(12.dp))
        Text("Personnes", style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.weight(1f)) {
            items(users.filter { it.name != me }, key = { it.name }) { u ->
                val on = u.name in online
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = u.name in picked, enabled = on,
                        onCheckedChange = { if (it) picked.add(u.name) else picked.remove(u.name) }
                    )
                    Text(u.name, color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline)
                    Spacer(Modifier.weight(1f))
                    Text(if (on) "en ligne" else "hors ligne", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Button(
            modifier = Modifier.fillMaxWidth(), enabled = picked.isNotEmpty(),
            onClick = { CallEngine.startCall(picked.toList()); picked.clear() }
        ) {
            Icon(Icons.Filled.Call, null)
            Spacer(Modifier.padding(4.dp))
            Text("Appeler (${picked.size})")
        }
    }
}

@Composable
fun CallOverlay(call: CallUi) {
    var secs by remember { mutableLongStateOf(0L) }
    var menu by remember { mutableStateOf(false) }
    val online by Hub.online.collectAsStateWithLifecycle()
    val me = Prefs.username

    val act = LocalContext.current as? Activity
    DisposableEffect(call.phase) {
        if (call.phase != Phase.IDLE) act?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { act?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    LaunchedEffect(call.startedAt) {
        while (call.startedAt > 0) {
            secs = (System.currentTimeMillis() - call.startedAt) / 1000
            delay(1000)
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp))
            Text(
                if (call.phase == Phase.ACTIVE) "Appel en cours" else "Connexion…",
                style = MaterialTheme.typography.headlineSmall
            )
            if (call.phase == Phase.ACTIVE) Text("%02d:%02d".format(secs / 60, secs % 60), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(16.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(call.participants, key = { it }) { p ->
                    val mineRow = p == me
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (mineRow) "$p (moi)" else p, fontWeight = FontWeight.Bold)
                            if (!mineRow) Text(call.status[p] ?: "connexion…", style = MaterialTheme.typography.labelSmall)
                        }
                        if (!mineRow) {
                            val m = p in call.mutedPeers
                            IconButton(onClick = { CallEngine.setPeerMuted(p, !m) }) {
                                Icon(if (m) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, "Couper $p")
                            }
                        }
                    }
                }
                items(call.invited.toList(), key = { "inv-$it" }) { p ->
                    Text("$p · sonne…", Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outline)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), onClick = { CallEngine.setMuted(!call.muted) }) {
                    Icon(if (call.muted) Icons.Filled.MicOff else Icons.Filled.Mic, "Micro")
                }
                OutlinedButton(modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), onClick = { CallEngine.setSpeaker(!call.speaker) }) {
                    Icon(if (call.speaker) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff, "Haut-parleur")
                }
                OutlinedButton(modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), enabled = call.phase == Phase.ACTIVE, onClick = { CallEngine.setLocked(true) }) {
                    Icon(Icons.Filled.Lock, "Verrouiller l'écran")
                }
                Box(Modifier.weight(1f)) {
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), enabled = call.phase == Phase.ACTIVE, onClick = { menu = true }) { Icon(Icons.Filled.PersonAdd, "Ajouter") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        val cand = online.filter { it != me && it !in call.participants && it !in call.invited }
                        if (cand.isEmpty()) DropdownMenuItem(text = { Text("Personne à ajouter") }, onClick = { menu = false })
                        cand.forEach { u ->
                            DropdownMenuItem(text = { Text(u) }, onClick = { menu = false; CallEngine.invite(listOf(u)) })
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { CallEngine.hangup() },
                modifier = Modifier.fillMaxWidth().height(64.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
            ) {
                Icon(Icons.Filled.CallEnd, null)
                Spacer(Modifier.width(8.dp))
                Text("Raccrocher", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ====================================================================== réglages
@Composable
fun SettingsTab(onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var voice by remember { mutableStateOf(Prefs.voiceEnabled) }
    var needWake by remember { mutableStateOf(Prefs.requireWake) }
    var wake by remember { mutableStateOf(Prefs.wakeWord) }
    val st by Voice.status.collectAsStateWithLifecycle()
    val prog by Voice.progress.collectAsStateWithLifecycle()
    val ready by Voice.ready.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Connecté : ${Prefs.username}", style = MaterialTheme.typography.titleMedium)
        Text(Prefs.serverUrl, style = MaterialTheme.typography.bodySmall)
        HorizontalDivider()

        if (Prefs.hostMode) { HostSettings(); HorizontalDivider() }

        Text("Commandes vocales (hors ligne)", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Écoute vocale", Modifier.weight(1f))
            Switch(checked = voice, onCheckedChange = { voice = it; Prefs.voiceEnabled = it; Voice.enabled.value = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Exiger le mot d'activation", Modifier.weight(1f))
            Switch(checked = needWake, onCheckedChange = { needWake = it; Prefs.requireWake = it })
        }
        OutlinedTextField(
            wake, { wake = it; Prefs.wakeWord = it; Voice.markDirty() }, Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("Mot d'activation") }
        )
        Text("État : $st", style = MaterialTheme.typography.bodySmall)
        if (prog >= 0f) LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
        if (!ready && prog < 0f) {
            Button(onClick = { scope.launch { Voice.download(ctx.applicationContext) } }, modifier = Modifier.fillMaxWidth()) {
                Text("Installer le modèle vocal (≈ 40 Mo, une seule fois)")
            }
        }
        Text(
            "Le micro reste ouvert pour l'écoute tant que l'option est activée (un point vert Android s'affiche).",
            style = MaterialTheme.typography.bodySmall
        )
        HorizontalDivider()

        OutlinedButton(
            onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Ne pas optimiser la batterie (appels fiables)") }

        if (!Prefs.hostMode) OutlinedButton(
            onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Api.base + "/gestion_serveur.html")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Administration du serveur (navigateur)") }

        Button(
            onClick = {
                scope.launch { fullLogout(ctx, true); onLogout() }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Se déconnecter / changer de serveur") }
    }
}


// ====================================================================== verrou tactile (comme vocal.js)
/** Plus rien ne répond sauf un appui long sur « déverrouiller » : téléphone en poche, plus de fausse manip. */
@Composable
fun LockOverlay(call: CallUi) {
    var progress by remember { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()
    BackHandler(enabled = true) { }
    Surface(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }, color = Color(0xFF0B0B10)) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Filled.Lock, null, tint = Color.White)
            Spacer(Modifier.height(12.dp))
            Text("Écran verrouillé", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text(call.participants.filter { it != Prefs.username }.joinToString().ifBlank { "Appel en cours" }, color = Color.LightGray)
            Spacer(Modifier.height(8.dp))
            Text(if (call.muted) "🔇 Micro coupé" else "🎙 Micro actif", color = Color.LightGray)
            Text("Commandes vocales actives · volume ± pour couper/réactiver le micro", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(40.dp))
            Box(
                Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(24.dp)).background(Color(0xFF3730A3))
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            val job = scope.launch {
                                val t0 = System.currentTimeMillis()
                                while (true) {
                                    progress = ((System.currentTimeMillis() - t0) / 700f).coerceAtMost(1f)
                                    if (progress >= 1f) { CallEngine.setLocked(false); break }
                                    delay(30)
                                }
                            }
                            tryAwaitRelease()
                            job.cancel()
                            progress = 0f
                        })
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Maintenir pour déverrouiller", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(0.7f))
                }
            }
        }
    }
}


// ====================================================================== téléphone hôte (mode sans PC)
@Composable
fun HostSettings() {
    val srv = LocalServer.instance
    var list by remember { mutableStateOf(srv?.listUsers().orEmpty()) }
    var newName by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val ips = remember { LocalServer.localIps() }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Ce téléphone est le serveur", style = MaterialTheme.typography.titleMedium)
        Text(
            if (ips.isEmpty()) "Aucun réseau détecté : connecte-toi à un Wi-Fi ou active le point d'accès."
            else "Sur les autres appareils, saisis : " + ips.joinToString(" ou ") { "$it:${LocalServer.PORT}" },
            style = MaterialTheme.typography.bodyMedium
        )
        Text("Les autres téléphones peuvent aussi le trouver tout seuls sur l'écran de connexion.", style = MaterialTheme.typography.bodySmall)
        list.forEach { (name, role) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$name ($role)", Modifier.weight(1f))
                if (name != Prefs.username) {
                    TextButton(onClick = { srv?.deleteUser(name); list = srv?.listUsers().orEmpty() }) { Text("Supprimer") }
                }
            }
        }
        OutlinedTextField(newName, { newName = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nouvel utilisateur") })
        OutlinedTextField(
            newPass, { newPass = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Mot de passe") },
            visualTransformation = PasswordVisualTransformation()
        )
        if (msg.isNotBlank()) Text(msg, color = MaterialTheme.colorScheme.error)
        Button(
            enabled = newName.isNotBlank() && newPass.isNotBlank(),
            onClick = {
                val e = srv?.addUser(newName.trim(), newPass.trim())
                msg = e ?: ""
                if (e == null) { newName = ""; newPass = ""; list = srv?.listUsers().orEmpty() }
            }
        ) { Text("Ajouter un utilisateur") }
    }
}
