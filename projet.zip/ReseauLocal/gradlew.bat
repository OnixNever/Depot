@echo off
setlocal
set "DIR=%~dp0"
if exist "%DIR%gradle\wrapper\gradle-wrapper.jar" goto wrapper
where gradle >nul 2>nul
if errorlevel 1 goto nogradle
call gradle %*
exit /b %errorlevel%
:wrapper
java -classpath "%DIR%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %errorlevel%
:nogradle
echo Gradle introuvable : installe Gradle 8.7 ou plus (JDK 17 ou plus), ou ajoute gradle\wrapper\gradle-wrapper.jar.
exit /b 1
