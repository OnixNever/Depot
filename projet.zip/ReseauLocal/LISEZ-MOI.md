# Réseau local — appli Android native (V1)

Remplace l'interface web (`utilisateur.html` + `vocal.js`) par une vraie appli Android.
Elle parle au **même serveur** `serveur.py` (HTTP port 8000, aucune modification du serveur nécessaire)
et utilise le **même protocole d'appels** : les pages web existantes et l'appli peuvent s'appeler entre elles.

## Ce qui change par rapport au web
- Un **service au premier plan** garde la connexion, l'appel WebRTC et l'écoute vocale en vie
  écran éteint, appli en arrière-plan ou fermée du multitâche (fini l'appel qui coupe à la mise en veille).
- **Appels de groupe** (WebRTC natif, jusqu'à la limite du serveur), sonnerie + notification plein écran,
  boutons Répondre / Refuser / Raccrocher / Micro dans la notification.
- **Commandes vocales hors ligne, gratuites, sans clé API** (Vosk), utilisables **pendant un appel** :
  le micro de l'appel est partagé avec la reconnaissance (un seul micro, deux usages).
- Messages, fichiers, images, messages vocaux (.m4a), suppression (appui long sur ses messages).

## Commandes vocales
Toujours précédées du mot d'activation (réglable, « assistant » par défaut), pour ne pas réagir à la voix des autres :
- « assistant appelle <nom> » / « appelle tout le monde » · « assistant ajoute <nom> »
- « assistant raccroche » · « assistant réponds » / « refuse »
- « assistant coupe le micro » / « remets le micro »
- « assistant coupe <nom> » / « remets <nom> » · « coupe tout le monde »
- « assistant active / coupe le haut-parleur »

Au premier lancement : **Réglages → Installer le modèle vocal** (≈ 40 Mo, une seule fois, ensuite tout est hors ligne).
Pour le faire sans réseau : dézipper `vosk-model-small-fr-0.22` et le copier dans
`Android/data/com.reseau.local/files/vosk-fr/` (le dossier doit contenir `am`, `conf`, `graph`…).

## Compiler
- **GitHub** : pousser ce dossier, le workflow `.github/workflows/build.yml` fabrique `app-debug.apk` (onglet Actions → Artifacts).
- Ou Android Studio : ouvrir le dossier, Run.
- Logo : remplacer `app/src/main/res/drawable/ic_launcher.xml`.

## Utilisation
Serveur : `192.168.x.x:8000` (HTTP). Un tunnel https complet (`https://…`) fonctionne aussi.
Autoriser le micro et les notifications, puis « Ne pas optimiser la batterie » dans Réglages.

## Limites connues de cette V1
- **Le serveur PC reste nécessaire** (c'est lui le standard téléphonique). Le mode « sans PC »
  (le téléphone fait office de serveur, appels directs entre téléphones) est l'étape suivante.
- Si le WebSocket tombe (Wi-Fi coupé), le serveur termine l'appel : l'appli se reconnecte seule mais l'appel est perdu.
- Pas de serveur STUN/TURN : appels sur le même réseau local (ou tunnel pour la signalisation, mais l'audio est en direct).
- L'écoute vocale permanente garde le micro ouvert (point vert Android) : désactivable dans Réglages.
- Les versions des bibliothèques (WebRTC, Vosk, Compose) n'ont pas pu être vérifiées ici sans réseau.
