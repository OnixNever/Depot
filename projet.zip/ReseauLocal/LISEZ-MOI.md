# Réseau local — appli Android native (V2)

Remplace l'interface web (`utilisateur.html` + `vocal.js`) par une vraie appli Android.
Elle parle au **même serveur** `serveur.py` (HTTP, port 8000, aucune modification nécessaire) et utilise
le **même protocole d'appels** : les pages web et l'appli peuvent s'appeler entre elles.

## Ce qui est repris de ton interface web
- **Discussion** : messages en direct, « untel écrit… », envoi de plusieurs fichiers à la fois, images avec visionneuse,
  messages vocaux (.m4a, lecture dans l'appli), appui long sur un message : Copier / Télécharger / Supprimer (les siens),
  notifications de messages quand l'appli est en arrière-plan.
- **Appels de groupe** : WebRTC natif, sonnerie + notification plein écran, inviter quelqu'un en cours d'appel,
  couper le son d'un participant ou de tous les autres (chez toi uniquement), minuteur, haut-parleur.
- **Projets (cartes mentales)** : liste, création, suppression, import/export `.json` (même format que la page web),
  arbre avec sous-thèmes repliables, renommer, ajouter, « maîtrisé », supprimer, sauvegarde,
  génération de sous-thèmes par IA locale (Ollama sur le PC, réglages IA dans l'éditeur).
- Déconnexion forcée / compte supprimé gérés. Administration : bouton qui ouvre `gestion_serveur.html` dans le navigateur.

## Ce que le mobile apporte en plus
- Un **service au premier plan** garde connexion, appel et écoute vocale en vie écran éteint, téléphone en poche
  (fini l'appel qui coupe à la mise en veille). L'écran reste allumé pendant un appel.
- **Commandes vocales hors ligne** (Vosk, gratuit, sans clé API), **portage fidèle de ton moteur de `vocal.js`** :
  mêmes listes de formulations (mute, démute, raccroche, coupe les autres, coupe <pseudo>, verrouille l'écran…),
  mots parasites ignorés (« euh », « s'il te plaît »…), négations (« ne coupe pas »), tolérance aux erreurs de
  transcription, reconnaissance des pseudos, 9 mots maximum, et ignorance de ce qui est capté pendant qu'un autre parle.
  **Pendant un appel, aucun mot d'activation n'est nécessaire** (comme dans la version web).
- **Hors appel, téléphone dans la poche** : « assistant appelle <nom> », « assistant appelle tout le monde »,
  « assistant réponds » / « assistant refuse » (le mot d'activation est réglable ou désactivable).
- **Verrou tactile** (« verrouille l'écran » ou bouton cadenas) : seul un appui long sur « Maintenir pour déverrouiller »
  répond ; le bouton retour est neutralisé.
- **Mute physique** : écran verrouillé, les touches de volume coupent/réactivent le micro ;
  le bouton du casque ou des écouteurs coupe/réactive le micro pendant un appel (et répond quand ça sonne).
  Boutons Micro / Raccrocher dans la notification.

## Installation du modèle vocal (une seule fois)
Réglages → « Installer le modèle vocal » (≈ 40 Mo). Sans réseau : dézipper `vosk-model-small-fr-0.22` dans
`Android/data/com.reseau.local/files/vosk-fr/` (le dossier doit contenir `am`, `conf`, `graph`…).

## Compiler
- **GitHub** : pousser le dossier ; `.github/workflows/build.yml` fabrique `app-debug.apk` (Actions → Artifacts).
- Ou Android Studio : ouvrir le dossier, Run. Logo : remplacer `app/src/main/res/drawable/ic_launcher.xml`.

## Connexion
Champ serveur : l'IP du PC suffit (`192.168.1.20` → `http://192.168.1.20:8000`).
Un lien de tunnel complet (`https://…`) est gardé tel quel.

## Limites connues
- Le serveur PC reste nécessaire (c'est le standard téléphonique). Le mode sans PC et le relais pour l'audio
  des appels hors Wi-Fi (4G) sont l'étape suivante : il n'y a pas de serveur STUN/TURN pour l'instant.
- Si le WebSocket tombe, le serveur termine l'appel ; l'appli se reconnecte seule mais l'appel est perdu.
- L'écoute vocale permanente garde le micro ouvert (point vert Android), désactivable dans Réglages.
- Cartes mentales : arbre repliable (pas de zoom/déplacement libre comme sur la page web).
- Pas encore repris : gestion des utilisateurs/couleurs (reste dans la page d'administration), transcription Whisper
  (remplacée par Vosk), glisser-déposer / coller d'images.
- Code non compilé ici (pas de réseau dans mon environnement) : si GitHub renvoie une erreur, envoie-la-moi.
