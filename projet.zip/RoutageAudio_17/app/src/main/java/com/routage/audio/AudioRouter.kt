package com.routage.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper

/**
 * Appelle IAudioService (API cachée). Utilisé DANS le processus Shizuku (wrap=false).
 * Android 10/11 : setPreferredDeviceForStrategy(int, AudioDeviceAttributes)
 * Android 12+   : setPreferredDevicesForStrategy(int, List<AudioDeviceAttributes>)
 *
 * v0.3 : routage PAR APPLI via une AudioPolicy (un AudioMix « règle UID » par appli,
 * routé vers l'appareil choisi) + setUidDeviceAffinity.
 */
object AudioRouter {

    init {
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
    }

    data class AppRoute(val pkg: String, val uid: Int, val type: Int, val address: String)

    private var appPolicy: Any? = null
    private var appPolicyAm: AudioManager? = null

    // Pour une appli normale, Android MASQUE l'adresse Bluetooth (« XX:XX:XX:XX:B6:4C »).
    // Le processus Shizuku (shell) voit l'adresse complète : on compare donc aussi sur les 2 derniers octets.
    private val MASKED = Regex("^(XX:){4}([0-9A-Fa-f]{2}:[0-9A-Fa-f]{2})$", RegexOption.IGNORE_CASE)

    fun addrMatches(real: String?, wanted: String): Boolean {
        val r = real ?: ""
        if (r.equals(wanted, ignoreCase = true)) return true
        val m = MASKED.find(wanted) ?: return false
        return r.endsWith(m.groupValues[2], ignoreCase = true)
    }

    /** Remplace une adresse masquée par la vraie adresse vue par le service. */
    private fun realAddress(ctx: Context?, type: Int, wanted: String, inputs: Boolean): String {
        if (ctx == null || wanted.isEmpty()) return wanted
        return try {
            val am = (shellContext(ctx) { } ?: ctx).getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val list = am.getDevices(if (inputs) AudioManager.GET_DEVICES_INPUTS else AudioManager.GET_DEVICES_OUTPUTS)
            list.firstOrNull { it.type == type && addrMatches(it.address, wanted) }?.address ?: wanted
        } catch (_: Throwable) { wanted }
    }

    private fun audioService(wrap: Boolean): Any {
        val sm = Class.forName("android.os.ServiceManager")
        var binder = sm.getMethod("getService", String::class.java).invoke(null, "audio") as IBinder
        if (wrap) binder = ShizukuBinderWrapper(binder)
        return Class.forName("android.media.IAudioService\$Stub")
            .getMethod("asInterface", IBinder::class.java)
            .invoke(null, binder)!!
    }

    private fun attrs(type: Int, address: String, role: Int = 2 /* 2 = sortie, 1 = entrée */): Any {
        val c = Class.forName("android.media.AudioDeviceAttributes")
        return c.getConstructor(Int::class.java, Int::class.java, String::class.java)
            .newInstance(role, type, address)
    }

    private fun mediaStrategyId(log: (String) -> Unit): Int? {
        val c = Class.forName("android.media.audiopolicy.AudioProductStrategy")
        val list = c.getMethod("getAudioProductStrategies").invoke(null) as List<*>
        for (s in list) {
            val name = c.getMethod("getName").invoke(s) as String
            val id = c.getMethod("getId").invoke(s) as Int
            log("strategy $id = $name")
            if (name.contains("MEDIA", ignoreCase = true)) return id
        }
        return null
    }

    private fun explain(t: Throwable, log: (String) -> Unit) {
        val r = t.cause ?: t
        log("ERREUR : $r")
        r.stackTrace.take(5).forEach { log("   at $it") }
    }

    fun route(ctx: Context?, type: Int, address0: String, wrap: Boolean, log: (String) -> Unit): Boolean {
        return try {
        log("Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), uid=${android.os.Process.myUid()}")
        val id = mediaStrategyId(log) ?: run { log("strategy MEDIA introuvable"); return false }
        val svc = audioService(wrap)
        val address = realAddress(ctx, type, address0, false)
        log("adresse utilisée : $address")
        val a = attrs(type, address)
        val res: Any? = if (Build.VERSION.SDK_INT >= 31) {
            svc.javaClass.methods.first { it.name == "setPreferredDevicesForStrategy" }
                .invoke(svc, id, listOf(a))
        } else {
            svc.javaClass.methods.first { it.name == "setPreferredDeviceForStrategy" }
                .invoke(svc, id, a)
        }
        log("OK → code retour = $res (0 = succès)")
        res == null || res == 0
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun reset(wrap: Boolean, log: (String) -> Unit): Boolean {
        return try {
            val id = mediaStrategyId(log) ?: return false
            val svc = audioService(wrap)
            // Le nom change selon la version d'Android (Device / Devices) : on accepte les deux
            val res = svc.javaClass.methods.first {
                it.name == "removePreferredDevicesForStrategy" || it.name == "removePreferredDeviceForStrategy"
            }.invoke(svc, id)
            log("Retour automatique → code = $res")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    // ───────────────────────── Routage par appli ─────────────────────────

    /** Le contexte du paquet com.android.shell (uid 2000) colle à l'identité du processus Shizuku. */
    private fun shellContext(base: Context?, log: (String) -> Unit): Context? {
        if (base == null) return null
        return try {
            val c = base.createPackageContext("com.android.shell", Context.CONTEXT_IGNORE_SECURITY)
            log("Context : com.android.shell"); c
        } catch (t: Throwable) {
            log("Context shell indisponible ($t) → Context de l'appli"); base
        }
    }

    fun routeApps(base: Context?, entries: List<AppRoute>, log: (String) -> Unit): Boolean {
        return try {
            log("Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), uid=${android.os.Process.myUid()}")
            clearApps(log)
            if (entries.isEmpty()) { log("Aucune appli à router"); return true }
            val ctx = shellContext(base, log) ?: run { log("Pas de Context : impossible"); return false }
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            outputs.forEach { log("sortie vue par le service : id=${it.id} type=${it.type} ${it.productName} [${it.address}]") }

            val ruleC = Class.forName("android.media.audiopolicy.AudioMixingRule")
            val ruleBC = Class.forName("android.media.audiopolicy.AudioMixingRule\$Builder")
            val mixC = Class.forName("android.media.audiopolicy.AudioMix")
            val mixBC = Class.forName("android.media.audiopolicy.AudioMix\$Builder")
            val polC = Class.forName("android.media.audiopolicy.AudioPolicy")
            val polBC = Class.forName("android.media.audiopolicy.AudioPolicy\$Builder")

            val format = AudioFormat.Builder()
                .setSampleRate(48000)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .build()

            val pb = polBC.getConstructor(Context::class.java).newInstance(ctx)
            val affinity = ArrayList<Pair<AppRoute, AudioDeviceInfo>>()

            // Android n'accepte qu'UN mix par adresse d'appareil : on regroupe donc les applis par appareil
            // (un seul mix, plusieurs règles UID) au lieu d'un mix par appli.
            val groups = LinkedHashMap<Int, Pair<AudioDeviceInfo, ArrayList<AppRoute>>>()
            for (e in entries) {
                val cands = if (e.address.isNotEmpty()) outputs.filter { addrMatches(it.address, e.address) }
                            else outputs.filter { it.type == e.type }
                val dev = cands.firstOrNull { it.type == e.type }
                    ?: cands.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
                    ?: cands.firstOrNull()
                if (dev == null) { log("${e.pkg} : appareil introuvable (type ${e.type}, ${e.address})"); continue }
                groups.getOrPut(dev.id) { dev to ArrayList() }.second.add(e)
                affinity.add(e to dev)
            }

            for ((dev, apps) in groups.values) {
                // règle : tous les sons de ces UID
                val rb = ruleBC.getConstructor().newInstance()
                val addRule = ruleBC.getMethod("addMixRule", Int::class.javaPrimitiveType, Any::class.java)
                for (uid in apps.map { it.uid }.distinct()) addRule.invoke(rb, 4 /* RULE_MATCH_UID */, uid)
                val rule = ruleBC.getMethod("build").invoke(rb)

                // mix : rendu (ROUTE_FLAG_RENDER = 1) vers l'appareil précis
                val mb = mixBC.getConstructor(ruleC).newInstance(rule)
                mixBC.getMethod("setFormat", AudioFormat::class.java).invoke(mb, format)
                mixBC.getMethod("setRouteFlags", Int::class.javaPrimitiveType).invoke(mb, 1)
                mixBC.getMethod("setDevice", AudioDeviceInfo::class.java).invoke(mb, dev)
                val mix = mixBC.getMethod("build").invoke(mb)

                polBC.getMethod("addMix", mixC).invoke(pb, mix)
                log("mix prêt : ${apps.joinToString { it.pkg }} → ${typeName(dev.type)} ${dev.productName} [${dev.address}]")
            }
            if (affinity.isEmpty()) { log("Aucun mix créé"); return false }

            val policy = polBC.getMethod("build").invoke(pb)!!
            val code = am.javaClass.getMethod("registerAudioPolicy", polC).invoke(am, policy)
            log("registerAudioPolicy → $code (0 = succès)")
            try { log("statut de la politique : " + policy.javaClass.getMethod("getStatus").invoke(policy)) } catch (_: Throwable) {}
            if (code != 0) { log("Politique refusée par Android"); return false }
            appPolicy = policy; appPolicyAm = am

            for ((e, dev) in affinity) {
                try {
                    val m = polC.getMethod("setUidDeviceAffinity", Int::class.javaPrimitiveType, List::class.java)
                    // Mêmes écouteurs, autres profils (ex. « appel » en plus de « média ») : les appels suivent aussi
                    val twins = outputs.filter { it.id != dev.id && !dev.address.isNullOrEmpty() && it.address == dev.address }
                    var ok = m.invoke(policy, e.uid, listOf(dev) + twins)
                    log("setUidDeviceAffinity ${e.pkg} (+${twins.size} profil(s) du même appareil) → $ok")
                    if (ok != true && twins.isNotEmpty()) {
                        ok = m.invoke(policy, e.uid, listOf(dev))
                        log("setUidDeviceAffinity ${e.pkg} (appareil seul) → $ok")
                    }
                } catch (t: Throwable) { log("affinité ${e.pkg} :"); explain(t, log) }
            }
            log("Relance la lecture dans les applis pour que le son bascule.")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun clearApps(log: (String) -> Unit): Boolean {
        val p = appPolicy ?: return true
        return try {
            val polC = Class.forName("android.media.audiopolicy.AudioPolicy")
            val am = appPolicyAm!!
            am.javaClass.getMethod("unregisterAudioPolicy", polC).invoke(am, p)
            appPolicy = null; appPolicyAm = null
            log("Routage par appli retiré")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    // ───────────────────────── Micro (réglage global) ─────────────────────────

    // MIC, CAMCORDER, VOICE_RECOGNITION, VOICE_COMMUNICATION, UNPROCESSED, VOICE_PERFORMANCE
    private val capturePresets = intArrayOf(1, 5, 6, 7, 9, 10)

    fun setMic(ctx: Context?, type: Int, address0: String, log: (String) -> Unit): Boolean {
        return try {
            val svc = audioService(false)
            val m = svc.javaClass.methods.firstOrNull {
                it.name.startsWith("setPreferredDevice") && it.name.endsWith("ForCapturePreset") && it.parameterTypes.size == 2
            } ?: run { log("ERREUR : API micro introuvable sur cet Android"); return false }
            val address = realAddress(ctx, type, address0, true)
            val a = attrs(type, address, 1)
            val wantsList = List::class.java.isAssignableFrom(m.parameterTypes[1])
            var ok = 0
            for (p in capturePresets) {
                try {
                    val r = m.invoke(svc, p, if (wantsList) listOf(a) else a)
                    log("micro preset $p → code $r (0 = succès)")
                    if (r == null || r == 0) ok++
                } catch (t: Throwable) { log("micro preset $p :"); explain(t, log) }
            }
            if (ok == 0) log("ERREUR : micro refusé par Android")
            ok > 0
        } catch (t: Throwable) { explain(t, log); false }
    }

    // ───────────── Volume par appareil ─────────────

    private fun audioManagerShell(base: Context?): AudioManager? {
        val c = shellContext(base) { } ?: base ?: return null
        return c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    /** Exécute une commande shell (le service tourne en uid 2000) et renvoie sa sortie. */
    private fun sh(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", "$cmd 2>&1"))
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor(); out
    } catch (t: Throwable) { "ERR: $t" }

    private fun looksFailed(o: String) =
        o.isNotEmpty() && Regex("(?i)(error|unknown|exception|usage|not found|denied|invalid|erreur|ERR:)").containsMatchIn(o)

    /** Code « natif » Android du type d'appareil (celui qu'attendent les commandes système). */
    fun legacyDeviceInt(type: Int): Int = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> 0x1
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> 0x2
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> 0x4
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> 0x8
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> 0x10
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> 0x80
        AudioDeviceInfo.TYPE_USB_HEADSET -> 0x4000000
        else -> 0
    }

    /** Diagnostic : volume actuel (index) d'un appareil, pour le Journal. */
    fun peekDeviceVolume(type: Int, stream: Int): String {
        val nat = legacyDeviceInt(type)
        return if (nat == 0) "type $type sans code natif" else sh("cmd audio get-device-volume $stream $nat").take(100)
    }

    private fun volInfo(stream: Int, min: Int, max: Int, index: Int?): Any {
        val vbC = Class.forName("android.media.VolumeInfo\$Builder")
        val vb = vbC.getConstructor(Int::class.javaPrimitiveType).newInstance(stream)
        if (index != null) {
            vbC.getMethod("setMinVolumeIndex", Int::class.javaPrimitiveType).invoke(vb, min)
            vbC.getMethod("setMaxVolumeIndex", Int::class.javaPrimitiveType).invoke(vb, max)
            vbC.getMethod("setVolumeIndex", Int::class.javaPrimitiveType).invoke(vb, index)
        }
        return vbC.getMethod("build").invoke(vb)!!
    }

    /**
     * Règle le volume d'UN appareil de sortie (stream : 3 = média, 0 = appel).
     * Trois méthodes, essayées dans l'ordre, chacune écrite dans le Journal :
     *  [A] commande système « cmd audio set-device-volume » (faite pour le shell)
     *  [B] AudioManager.setDeviceVolume (API cachée Android 14+)
     *  [C] AudioSystem.setStreamVolumeIndexAS (appel natif direct)
     */
    fun setDeviceVolume(base: Context?, type: Int, address0: String, stream: Int, percent: Int, log: (String) -> Unit): Boolean {
        val am = audioManagerShell(base) ?: run { log("ERREUR : pas de Context"); return false }
        val address = realAddress(base, type, address0, false)
        val max = am.getStreamMaxVolume(stream)
        val min = try { am.getStreamMinVolume(stream) } catch (_: Throwable) { 0 }
        val index = (min + Math.round((max - min) * percent.coerceIn(0, 100) / 100f)).coerceIn(min, max)
        val nat = legacyDeviceInt(type)
        log("demande : ${typeName(type)} [$address] flux=$stream $percent % → index $index/$max (code natif $nat)")

        if (nat != 0) {
            val o = sh("cmd audio set-device-volume $stream $index $nat")
            log("[A] cmd audio set-device-volume → " + (o.ifEmpty { "ok (aucune sortie)" }).take(110))
            if (!looksFailed(o)) return true
        } else log("[A] pas de code natif pour le type $type")

        try {
            val viC = Class.forName("android.media.VolumeInfo")
            val adaC = Class.forName("android.media.AudioDeviceAttributes")
            am.javaClass.getMethod("setDeviceVolume", viC, adaC).invoke(am, volInfo(stream, min, max, index), attrs(type, address))
            log("[B] AudioManager.setDeviceVolume → ok")
            return true
        } catch (t: Throwable) { log("[B] AudioManager.setDeviceVolume refusé : ${(t.cause ?: t)}") }

        if (nat != 0) try {
            val asC = Class.forName("android.media.AudioSystem")
            val m = asC.getMethod("setStreamVolumeIndexAS", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            val r = m.invoke(null, stream, index, nat)
            log("[C] AudioSystem.setStreamVolumeIndexAS → $r (0 = succès)")
            if (r == 0) return true
        } catch (t: Throwable) { log("[C] AudioSystem refusé : ${(t.cause ?: t)}") }

        log("ERREUR : les 3 méthodes de volume par appareil ont échoué")
        return false
    }

    /** Lit le volume (en %) d'un appareil. Le retour contient « vol=NN » (ou « vol=-1 »). */
    fun getDeviceVolume(base: Context?, type: Int, address0: String, stream: Int, log: (String) -> Unit): Boolean {
        val am = audioManagerShell(base) ?: run { log("ERREUR : pas de Context"); return false }
        val max = am.getStreamMaxVolume(stream)
        val min = try { am.getStreamMinVolume(stream) } catch (_: Throwable) { 0 }
        val nat = legacyDeviceInt(type)
        if (nat != 0) {
            val o = sh("cmd audio get-device-volume $stream $nat")
            val idx = Regex("-?\\d+").find(o)?.value?.toIntOrNull()
            if (!looksFailed(o) && idx != null && max > min) {
                log("vol=" + ((idx - min) * 100f / (max - min)).toInt().coerceIn(0, 100)); return true
            }
            log("lecture [A] : " + o.take(100))
        }
        try {
            val address = realAddress(base, type, address0, false)
            val viC = Class.forName("android.media.VolumeInfo")
            val adaC = Class.forName("android.media.AudioDeviceAttributes")
            val vi = am.javaClass.getMethod("getDeviceVolume", viC, adaC).invoke(am, volInfo(stream, min, max, null), attrs(type, address))
            val idx = viC.getMethod("getVolumeIndex").invoke(vi) as Int
            log("vol=" + (if (max > min) ((idx - min) * 100f / (max - min)).toInt().coerceIn(0, 100) else 0)); return true
        } catch (t: Throwable) { log("lecture [B] : ${(t.cause ?: t)}") }
        log("vol=-1"); return false
    }

    fun clearMic(log: (String) -> Unit): Boolean {
        return try {
            val svc = audioService(false)
            val m = svc.javaClass.methods.firstOrNull {
                it.name.contains("ForCapturePreset") && (it.name.startsWith("clear") || it.name.startsWith("remove")) &&
                    it.parameterTypes.size == 1
            } ?: run { log("Micro : rien à réinitialiser (API absente)"); return true }
            for (p in capturePresets) {
                try { m.invoke(svc, p) } catch (t: Throwable) { log("micro reset $p : ${t.cause ?: t}") }
            }
            log("Micro en automatique")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Haut-parleur du téléphone"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Écouteur interne"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Casque filaire"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Écouteurs filaires"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (média)"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (appel)"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Micro du téléphone"
        AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> "Sortie type $t"
    }
}
