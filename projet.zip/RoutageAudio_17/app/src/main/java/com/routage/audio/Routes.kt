package com.routage.audio

import android.content.Context
import android.media.AudioManager
import org.json.JSONArray
import org.json.JSONObject

/**
 * Lecture des routages sauvegardés + vérification du résultat.
 * Partagé par l'écran principal et par le veilleur du panneau de volume (qui ré-applique le routage
 * quand un appareil se (re)connecte, même appli fermée).
 */
object Routes {
    class Mic(val type: Int, val address: String)

    private fun same(t1: Int, a1: String, t2: Int, a2: String): Boolean =
        if (a1.isNotEmpty() || a2.isNotEmpty()) a1 == a2 else t1 == t2

    /** (demande pour le service, nombre d'applis qui ont un appareil choisi). Seuls les appareils connectés sont envoyés. */
    fun spec(ctx: Context): Pair<String, Int> {
        val prefs = ctx.getSharedPreferences("routes", Context.MODE_PRIVATE)
        val out = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val sb = StringBuilder()
        var wanted = 0
        try {
            val arr = JSONArray(prefs.getString("apps", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optInt("type", -1)
                if (t < 0) continue
                wanted++
                val a = o.optString("address")
                if (out.none { same(it.type, it.address ?: "", t, a) }) continue
                val pkg = o.getString("pkg")
                val uid = try { ctx.packageManager.getApplicationInfo(pkg, 0).uid } catch (x: Exception) { continue }
                sb.appendLine("$pkg|$uid|$t|$a")
            }
        } catch (e: Exception) { LogStore.add("Lecture sauvegarde : $e") }
        return sb.toString() to wanted
    }

    /** Micro choisi ET actuellement connecté (sinon null). */
    fun mic(ctx: Context): Mic? {
        return try {
            val o = JSONObject(ctx.getSharedPreferences("routes", Context.MODE_PRIVATE).getString("mic", "{}") ?: "{}")
            val t = o.optInt("type", -1)
            if (t < 0) return null
            val a = o.optString("address")
            val ins = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getDevices(AudioManager.GET_DEVICES_INPUTS)
            if (ins.any { same(it.type, it.address ?: "", t, a) }) Mic(t, a) else null
        } catch (e: Exception) { null }
    }

    fun hasMicChoice(ctx: Context): Boolean = try {
        JSONObject(ctx.getSharedPreferences("routes", Context.MODE_PRIVATE).getString("mic", "{}") ?: "{}").optInt("type", -1) >= 0
    } catch (e: Exception) { false }

    /** Résume le compte rendu de routeApps : (tout va bien ?, phrase pour le Journal / l'écran). */
    fun verdict(report: String, wanted: Int, sent: Int): Pair<Boolean, String> {
        if (sent == 0) return true to (if (wanted == 0) "aucune appli à router" else "appareil non connecté pour $wanted appli(s) — routage en attente")
        val last = HashMap<String, String>()
        Regex("setUidDeviceAffinity (\\S+) \\((.*?)\\) → (\\w+)").findAll(report).forEach {
            last[it.groupValues[1]] = it.groupValues[2] + "|" + it.groupValues[3]
        }
        val problems = ArrayList<String>()
        if (report.contains("refusée") || report.contains("Aucun mix") || report.contains("ERREUR"))
            problems.add("Android a refusé ou n'a pas pu appliquer le routage")
        val bad = last.filter { !it.value.endsWith("|true") }.keys
        if (bad.isNotEmpty()) problems.add("son non redirigé pour : " + bad.joinToString())
        if (last.size < sent) problems.add("${sent - last.size} appli(s) non confirmée(s) par Android")
        if (problems.isNotEmpty()) return false to problems.joinToString(" ; ")
        val both = last.values.count { Regex("^\\+[1-9]").containsMatchIn(it.substringBefore("|")) }
        val mediaOnly = last.size - both
        return true to "$sent appli(s) routée(s) ✓ (média + appel : $both, média seul : $mediaOnly)"
    }
}
