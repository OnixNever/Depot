package com.routage.audio

import android.content.ComponentName
import rikka.shizuku.Shizuku

/** Une seule définition du service Shizuku, partagée par l'écran et par le panneau de volume. */
object Cfg {
    const val SERVICE_VERSION = 9

    /** Vrai quand l'écran de l'appli est ouvert : c'est lui qui ré-applique le routage ; sinon c'est le veilleur du panneau. */
    @Volatile var uiOpen = false

    fun args(pkg: String): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(ComponentName(pkg, UserService::class.java.name))
            .daemon(true).processNameSuffix("audio").debuggable(false).version(SERVICE_VERSION)
}
