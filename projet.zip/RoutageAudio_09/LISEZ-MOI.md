# Routage Audio v0.6.0

- Sortie par appli : tout le son de l'appli (média, appels, navigation) vise l'appareil choisi ;
  les autres profils du même appareil (ex. « appel » d'écouteurs Bluetooth) sont autorisés aussi.
- Micro : réglage séparé de la sortie. Il est COMMUN à toutes les applis (Android ne sait pas
  choisir un micro par appli de façon fiable). Appliqué aux usages micro, vocal, reconnaissance,
  communication et enregistrement.
- « Tout en automatique » remet sorties, applis et micro en automatique.
- Tout est sauvegardé et ré-appliqué à l'ouverture ; le service Shizuku garde le routage actif
  appli fermée (tant que Shizuku tourne).
- « Journal » (en bas) : détail technique en cas de problème.

- v0.6.0 : service Shizuku relancé avec le nouveau code (version 3) ; les erreurs sont écrites dans le Journal
  au lieu de fermer l'appli ; un plantage est enregistré et affiché à la réouverture suivante.

- v0.6.0 : un appareil Bluetooth = UNE ligne (profils média + appel regroupés) ; plusieurs applis sur le même
  appareil partagent un seul mix (Android refuse deux mix pour la même adresse) ; service relancé (version 4).
- Micro : toujours un réglage commun à toutes les applis (pas d'API Android pour un micro par appli).
