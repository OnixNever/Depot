package com.routage.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper

/**
 * Appelle IAudioService (API cachée). Utilisé DANS le processus Shizuku (wrap=false).
 * Android 10/11 : setPreferredDeviceForStrategy(int, AudioDeviceAttributes)
 * Android 12+   : setPreferredDevicesForStrategy(int, List<AudioDeviceAttributes>)
 *
 * v0.3 : routage PAR APPLI via une AudioPolicy (un AudioMix « règle UID » par appli,
 * routé vers l'appareil choisi) + setUidDeviceAffinity.
 */
object AudioRouter {

    init {
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
    }

    data class AppRoute(val pkg: String, val uid: Int, val type: Int, val address: String)

    private var appPolicy: Any? = null
    private var appPolicyAm: AudioManager? = null

    private fun audioService(wrap: Boolean): Any {
        val sm = Class.forName("android.os.ServiceManager")
        var binder = sm.getMethod("getService", String::class.java).invoke(null, "audio") as IBinder
        if (wrap) binder = ShizukuBinderWrapper(binder)
        return Class.forName("android.media.IAudioService\$Stub")
            .getMethod("asInterface", IBinder::class.java)
            .invoke(null, binder)!!
    }

    private fun attrs(type: Int, address: String, role: Int = 2 /* 2 = sortie, 1 = entrée */): Any {
        val c = Class.forName("android.media.AudioDeviceAttributes")
        return c.getConstructor(Int::class.java, Int::class.java, String::class.java)
            .newInstance(role, type, address)
    }

    private fun mediaStrategyId(log: (String) -> Unit): Int? {
        val c = Class.forName("android.media.audiopolicy.AudioProductStrategy")
        val list = c.getMethod("getAudioProductStrategies").invoke(null) as List<*>
        for (s in list) {
            val name = c.getMethod("getName").invoke(s) as String
            val id = c.getMethod("getId").invoke(s) as Int
            log("strategy $id = $name")
            if (name.contains("MEDIA", ignoreCase = true)) return id
        }
        return null
    }

    private fun explain(t: Throwable, log: (String) -> Unit) {
        val r = t.cause ?: t
        log("ERREUR : $r")
        r.stackTrace.take(5).forEach { log("   at $it") }
    }

    fun route(type: Int, address: String, wrap: Boolean, log: (String) -> Unit): Boolean {
        return try {
        log("Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), uid=${android.os.Process.myUid()}")
        val id = mediaStrategyId(log) ?: run { log("strategy MEDIA introuvable"); return false }
        val svc = audioService(wrap)
        val a = attrs(type, address)
        val res: Any? = if (Build.VERSION.SDK_INT >= 31) {
            svc.javaClass.methods.first { it.name == "setPreferredDevicesForStrategy" }
                .invoke(svc, id, listOf(a))
        } else {
            svc.javaClass.methods.first { it.name == "setPreferredDeviceForStrategy" }
                .invoke(svc, id, a)
        }
        log("OK → code retour = $res (0 = succès)")
        res == null || res == 0
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun reset(wrap: Boolean, log: (String) -> Unit): Boolean {
        return try {
            val id = mediaStrategyId(log) ?: return false
            val svc = audioService(wrap)
            // Le nom change selon la version d'Android (Device / Devices) : on accepte les deux
            val res = svc.javaClass.methods.first {
                it.name == "removePreferredDevicesForStrategy" || it.name == "removePreferredDeviceForStrategy"
            }.invoke(svc, id)
            log("Retour automatique → code = $res")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    // ───────────────────────── Routage par appli ─────────────────────────

    /** Le contexte du paquet com.android.shell (uid 2000) colle à l'identité du processus Shizuku. */
    private fun shellContext(base: Context?, log: (String) -> Unit): Context? {
        if (base == null) return null
        return try {
            val c = base.createPackageContext("com.android.shell", Context.CONTEXT_IGNORE_SECURITY)
            log("Context : com.android.shell"); c
        } catch (t: Throwable) {
            log("Context shell indisponible ($t) → Context de l'appli"); base
        }
    }

    fun routeApps(base: Context?, entries: List<AppRoute>, log: (String) -> Unit): Boolean {
        return try {
            log("Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), uid=${android.os.Process.myUid()}")
            clearApps(log)
            if (entries.isEmpty()) { log("Aucune appli à router"); return true }
            val ctx = shellContext(base, log) ?: run { log("Pas de Context : impossible"); return false }
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

            val ruleC = Class.forName("android.media.audiopolicy.AudioMixingRule")
            val ruleBC = Class.forName("android.media.audiopolicy.AudioMixingRule\$Builder")
            val mixC = Class.forName("android.media.audiopolicy.AudioMix")
            val mixBC = Class.forName("android.media.audiopolicy.AudioMix\$Builder")
            val polC = Class.forName("android.media.audiopolicy.AudioPolicy")
            val polBC = Class.forName("android.media.audiopolicy.AudioPolicy\$Builder")

            val format = AudioFormat.Builder()
                .setSampleRate(48000)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .build()

            val pb = polBC.getConstructor(Context::class.java).newInstance(ctx)
            val affinity = ArrayList<Pair<AppRoute, AudioDeviceInfo>>()

            // Android n'accepte qu'UN mix par adresse d'appareil : on regroupe donc les applis par appareil
            // (un seul mix, plusieurs règles UID) au lieu d'un mix par appli.
            val groups = LinkedHashMap<Int, Pair<AudioDeviceInfo, ArrayList<AppRoute>>>()
            for (e in entries) {
                val cands = if (e.address.isNotEmpty()) outputs.filter { (it.address ?: "") == e.address }
                            else outputs.filter { it.type == e.type }
                val dev = cands.firstOrNull { it.type == e.type }
                    ?: cands.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
                    ?: cands.firstOrNull()
                if (dev == null) { log("${e.pkg} : appareil introuvable (type ${e.type}, ${e.address})"); continue }
                groups.getOrPut(dev.id) { dev to ArrayList() }.second.add(e)
                affinity.add(e to dev)
            }

            for ((dev, apps) in groups.values) {
                // règle : tous les sons de ces UID
                val rb = ruleBC.getConstructor().newInstance()
                val addRule = ruleBC.getMethod("addMixRule", Int::class.javaPrimitiveType, Any::class.java)
                for (uid in apps.map { it.uid }.distinct()) addRule.invoke(rb, 4 /* RULE_MATCH_UID */, uid)
                val rule = ruleBC.getMethod("build").invoke(rb)

                // mix : rendu (ROUTE_FLAG_RENDER = 1) vers l'appareil précis
                val mb = mixBC.getConstructor(ruleC).newInstance(rule)
                mixBC.getMethod("setFormat", AudioFormat::class.java).invoke(mb, format)
                mixBC.getMethod("setRouteFlags", Int::class.javaPrimitiveType).invoke(mb, 1)
                mixBC.getMethod("setDevice", AudioDeviceInfo::class.java).invoke(mb, dev)
                val mix = mixBC.getMethod("build").invoke(mb)

                polBC.getMethod("addMix", mixC).invoke(pb, mix)
                log("mix prêt : ${apps.joinToString { it.pkg }} → ${typeName(dev.type)} ${dev.productName} [${dev.address}]")
            }
            if (affinity.isEmpty()) { log("Aucun mix créé"); return false }

            val policy = polBC.getMethod("build").invoke(pb)!!
            val code = am.javaClass.getMethod("registerAudioPolicy", polC).invoke(am, policy)
            log("registerAudioPolicy → $code (0 = succès)")
            if (code != 0) { log("Politique refusée par Android"); return false }
            appPolicy = policy; appPolicyAm = am

            for ((e, dev) in affinity) {
                try {
                    val m = polC.getMethod("setUidDeviceAffinity", Int::class.javaPrimitiveType, List::class.java)
                    // Mêmes écouteurs, autres profils (ex. « appel » en plus de « média ») : les appels suivent aussi
                    val twins = outputs.filter { it.id != dev.id && e.address.isNotEmpty() && (it.address ?: "") == e.address }
                    var ok = m.invoke(policy, e.uid, listOf(dev) + twins)
                    log("setUidDeviceAffinity ${e.pkg} (+${twins.size} profil(s) du même appareil) → $ok")
                    if (ok != true && twins.isNotEmpty()) {
                        ok = m.invoke(policy, e.uid, listOf(dev))
                        log("setUidDeviceAffinity ${e.pkg} (appareil seul) → $ok")
                    }
                } catch (t: Throwable) { log("affinité ${e.pkg} :"); explain(t, log) }
            }
            log("Relance la lecture dans les applis pour que le son bascule.")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun clearApps(log: (String) -> Unit): Boolean {
        val p = appPolicy ?: return true
        return try {
            val polC = Class.forName("android.media.audiopolicy.AudioPolicy")
            val am = appPolicyAm!!
            am.javaClass.getMethod("unregisterAudioPolicy", polC).invoke(am, p)
            appPolicy = null; appPolicyAm = null
            log("Routage par appli retiré")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    // ───────────────────────── Micro (réglage global) ─────────────────────────

    // MIC, CAMCORDER, VOICE_RECOGNITION, VOICE_COMMUNICATION, UNPROCESSED, VOICE_PERFORMANCE
    private val capturePresets = intArrayOf(1, 5, 6, 7, 9, 10)

    fun setMic(type: Int, address: String, log: (String) -> Unit): Boolean {
        return try {
            val svc = audioService(false)
            val m = svc.javaClass.methods.firstOrNull {
                it.name.startsWith("setPreferredDevice") && it.name.endsWith("ForCapturePreset") && it.parameterTypes.size == 2
            } ?: run { log("ERREUR : API micro introuvable sur cet Android"); return false }
            val a = attrs(type, address, 1)
            val wantsList = List::class.java.isAssignableFrom(m.parameterTypes[1])
            var ok = 0
            for (p in capturePresets) {
                try {
                    val r = m.invoke(svc, p, if (wantsList) listOf(a) else a)
                    log("micro preset $p → code $r (0 = succès)")
                    if (r == null || r == 0) ok++
                } catch (t: Throwable) { log("micro preset $p :"); explain(t, log) }
            }
            if (ok == 0) log("ERREUR : micro refusé par Android")
            ok > 0
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun clearMic(log: (String) -> Unit): Boolean {
        return try {
            val svc = audioService(false)
            val m = svc.javaClass.methods.firstOrNull {
                it.name.contains("ForCapturePreset") && (it.name.startsWith("clear") || it.name.startsWith("remove")) &&
                    it.parameterTypes.size == 1
            } ?: run { log("Micro : rien à réinitialiser (API absente)"); return true }
            for (p in capturePresets) {
                try { m.invoke(svc, p) } catch (t: Throwable) { log("micro reset $p : ${t.cause ?: t}") }
            }
            log("Micro en automatique")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Haut-parleur du téléphone"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Écouteur interne"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Casque filaire"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Écouteurs filaires"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (média)"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (appel)"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Micro du téléphone"
        AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> "Sortie type $t"
    }
}
