package com.routage.audio

import android.content.Context
import androidx.annotation.Keep
import kotlin.system.exitProcess

/** Tourne dans un processus lancé par Shizuku (identité shell). */
class UserService : IUserService.Stub {

    private var ctx: Context? = null

    constructor() : super()
    @Keep constructor(context: Context) : super() { ctx = context }

    override fun destroy() { AudioRouter.clearApps { }; exitProcess(0) }

    override fun exec(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        out + err
    } catch (t: Throwable) { "ERR: $t" }

    override fun route(type: Int, address: String): String {
        val sb = StringBuilder()
        AudioRouter.route(type, address, false) { sb.appendLine(it) }
        return sb.toString()
    }

    override fun reset(): String {
        val sb = StringBuilder()
        AudioRouter.reset(false) { sb.appendLine(it) }
        return sb.toString()
    }

    /** spec : une ligne par appli, « paquet|uid|typeAppareil|adresse ». */
    override fun routeApps(spec: String): String {
        val sb = StringBuilder()
        try {
            val entries = spec.lines().mapNotNull { l ->
                val p = l.trim().split("|")
                if (p.size < 4) null else AudioRouter.AppRoute(p[0], p[1].toInt(), p[2].toInt(), p[3])
            }
            AudioRouter.routeApps(ctx, entries) { sb.appendLine(it) }
        } catch (t: Throwable) { sb.appendLine("ERREUR spec : $t") }
        return sb.toString()
    }

    override fun setMic(type: Int, address: String): String {
        val sb = StringBuilder()
        AudioRouter.setMic(type, address) { sb.appendLine(it) }
        return sb.toString()
    }

    override fun clearMic(): String {
        val sb = StringBuilder()
        AudioRouter.clearMic { sb.appendLine(it) }
        return sb.toString()
    }

    override fun clearApps(): String {
        val sb = StringBuilder()
        AudioRouter.clearApps { sb.appendLine(it) }
        return sb.toString()
    }
}
