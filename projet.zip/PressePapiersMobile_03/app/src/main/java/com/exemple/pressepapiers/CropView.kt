package com.exemple.pressepapiers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** Image avec un cadre de rognage déplaçable (coins, bords, ou le cadre entier). */
class CropView(c: Context) : View(c) {
    private var bitmap: Bitmap? = null
    private val zoneImage = RectF()
    private val cadre = RectF()
    private var surLeCadre = false

    private val peinture = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val voile = Paint().apply { color = Color.argb(150, 0, 0, 0) }
    private val trait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val grille = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val poignee = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private val marge = 64f
    private val minimum = 90f
    private val GAUCHE = 1
    private val HAUT = 2
    private val DROITE = 4
    private val BAS = 8
    private val DEPLACER = 16
    private var mode = 0
    private var dernierX = 0f
    private var dernierY = 0f

    fun definir(b: Bitmap) {
        bitmap = b
        surLeCadre = false
        requestLayout()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        calculerZone()
    }

    private fun calculerZone() {
        val b = bitmap ?: return
        if (width == 0 || height == 0) return
        val echelle = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
        val lw = b.width * echelle
        val lh = b.height * echelle
        val ancienne = RectF(zoneImage)
        zoneImage.set((width - lw) / 2, (height - lh) / 2, (width + lw) / 2, (height + lh) / 2)
        if (!surLeCadre || ancienne.isEmpty) {
            cadre.set(zoneImage)
            surLeCadre = true
        }
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        if (zoneImage.isEmpty) calculerZone()
        canvas.drawBitmap(b, null, zoneImage, peinture)

        // voile sombre autour du cadre
        canvas.drawRect(zoneImage.left, zoneImage.top, zoneImage.right, cadre.top, voile)
        canvas.drawRect(zoneImage.left, cadre.bottom, zoneImage.right, zoneImage.bottom, voile)
        canvas.drawRect(zoneImage.left, cadre.top, cadre.left, cadre.bottom, voile)
        canvas.drawRect(cadre.right, cadre.top, zoneImage.right, cadre.bottom, voile)

        // grille des tiers
        val tx = cadre.width() / 3
        val ty = cadre.height() / 3
        for (i in 1..2) {
            canvas.drawLine(cadre.left + tx * i, cadre.top, cadre.left + tx * i, cadre.bottom, grille)
            canvas.drawLine(cadre.left, cadre.top + ty * i, cadre.right, cadre.top + ty * i, grille)
        }
        canvas.drawRect(cadre, trait)

        // poignées : coins et milieux des bords
        val xs = floatArrayOf(cadre.left, cadre.centerX(), cadre.right)
        val ys = floatArrayOf(cadre.top, cadre.centerY(), cadre.bottom)
        for (xi in 0..2) for (yi in 0..2) {
            if (xi == 1 && yi == 1) continue
            canvas.drawCircle(xs[xi], ys[yi], 14f, poignee)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = trouverMode(e.x, e.y)
                dernierX = e.x
                dernierY = e.y
                return mode != 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 0) return false
                bouger(e.x - dernierX, e.y - dernierY)
                dernierX = e.x
                dernierY = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }

    private fun trouverMode(x: Float, y: Float): Int {
        val r = cadre
        var f = 0
        val dansY = y > r.top - marge && y < r.bottom + marge
        val dansX = x > r.left - marge && x < r.right + marge
        if (dansY) {
            val g = abs(x - r.left)
            val d = abs(x - r.right)
            if (g < marge && g <= d) f = f or GAUCHE else if (d < marge) f = f or DROITE
        }
        if (dansX) {
            val h = abs(y - r.top)
            val b = abs(y - r.bottom)
            if (h < marge && h <= b) f = f or HAUT else if (b < marge) f = f or BAS
        }
        if (f == 0 && r.contains(x, y)) f = DEPLACER
        return f
    }

    private fun bouger(dx: Float, dy: Float) {
        val z = zoneImage
        if (mode == DEPLACER) {
            val ddx = dx.coerceIn(z.left - cadre.left, z.right - cadre.right)
            val ddy = dy.coerceIn(z.top - cadre.top, z.bottom - cadre.bottom)
            cadre.offset(ddx, ddy)
            return
        }
        if (mode and GAUCHE != 0) cadre.left = (cadre.left + dx).coerceIn(z.left, cadre.right - minimum)
        if (mode and DROITE != 0) cadre.right = (cadre.right + dx).coerceIn(cadre.left + minimum, z.right)
        if (mode and HAUT != 0) cadre.top = (cadre.top + dy).coerceIn(z.top, cadre.bottom - minimum)
        if (mode and BAS != 0) cadre.bottom = (cadre.bottom + dy).coerceIn(cadre.top + minimum, z.bottom)
    }

    /** Cadre exprimé en fractions (0 à 1) de l'image : gauche, haut, droite, bas. */
    fun fractions(): RectF {
        if (zoneImage.isEmpty) return RectF(0f, 0f, 1f, 1f)
        return RectF(
            (cadre.left - zoneImage.left) / zoneImage.width(),
            (cadre.top - zoneImage.top) / zoneImage.height(),
            (cadre.right - zoneImage.left) / zoneImage.width(),
            (cadre.bottom - zoneImage.top) / zoneImage.height()
        )
    }

    fun toutReinitialiser() {
        cadre.set(zoneImage)
        invalidate()
    }
}
