package com.routage.audio

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var logView: TextView
    private var selected: Int = -1
    private var svc: IUserService? = null
    private var binding = false
    private var snapshot: Set<String>? = null

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
    private val binderListener = Shizuku.OnBinderReceivedListener { refresh() }

    private val conn: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = IUserService.Stub.asInterface(b); binding = false
            log("Service Shizuku prêt"); refresh()
        }
        override fun onServiceDisconnected(n: ComponentName?) { svc = null; binding = false }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun card(color: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(16).toFloat(); setColor(color); setStroke(dp(2), stroke)
    }

    private fun log(s: String): Unit = runOnUiThread { logView.append(s.trimEnd() + "\n") }

    private fun bg(block: () -> Unit): Thread = Thread {
        try { block() } catch (t: Throwable) { log("ERREUR UI : $t") }
    }.start()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(TextView(this).apply {
            text = "Routage Audio"; textSize = 28f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "v0.2 · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · ${Build.MODEL}"
            textSize = 13f; setTextColor(Color.parseColor("#8B97A6")); setPadding(0, dp(2), 0, dp(16))
        })
        statusView = TextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(statusView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)

        fun add(label: String, color: String, onClick: () -> Unit): Unit =
            root.addView(button(label, color, onClick), LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })

        add("Revenir en automatique", "#2A3441") {
            selected = -1; refresh()
            bg { log(svc?.reset() ?: "Service non prêt") }
        }
        add("Diagnostic (qui suis-je pour Android ?)", "#2A3441") {
            bg {
                log(svc?.exec(
                    "id; getprop ro.build.version.release; getprop ro.build.version.sdk; " +
                    "dumpsys package com.android.shell | grep -i -E 'audio' | head -20"
                ) ?: "Service non prêt")
            }
        }
        add("Réglages : photo AVANT", "#2A3441") {
            bg { snapshot = settingsLines(); log("Photo prise : ${snapshot?.size} réglages") }
        }
        add("Réglages : comparer APRÈS", "#2A3441") {
            bg {
                val before = snapshot ?: run { log("Fais d'abord la photo AVANT"); return@bg }
                val after = settingsLines()
                val added = (after - before).take(40); val gone = (before - after).take(40)
                log("Nouveaux/modifiés (${added.size}) :"); added.forEach { log("  + $it") }
                log("Disparus (${gone.size}) :"); gone.forEach { log("  - $it") }
            }
        }

        logView = TextView(this).apply {
            textSize = 11f; setTextColor(Color.parseColor("#6EE7B7")); typeface = Typeface.MONOSPACE
            setPadding(0, dp(16), 0, 0); setTextIsSelectable(true)
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
    }

    private fun settingsLines(): Set<String> {
        val s = svc ?: return emptySet()
        val out = HashSet<String>()
        for (ns in listOf("system", "secure", "global")) {
            s.exec("settings list $ns").lines().filter { it.contains("=") }.forEach { out.add("$ns/$it") }
        }
        return out
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    private fun button(label: String, color: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        background = card(Color.parseColor(color)); setOnClickListener { onClick() }
    }

    private fun refresh(): Unit = runOnUiThread {
        listBox.removeAllViews()
        when {
            !Shizuku.pingBinder() -> {
                statusView.text = "Shizuku n'est pas lancé.\nOuvre Shizuku et démarre-le."
                statusView.background = card(Color.parseColor("#4A2A2A"))
            }
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                statusView.text = "Autoriser Routage Audio dans Shizuku  ›"
                statusView.background = card(Color.parseColor("#4A3B1F"))
                statusView.setOnClickListener { Shizuku.requestPermission(1) }
            }
            svc == null -> {
                statusView.text = "Connexion au service Shizuku…"
                statusView.background = card(Color.parseColor("#4A3B1F"))
                if (!binding) {
                    binding = true
                    try {
                        Shizuku.bindUserService(
                            Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
                                .daemon(false).processNameSuffix("audio").debuggable(false).version(1),
                            conn
                        )
                    } catch (t: Throwable) { binding = false; log("bindUserService : $t") }
                }
            }
            else -> {
                statusView.text = "Shizuku connecté ✓"
                statusView.background = card(Color.parseColor("#1F3A33"))
                statusView.setOnClickListener(null)
                showDevices()
            }
        }
    }

    private fun showDevices() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter { it.type != AudioDeviceInfo.TYPE_TELEPHONY }
            .forEach { d ->
                val on = selected == d.id
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(14))
                    background = card(Color.parseColor("#171C24"), if (on) Color.parseColor("#4FD1C5") else Color.TRANSPARENT)
                    setOnClickListener {
                        selected = d.id; refresh()
                        bg { log(svc?.route(d.type, d.address ?: "") ?: "Service non prêt") }
                    }
                }
                row.addView(TextView(this).apply {
                    text = AudioRouter.typeName(d.type); textSize = 17f; setTextColor(Color.WHITE)
                })
                row.addView(TextView(this).apply {
                    text = (d.productName?.toString() ?: "") + if (on) "  ·  actif" else ""
                    textSize = 13f; setTextColor(Color.parseColor("#8B97A6"))
                })
                listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
    }
}
