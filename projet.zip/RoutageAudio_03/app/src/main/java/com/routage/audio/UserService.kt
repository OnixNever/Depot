package com.routage.audio

import android.content.Context
import androidx.annotation.Keep
import kotlin.system.exitProcess

/** Tourne dans un processus lancé par Shizuku (identité shell). */
class UserService : IUserService.Stub {

    constructor() : super()
    @Keep constructor(@Suppress("UNUSED_PARAMETER") context: Context) : super()

    override fun destroy() { exitProcess(0) }

    override fun exec(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        out + err
    } catch (t: Throwable) { "ERR: $t" }

    override fun route(type: Int, address: String): String {
        val sb = StringBuilder()
        AudioRouter.route(type, address, false) { sb.appendLine(it) }
        return sb.toString()
    }

    override fun reset(): String {
        val sb = StringBuilder()
        AudioRouter.reset(false) { sb.appendLine(it) }
        return sb.toString()
    }
}
