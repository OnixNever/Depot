package com.routage.audio

import android.media.AudioDeviceInfo
import android.os.Build
import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper

/**
 * Appelle IAudioService (API cachée). Utilisé DANS le processus Shizuku (wrap=false).
 * Android 10/11 : setPreferredDeviceForStrategy(int, AudioDeviceAttributes)
 * Android 12+   : setPreferredDevicesForStrategy(int, List<AudioDeviceAttributes>)
 */
object AudioRouter {

    init {
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
    }

    private fun audioService(wrap: Boolean): Any {
        val sm = Class.forName("android.os.ServiceManager")
        var binder = sm.getMethod("getService", String::class.java).invoke(null, "audio") as IBinder
        if (wrap) binder = ShizukuBinderWrapper(binder)
        return Class.forName("android.media.IAudioService\$Stub")
            .getMethod("asInterface", IBinder::class.java)
            .invoke(null, binder)!!
    }

    private fun attrs(type: Int, address: String): Any {
        val c = Class.forName("android.media.AudioDeviceAttributes")
        return c.getConstructor(Int::class.java, Int::class.java, String::class.java)
            .newInstance(2 /* ROLE_OUTPUT */, type, address)
    }

    private fun mediaStrategyId(log: (String) -> Unit): Int? {
        val c = Class.forName("android.media.audiopolicy.AudioProductStrategy")
        val list = c.getMethod("getAudioProductStrategies").invoke(null) as List<*>
        for (s in list) {
            val name = c.getMethod("getName").invoke(s) as String
            val id = c.getMethod("getId").invoke(s) as Int
            log("strategy $id = $name")
            if (name.contains("MEDIA", ignoreCase = true)) return id
        }
        return null
    }

    private fun explain(t: Throwable, log: (String) -> Unit) {
        val r = t.cause ?: t
        log("ERREUR : $r")
        r.stackTrace.take(5).forEach { log("   at $it") }
    }

    fun route(type: Int, address: String, wrap: Boolean, log: (String) -> Unit): Boolean {
        return try {
        log("Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), uid=${android.os.Process.myUid()}")
        val id = mediaStrategyId(log) ?: run { log("strategy MEDIA introuvable"); return false }
        val svc = audioService(wrap)
        val a = attrs(type, address)
        val res: Any? = if (Build.VERSION.SDK_INT >= 31) {
            svc.javaClass.methods.first { it.name == "setPreferredDevicesForStrategy" }
                .invoke(svc, id, listOf(a))
        } else {
            svc.javaClass.methods.first { it.name == "setPreferredDeviceForStrategy" }
                .invoke(svc, id, a)
        }
        log("OK → code retour = $res (0 = succès)")
        res == null || res == 0
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun reset(wrap: Boolean, log: (String) -> Unit): Boolean {
        return try {
            val id = mediaStrategyId(log) ?: return false
            val svc = audioService(wrap)
            val res = svc.javaClass.methods.first { it.name == "removePreferredDeviceForStrategy" }.invoke(svc, id)
            log("Retour automatique → code = $res")
            true
        } catch (t: Throwable) { explain(t, log); false }
    }

    fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Haut-parleur du téléphone"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Écouteur interne"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Casque filaire"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Écouteurs filaires"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (média)"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (appel)"
        AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> "Sortie type $t"
    }
}
