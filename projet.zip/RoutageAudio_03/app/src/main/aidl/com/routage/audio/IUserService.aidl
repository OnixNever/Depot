package com.routage.audio;

interface IUserService {
    void destroy() = 16777114;
    String exec(String cmd) = 1;
    String route(int type, String address) = 2;
    String reset() = 3;
}
