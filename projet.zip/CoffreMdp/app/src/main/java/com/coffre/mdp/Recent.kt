package com.coffre.mdp

import android.content.Context

/**
 * Retient le dernier compte rempli et dans quelle appli. Si seul le mail a été rempli
 * (connexion en deux étapes), la page du mot de passe qui suit s'occupe du reste.
 */
object Recent {
    private const val WINDOW_MS = 180_000L

    private fun p(c: Context) = c.getSharedPreferences("recent", Context.MODE_PRIVATE)

    private fun age(c: Context) = System.currentTimeMillis() - p(c).getLong("at", 0)

    fun mark(c: Context, accountId: String, passwordStillNeeded: Boolean, pkg: String?) {
        p(c).edit()
            .putString("id", accountId)
            .putString("pkg", pkg)
            .putLong("at", System.currentTimeMillis())
            .putBoolean("pending", passwordStillNeeded)
            .apply()
    }

    fun lastId(c: Context): String? = if (age(c) < WINDOW_MS) p(c).getString("id", null) else null

    fun lastPkg(c: Context): String? = p(c).getString("pkg", null)

    fun passwordStillNeeded(c: Context, maxAgeMs: Long = WINDOW_MS): Boolean =
        age(c) < maxAgeMs && p(c).getBoolean("pending", false)

    fun passwordFilled(c: Context) {
        p(c).edit().putBoolean("pending", false).apply()
    }
}
