package com.coffre.mdp

import android.content.Context

/**
 * Retient le dernier compte rempli. Si seul le mail a été rempli (connexion en deux étapes),
 * la page suivante, celle du mot de passe, le propose en premier même si le champ est difficile à reconnaître.
 */
object Recent {
    private const val WINDOW_MS = 180_000L

    private fun p(c: Context) = c.getSharedPreferences("recent", Context.MODE_PRIVATE)

    private fun fresh(c: Context) = System.currentTimeMillis() - p(c).getLong("at", 0) < WINDOW_MS

    fun mark(c: Context, accountId: String, passwordStillNeeded: Boolean) {
        p(c).edit()
            .putString("id", accountId)
            .putLong("at", System.currentTimeMillis())
            .putBoolean("pending", passwordStillNeeded)
            .apply()
    }

    fun lastId(c: Context): String? = if (fresh(c)) p(c).getString("id", null) else null

    fun passwordStillNeeded(c: Context): Boolean = fresh(c) && p(c).getBoolean("pending", false)
}
