package com.coffre.mdp

import android.os.Bundle
import android.view.WindowManager
import android.view.autofill.AutofillManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    private var locked by mutableStateOf(true)
    private var autofillOn by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Pas de capture d'écran ni d'aperçu dans les applis récentes
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            CoffreTheme {
                Root(locked = locked, autofillOn = autofillOn, onUnlocked = { locked = false })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        autofillOn = getSystemService(AutofillManager::class.java)?.hasEnabledAutofillServices() == true
    }

    override fun onStop() {
        super.onStop()
        locked = true // le coffre se reverrouille dès qu'on quitte l'appli
    }
}

@Composable
fun Root(locked: Boolean, autofillOn: Boolean, onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    var isSet by remember { mutableStateOf(PatternStore.isSet(ctx)) }
    when {
        !isSet -> SetupScreen(onDone = { isSet = true; onUnlocked() })
        locked -> LockScreen(onUnlocked = onUnlocked)
        else -> Home(autofillOn = autofillOn)
    }
}
