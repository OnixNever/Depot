package com.coffre.mdp

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Account(
    val id: String,
    val label: String,
    val email: String,
    val password: String
)

/** Coffre chiffré (AES-256-GCM, clé dans l'Android Keystore). Tout reste sur le téléphone. */
object Vault {
    private const val ALIAS = "coffre_key"
    private const val FILE = "vault.bin"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun sorted(list: List<Account>): List<Account> =
        list.sortedBy { it.label.ifBlank { it.email }.lowercase() }

    @Synchronized
    fun load(ctx: Context): List<Account> {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return emptyList()
        return try {
            val raw = f.readBytes()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            val plain = cipher.doFinal(raw, 12, raw.size - 12)
            val json = JSONArray(String(plain, Charsets.UTF_8))
            sorted((0 until json.length()).map { i ->
                val o = json.getJSONObject(i)
                Account(
                    id = o.getString("id"),
                    label = o.optString("label"),
                    email = o.getString("email"),
                    password = o.getString("password")
                )
            })
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun save(ctx: Context, list: List<Account>) {
        val json = JSONArray()
        list.forEach {
            json.put(
                JSONObject()
                    .put("id", it.id)
                    .put("label", it.label)
                    .put("email", it.email)
                    .put("password", it.password)
            )
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(json.toString().toByteArray(Charsets.UTF_8))
        val tmp = File(ctx.filesDir, "$FILE.tmp")
        tmp.writeBytes(cipher.iv + encrypted)
        tmp.renameTo(File(ctx.filesDir, FILE))
    }

    fun upsert(ctx: Context, account: Account): List<Account> {
        val list = load(ctx).toMutableList()
        val index = list.indexOfFirst { it.id == account.id }
        when {
            account.id.isBlank() -> list.add(account.copy(id = UUID.randomUUID().toString()))
            index >= 0 -> list[index] = account
            else -> list.add(account)
        }
        save(ctx, list)
        return sorted(list)
    }

    fun remove(ctx: Context, id: String): List<Account> {
        val list = load(ctx).filter { it.id != id }
        save(ctx, list)
        return sorted(list)
    }
}
