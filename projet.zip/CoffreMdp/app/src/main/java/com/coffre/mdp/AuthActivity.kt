package com.coffre.mdp

import android.content.Intent
import android.os.Bundle
import android.service.autofill.Dataset
import android.view.WindowManager
import android.view.autofill.AutofillId
import android.view.autofill.AutofillManager
import android.view.autofill.AutofillValue
import android.widget.RemoteViews
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

/**
 * Ouverte quand tu choisis un compte dans la bulle de remplissage :
 * demande le schéma (sauf si validé il y a moins de 2 min), puis renvoie mail et/ou mot de passe.
 */
class AuthActivity : ComponentActivity() {

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val accountId = intent.getStringExtra(EXTRA_ACCOUNT)
        val userId = intent.getParcelableExtra<AutofillId>(EXTRA_USER)
        val passId = intent.getParcelableExtra<AutofillId>(EXTRA_PASS)
        val account = Vault.load(this).firstOrNull { it.id == accountId }
        val targetPkg = intent.getStringExtra(EXTRA_PKG)

        if (account == null || (userId == null && passId == null)) {
            setResult(RESULT_CANCELED)
            finish()
            return
        }

        // Schéma validé il y a moins de 2 minutes : remplissage direct, sans écran
        if (PatternStore.recentlyValidated(this)) {
            deliver(account, userId, passId, targetPkg)
            return
        }

        setContent {
            CoffreTheme {
                var msg by remember { mutableStateOf("Remplir avec ${account.email}") }
                PatternScreen(title = "Confirme ton schéma", subtitle = msg) { p ->
                    val r = PatternStore.attempt(this@AuthActivity, p)
                    if (r.ok) deliver(account, userId, passId, targetPkg) else msg = r.message
                    r.ok
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun deliver(account: Account, userId: AutofillId?, passId: AutofillId?, targetPkg: String?) {
        val presentation = RemoteViews(packageName, R.layout.autofill_item).apply {
            setTextViewText(R.id.autofill_label, account.email)
        }
        val builder = Dataset.Builder(presentation)
        userId?.let { builder.setValue(it, AutofillValue.forText(account.email)) }
        passId?.let { builder.setValue(it, AutofillValue.forText(account.password)) }

        // Si seul le mail est rempli, la page suivante proposera le mot de passe en premier
        Recent.mark(this, account.id, passwordStillNeeded = passId == null, pkg = targetPkg)

        setResult(
            RESULT_OK,
            Intent().putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, builder.build())
        )
        finish()
    }

    companion object {
        const val EXTRA_ACCOUNT = "account_id"
        const val EXTRA_USER = "user_field"
        const val EXTRA_PASS = "pass_field"
        const val EXTRA_PKG = "target_pkg"
    }
}
