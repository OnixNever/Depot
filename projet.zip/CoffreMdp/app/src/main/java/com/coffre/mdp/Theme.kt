package com.coffre.mdp

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val Bg = Color(0xFFEEF2F1)
    val Ink = Color(0xFF12302F)
    val Muted = Color(0xFF5E7573)
    val Teal = Color(0xFF0E7C7B)
    val TealSoft = Color(0xFFD3E8E6)
    val Amber = Color(0xFFF2B134)
    val Danger = Color(0xFFC0392B)
    val Card = Color(0xFFFFFFFF)
}

@Composable
fun CoffreTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = C.Teal,
            onPrimary = Color.White,
            background = C.Bg,
            onBackground = C.Ink,
            surface = C.Card,
            onSurface = C.Ink,
            error = C.Danger,
            surfaceVariant = C.TealSoft,
            onSurfaceVariant = C.Muted
        ),
        typography = Typography(),
        content = content
    )
}
