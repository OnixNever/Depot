package com.coffre.mdp

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Stocke l'empreinte du schéma (jamais le schéma lui-même) et limite les essais. */
object PatternStore {
    data class Attempt(val ok: Boolean, val message: String)

    private fun prefs(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun derive(p: List<Int>, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(p.joinToString("-").toCharArray(), salt, 20000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)

    fun isSet(c: Context) = prefs(c).contains("hash")

    fun set(c: Context, p: List<Int>) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(c).edit()
            .putString("salt", b64(salt))
            .putString("hash", b64(derive(p, salt)))
            .putInt("fails", 0)
            .putLong("until", 0)
            .apply()
    }

    private fun lockRemainingMs(c: Context): Long =
        maxOf(0L, prefs(c).getLong("until", 0) - System.currentTimeMillis())

    fun attempt(c: Context, p: List<Int>): Attempt {
        val pr = prefs(c)
        val wait = lockRemainingMs(c)
        if (wait > 0) return Attempt(false, "Trop d'essais. Réessaie dans ${wait / 1000 + 1} s.")

        val salt = Base64.decode(pr.getString("salt", "") ?: "", Base64.NO_WRAP)
        val expected = Base64.decode(pr.getString("hash", "") ?: "", Base64.NO_WRAP)
        if (MessageDigest.isEqual(expected, derive(p, salt))) {
            pr.edit().putInt("fails", 0).apply()
            return Attempt(true, "")
        }

        val fails = pr.getInt("fails", 0) + 1
        if (fails >= 5) {
            pr.edit().putInt("fails", 0).putLong("until", System.currentTimeMillis() + 30_000).apply()
            return Attempt(false, "Trop d'essais. Réessaie dans 30 s.")
        }
        pr.edit().putInt("fails", fails).apply()
        return Attempt(false, "Schéma incorrect. ${5 - fails} essai(s) restant(s).")
    }
}
