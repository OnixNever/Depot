package com.coffre.mdp

import android.app.PendingIntent
import android.app.assist.AssistStructure
import android.content.Intent
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveRequest
import android.text.InputType
import android.view.View
import android.view.autofill.AutofillId
import android.widget.RemoteViews

class PassAutofillService : AutofillService() {

    @Suppress("DEPRECATION")
    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        val structure = request.fillContexts.last().structure

        // Jamais de proposition dans l'appli Coffre elle-même
        if (structure.activityComponent?.packageName == packageName) {
            callback.onSuccess(null)
            return
        }

        val fields = FieldFinder.find(structure)

        // Page du mot de passe difficile à reconnaître : si on vient de remplir un mail,
        // le champ qui a le focus est forcément le mot de passe.
        if (fields.user == null && fields.pass == null &&
            fields.focused != null && Recent.passwordStillNeeded(this)
        ) {
            fields.pass = fields.focused
        }

        if (fields.user == null && fields.pass == null) {
            callback.onSuccess(null)
            return
        }

        val accounts = Vault.load(this)
        if (accounts.isEmpty()) {
            callback.onSuccess(null)
            return
        }

        val last = Recent.lastId(this)
        val ordered = accounts.sortedByDescending { it.id == last }

        val response = FillResponse.Builder()
        ordered.forEachIndexed { index, account ->
            val title = account.label.ifBlank { account.email }
            val sub = listOfNotNull(
                if (account.id == last) "Dernier utilisé" else null,
                account.label.takeIf { it.isNotBlank() }
            ).joinToString(" – ").ifBlank {
                if (fields.user == null) "Remplir le mot de passe" else "Coffre"
            }
            val presentation = RemoteViews(packageName, R.layout.autofill_item).apply {
                setTextViewText(R.id.autofill_initial, title.take(1).uppercase())
                setTextViewText(R.id.autofill_label, account.email)
                setTextViewText(R.id.autofill_sub, sub)
            }
            val intent = Intent(this, AuthActivity::class.java)
                .putExtra(AuthActivity.EXTRA_ACCOUNT, account.id)
                .putExtra(AuthActivity.EXTRA_USER, fields.user)
                .putExtra(AuthActivity.EXTRA_PASS, fields.pass)
            val pending = PendingIntent.getActivity(
                this,
                index,
                intent,
                PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            val dataset = Dataset.Builder(presentation)
            // Valeurs vides : elles ne sont remplies qu'après validation du schéma
            fields.user?.let { dataset.setValue(it, null) }
            fields.pass?.let { dataset.setValue(it, null) }
            dataset.setAuthentication(pending.intentSender)
            response.addDataset(dataset.build())
        }
        callback.onSuccess(response.build())
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        callback.onSuccess()
    }
}

/** Repère les champs mail et mot de passe, dans les applis comme dans les pages web. */
object FieldFinder {
    class Result {
        var user: AutofillId? = null
        var pass: AutofillId? = null
        var focused: AutofillId? = null
    }

    fun find(structure: AssistStructure): Result {
        val result = Result()
        for (i in 0 until structure.windowNodeCount) {
            walk(structure.getWindowNodeAt(i).rootViewNode, result)
        }
        return result
    }

    private val userWords = listOf("mail", "user", "login", "identifiant", "pseudo", "courriel", "account")
    private val passWords = listOf("password", "passwd", "passcode", "pwd", "mdp", "mot de passe", "motdepasse", "contrasena")

    private fun walk(node: AssistStructure.ViewNode, r: Result) {
        val id = node.autofillId
        if (id != null && node.autofillType == View.AUTOFILL_TYPE_TEXT) {
            val hints = node.autofillHints?.map { it.lowercase() } ?: emptyList()
            val variation = node.inputType and InputType.TYPE_MASK_VARIATION
            val isTextClass = (node.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT
            val html = node.htmlInfo
            val attrs = html?.attributes
            val htmlType = attrs?.firstOrNull { it.first == "type" }?.second?.lowercase()
            val htmlText = attrs
                ?.filter { it.first == "name" || it.first == "id" || it.first == "autocomplete" || it.first == "placeholder" || it.first == "aria-label" }
                ?.joinToString(" ") { it.second.lowercase() } ?: ""
            val text = listOfNotNull(node.idEntry, node.hint, node.contentDescription?.toString())
                .joinToString(" ").lowercase() + " " + htmlText

            val isPass = hints.any { it.contains("password") } ||
                htmlType == "password" ||
                (isTextClass && (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)) ||
                (htmlType != "email" && passWords.any { text.contains(it) })

            val isUser = hints.any { it.contains("username") || it.contains("email") } ||
                htmlType == "email" ||
                (isTextClass && (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)) ||
                ((htmlType == null || htmlType == "text" || htmlType == "tel") && userWords.any { text.contains(it) })

            if (isPass) {
                if (r.pass == null) r.pass = id
            } else if (isUser) {
                if (r.user == null) r.user = id
            }
            if (node.isFocused && r.focused == null) r.focused = id
        }
        for (j in 0 until node.childCount) walk(node.getChildAt(j), r)
    }
}
