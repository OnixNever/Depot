package com.coffre.mdp

import android.app.PendingIntent
import android.app.assist.AssistStructure
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.InlinePresentation
import android.service.autofill.SaveCallback
import android.service.autofill.SaveRequest
import android.text.InputType
import android.view.View
import android.view.autofill.AutofillId
import android.widget.RemoteViews
import android.widget.inline.InlinePresentationSpec
import androidx.annotation.RequiresApi
import androidx.autofill.inline.UiVersions
import androidx.autofill.inline.v1.InlineSuggestionUi
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PassAutofillService : AutofillService() {

    private class Entry(
        val account: Account,
        val user: AutofillId?,
        val pass: AutofillId?,
        val kind: String?
    )

    @Suppress("DEPRECATION")
    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        val structure = request.fillContexts.last().structure
        val target = structure.activityComponent?.packageName

        // Jamais de proposition dans l'appli Coffre elle-même
        if (target == packageName) {
            callback.onSuccess(null)
            return
        }

        val manual = (request.flags and FillRequest.FLAG_MANUAL_REQUEST) != 0
        val fields = FieldFinder.find(structure)

        val log = StringBuilder()
        log.append("== ")
            .append(SimpleDateFormat("HH:mm:ss", Locale.FRANCE).format(Date()))
            .append("  ").append(target).append(if (manual) "  [demande manuelle]" else "").append('\n')
        fields.lines.forEach { log.append(it).append('\n') }
        log.append("détecté : mail=").append(fields.user != null)
            .append(" mdp=").append(fields.pass != null)
            .append(" champ actif=").append(fields.focused != null).append('\n')

        // Page du mot de passe difficile à reconnaître : si on vient de remplir un mail,
        // le champ qui a le focus est forcément le mot de passe.
        if (fields.user == null && fields.pass == null &&
            fields.focused != null && Recent.passwordStillNeeded(this)
        ) {
            fields.pass = fields.focused
            log.append("→ après un mail rempli, le champ actif est pris pour le mot de passe\n")
        }

        val last = Recent.lastId(this)
        val ordered = Vault.load(this).sortedByDescending { it.id == last }

        val entries = ArrayList<Entry>()
        if (fields.user != null || fields.pass != null) {
            ordered.forEach { entries.add(Entry(it, fields.user, fields.pass, null)) }
        } else if (manual && fields.focused != null) {
            // Appui long sur un champ > Remplissage automatique : on propose mail ET mot de passe
            ordered.forEach {
                entries.add(Entry(it, fields.focused, null, "Mail"))
                entries.add(Entry(it, null, fields.focused, "Mot de passe"))
            }
        }

        if (entries.isEmpty()) {
            log.append("→ aucune proposition\n")
            Diag.add(this, log.toString())
            callback.onSuccess(null)
            return
        }

        // Proposition dans la barre du clavier (Android 11+), comme le remplissage Samsung
        var specs: List<InlinePresentationSpec> = emptyList()
        var maxInline = 0
        var inlineAsked = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val inlineReq = request.inlineSuggestionsRequest
            if (inlineReq != null) {
                inlineAsked = true
                specs = inlineReq.inlinePresentationSpecs
                maxInline = inlineReq.maxSuggestionCount
            }
        }
        log.append("clavier : ")
            .append(if (inlineAsked) "propositions dans le clavier demandées (${specs.size} modèle(s), max $maxInline)" else "bulle classique")
            .append('\n')

        val response = FillResponse.Builder()
        entries.forEachIndexed { index, e ->
            val account = e.account
            val title = account.label.ifBlank { account.email }
            val label = account.label.takeIf { it.isNotBlank() }
            val sub = if (e.kind != null) {
                e.kind + (label?.let { " – $it" } ?: "")
            } else {
                listOfNotNull(
                    if (account.id == last) (if (e.user == null) "Associé au mail choisi" else "Dernier utilisé") else null,
                    label
                )
                    .joinToString(" – ")
                    .ifBlank { if (e.user == null) "Remplir le mot de passe" else "Coffre" }
            }

            val presentation = RemoteViews(packageName, R.layout.autofill_item).apply {
                setTextViewText(R.id.autofill_initial, title.take(1).uppercase())
                setTextViewText(R.id.autofill_label, account.email)
                setTextViewText(R.id.autofill_sub, sub)
            }
            val intent = Intent(this, AuthActivity::class.java)
                .putExtra(AuthActivity.EXTRA_ACCOUNT, account.id)
                .putExtra(AuthActivity.EXTRA_USER, e.user)
                .putExtra(AuthActivity.EXTRA_PASS, e.pass)
                .putExtra(AuthActivity.EXTRA_PKG, target)
            val pending = PendingIntent.getActivity(
                this,
                index,
                intent,
                PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_MUTABLE
            )

            val dataset = Dataset.Builder(presentation)
            // Valeurs vides : elles ne sont remplies qu'après validation du schéma
            e.user?.let { dataset.setValue(it, null) }
            e.pass?.let { dataset.setValue(it, null) }
            dataset.setAuthentication(pending.intentSender)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && inlineAsked &&
                specs.isNotEmpty() && index < maxInline
            ) {
                val spec = specs[minOf(index, specs.size - 1)]
                inlinePresentation(spec, account.email, sub)?.let { dataset.setInlinePresentation(it) }
            }
            response.addDataset(dataset.build())
        }

        log.append("→ ").append(entries.size).append(" proposition(s) envoyée(s)\n")
        Diag.add(this, log.toString())
        callback.onSuccess(response.build())
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun inlinePresentation(
        spec: InlinePresentationSpec,
        title: String,
        subtitle: String
    ): InlinePresentation? {
        if (!UiVersions.getVersions(spec.style).contains(UiVersions.INLINE_UI_VERSION_1)) return null
        val attribution = PendingIntent.getService(this, 0, Intent(), PendingIntent.FLAG_IMMUTABLE)
        val content = InlineSuggestionUi.newContentBuilder(attribution)
            .setTitle(title)
            .setSubtitle(subtitle)
            .setStartIcon(Icon.createWithResource(this, R.drawable.ic_bubble_lock))
            .build()
        return InlinePresentation(content.slice, spec, false)
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        callback.onSuccess()
    }
}

/** Repère les champs mail et mot de passe, dans les applis comme dans les pages web. */
object FieldFinder {
    class Cand(val id: AutofillId, val visible: Boolean)

    class Result {
        var user: AutofillId? = null
        var pass: AutofillId? = null
        var focused: AutofillId? = null
        val cands = ArrayList<Cand>()
        val lines = ArrayList<String>()
    }

    fun find(structure: AssistStructure): Result {
        val r = Result()
        for (i in 0 until structure.windowNodeCount) {
            walk(structure.getWindowNodeAt(i).rootViewNode, r)
        }
        // Formulaire à deux champs : le seul autre champ visible est le complément
        val others = r.cands.filter { it.visible && it.id != r.user && it.id != r.pass }
        if (r.user != null && r.pass == null && others.size == 1) {
            r.pass = others[0].id
            r.lines.add("→ le 2e champ visible est pris pour le mot de passe")
        } else if (r.pass != null && r.user == null && others.size == 1) {
            r.user = others[0].id
            r.lines.add("→ le 2e champ visible est pris pour le mail")
        }
        return r
    }

    private val userWords = listOf("mail", "user", "login", "identifiant", "pseudo", "courriel", "account")
    private val passWords = listOf("password", "passwd", "passcode", "pwd", "mdp", "mot de passe", "motdepasse", "contrasena")

    private fun walk(node: AssistStructure.ViewNode, r: Result) {
        val id = node.autofillId
        if (id != null && node.autofillType == View.AUTOFILL_TYPE_TEXT) {
            val hints = node.autofillHints?.map { it.lowercase() } ?: emptyList()
            val variation = node.inputType and InputType.TYPE_MASK_VARIATION
            val isTextClass = (node.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT
            val attrs = node.htmlInfo?.attributes
            val htmlType = attrs?.firstOrNull { it.first == "type" }?.second?.lowercase()
            val htmlText = attrs
                ?.filter { it.first == "name" || it.first == "id" || it.first == "autocomplete" || it.first == "placeholder" || it.first == "aria-label" }
                ?.joinToString(" ") { it.second.lowercase() } ?: ""
            val text = listOfNotNull(node.idEntry, node.hint, node.contentDescription?.toString())
                .joinToString(" ").lowercase() + " " + htmlText

            val isPass = hints.any { it.contains("password") } ||
                htmlType == "password" ||
                (isTextClass && (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)) ||
                (htmlType != "email" && passWords.any { text.contains(it) })

            val isUser = hints.any { it.contains("username") || it.contains("email") } ||
                htmlType == "email" ||
                (isTextClass && (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)) ||
                ((htmlType == null || htmlType == "text" || htmlType == "tel") && userWords.any { text.contains(it) })

            val visible = node.visibility == View.VISIBLE && node.width > 0 && node.height > 0
            r.cands.add(Cand(id, visible))

            if (isPass) {
                if (r.pass == null) r.pass = id
            } else if (isUser) {
                if (r.user == null) r.user = id
            }
            if (node.isFocused && r.focused == null) r.focused = id

            if (r.lines.size < 15) {
                val kind = if (isPass) "MDP" else if (isUser) "MAIL" else "?"
                r.lines.add(
                    "• ${node.className?.substringAfterLast('.')} id=${node.idEntry} hint=${node.hint} " +
                        "type=${node.inputType} html=${htmlType ?: "-"} visible=$visible actif=${node.isFocused} → $kind"
                )
            }
        }
        for (j in 0 until node.childCount) walk(node.getChildAt(j), r)
    }
}
