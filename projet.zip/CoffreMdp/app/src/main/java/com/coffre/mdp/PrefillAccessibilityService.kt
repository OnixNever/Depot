package com.coffre.mdp

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Vrai si l'utilisateur a activé le service « mot de passe automatique » dans l'Accessibilité. */
fun isPrefillEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
    return enabled.split(':').any {
        it.startsWith(ctx.packageName + "/") && it.endsWith("PrefillAccessibilityService")
    }
}

/**
 * Facultatif, inactif tant que tu ne l'actives pas dans les réglages d'Accessibilité.
 * Quand tu viens de choisir un mail avec Coffre, il écrit le mot de passe de ce compte dans le champ
 * mot de passe qui suit, dans la même appli et dans les 90 secondes. Rien d'autre n'est lu ni enregistré.
 */
class PrefillAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val type = event.eventType
        if (type != AccessibilityEvent.TYPE_VIEW_FOCUSED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) return

        if (!Recent.passwordStillNeeded(this, 90_000L)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != Recent.lastPkg(this)) return
        val accountId = Recent.lastId(this) ?: return

        val field = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (!field.isPassword || !field.isEditable) return
        if (!field.text.isNullOrEmpty()) return

        val account = Vault.load(this).firstOrNull { it.id == accountId } ?: return
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, account.password)
        }
        if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            Recent.passwordFilled(this)
        }
    }

    override fun onInterrupt() {}
}
