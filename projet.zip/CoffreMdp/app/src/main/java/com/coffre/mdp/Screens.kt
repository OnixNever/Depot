package com.coffre.mdp

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.SecureRandom

/* ---------- Écran de schéma (création, déverrouillage, validation autofill) ---------- */

@Composable
fun PatternScreen(title: String, subtitle: String, onComplete: (List<Int>) -> Boolean) {
    Column(
        Modifier
            .fillMaxSize()
            .background(C.Bg)
            .systemBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(C.Teal),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = C.Ink)
        Spacer(Modifier.height(8.dp))
        Text(
            subtitle,
            color = C.Muted,
            textAlign = TextAlign.Center,
            modifier = Modifier.heightIn(min = 52.dp)
        )
        Spacer(Modifier.height(24.dp))
        PatternPad(onComplete = onComplete)
    }
}

@Composable
fun SetupScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var first by remember { mutableStateOf<List<Int>?>(null) }
    var msg by remember { mutableStateOf("Relie au moins 4 points pour protéger ton coffre.") }
    PatternScreen(
        title = if (first == null) "Crée ton schéma" else "Confirme ton schéma",
        subtitle = msg
    ) { p ->
        val f = first
        when {
            p.size < 4 -> {
                msg = "Relie au moins 4 points."
                false
            }
            f == null -> {
                first = p
                msg = "Dessine le même schéma pour confirmer."
                true
            }
            f == p -> {
                PatternStore.set(ctx, p)
                onDone()
                true
            }
            else -> {
                first = null
                msg = "Les deux schémas sont différents. Recommence."
                false
            }
        }
    }
}

@Composable
fun LockScreen(onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("Dessine ton schéma pour ouvrir le coffre.") }
    PatternScreen(title = "Coffre verrouillé", subtitle = msg) { p ->
        val r = PatternStore.attempt(ctx, p)
        if (r.ok) onUnlocked() else msg = r.message
        r.ok
    }
}

/* ---------- Accueil : liste des comptes ---------- */

@Composable
fun Home(autofillOn: Boolean) {
    val ctx = LocalContext.current
    var accounts by remember { mutableStateOf(Vault.load(ctx)) }
    var editor by remember { mutableStateOf<Account?>(null) }
    var grace by remember { mutableStateOf(PatternStore.graceEnabled(ctx)) }
    val current = editor

    if (current != null) {
        androidx.activity.compose.BackHandler { editor = null }
        EditorScreen(
            initial = current,
            onSave = { accounts = Vault.upsert(ctx, it); editor = null },
            onDelete = { accounts = Vault.remove(ctx, it.id); editor = null },
            onBack = { editor = null }
        )
    } else {
        ListScreen(
            accounts = accounts,
            autofillOn = autofillOn,
            grace = grace,
            onGrace = { grace = it; PatternStore.setGrace(ctx, it) },
            onOpen = { editor = it },
            onAdd = { editor = Account("", "", "", "") }
        )
    }
}

@Composable
fun ListScreen(
    accounts: List<Account>,
    autofillOn: Boolean,
    grace: Boolean,
    onGrace: (Boolean) -> Unit,
    onOpen: (Account) -> Unit,
    onAdd: () -> Unit
) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().background(C.Bg)) {
        LazyColumn(
            Modifier.fillMaxSize().systemBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("Mes comptes", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = C.Ink)
                if (accounts.isNotEmpty()) {
                    Text(
                        "${accounts.size} compte${if (accounts.size > 1) "s" else ""}",
                        color = C.Muted,
                        modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                    )
                }
            }
            if (!autofillOn) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(C.TealSoft)
                            .padding(16.dp)
                    ) {
                        Text("Active le remplissage automatique", fontWeight = FontWeight.SemiBold, color = C.Ink)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Choisis Coffre comme service de remplissage pour que tes mails te soient proposés dans les champs de connexion.",
                            color = C.Muted,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val i = Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE)
                                    .setData(Uri.parse("package:${ctx.packageName}"))
                                runCatching { ctx.startActivity(i) }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = C.Teal),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("Activer") }
                    }
                }
            }
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(C.Card)
                        .padding(start = 16.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Schéma moins fréquent", fontWeight = FontWeight.SemiBold, color = C.Ink)
                        Text(
                            "Ne pas le redemander pendant 2 minutes après une validation.",
                            color = C.Muted,
                            fontSize = 13.sp
                        )
                    }
                    Switch(
                        checked = grace,
                        onCheckedChange = onGrace,
                        colors = SwitchDefaults.colors(checkedTrackColor = C.Teal)
                    )
                }
            }
            if (accounts.isEmpty()) {
                item {
                    Text(
                        "Aucun compte pour l'instant. Appuie sur Ajouter pour enregistrer ton premier mail.",
                        color = C.Muted,
                        modifier = Modifier.padding(top = 24.dp)
                    )
                }
            }
            items(accounts, key = { it.id }) { a ->
                val title = a.label.ifBlank { a.email }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(C.Card)
                        .clickable { onOpen(a) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(C.TealSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(title.take(1).uppercase(), color = C.Teal, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, fontWeight = FontWeight.SemiBold, color = C.Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (a.label.isNotBlank()) {
                            Text(a.email, color = C.Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        } else {
                            Text("Mot de passe enregistré", color = C.Muted, fontSize = 14.sp)
                        }
                    }
                    Icon(Icons.Filled.Edit, contentDescription = "Modifier", tint = C.Muted)
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = onAdd,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(20.dp),
            containerColor = C.Teal,
            contentColor = Color.White
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Ajouter")
        }
    }
}

/* ---------- Création / modification d'un compte ---------- */

private fun generatePassword(length: Int = 18): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#%&*?"
    val r = SecureRandom()
    return (1..length).map { chars[r.nextInt(chars.length)] }.joinToString("")
}

@Composable
fun EditorScreen(
    initial: Account,
    onSave: (Account) -> Unit,
    onDelete: (Account) -> Unit,
    onBack: () -> Unit
) {
    var label by remember { mutableStateOf(initial.label) }
    var email by remember { mutableStateOf(initial.email) }
    var password by remember { mutableStateOf(initial.password) }
    var show by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val isNew = initial.id.isBlank()
    val valid = email.isNotBlank() && password.isNotEmpty()

    Column(
        Modifier
            .fillMaxSize()
            .background(C.Bg)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.Close, contentDescription = "Fermer", tint = C.Ink)
            }
            Text(
                if (isNew) "Nouveau compte" else "Modifier le compte",
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = C.Ink
            )
        }
        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = label,
            onValueChange = { label = it },
            label = { Text("Nom (site ou appli, facultatif)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Mail") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Mot de passe") },
            singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                TextButton(onClick = { show = !show }) { Text(if (show) "Masquer" else "Afficher") }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { password = generatePassword(); show = true },
            shape = RoundedCornerShape(12.dp)
        ) { Text("Générer un mot de passe fort") }

        Spacer(Modifier.height(28.dp))
        Button(
            onClick = {
                onSave(initial.copy(label = label.trim(), email = email.trim(), password = password))
            },
            enabled = valid,
            colors = ButtonDefaults.buttonColors(containerColor = C.Teal),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Enregistrer", fontSize = 16.sp) }

        if (!isNew) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Supprimer ce compte", color = C.Danger)
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Supprimer ce compte ?") },
            text = { Text("Le mail et son mot de passe seront effacés de ce téléphone.") },
            confirmButton = {
                TextButton(onClick = { confirm = false; onDelete(initial) }) {
                    Text("Supprimer", color = C.Danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Annuler") }
            }
        )
    }
}
