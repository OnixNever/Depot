package com.coffre.mdp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Liste déroulante des comptes, ouverte depuis la bulle de remplissage.
 * [manual] = true : appui long sur un champ > on choisit aussi s'il faut remplir le mail ou le mot de passe.
 * [onPick] reçoit le compte et ce qu'il faut remplir (mail, mot de passe).
 */
@Composable
fun AccountPicker(
    accounts: List<Account>,
    manual: Boolean,
    onPick: (Account, fillUser: Boolean, fillPass: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val shown = remember(accounts, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) accounts
        else accounts.filter { it.email.lowercase().contains(q) || it.label.lowercase().contains(q) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.62f)
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(C.Bg)
                .clickable(enabled = false) {}
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Choisir un compte (${accounts.size})",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = C.Ink,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onDismiss) { Text("Fermer", color = C.Teal) }
            }
            if (accounts.size > 5) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Rechercher") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
            }
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { a ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(C.Card)
                            .clickable(enabled = !manual) { onPick(a, true, true) }
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(C.TealSoft),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    a.label.ifBlank { a.email }.take(1).uppercase(),
                                    color = C.Teal,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                            }
                            Spacer(Modifier.size(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    a.email,
                                    color = C.Ink,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (a.label.isNotBlank()) {
                                    Text(
                                        a.label,
                                        color = C.Muted,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        if (manual) {
                            Row(Modifier.padding(top = 6.dp)) {
                                TextButton(onClick = { onPick(a, true, false) }) { Text("Mail", color = C.Teal) }
                                TextButton(onClick = { onPick(a, false, true) }) { Text("Mot de passe", color = C.Teal) }
                            }
                        }
                    }
                }
            }
        }
    }
}
