package com.coffre.mdp

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Grille 3x3 façon Android. [onComplete] reçoit les points reliés (0..8)
 * et renvoie true si le schéma est accepté, false pour le faire clignoter en rouge.
 */
@Composable
fun PatternPad(onComplete: (List<Int>) -> Boolean, modifier: Modifier = Modifier) {
    val selected = remember { mutableStateListOf<Int>() }
    var pointer by remember { mutableStateOf<Offset?>(null) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var flashError by remember { mutableStateOf(false) }
    var clearJob by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()
    val currentOnComplete by rememberUpdatedState(onComplete)

    fun center(i: Int): Offset {
        val cell = boxSize.width / 3f
        return Offset((i % 3 + 0.5f) * cell, (i / 3 + 0.5f) * cell)
    }

    fun hit(p: Offset) {
        val cell = boxSize.width / 3f
        for (i in 0..8) {
            if (i !in selected && (center(i) - p).getDistance() < cell * 0.32f) {
                selected.add(i)
                break
            }
        }
    }

    Canvas(
        modifier = modifier
            .size(280.dp)
            .onSizeChanged { boxSize = it }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o ->
                        clearJob?.cancel()
                        flashError = false
                        selected.clear()
                        pointer = o
                        hit(o)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        pointer = change.position
                        hit(change.position)
                    },
                    onDragEnd = {
                        pointer = null
                        val result = selected.toList()
                        val ok = if (result.isEmpty()) true else currentOnComplete(result)
                        if (!ok) flashError = true
                        clearJob = scope.launch {
                            delay(500)
                            selected.clear()
                            flashError = false
                        }
                    },
                    onDragCancel = {
                        pointer = null
                        selected.clear()
                    }
                )
            }
    ) {
        val cell = this.size.width / 3f
        val color = if (flashError) C.Danger else C.Teal
        val pts = selected.map { center(it) }
        for (k in 0 until pts.size - 1) {
            drawLine(
                color = color,
                start = pts[k],
                end = pts[k + 1],
                strokeWidth = 10f,
                cap = StrokeCap.Round
            )
        }
        val p = pointer
        if (pts.isNotEmpty() && p != null) {
            drawLine(
                color = color.copy(alpha = 0.5f),
                start = pts.last(),
                end = p,
                strokeWidth = 10f,
                cap = StrokeCap.Round
            )
        }
        for (i in 0..8) {
            val c = center(i)
            if (i in selected) {
                drawCircle(color = color.copy(alpha = 0.18f), radius = cell * 0.30f, center = c)
                drawCircle(color = color, radius = 14f, center = c)
            } else {
                drawCircle(color = C.Muted.copy(alpha = 0.55f), radius = 9f, center = c)
            }
        }
    }
}
