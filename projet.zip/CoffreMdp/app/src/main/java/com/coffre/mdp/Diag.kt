package com.coffre.mdp

import android.content.Context

/** Journal court des dernières demandes de remplissage, consultable dans l'appli. Aucun mot de passe n'y est écrit. */
object Diag {
    private fun p(c: Context) = c.getSharedPreferences("diag", Context.MODE_PRIVATE)

    fun add(c: Context, text: String) {
        val old = p(c).getString("log", "") ?: ""
        p(c).edit().putString("log", (text + "\n" + old).take(6000)).apply()
    }

    fun read(c: Context): String =
        (p(c).getString("log", "") ?: "").ifBlank { "Rien d'enregistré pour l'instant." }
}
