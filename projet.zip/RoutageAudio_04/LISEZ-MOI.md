# Routage Audio v0.2.1 — diagnostic

Correctif 0.2.1 : erreur de compilation Kotlin (fonction bg) corrigée ; retour automatique compatible Android 12 et 13+.

Changements 0.2 : l'appel audio s'exécute maintenant dans un vrai processus Shizuku (service utilisateur),
le journal affiche l'endroit exact du refus, et 3 outils de diagnostic sont ajoutés.

1. Touche un périphérique → copie le journal vert.
2. « Diagnostic » → donne l'uid réel et si le profil shell a les permissions audio.
3. « Réglages AVANT » → active à la main « Son d'application séparé » dans les paramètres Samsung
   → « Réglages APRÈS » : montre quelles clés Samsung changent (piste B).

Le routage par appli (YouTube seul) n'est pas encore codé : il dépend de ces résultats.
