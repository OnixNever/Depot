package com.assistant.vocal

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Calibrage guidé : l'appli enregistre TA voix disant la phrase (près, 1 m, 3 m), mesure le bruit
 * de la pièce, teste avec des phrases quelconques, puis règle toute seule gain et seuil.
 */
class CalibrationActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var info: TextView
    private lateinit var start: Button
    private val h = Handler(Looper.getMainLooper())
    private var loop: AudioLoop? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        root.addView(TextView(this).apply { text = "Calibrage de ta voix"; textSize = 24f })
        info = TextView(this).apply {
            textSize = 16f
            text = "Phrase : « ${prefs.phrase} »\n\nL'appli va apprendre TA voix : tu diras la phrase 6 fois tout près, " +
                "3 fois à 1 mètre, 3 fois à 2-3 mètres, puis tu parleras librement 10 secondes pour qu'elle " +
                "apprenne à ne pas se déclencher à tort. Le mot peut être n'importe lequel, même inventé."
            setPadding(0, pad, 0, pad)
        }
        root.addView(info)
        start = Button(this).apply { text = "Démarrer le calibrage"; setOnClickListener { go() } }
        root.addView(start)
    }

    override fun onDestroy() { loop?.stopAndWait(); super.onDestroy() }

    private fun show(t: String) { h.post { info.text = t } }

    private fun go() {
        if (!ModelManager.isReady(this)) { info.text = "Installe d'abord le modèle vocal (écran principal)."; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        ListenService.stop(this) // libère le micro
        start.isEnabled = false
        Thread {
            try { calibrate() } catch (t: Throwable) { show("Erreur : ${t.message}") }
            h.post { start.isEnabled = true }
        }.start()
    }

    private fun calibrate() {
        Thread.sleep(600)
        val phrase = prefs.phrase
        val vw = VoiceWake()
        val stage = AtomicInteger(-1)
        val count = AtomicInteger(0)
        val noise = Collections.synchronizedList(ArrayList<Float>())
        val peaks = FloatArray(5)
        val samples = Collections.synchronizedList(ArrayList<Array<FloatArray>>())
        val negs = Collections.synchronizedList(ArrayList<Array<FloatArray>>())

        val l = AudioLoop(prefs) { b, n, rms ->
            val s = stage.get()
            if (s == 0) noise.add(rms)
            if (s >= 1) {
                if (rms > peaks[s]) peaks[s] = rms
                val u = vw.feed(b, n)
                if (u != null) {
                    if (s in 1..3) {
                        if (u.ms in 450..2800) { samples.add(u.feat); count.incrementAndGet() }
                    } else if (u.ms >= 450) negs.add(u.feat)
                }
            }
        }
        l.testMode = true
        loop = l
        l.start()

        val titles = listOf(
            "Silence : ne dis rien pendant 4 secondes",
            "Dis « $phrase » 6 fois, tout près du téléphone (une fois toutes les 2 secondes)",
            "Dis-le 3 fois à environ 1 mètre",
            "Dis-le 3 fois à 2 ou 3 mètres",
            "Dernière étape : parle librement 10 secondes, sans dire la phrase (ce que tu dis d'habitude)"
        )
        val need = intArrayOf(0, 6, 3, 3, 0)
        val maxSec = intArrayOf(4, 45, 30, 30, 10)
        for (i in 0..4) {
            stage.set(-1)
            for (c in 3 downTo 1) { show("Prépare-toi… $c\n\n${titles[i]}"); Thread.sleep(1000) }
            vw.reset()
            count.set(0)
            stage.set(i)
            var t = 0
            while (t < maxSec[i] * 10) {
                Thread.sleep(100)
                t++
                if (need[i] > 0 && count.get() >= need[i]) break
                if (t % 5 == 0) {
                    val prog = if (need[i] > 0) "échantillons : ${count.get()}/${need[i]}" else ""
                    show("${titles[i]}\n\n⏱ ${maxSec[i] - t / 10} s   $prog")
                }
            }
            stage.set(-1)
            Thread.sleep(500)
        }
        l.stopAndWait()

        // ---- Calculs ----
        var tpl = ArrayList(samples)
        val nz = if (noise.isEmpty()) prefs.noiseRms else noise.average().toFloat().coerceAtLeast(30f)
        val ref = when {
            peaks[3] > nz * 1.5f -> peaks[3]
            peaks[2] > nz * 1.5f -> peaks[2]
            else -> peaks[1]
        }
        val gain = (2500f / ref.coerceAtLeast(50f)).coerceIn(1.5f, 12f)
        prefs.noiseRms = nz
        prefs.maxGain = gain

        if (tpl.size < 4) {
            show("Pas assez d'échantillons (${tpl.size}). Parle un peu plus fort, par petites phrases bien séparées, et recommence.")
            return
        }
        var loo = tpl.indices.map { VoiceStore.score(tpl[it], tpl, it) }
        // Un échantillon de durée très différente des autres donne une distance « infinie » : on l'écarte
        val aberrant = loo.count { it >= 1e6f }
        if (aberrant > 0) {
            val keep = loo.map { it < 1e6f }
            tpl = ArrayList(tpl.filterIndexed { i, _ -> keep[i] })
            Status.log("CALIBRAGE : $aberrant échantillon(s) aberrant(s) écarté(s)")
            if (tpl.size < 4) {
                show("Trop d'échantillons inutilisables (durées trop différentes). Redis la phrase à chaque fois avec le même rythme, et recommence.")
                return
            }
            loo = tpl.indices.map { VoiceStore.score(tpl[it], tpl, it) }
        }
        val mean = loo.average().toFloat()
        val sd = sqrt(loo.map { (it - mean) * (it - mean) }.average()).toFloat()
        val posMax = loo.max()
        var thr = max(posMax * 1.05f, mean + 1.5f * sd)
        val negD = ArrayList(negs).map { VoiceStore.score(it, tpl) }
        val negMin = negD.minOrNull()
        if (negMin != null && negMin <= thr) {
            thr = if (negMin > posMax * 1.02f) (posMax + negMin) / 2f else negMin * 0.92f
        }
        VoiceStore.save(this, tpl)
        prefs.voiceThr = thr
        prefs.voiceBase = thr
        prefs.wakeMode = "voice"
        prefs.calibrated = true
        Status.log("CALIBRAGE : ${tpl.size} échantillons, positifs moy=${"%.2f".format(mean)} écart=${"%.2f".format(sd)} max=${"%.2f".format(posMax)}, faux le plus proche=${negMin?.let { "%.2f".format(it) } ?: "aucun"}, seuil=${"%.2f".format(thr)}, bruit=${nz.toInt()}, gain=${"%.1f".format(gain)}")

        val pass = loo.count { it <= thr }
        val falsePos = negD.count { it <= thr }
        val res = StringBuilder("Calibrage terminé\n\n")
        res.append("Échantillons de ta voix : ${tpl.size}\n")
        res.append("Reconnus : $pass sur ${tpl.size}\n")
        res.append("Fausses détections sur ta parole libre : $falsePos sur ${negD.size}\n\n")
        res.append("Bruit ambiant : ${nz.toInt()}  ·  gain max ×${"%.1f".format(gain)}  ·  seuil ${"%.2f".format(thr)}\n\n")
        if (pass < tpl.size * 0.7) res.append("Peu d'échantillons reconnus : recommence en disant toujours la phrase de la même façon.\n")
        if (falsePos > 0) res.append("Elle se déclenche sur ta parole libre : choisis un nom plus long ou plus original, ou recommence.\n")
        res.append("\nL'appli continuera à s'ajuster toute seule. Relance l'écoute depuis l'écran principal.")
        show(res.toString())
    }
}
