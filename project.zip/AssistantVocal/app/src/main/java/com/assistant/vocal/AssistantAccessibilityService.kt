package com.assistant.vocal

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Les « yeux et les doigts » de l'assistant : lit l'écran, touche, défile, écrit, maintient un appui. */
class AssistantAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AssistantAccessibilityService? = null

        /** Comparaison par le son : « ya habibi » ~ « yaa habiby ». */
        fun phon(s: String): String {
            var t = Txt.norm(s).replace(" ", "")
            val rules = listOf(
                "ph" to "f", "ch" to "5", "sh" to "5", "ou" to "u", "qu" to "k", "gu" to "g", "ck" to "k",
                "eau" to "o", "au" to "o", "ai" to "e", "ei" to "e", "oi" to "wa", "y" to "i", "w" to "u",
                "h" to "", "c" to "k", "q" to "k", "z" to "s", "x" to "ks", "ee" to "e", "ii" to "i", "aa" to "a", "oo" to "o"
            )
            for ((a, b) in rules) t = t.replace(a, b)
            val sb = StringBuilder()
            for (c in t) if (sb.isEmpty() || sb.last() != c) sb.append(c)
            var r = sb.toString()
            while (r.length > 3 && (r.endsWith("s") || r.endsWith("t") || r.endsWith("d") || r.endsWith("e"))) r = r.dropLast(1)
            return r
        }

        fun lev(a: String, b: String): Int {
            if (a == b) return 0
            if (a.isEmpty()) return b.length
            if (b.isEmpty()) return a.length
            var prev = IntArray(b.length + 1) { it }
            for (i in 1..a.length) {
                val cur = IntArray(b.length + 1)
                cur[0] = i
                for (j in 1..b.length) {
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
                }
                prev = cur
            }
            return prev[b.length]
        }
    }

    class Item(val label: String, val node: AccessibilityNodeInfo)

    private val ui = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this; Status.log("Accessibilité connectée") }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; Status.log("Accessibilité déconnectée"); return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val r = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { r.add(it) }
        try {
            for (w in windows) {
                val x = w.root
                if (x != null && r.none { it == x }) r.add(x)
            }
        } catch (_: Throwable) {}
        return r
    }

    /** Tous les noms possibles d'un élément : texte, description, indice, info-bulle, identifiant technique. */
    private fun labelsOf(n: AccessibilityNodeInfo): List<Pair<String, Boolean>> {
        val out = ArrayList<Pair<String, Boolean>>(4) // (nom, vient de l'identifiant technique ?)
        n.text?.toString()?.let { if (it.isNotBlank()) out.add(it to false) }
        n.contentDescription?.toString()?.let { if (it.isNotBlank()) out.add(it to false) }
        try { if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString()?.let { if (it.isNotBlank()) out.add(it to false) } } catch (_: Throwable) {}
        try { if (Build.VERSION.SDK_INT >= 28) n.tooltipText?.toString()?.let { if (it.isNotBlank()) out.add(it to false) } } catch (_: Throwable) {}
        try {
            n.viewIdResourceName?.substringAfterLast('/')?.replace('_', ' ')?.replace('-', ' ')?.let {
                if (it.isNotBlank()) out.add(it to true)
            }
        } catch (_: Throwable) {}
        return out
    }

    private class Cand(val node: AccessibilityNodeInfo, val labels: List<Pair<String, Boolean>>)

    private fun candidates(): List<Cand> {
        val res = ArrayList<Cand>()
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (n.isVisibleToUser) {
                val l = labelsOf(n)
                if (l.isNotEmpty()) res.add(Cand(n, l))
            }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        for (r in roots()) visit(r, 0)
        return res
    }

    /** Éléments utiles à l'écran (pour le cerveau) : visibles, avec un nom, cliquables en priorité. */
    fun screenItems(max: Int = 40): List<Item> = try {
        val seen = HashSet<String>()
        val list = ArrayList<Item>()
        for (c in candidates()) {
            val real = c.labels.firstOrNull { !it.second }?.first
            // Identifiant technique seul et long (ex. « googleapp third party search widget ») : bruit pour le cerveau
            if (real == null && c.labels.first().first.trim().split(Regex("\\s+")).size > 3) continue
            val name = real ?: c.labels.first().first
            val clean = name.replace(Regex("\\s+"), " ").trim().take(40)
            var clickable = false
            var p: AccessibilityNodeInfo? = c.node
            var k = 0
            while (p != null && k < 6) { if (p.isClickable) { clickable = true; break }; p = p.parent; k++ }
            if (!clickable && !c.node.isEditable) continue
            if (seen.add(Txt.norm(clean))) list.add(Item(clean, c.node))
            if (list.size >= max) break
        }
        list
    } catch (_: Throwable) { emptyList() }

    /** Cherche le nœud visible dont le nom correspond le mieux ; à défaut, celui qui ressemble le plus par le son. */
    fun findNode(q: String): AccessibilityNodeInfo? = try { findNodeUnsafe(q) } catch (_: Throwable) { null }

    private fun findNodeUnsafe(q: String): AccessibilityNodeInfo? {
        val nq = Txt.norm(q)
        if (nq.isEmpty()) return null
        val sq = Txt.stem(nq)
        val sigQ = sq.split(" ").filter { it.length >= 4 }
        var best: AccessibilityNodeInfo? = null
        var bestRank = 99

        fun rankOf(t: String): Int {
            if (t == nq) return 0
            if (" $t ".contains(" $nq ")) return 1
            val st = Txt.stem(t)
            if (st == sq) return 1
            if (" $st ".contains(" $sq ")) return 2
            if (sigQ.size >= 2) {
                val sigT = st.split(" ")
                if (sigQ.all { it in sigT }) return 2
            }
            if (t.length >= 3 && " $nq ".contains(" $t ")) return 3
            return 99
        }

        val cands = candidates()
        for (c in cands) {
            for ((raw, fromId) in c.labels) {
                val t = Txt.norm(raw)
                if (t.isEmpty()) continue
                var rank = rankOf(t)
                if (rank == 99) continue
                if (fromId) rank += 1 // un identifiant technique vaut un peu moins qu'un vrai texte
                if (rank < bestRank) { bestRank = rank; best = c.node }
            }
        }
        if (best != null) return best

        // Plan B : ressemblance sonore (noms étrangers, mal transcrits)
        if (nq.length < 4) return null
        val pq = phon(nq)
        if (pq.length < 3) return null
        val qWords = nq.split(" ").size
        var bestScore = 0f
        for (c in cands) {
            for ((raw, fromId) in c.labels) {
                if (fromId) continue
                val words = Txt.norm(raw).split(" ").filter { it.isNotEmpty() }
                if (words.isEmpty()) continue
                val windows = ArrayList<String>()
                if (words.size <= qWords + 1) windows.add(words.joinToString(" "))
                else for (i in 0..(words.size - qWords)) windows.add(words.subList(i, i + qWords).joinToString(" "))
                for (w in windows) {
                    val pw = phon(w)
                    if (pw.length < 3) continue
                    val d = lev(pq, pw)
                    val score = 1f - d.toFloat() / maxOf(pq.length, pw.length)
                    if (score > bestScore) { bestScore = score; best = c.node }
                }
            }
        }
        return if (bestScore >= 0.72f) best else null
    }

    fun clickText(q: String): Boolean = try {
        val n = findNode(q)
        if (n == null) false else click(n)
    } catch (_: Throwable) { false }

    fun click(n: AccessibilityNodeInfo): Boolean {
        try {
            var p: AccessibilityNodeInfo? = n
            while (p != null) {
                if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                p = p.parent
            }
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) { tap(r.exactCenterX(), r.exactCenterY()); return true }
        } catch (_: Throwable) {}
        return false
    }

    private fun focusedInput(): AccessibilityNodeInfo? {
        for (r in roots()) {
            val f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null && f.isEditable) return f
        }
        var found: AccessibilityNodeInfo? = null
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || found != null || depth > 40) return
            if (n.isEditable && n.isVisibleToUser) { found = n; return }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        for (r in roots()) visit(r, 0)
        return found
    }

    fun setText(text: String): Boolean = try {
        val node = focusedInput()
        if (node == null) false else {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val b = Bundle()
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        }
    } catch (_: Throwable) { false }

    /** Plus grande zone défilable visible (liste de contacts, de chansons…). */
    private fun findScrollable(): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (n.isScrollable && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val a = r.width() * r.height()
                if (a > bestArea) { bestArea = a; best = n }
            }
            for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
        }
        for (r in roots()) visit(r, 0)
        return best
    }

    /** Saute tout en haut (top = true) ou tout en bas de la liste affichée. */
    fun scrollEdge(top: Boolean): Boolean {
        val n = try { findScrollable() } catch (_: Throwable) { null }
        if (n == null) {
            repeat(8) { scroll(!top); Thread.sleep(450) }
            return true
        }
        val action = if (top) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        var i = 0
        try {
            while (i < 60) {
                n.refresh()
                if (!n.performAction(action)) break
                Thread.sleep(160)
                i++
            }
        } catch (_: Throwable) {}
        return true
    }

    fun scroll(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val a = dm.heightPixels * (if (down) 0.70f else 0.30f)
        val b = dm.heightPixels * (if (down) 0.30f else 0.70f)
        swipe(x, a, x, b, 350)
    }

    fun tap(x: Float, y: Float) = swipe(x, y, x, y, 60)

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        try {
            val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
            dispatchGesture(
                GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(),
                null, null
            )
        } catch (_: Throwable) {}
    }

    // ---- Appui maintenu (message vocal : on garde le doigt sur le micro) ----
    @Volatile private var holdRelease = false
    @Volatile var holding = false
        private set

    /** Maintient le doigt sur l'élément pendant `seconds` secondes puis relâche (bloquant). */
    fun holdFor(n: AccessibilityNodeInfo, seconds: Int): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        holdRelease = false
        holding = true
        val x = r.exactCenterX()
        val y = r.exactCenterY()
        val segments = (seconds * 1000 / 600).coerceIn(2, 100)
        var count = 0

        fun segment(prev: GestureDescription.StrokeDescription?) {
            count++
            val last = holdRelease || count >= segments
            val path = Path().apply { moveTo(x, y) }
            val sd = try {
                if (prev == null) GestureDescription.StrokeDescription(path, 0, 600, !last)
                else prev.continueStroke(path, 0, 600, !last)
            } catch (_: Throwable) { holding = false; return }
            val cb = object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    if (last) holding = false else segment(sd)
                }
                override fun onCancelled(g: GestureDescription?) { holding = false }
            }
            try { dispatchGesture(GestureDescription.Builder().addStroke(sd).build(), cb, ui) } catch (_: Throwable) { holding = false }
        }
        segment(null)
        val deadline = System.currentTimeMillis() + seconds * 1000L + 4000L
        while (holding && System.currentTimeMillis() < deadline) Thread.sleep(100)
        holdRelease = true
        return true
    }
}
