package com.assistant.vocal

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import rikka.shizuku.Shizuku

/** Utilisé UNE SEULE FOIS pour accorder les autorisations. Ensuite Shizuku n'est plus nécessaire. */
object ShizukuSetup {

    fun available(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun request(code: Int) { try { Shizuku.requestPermission(code) } catch (_: Throwable) {} }

    private fun sh(cmd: String): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        return p.waitFor() to out.trim()
    }

    fun run(ctx: Context): List<String> {
        val pkg = ctx.packageName
        val log = ArrayList<String>()
        fun step(name: String, cmd: String) {
            log.add(
                try {
                    val (code, out) = sh(cmd)
                    if (code == 0) "✔ $name" else "✘ $name ($out)"
                } catch (t: Throwable) { "✘ $name : ${t.message}" }
            )
        }
        step("Réglages sécurisés", "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
        step("Micro", "pm grant $pkg android.permission.RECORD_AUDIO")
        step("Notifications", "pm grant $pkg android.permission.POST_NOTIFICATIONS")
        step("Affichage par-dessus les autres applis", "appops set $pkg SYSTEM_ALERT_WINDOW allow")
        step("Batterie sans restriction", "dumpsys deviceidle whitelist +$pkg")
        step("Activité en arrière-plan", "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        log.add(if (enableAccessibility(ctx)) "✔ Service d'accessibilité activé" else "✘ Service d'accessibilité non activé")
        return log
    }

    /** Active le service d'accessibilité sans passer par les menus Samsung (nécessite WRITE_SECURE_SETTINGS). */
    fun enableAccessibility(ctx: Context): Boolean = try {
        val cn = "${ctx.packageName}/${AssistantAccessibilityService::class.java.name}"
        val cr = ctx.contentResolver
        val cur = Settings.Secure.getString(cr, "enabled_accessibility_services") ?: ""
        if (!cur.split(":").contains(cn)) {
            Settings.Secure.putString(cr, "enabled_accessibility_services", if (cur.isEmpty()) cn else "$cur:$cn")
        }
        Settings.Secure.putInt(cr, "accessibility_enabled", 1)
        true
    } catch (_: Throwable) { false }
}
