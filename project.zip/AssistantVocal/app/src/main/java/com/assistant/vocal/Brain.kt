package com.assistant.vocal

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Installation du « cerveau » : un petit modèle de langage qui tourne sur le téléphone. */
object BrainManager {
    // Qwen2.5 1,5 milliard de paramètres, quantifié 8 bits, format MediaPipe (licence Apache 2.0, ~1,6 Go)
    private const val URL_MODEL =
        "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/" +
            "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"

    fun file(ctx: Context) = File(File(ctx.filesDir, "brain"), "model.task")
    fun isReady(ctx: Context) = file(ctx).length() > 100_000_000L

    fun download(ctx: Context, progress: (String) -> Unit) {
        val c = URL(URL_MODEL).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) AssistantVocal")
        c.instanceFollowRedirects = true
        c.connect()
        if (c.responseCode !in 200..299) throw IOException("Serveur : code ${c.responseCode}")
        save(ctx, c.inputStream, c.contentLengthLong, progress)
    }

    fun save(ctx: Context, input: InputStream, total: Long, progress: (String) -> Unit) {
        Brain.release()
        val dest = file(ctx)
        dest.parentFile?.mkdirs()
        val tmp = File(dest.parentFile, "model.part")
        var n = 0L
        var last = -1
        input.use { i ->
            FileOutputStream(tmp).use { o ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r)
                    n += r
                    val p = if (total > 0) (n * 100 / total).toInt() else (n / 50_000_000L).toInt()
                    if (p != last) { last = p; progress(if (total > 0) "$p %" else "${n / 1_000_000} Mo") }
                }
            }
        }
        if (n < 100_000_000L) { tmp.delete(); throw IOException("Fichier trop petit : ce n'est pas un modèle .task") }
        dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("Impossible d'installer le cerveau")
    }
}

/** Le cerveau : reçoit ta phrase + la liste de ce qui est à l'écran, répond par UNE action. */
object Brain {
    class Decision(val a: String, val n: Int, val t: String, val d: String, val raw: String)

    @Volatile private var llm: LlmInference? = null
    @Volatile private var failed = false

    fun enabled(ctx: Context) = Prefs(ctx).brainOn && BrainManager.isReady(ctx) && !failed

    @Synchronized
    fun get(ctx: Context): LlmInference? {
        llm?.let { return it }
        if (failed || !BrainManager.isReady(ctx)) return null
        return try {
            Status.log("Cerveau : chargement…")
            val o = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(BrainManager.file(ctx).absolutePath)
                .setMaxTokens(1024)
                .build()
            val m = LlmInference.createFromOptions(ctx.applicationContext, o)
            llm = m
            Status.log("Cerveau : prêt")
            m
        } catch (t: Throwable) {
            failed = true
            Status.error = "Cerveau indisponible : ${t.message?.take(80)}"
            Status.log("Cerveau : échec du chargement")
            null
        }
    }

    @Synchronized
    fun release() {
        try { llm?.close() } catch (_: Throwable) {}
        llm = null
        failed = false
    }

    private const val SYSTEM =
        "Tu pilotes un téléphone Android à la voix. Tu reçois l'ordre de l'utilisateur (transcrit par reconnaissance " +
            "vocale, donc avec des erreurs possibles) et la liste numérotée de ce qui est touchable à l'écran. " +
            "Réponds par UNE seule ligne JSON, rien d'autre.\n" +
            "Actions : {\"a\":\"click\",\"n\":NUMERO} toucher l'élément ; {\"a\":\"type\",\"t\":\"texte\"} écrire du texte ; " +
            "{\"a\":\"scroll\",\"d\":\"down\"} ou \"up\" ; {\"a\":\"open\",\"t\":\"nom de l'appli\"} ; {\"a\":\"back\"} ; " +
            "{\"a\":\"none\"} si rien ne convient.\n" +
            "Choisis l'élément dont le nom a le même sens ou le même son que l'ordre, même si l'orthographe ou la langue " +
            "diffère. N'invente jamais de numéro.\n" +
            "Exemples :\nÉcran : 1. Joindre 2. Message 3. Appareil photo\nOrdre : partage une photo\n{\"a\":\"click\",\"n\":1}\n" +
            "Écran : 1. Pause 2. Suivant 3. Précédent\nOrdre : mets la suivante\n{\"a\":\"click\",\"n\":2}\n" +
            "Écran : 1. Message 2. Joindre\nOrdre : dis-lui que j'arrive\n{\"a\":\"type\",\"t\":\"j'arrive\"}"

    fun decide(ctx: Context, utterance: String, screen: List<String>): Decision? {
        val m = get(ctx) ?: return null
        val sb = StringBuilder("Écran : ")
        screen.forEachIndexed { i, s -> sb.append("${i + 1}. ").append(s).append(' ') }
        sb.append("\nOrdre : ").append(utterance)
        val prompt = "<|im_start|>system\n$SYSTEM<|im_end|>\n<|im_start|>user\n$sb<|im_end|>\n<|im_start|>assistant\n"
        return try {
            val out = m.generateResponse(prompt)
            val i = out.indexOf('{')
            val j = out.indexOf('}', i + 1)
            if (i < 0 || j < 0) return null
            val raw = out.substring(i, j + 1)
            val js = JSONObject(raw)
            Decision(js.optString("a"), js.optInt("n", 0), js.optString("t"), js.optString("d"), raw)
        } catch (t: Throwable) {
            Status.log("Cerveau : erreur ${t.javaClass.simpleName}")
            null
        }
    }
}
