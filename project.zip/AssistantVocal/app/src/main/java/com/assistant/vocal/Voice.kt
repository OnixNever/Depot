package com.assistant.vocal

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Empreinte de la voix (MFCC) : 12 coefficients + énergie, normalisés par énoncé. */
object Mfcc {
    private const val FRAME = 400
    private const val HOP = 160
    private const val NFFT = 512
    private const val NMEL = 26
    private const val NCEP = 13

    private val window = FloatArray(FRAME) { (0.54 - 0.46 * cos(2.0 * PI * it / (FRAME - 1))).toFloat() }
    private val mel: Array<FloatArray> = buildMel()
    private val dct: Array<FloatArray> =
        Array(NCEP) { k -> FloatArray(NMEL) { n -> cos(PI * k * (n + 0.5) / NMEL).toFloat() } }

    private fun hz2mel(f: Double) = 2595.0 * log10(1.0 + f / 700.0)
    private fun mel2hz(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)

    private fun buildMel(): Array<FloatArray> {
        val lo = hz2mel(100.0)
        val hi = hz2mel(7500.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { floor((NFFT + 1) * pts[it] / 16000.0).toInt().coerceIn(0, NFFT / 2) }
        return Array(NMEL) { m ->
            val f = FloatArray(NFFT / 2 + 1)
            val a = bins[m]
            val b = bins[m + 1]
            val c = bins[m + 2]
            if (b > a) for (k in a until b) f[k] = (k - a).toFloat() / (b - a)
            if (c > b) for (k in b..c) f[k] = (c - k).toFloat() / (c - b)
            f
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                val half = len / 2
                for (k in 0 until half) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val vr = re[i + k + half] * cr - im[i + k + half] * ci
                    val vi = re[i + k + half] * ci + im[i + k + half] * cr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + half] = ur - vr
                    im[i + k + half] = ui - vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    fun compute(pcm: ShortArray, len: Int): Array<FloatArray> {
        if (len < FRAME) return emptyArray()
        val nF = (len - FRAME) / HOP + 1
        val out = Array(nF) { FloatArray(NCEP) }
        val re = FloatArray(NFFT)
        val im = FloatArray(NFFT)
        val melE = FloatArray(NMEL)
        for (t in 0 until nF) {
            val off = t * HOP
            java.util.Arrays.fill(re, 0f)
            java.util.Arrays.fill(im, 0f)
            var e = 0.0
            for (i in 0 until FRAME) {
                val cur = pcm[off + i].toFloat()
                val prev = if (off + i > 0) pcm[off + i - 1].toFloat() else 0f
                re[i] = (cur - 0.97f * prev) * window[i]
                e += cur.toDouble() * cur
            }
            fft(re, im)
            for (m in 0 until NMEL) {
                var s = 0f
                val f = mel[m]
                for (k in 0..NFFT / 2) if (f[k] != 0f) s += f[k] * (re[k] * re[k] + im[k] * im[k])
                melE[m] = ln(s.toDouble() + 1.0).toFloat()
            }
            for (k in 1..12) {
                var c = 0f
                for (n in 0 until NMEL) c += melE[n] * dct[k][n]
                out[t][k - 1] = c
            }
            out[t][12] = ln(e + 1.0).toFloat()
        }
        // Normalisation moyenne / variance par énoncé (insensible au volume et au micro)
        for (d in 0 until NCEP) {
            var mean = 0f
            for (t in 0 until nF) mean += out[t][d]
            mean /= nF
            var v = 0f
            for (t in 0 until nF) { val x = out[t][d] - mean; v += x * x }
            val sd = sqrt(v / nF).coerceAtLeast(1e-3f)
            for (t in 0 until nF) out[t][d] = (out[t][d] - mean) / sd
        }
        return out
    }
}

/** Comparaison de deux empreintes en tolérant les différences de vitesse (DTW). Plus petit = plus proche. */
object Dtw {
    private fun ed(x: FloatArray, y: FloatArray): Float {
        var s = 0f
        for (i in x.indices) { val d = x[i] - y[i]; s += d * d }
        return sqrt(s)
    }

    fun dist(a: Array<FloatArray>, b: Array<FloatArray>): Float {
        val n = a.size
        val m = b.size
        if (n == 0 || m == 0) return 1e9f
        val ratio = n.toFloat() / m
        if (ratio < 0.55f || ratio > 1.8f) return 1e9f
        val band = max(abs(n - m), max(n, m) / 4) + 3
        val inf = 1e30f
        var prev = FloatArray(m + 1) { inf }
        var cur = FloatArray(m + 1) { inf }
        prev[0] = 0f
        for (i in 1..n) {
            java.util.Arrays.fill(cur, inf)
            val jc = (i.toLong() * m / n).toInt()
            val j0 = max(1, jc - band)
            val j1 = min(m, jc + band)
            for (j in j0..j1) {
                val d = ed(a[i - 1], b[j - 1])
                cur[j] = min(prev[j - 1] + 2f * d, min(prev[j] + d, cur[j - 1] + d))
            }
            val t = prev; prev = cur; cur = t
        }
        val r = prev[m]
        return if (r > 1e20f) 1e9f else r / (n + m)
    }
}

/** Découpe le flux micro en énoncés (silence / parole) et calcule leur empreinte. */
class VoiceWake {
    class Utt(val feat: Array<FloatArray>, val ms: Int)

    private val pre = ArrayDeque<ShortArray>()
    private val buf = ShortArray(16000 * 4)
    private var len = 0
    private var inSpeech = false
    private var quiet = 0
    private var floor = 0f

    fun reset() {
        pre.clear()
        len = 0
        inSpeech = false
        quiet = 0
    }

    private fun append(c: ShortArray, k: Int) {
        if (len + k > buf.size) return
        System.arraycopy(c, 0, buf, len, k)
        len += k
    }

    /** Appelé toutes les 100 ms (déjà amplifié). Renvoie un énoncé terminé, ou null. */
    fun feed(b: ShortArray, n: Int): Utt? {
        var s = 0.0
        for (i in 0 until n) s += b[i].toDouble() * b[i]
        val rms = sqrt(s / n).toFloat()
        if (floor == 0f) floor = rms.coerceAtLeast(50f)
        val startThr = max(floor * 2.8f, 400f)
        val endThr = max(floor * 1.8f, 250f)

        if (!inSpeech) {
            pre.addLast(b.copyOf(n))
            if (pre.size > 3) pre.removeFirst()
            if (rms > startThr) {
                inSpeech = true
                quiet = 0
                len = 0
                for (c in pre) append(c, c.size)
                pre.clear()
            } else {
                floor = floor * 0.97f + rms * 0.03f
            }
            return null
        }

        append(b, n)
        if (rms < endThr) quiet++ else quiet = 0
        val tooLong = len > 16000 * 7 / 2
        if (quiet >= 5 || tooLong) {
            inSpeech = false
            val keep = (len - max(quiet - 1, 0) * 1600).coerceAtLeast(0)
            val wasLong = tooLong && quiet < 5
            len = 0
            quiet = 0
            if (wasLong || keep < 5600) return null
            val f = Mfcc.compute(buf, keep)
            if (f.isEmpty()) return null
            return Utt(f, keep / 16)
        }
        return null
    }
}

/** Gabarits de ta voix, stockés sur le téléphone. */
object VoiceStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "voice_templates.bin")

    fun exists(ctx: Context) = file(ctx).exists()

    fun clear(ctx: Context) { file(ctx).delete() }

    fun save(ctx: Context, t: List<Array<FloatArray>>) {
        DataOutputStream(BufferedOutputStream(FileOutputStream(file(ctx)))).use { o ->
            o.writeInt(t.size)
            for (m in t) {
                o.writeInt(m.size)
                o.writeInt(if (m.isEmpty()) 0 else m[0].size)
                for (r in m) for (v in r) o.writeFloat(v)
            }
        }
    }

    fun load(ctx: Context): List<Array<FloatArray>> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        DataInputStream(BufferedInputStream(FileInputStream(f))).use { i ->
            val n = i.readInt()
            val out = ArrayList<Array<FloatArray>>()
            repeat(n) {
                val frames = i.readInt()
                val dims = i.readInt()
                out.add(Array(frames) { FloatArray(dims) { i.readFloat() } })
            }
            return out
        }
    }

    /** Distance moyenne aux deux gabarits les plus proches (skip = gabarit à ignorer, pour le calibrage). */
    fun score(f: Array<FloatArray>, t: List<Array<FloatArray>>, skip: Int = -1): Float {
        val ds = ArrayList<Float>()
        for ((i, m) in t.withIndex()) if (i != skip) ds.add(Dtw.dist(f, m))
        if (ds.isEmpty()) return 1e9f
        ds.sort()
        return if (ds.size >= 2) (ds[0] + ds[1]) / 2f else ds[0]
    }
}
