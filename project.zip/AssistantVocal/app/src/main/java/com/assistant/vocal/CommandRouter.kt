package com.assistant.vocal

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.media.AudioManager
import android.view.KeyEvent

/**
 * Transforme une phrase en action. Renvoie null si tout s'est bien passé, sinon un message d'erreur.
 * Les phrases sont comprises de façon souple : mots parasites retirés, tournures variées acceptées.
 * On peut enchaîner avec « puis ».
 */
class CommandRouter(private val ctx: Context) {

    var onSpeak: ((String) -> Unit)? = null

    /** Dernier élément visé : permet « clique dessus » après avoir remonté / descendu à la main. */
    private var lastQuery = ""

    private val help = "Je sais ouvrir une application et naviguer dedans, défiler, remonter tout en haut " +
        "ou descendre tout en bas, cliquer sur un élément en disant son nom, ouvrir une liste de lecture, " +
        "écrire et envoyer un message, lancer une musique, la mettre en boucle, et régler le volume. " +
        "Pour me fermer, dis : c'est fini."

    // Ce que tu dis -> mots cherchés dans le nom des applis installées (à compléter à ta guise)
    private val aliases = mapOf(
        "musique" to listOf("music", "musique", "spotify", "deezer"),
        "messages" to listOf("messages", "message"),
        "sms" to listOf("messages"),
        "appareil photo" to listOf("appareil photo", "camera"),
        "camera" to listOf("appareil photo", "camera"),
        "parametres" to listOf("parametres", "settings"),
        "reglages" to listOf("parametres", "settings"),
        "telephone" to listOf("telephone", "phone"),
        "calculatrice" to listOf("calculatrice", "calculator"),
        "horloge" to listOf("horloge", "clock"),
        "galerie" to listOf("galerie", "gallery"),
        "navigateur" to listOf("chrome", "internet", "firefox"),
        "carte" to listOf("maps", "cartes"),
        "mail" to listOf("gmail", "mail", "outlook"),
        "what s app" to listOf("whatsapp"),
        "whats app" to listOf("whatsapp"),
        "watsap" to listOf("whatsapp")
    )

    // Boutons d'appli décrits par leur FONCTION (souvent de simples icônes, nommées en anglais ou cachées)
    private val sem = mapOf(
        "play" to listOf("play", "lecture", "lire", "jouer", "reprendre", "resume", "ecouter"),
        "pause" to listOf("pause", "mettre en pause"),
        "next" to listOf("suivant", "suivante", "next", "piste suivante", "skip next", "passer au suivant"),
        "prev" to listOf("precedent", "precedente", "previous", "piste precedente", "prev"),
        "loop" to listOf("repeter", "repeat", "boucle", "loop", "repetition", "repeat all", "repeat one"),
        "shuffle" to listOf("aleatoire", "shuffle", "melanger", "lecture aleatoire"),
        "voice" to listOf("message vocal", "voice message", "voice note", "vocal", "micro", "microphone", "enregistrer", "record", "dictaphone"),
        "attach" to listOf("joindre", "pieces jointes", "piece jointe", "attach", "attachment"),
        "gallery" to listOf("galerie", "gallery", "photos et videos", "photos", "images"),
        "camera" to listOf("appareil photo", "camera"),
        "doc" to listOf("document", "fichier", "file"),
        "loc" to listOf("position", "localisation", "location"),
        "send" to listOf("envoyer", "send")
    )

    private fun press(key: String): Boolean {
        val a = AssistantAccessibilityService.instance ?: return false
        return clickAny(a, sem.getValue(key), false)
    }

    /** Touche l'icône à l'écran si elle existe, sinon envoie la touche média du système. */
    private fun mediaOr(key: String, code: Int): String? {
        if (press(key)) return null
        media(code)
        return null
    }

    // Éléments d'écran qui portent plusieurs noms possibles
    private val clickAliases = mapOf("moi" to listOf("moi", "vous"))

    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val chain = Regex("\\s+(puis|ensuite|et ensuite|et apres|apres ca)\\s+")
    private val prep = Regex("^(dans|sur|vers|a|au|aux|en|chez) ")
    private val art = Regex("^(le|la|les|l|un|une|mon|ma|mes|du|de la|de|des|d) ")
    private val appw = Regex("^(application|appli|app) ")
    private val classw = Regex("^(playlist|liste de lecture|contact|conversation|discussion|onglet|bouton|dossier|album|titre|chanson|rubrique|menu|section) ")

    private val click = "(clique|cliquer|appuie|appuyer|appuis|touche|toucher|selectionne|choisis|choisir|presse|tape sur)"
    private val open = "(ouvre|ouvrir|lance|lancer|demarre|demarrer|va|vas|aller|entre|rentre|affiche|montre|joue|ecoute)"

    /** Mots parasites retirés au DÉBUT de chaque ordre (jamais dans le texte d'un message). */
    private val fillers = listOf(
        "c'est la", "c'est ici", "d'accord", "s'il te plait", "essaie de", "essaye de", "essayer de",
        "est ce que tu peux", "tu peux", "tu pourrais", "peux tu", "pourrais tu",
        "je voudrais que tu", "je veux que tu", "j'aimerais que tu", "je voudrais", "je veux", "j'aimerais",
        "du coup", "en fait", "voila", "genre", "tu vois", "maintenant", "alors", "donc",
        "euh", "heu", "hum", "ben", "bah", "bon", "ok", "okay", "oui", "ouais", "non", "et", "puis", "ensuite", "la", "ici"
    ).sortedByDescending { it.length }

    fun execute(raw: String): String? {
        var o = raw.trim()
            .replace(Regex("(['’])\\s+"), "'").replace("’", "'")
            .replace("-", " ").replace(Regex("\\s+"), " ")
        if (o.isEmpty()) return null
        val f = Txt.fold(o)
        if (f.length != o.length) o = f
        val segs = ArrayList<Pair<String, String>>()
        var last = 0
        for (m in chain.findAll(f)) {
            segs.add(o.substring(last, m.range.first) to f.substring(last, m.range.first))
            last = m.range.last + 1
        }
        segs.add(o.substring(last) to f.substring(last))
        var first = true
        for (s in segs) {
            val (so, sf) = clean(s.first, s.second)
            if (sf.isEmpty()) continue
            if (!first) Thread.sleep(1500)
            first = false
            val err = single(so, sf)
            if (err != null) return err
        }
        return null
    }

    /** Retire les mots parasites au début et la politesse à la fin (o et f restent alignés). */
    private fun clean(o0: String, f0: String): Pair<String, String> {
        var o = o0.trim()
        var f = f0.trim()
        var again = true
        while (again && f.isNotEmpty()) {
            again = false
            for (w in fillers) {
                if (f == w) { o = ""; f = ""; break }
                if (f.startsWith("$w ")) {
                    val k = w.length + 1
                    o = o.substring(k).trim()
                    f = f.substring(k).trim()
                    again = true
                    break
                }
            }
        }
        val tail = Regex(" (s'il te plait|s'il vous plait|stp|merci)$").find(f)
        if (tail != null) {
            o = o.substring(0, tail.range.first).trim()
            f = f.substring(0, tail.range.first).trim()
        }
        return o to f
    }

    private fun act(err: String? = null, block: (AssistantAccessibilityService) -> Boolean): String? {
        val a = AssistantAccessibilityService.instance
            ?: return "Le service d'accessibilité n'est pas actif"
        return try {
            if (block(a)) null else (err ?: "Je n'ai pas réussi")
        } catch (t: Throwable) {
            "Erreur évitée : ${t.javaClass.simpleName}"
        }
    }

    private val vous = mapOf(
        "ouvrez" to "ouvre", "lancez" to "lance", "cliquez" to "clique", "appuyez" to "appuie", "ecrivez" to "ecris",
        "envoyez" to "envoie", "mettez" to "mets", "cherchez" to "cherche", "tapez" to "tape", "descendez" to "descends",
        "montez" to "monte", "choisissez" to "choisis", "selectionnez" to "selectionne", "affichez" to "affiche",
        "montrez" to "montre", "allez" to "va", "jouez" to "joue", "ecoutez" to "ecoute", "passez" to "passe",
        "revenez" to "reviens", "retournez" to "retourne", "partagez" to "partage", "joignez" to "joins",
        "enregistrez" to "enregistre", "dites" to "dis", "repondez" to "reponds", "demarrez" to "demarre",
        "ouvres" to "ouvre", "lances" to "lance", "ouvrir" to "ouvre"
    )

    /** Remplace le premier mot « -ez » par sa forme simple, de la même façon dans le texte et sa version pliée. */
    private fun simplifyVerb(o: String, f: String): Pair<String, String> {
        val sf = f.indexOf(' ')
        val so = o.indexOf(' ')
        val first = if (sf < 0) f else f.substring(0, sf)
        val r = vous[first] ?: return o to f
        val o2 = r + (if (so < 0) "" else o.substring(so))
        val f2 = r + (if (sf < 0) "" else f.substring(sf))
        return o2 to f2
    }

    private fun single(o0: String, f0: String): String? {
        val (o, f) = simplifyVerb(o0, f0)
        val e = singleRules(o, f) ?: return null
        val soft = e.startsWith("Je n'ai pas compris") || e.startsWith("Je ne trouve pas") || e.startsWith("Je n'ai pas réussi")
        // Un seul mot (ex. « ouvrez ») : phrase coupée, le cerveau ne ferait qu'inventer
        val enoughWords = Txt.norm(o).split(" ").count { it.isNotEmpty() } >= 2
        if (soft && enoughWords && Brain.enabled(ctx)) {
            val r = brainRun(o)
            if (r == null) return null
            return r
        }
        return e
    }

    /** Dernier recours : le petit modèle de langage choisit quoi toucher à l'écran. */
    private fun brainRun(utter: String): String? {
        val a = AssistantAccessibilityService.instance ?: return "Le service d'accessibilité n'est pas actif"
        val items = a.screenItems(40)
        val d = Brain.decide(ctx, utter, items.map { it.label }) ?: return "Le cerveau n'a pas répondu"
        Status.log("Cerveau : ${d.raw}")
        try {
            when (d.a) {
                "click" -> {
                    val it = items.getOrNull(d.n - 1) ?: return "Le cerveau a choisi un élément qui n'existe pas"
                    lastQuery = Txt.norm(it.label)
                    return if (a.click(it.node)) null else "Je n'ai pas réussi"
                }
                "type" -> return if (d.t.isNotBlank() && a.setText(d.t)) null else "Je ne trouve pas de champ de texte"
                "scroll" -> { a.scroll(d.d != "up"); return null }
                "open" -> return if (openApp(Txt.norm(d.t))) null else "Je ne trouve pas l'appli ${d.t}"
                "back" -> { a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); return null }
            }
        } catch (t: Throwable) {
            return "Erreur évitée : ${t.javaClass.simpleName}"
        }
        return "Je n'ai pas compris"
    }

    private fun singleRules(o: String, f: String): String? {
        fun rx(p: String) = Regex(p).find(f)
        fun arg(m: MatchResult, g: Int) = o.substring(m.groups[g]!!.range).trim()
        fun glob(a: Int) = act { it.performGlobalAction(a) }

        // --- Aide : « qu'est-ce que tu sais faire » ---
        if (rx("(qu'est ce que tu (sais|peux) faire|que sais tu faire|que peux tu faire|tes fonctions|tes fonctionnalites|a quoi tu sers|tu sais faire quoi)") != null) {
            onSpeak?.invoke(help)
            return null
        }

        // --- Navigation système ---
        if (rx("^(retour|reviens|retourne|retour arriere|en arriere|(va|reviens|retourne) en arriere)$") != null)
            return glob(AccessibilityService.GLOBAL_ACTION_BACK)
        if (rx("^(accueil|ecran d.?accueil|maison|(va|reviens|retourne|rentre) (a|sur|vers) l.?(accueil|ecran d.?accueil))$") != null)
            return glob(AccessibilityService.GLOBAL_ACTION_HOME)
        if (rx("^((ouvre|affiche|montre) )?(les )?(applications? recentes?|apps? recentes?|recentes?|multitache)$") != null)
            return glob(AccessibilityService.GLOBAL_ACTION_RECENTS)
        if (rx("^((ouvre|affiche|montre|baisse) )?(les |la barre de )?notifications?$") != null)
            return glob(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        if (rx("^((ouvre|affiche|montre) )?(les )?(reglages|parametres) rapides$|^panneau rapide$") != null)
            return glob(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        if (rx("^(verrouille|bloque)( l.?ecran| le telephone)?$") != null)
            return glob(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        if (rx("^(capture( d.?ecran)?|screenshot|prends? une capture( d.?ecran)?|photo d.?ecran)$") != null)
            return glob(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)

        // --- Volume ---
        if (f.split(" ").size <= 6 && rx("\\b(volume|le son)\\b") != null) {
            val down = rx("\\b(moins|baisse|diminue|bas|doucement|faible)\\b") != null
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (down) AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI
            )
            return null
        }
        if (rx("^plus fort$") != null) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return null
        }
        if (rx("^(moins fort|plus doucement)$") != null) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return null
        }

        // --- Musique : d'abord les boutons à l'écran, sinon les touches média du système ---
        if (rx("^(pause|mets? en pause|mets? pause|met la en pause|arrete la musique|arrete|stop|stoppe)( la musique| la chanson| la lecture)?$") != null)
            return mediaOr("pause", KeyEvent.KEYCODE_MEDIA_PAUSE)
        if (rx("^(lecture|play|joue|reprends|reprends la lecture|relance|demarre|(lance|mets?|joue|demarre|remets?|relance|reprends)( la| ma| de la| une)? (musique|lecture|chanson|playlist|liste de lecture|titre|morceau)( en cours)?)$") != null)
            return mediaOr("play", KeyEvent.KEYCODE_MEDIA_PLAY)
        if (f.split(" ").size <= 8 && rx("\\b(suivant|suivante|prochaine|prochain|next)\\b") != null && rx("^$click ") == null)
            return mediaOr("next", KeyEvent.KEYCODE_MEDIA_NEXT)
        if (rx("^(passe|saute|change)( la| de)?( chanson| musique| titre| piste)?$") != null)
            return mediaOr("next", KeyEvent.KEYCODE_MEDIA_NEXT)
        if (f.split(" ").size <= 8 && rx("\\b(precedent|precedente|previous)\\b") != null && rx("^$click ") == null)
            return mediaOr("prev", KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        if (rx("^(.* )?(aleatoire|shuffle|melange)( .*)?$") != null && f.split(" ").size <= 6)
            return act("Je ne trouve pas le mode aléatoire") { clickAny(it, sem.getValue("shuffle"), false) }

        // --- Message vocal : on garde le doigt sur le micro quelques secondes, puis on relâche ---
        rx("^(?:enregistre|enregistrer|fais|envoie|envoyer|commence|lance|prends|laisse)(?: moi)?(?: un| une| le| mon)?(?: message)?(?: vocal| audio)(?: (.*))?$")?.let { m ->
            val tail = if (m.groups[1] != null) arg(m, 1) else ""
            val secs = Regex("(\\d+) ?(secondes?|s)\\b").find(Txt.fold(tail))?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(2, 60) ?: 10
            return act("Je ne trouve pas le micro") { a ->
                val n = sem.getValue("voice").firstNotNullOfOrNull { a.findNode(it) } ?: return@act false
                a.holdFor(n, secs)
                true
            }
        }

        // --- Pièces jointes : photo, galerie, appareil photo, document, position ---
        rx("^(?:envoie|envoi|envoyer|partage|partager|joins|joindre|ajoute|ajouter|mets|mettre)(?: lui| leur)?(?: une| un| la| le| des| mon| ma)? ?(photo|image|video|fichier|document|position|localisation|galerie|camera|appareil photo)s?(?: .*)?$")?.let { m ->
            val kind = Txt.norm(arg(m, 1))
            val second = when (kind) {
                "camera", "appareil photo" -> "camera"
                "fichier", "document" -> "doc"
                "position", "localisation" -> "loc"
                else -> "gallery"
            }
            return act("Je ne trouve pas le bouton pour joindre") { a ->
                if (!clickAny(a, sem.getValue("attach"), false)) return@act false
                Thread.sleep(900)
                clickAny(a, sem.getValue(second), false)
                true
            }
        }

        // --- Défilement : tout en haut / tout en bas, puis petit défilement ---
        if (rx("^((remonte|monte|retourne|reviens|va) )?(tout )?((en|au|vers le) )?haut( de la page| de la liste| de l.?ecran)?$|^(remonte|monte|retourne|reviens) (tout )?(en|au|vers le) haut\\b.*$") != null)
            return act { it.scrollEdge(true) }
        if (rx("^((descends|descend|va|retourne) )?(tout )?((en|au|vers le|jusqu'en|jusqu'au|jusqu en|jusqu au) )?bas( de la page| de la liste| de l.?ecran)?$|^(descends|descend) (tout )?(en|au|vers le|jusqu'en|jusqu'au) bas\\b.*$") != null)
            return act { it.scrollEdge(false) }
        if (rx("^(remonte|monte|remonte un peu|monte un peu|monte la page|remonte la page|vers le haut|defile vers le haut|plus haut|un peu plus haut)$") != null)
            return act { it.scroll(false); true }
        if (rx("^(descends?|descends un peu|descend un peu|descends encore|descends la page|defile|defile vers le bas|defile encore|scroll|scrolle|vers le bas|plus bas|un peu plus bas|fais defiler)$") != null)
            return act { it.scroll(true); true }

        // --- « clique dessus » : on reprend le dernier élément visé ---
        if (rx("^$click (dessus|la|ici|sur ca|sur celui la|sur celui ci|sur cet element|sur lui|sur elle)$|^(ouvre|ouvrir) (dessus|la|ici)$|^dessus$") != null) {
            if (lastQuery.isEmpty()) return "Je ne sais pas sur quoi cliquer"
            val qs = clickList(lastQuery)
            return act("Je ne trouve pas $lastQuery") { clickAny(it, qs, false) }
        }

        // --- Boucle / répétition ---
        if (rx("^(.* )?(en boucle|la boucle|repetition|repeter)$|^boucle$") != null)
            return act("Je ne trouve pas le bouton de répétition") {
                clickAny(it, sem.getValue("loop"), false)
            }

        // --- « envoie un message écrit salut » : on écrit seulement « salut » ---
        rx("^(envoie|envoi|envoyer|ecris|ecrit|ecrire|tape|dicte|saisis|dis|reponds|repondre|poste)( lui| leur| moi| y)?( un| une| le| mon| ce)? ?(message|sms|texto|mot)( ecrit| texte| texto| suivant)?( qui dit que| qui dit| disant| que)? (.+)$")?.let { m ->
            val t = arg(m, 7)
            val send = Txt.norm(arg(m, 1)) in listOf("envoie", "envoi", "envoyer", "poste")
            return act("Je ne trouve pas de champ de texte") { a ->
                if (!a.setText(t)) return@act false
                if (send) { Thread.sleep(600); clickAny(a, sem.getValue("send"), false) }
                true
            }
        }

        // --- Envoyer (avec ou sans texte) ---
        if (rx("^(envoie|envoi|envoyer|poste|valide|valider)( lui| leur)?( le message| le| la| ca| cela| maintenant| tout de suite)?$") != null)
            return act("Je ne trouve pas le bouton envoyer") { clickAny(it, listOf("envoyer", "send"), false) }
        rx("^(envoie|envoi|envoyer|poste)( lui| leur)? (.+)$")?.let { m ->
            val t = arg(m, 3)
            return act("Je ne trouve pas de champ de texte") { a ->
                if (!a.setText(t)) return@act false
                Thread.sleep(600)
                clickAny(a, listOf("envoyer", "send"), false)
            }
        }

        // --- Écrire : « écris test », « écris-lui test », « tape juste test » ---
        rx("^(ecris|ecrit|ecrire|tape|dicte|saisis|dis|reponds|repondre)( lui| leur| y| moi| ca)?( juste| simplement| seulement)? (.+)$")?.let { m ->
            val t = arg(m, 4)
            return act("Je ne trouve pas de champ de texte") { it.setText(t) }
        }

        // --- Recherche dans l'appli : « cherche X », « lance la recherche sur le contact X » ---
        rx("^(?:(?:lance|fais|ouvre|utilise|lancer|faire) (?:la |une |ma )?recherche|(?:cherche|chercher|recherche|rechercher|trouve|trouver)(?: moi)?)(?: (.+))?$")?.let { m ->
            val t = strip(Txt.norm(arg(m, 1)), prep, art, appw, classw)
            if (t.isEmpty()) return "Je n'ai pas compris quoi chercher"
            lastQuery = t
            return act("Je ne trouve pas la recherche") { a ->
                if (!(a.clickText("rechercher") || a.clickText("search") || a.clickText("recherche"))) return@act false
                Thread.sleep(900)
                if (!a.setText(t)) return@act false
                Thread.sleep(1300)
                true
            }
        }

        // --- Cliquer sur un élément par son nom ---
        rx("^$click (.+)$")?.let { m -> return clickTarget(arg(m, 2), false) }

        // --- Ouvrir une appli, ou aller sur un élément (contact, playlist…) ---
        rx("^$open (.+)$")?.let { m ->
            val playVerb = Txt.norm(arg(m, 1)) in listOf("lance", "lancer", "joue", "ecoute", "demarre", "demarrer")
            return openOrClick(arg(m, 2), playVerb)
        }

        return "Je n'ai pas compris"
    }

    private fun strip(s0: String, vararg rs: Regex): String {
        var s = s0.trim()
        var changed = true
        while (changed) {
            changed = false
            for (r in rs) {
                val n = r.replace(s, "").trim()
                if (n != s) { s = n; changed = true }
            }
        }
        return s
    }

    private fun clickList(t: String): List<String> = clickAliases[t] ?: listOf(t)

    private fun clickTarget(target: String, allowSearch: Boolean): String? {
        val t = strip(Txt.norm(target), prep, art, appw, classw)
        if (t.isEmpty()) return "Je n'ai pas compris"
        lastQuery = t
        return act("Je ne trouve pas $t") { a -> findAndClick(a, t, allowSearch) }
    }

    /** 1) à l'écran sans défiler, 2) via la recherche de l'appli (si permis), 3) en défilant. */
    private fun findAndClick(a: AssistantAccessibilityService, t: String, allowSearch: Boolean): Boolean {
        val qs = clickList(t)
        if (qs.any { a.clickText(it) }) return true
        if (allowSearch && searchThenClick(a, qs.first())) return true
        return clickAny(a, qs, true)
    }

    private fun openOrClick(target: String, play: Boolean = false): String? {
        val n = Txt.norm(target)
        val appT = strip(n, prep, art, appw)
        if (appT.length >= 3 && openApp(appT)) return null
        val clickT = strip(n, prep, art, appw, classw)
        if (clickT.isEmpty()) return "Je n'ai pas compris"
        lastQuery = clickT
        val hasClass = classw.containsMatchIn(strip(n, prep, art, appw) + " ")
        return act("Je ne trouve pas $clickT") { a ->
            val ok = findAndClick(a, clickT, true)
            if (ok && play && hasClass) { Thread.sleep(1400); clickAny(a, sem.getValue("play"), false) }
            ok
        }
    }

    private fun openApp(q: String): Boolean {
        val pm = ctx.packageManager
        val apps: List<ResolveInfo> =
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val words = aliases[q] ?: listOf(q)
        var best: ResolveInfo? = null
        var bestScore = 0
        for (ri in apps) {
            val label = Txt.norm(ri.loadLabel(pm).toString())
            for (w in words) {
                val sc = when {
                    label == w -> 100
                    w.length >= 3 && label.contains(w) -> 60 - minOf(label.length - w.length, 40)
                    else -> 0
                }
                if (sc > bestScore) { bestScore = sc; best = ri }
            }
        }
        val b = best ?: return false
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(b.activityInfo.packageName, b.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val starter: Context = AssistantAccessibilityService.instance ?: ctx
        return try { starter.startActivity(i); Thread.sleep(1200); true } catch (_: Throwable) { false }
    }

    private fun clickAny(a: AssistantAccessibilityService, qs: List<String>, scroll: Boolean): Boolean {
        val rounds = if (scroll) 4 else 2
        for (r in 0 until rounds) {
            for (q in qs) if (a.clickText(q)) return true
            Thread.sleep(600)
            if (scroll && r >= 1) { a.scroll(true); Thread.sleep(700) }
        }
        return false
    }

    /** Ouvre la recherche de l'appli, tape le nom, puis clique sur le résultat. */
    private fun searchThenClick(a: AssistantAccessibilityService, q: String): Boolean {
        val opened = a.clickText("rechercher") || a.clickText("search") || a.clickText("recherche")
        if (!opened) return false
        Thread.sleep(900)
        if (!a.setText(q)) return false
        Thread.sleep(1300)
        repeat(3) {
            if (a.clickText(q)) return true
            Thread.sleep(600)
        }
        return false
    }

    private fun media(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
