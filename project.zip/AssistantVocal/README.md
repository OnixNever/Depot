# Assistant vocal (Android, 100 % local)

Compilation : glisse ce dossier dans APK Builder (JDK 17, Gradle 8.7+).
Pas de gradlew fourni : le workflow doit utiliser `gradle assembleDebug`
ou générer le wrapper (`gradle wrapper --gradle-version 8.7`).

Premier lancement :
1. Installe l'APK, ouvre l'appli.
2. Lance Shizuku, puis dans l'appli : « Configuration automatique (Shizuku) ».
3. « Télécharger le modèle vocal » (une seule fois, ~40 Mo) ou « Importer un modèle (.zip) ».
4. « Calibrage vocal », puis « Démarrer l'écoute ».
Shizuku n'est ensuite plus nécessaire.

## Version 0.3.0 — cerveau local
- Bouton « Installer le cerveau » : télécharge une fois Qwen2.5-1.5B (≈1,6 Go, format MediaPipe, licence Apache 2.0).
  Il ne sert qu'en dernier recours, quand les règles simples ne comprennent pas ; tout reste sur le téléphone.
- Boutons sans texte : l'appli lit aussi les descriptions cachées et identifiants des boutons (play, next, voice message…).
- Noms de titres étrangers : comparaison par le son quand l'orthographe ne correspond pas.
- Journal des derniers événements sur l'écran principal.
